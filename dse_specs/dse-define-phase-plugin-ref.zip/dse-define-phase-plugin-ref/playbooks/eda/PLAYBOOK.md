---
id: eda
name: Exploratory Data Analysis
description: Stub playbook for EDA subgraph
analytical_frame: what_happened
trigger_conditions: profile/segment patterns
---

See dse-task-registry.md Layer 4 for full subgraph definition.
