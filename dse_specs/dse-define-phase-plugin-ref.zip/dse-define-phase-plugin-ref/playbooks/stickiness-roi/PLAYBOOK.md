---
id: stickiness_roi
name: Stickiness ROI Analysis
description: Stub playbook for Stickiness ROI subgraph
analytical_frame: what_it_was_worth
trigger_conditions: profile/compare/predict with retention/repeat/lifetime language
---

See dse-task-registry.md Layer 4 for full subgraph definition.
