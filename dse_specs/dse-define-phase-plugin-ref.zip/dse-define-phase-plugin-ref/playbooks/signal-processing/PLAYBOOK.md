---
id: signal_processing
name: Behavioral Signal Processing
description: Stub playbook for Signal Processing subgraph
analytical_frame: what_happened
trigger_conditions: explain/predict with signal/indicator/early warning language
---

See dse-task-registry.md Layer 4 for full subgraph definition.
