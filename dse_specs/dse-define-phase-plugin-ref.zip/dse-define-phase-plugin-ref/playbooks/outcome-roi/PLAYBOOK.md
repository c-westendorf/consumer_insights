---
id: outcome_roi
name: Outcome ROI Analysis
description: Stub playbook for Outcome ROI subgraph
analytical_frame: what_it_was_worth
trigger_conditions: compare/explain with value/roi/impact language
---

See dse-task-registry.md Layer 4 for full subgraph definition.
