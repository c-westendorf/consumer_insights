---
id: hypothesis_validation
name: Hypothesis Validation
description: Stub playbook for Hypothesis Validation subgraph
analytical_frame: why_it_happened
trigger_conditions: explain/compare with why/driver/cause language
---

See dse-task-registry.md Layer 4 for full subgraph definition.
