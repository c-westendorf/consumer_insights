---
id: sampling_playbook
name: Statistical Sampling
description: Stub playbook for Statistical Sampling subgraph
analytical_frame: methodology
trigger_conditions: population > threshold or matched comparison needed
---

See dse-task-registry.md Layer 4 for full subgraph definition.
