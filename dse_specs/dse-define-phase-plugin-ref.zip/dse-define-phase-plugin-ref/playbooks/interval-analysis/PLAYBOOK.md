---
id: interval_analysis_playbook
name: Interval Analysis
description: Stub playbook for Interval Analysis subgraph
analytical_frame: what_happened
trigger_conditions: profile/explain with over time/trajectory/lifecycle language
---

See dse-task-registry.md Layer 4 for full subgraph definition.
