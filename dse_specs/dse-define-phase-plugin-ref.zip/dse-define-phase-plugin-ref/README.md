# DSE Define Phase Plugin

The Data Scientist Engine (DSE) Define Phase plugin for Claude Code. Transforms business questions into validated, dependency-aware analytical plans through two coordinating agents, 41+ skills, and a governance layer of hooks and decision logging.

## Installation

```bash
claude plugin install dse-define-phase
```

## Commands

| Command | Purpose |
|---------|---------|
| `/scope` | Start scoping a business question through CGF-governed conversation |
| `/plan` | Generate a project plan from an approved scope artifact |
| `/dse-status` | Show current session state (scope, plan, decision log) |

## Architecture

```
Business Question → /scope → scope_artifact.json → /plan → plan_artifact.json → Analyze Phase
                     ↑                                ↑
                  Scope Agent                     Plan Agent
                  (4 skills)                      (4 skills)
                     ↑                                ↑
              Decision Log ←──────────────────── Decision Log
              (≥3 options per decision, institutional knowledge)
```

**Human-in-the-loop at every transition:** The user approves scope completion, handoff to plan, and plan approval.

## Directory Layout

```
dse-define-phase/
├── .claude-plugin/plugin.json       Plugin manifest
├── agents/                          Agent definitions (2)
│   ├── scope-agent.md               Interactive scoping agent
│   └── plan-agent.md                Generative planning agent
├── skills/                          Skills (41 total)
│   ├── _shared-references/          Shared knowledge files (13 references)
│   ├── intent-classification/       ┐
│   ├── scope-extraction/            │ Scope Agent skills (4)
│   ├── completeness-validation/     │
│   ├── scope-formatting/            ┘
│   ├── task-decomposition/          ┐
│   ├── dependency-resolution/       │ Plan Agent skills (4)
│   ├── budget-allocation/           │
│   ├── plan-formatting/             ┘
│   ├── eda-comprehensive/           ┐
│   ├── feature-engineering/         │
│   ├── metric-computation/          │ Analyze Phase skills (26+)
│   ├── statistical-comparison/      │ Referenced by playbooks,
│   ├── cohort-extraction/           │ executed in Analyze phase
│   ├── ...                          ┘
│   ├── dse-skill-builder/           ┐ Meta skills
│   └── dse-skill-tester/            ┘
├── playbooks/                       Playbook subgraph templates (7)
│   ├── eda/                         Exploratory Data Analysis
│   ├── outcome-roi/                 Outcome ROI Analysis
│   ├── stickiness-roi/              Stickiness ROI Analysis
│   ├── interval-analysis/           Interval Analysis
│   ├── signal-processing/           Behavioral Signal Processing
│   ├── hypothesis-validation/       Hypothesis Validation
│   └── sampling/                    Statistical Sampling
├── commands/                        Slash commands (3)
│   ├── scope.md                     /scope
│   ├── plan.md                      /plan
│   └── dse-status.md                /dse-status
├── hooks/                           Governance hooks
│   ├── hooks.json                   Hook definitions (auto-loaded)
│   └── scripts/                     Hook implementation scripts
│       ├── artifact-guard.sh        Block writes to approved artifacts
│       ├── sql-interceptor.sh       Log queries, block destructive SQL
│       └── decision-log-gate.sh     Require decisions before planning
└── schemas/                         JSON Schema validation
    ├── scope_artifact.schema.json   Scope artifact schema
    ├── plan_artifact.schema.json    Plan artifact schema
    ├── decision_log.schema.json     Decision entry schema
    └── decision_log_artifact.schema.json  Decision log file schema
```

## Hooks (Governance Layer)

The plugin ships with three PreToolUse hooks that enforce governance automatically:

| Hook | Trigger | Behavior |
|------|---------|----------|
| **artifact-guard** | `Write\|Edit` on `*_artifact.json` | Blocks overwriting approved artifacts (checks for `approved_at` field) |
| **sql-interceptor** | `Bash` | Logs all commands to `audit/query_log.jsonl`; blocks destructive DDL/DML (DROP, DELETE, TRUNCATE, etc.) |
| **decision-log-gate** | `Agent` (plan-agent) | Blocks plan generation unless `decision_log.json` exists with ≥1 decision entry |

Hooks use `exit 2` to block and write reasons to stderr. See [Claude Code hooks documentation](https://code.claude.com/docs/en/hooks) for the hook lifecycle.

## Decision Logging

Every analytical fork point generates a decision log entry with:
- At least **3 options** evaluated (enforced by schema `minItems: 3`)
- **Pros and cons** for each option
- **Rationale** for the selected option
- **Institutional knowledge links** to prior decisions on similar questions

The decision log accumulates across sessions. When a new analysis matches a prior lifecycle stage + analytical pattern, the agent surfaces past decisions as recommendations.

## Recommended Permission Settings

Add to your project's `.claude/settings.local.json` for smoother operation:

```json
{
  "permissions": {
    "allow": [
      "Bash(ls:*)",
      "Bash(find:*)",
      "Bash(grep:*)",
      "Bash(curl:*)"
    ]
  }
}
```

## Artifacts

All artifacts are written to the **project directory**, not the plugin directory:

| Artifact | Created By | Notes |
|----------|-----------|-------|
| `scope_session.json` | Scope Agent | Transient session state |
| `scope_artifact.json` | Scope Agent | Immutable after approval |
| `plan_artifact.json` | Plan Agent | Immutable after approval |
| `decision_log.json` | Both agents | Append-only; accumulates institutional knowledge |
| `audit/query_log.jsonl` | sql-interceptor hook | All Bash commands logged |

## Related Documents

- [Define Phase Specification](dse-define-phase-spec-local-agent.md) — Full system specification
- [30/60/90 Day Roadmap](dse-30-60-90-roadmap.md) — Incremental shipping plan
- [Skill Blueprint](../skill-blueprint/BLUEPRINT.md) — Skill design principles
