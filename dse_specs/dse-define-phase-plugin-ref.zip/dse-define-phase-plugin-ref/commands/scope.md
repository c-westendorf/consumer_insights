---
description: Start scoping a business question through CGF-governed conversation
argument-hint: <business question>
allowed-tools: [Read, Write, Grep, Glob]
---

# /scope

Activates the scope-agent to transform a business question into a validated scope_artifact.json.

The user's business question: $ARGUMENTS

See `dse-define-phase-spec-local-agent.md` §1-2 for full workflow.
