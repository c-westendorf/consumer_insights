---
description: Generate a project plan from an approved scope artifact
allowed-tools: [Read, Write, Grep, Glob]
---

# /plan

Activates the plan-agent to consume scope_artifact.json and produce plan_artifact.json.

Precondition: scope_artifact.json must exist and be approved.

See `dse-define-phase-spec-local-agent.md` §3-4 for full workflow.
