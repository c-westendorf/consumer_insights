---
description: Show current DSE session state
allowed-tools: [Read, Grep, Glob]
---

# /dse-status

Report the current state of the DSE Define phase session by reading available artifacts
from the project directory.

## What to Check

Read these files (if they exist) and report their status:

### 1. Scope Session — `scope_session.json`
- **If missing:** "No active scope session. Run `/scope` to start."
- **If present:** Report status (classifying / disambiguating / validating / approved),
  lifecycle stage, analytical pattern, confidence score, disambiguation turns used,
  and any open questions.

### 2. Scope Artifact — `scope_artifact.json`
- **If missing:** "No approved scope yet."
- **If present:** Report scope_id, lifecycle stage, analytical pattern, population summary,
  metric name, timeframe, and approved_at timestamp.
- **If approved_at is set:** Mark as "APPROVED (immutable)"

### 3. Plan Artifact — `plan_artifact.json`
- **If missing:** "No plan generated yet. Run `/plan` after scope approval."
- **If present:** Report plan_id, total tasks, critical path length, estimated complexity,
  any skill gaps, and any scope warnings.
- **If approved_at is set:** Mark as "APPROVED (immutable)"

### 4. Decision Log — `decision_log.json`
- **If missing:** "No decisions logged yet. Decisions will be captured during `/scope`."
- **If present:** Report:
  - Total decisions logged
  - Breakdown by phase (scope vs. plan)
  - Last decision: context, selected option, rationale (abbreviated)
  - Most common tags across all decisions
  - Whether any decisions reference prior decisions (institutional knowledge links)

## Output Format

Present a clear status summary:

```
DSE Define Phase Status
═══════════════════════

Scope Session:  [status]
Scope Artifact: [APPROVED / IN PROGRESS / NOT STARTED]
Plan Artifact:  [APPROVED / IN PROGRESS / NOT STARTED]
Decision Log:   [N decisions (scope: X, plan: Y)]

[Details for each section as described above]
```

If all artifacts are approved, add:
```
✓ Define phase complete. Ready for handoff to Analyze phase.
```
