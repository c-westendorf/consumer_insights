# Assessment Report: causal-linkage-analysis

Skill under test: `.claude/skills/causal-linkage-analysis/SKILL.md`
Date: 2026-04-10
Tester: DSE Skill Tester (automated)
Blueprint version: skill-blueprint/BLUEPRINT.md

---

## Test Summary

| Category | Tests | Pass | Fail | Notes |
|---|---|---|---|---|
| A: Happy Path | 6 | 6 | 0 | All variance combinations produce valid terminal artifact |
| B: Variance Coverage | 9 | 9 | 0 | All dimensions have >=2 values with distinct behavior |
| C: Precondition Violations | 10 | 10 | 0 | All violations produce HALT as required |
| D: Edge Cases | 9 | 8 | 1 | D8/D9 loop behavior specified but loop artifact_id renewal not explicit in Step 4 |
| **Total** | **34** | **33** | **1** | |

---

## Per-Test Results

### Category A: Happy Path

| ID | Result | Notes |
|---|---|---|
| A1 | PASS | DiD + panel + standard: Step 1 validates parallel trends, Step 2 estimates beta3, Step 3 runs 2 checks. Terminal artifact written with all fields. |
| A2 | PASS | PSM + cross-sectional + standard: Propensity model fitted, overlap checked, 1:1 matching performed, bootstrap CI computed. 2 robustness checks. |
| A3 | PASS | IV + cross-sectional + comprehensive: First-stage F-stat checked, 2SLS estimated, 4+ robustness checks including subsample. |
| A4 | PASS | RDD + natural-experiment + standard: McCrary density test, local linear regression at cutoff, 2 robustness checks. |
| A5 | PASS | PSM + comprehensive: All standard checks plus subsample analysis at 50%/75%. |
| A6 | PASS | DiD + comprehensive: All standard checks plus different pre-treatment windows. |

### Category B: Variance Coverage

| ID | Result | Notes |
|---|---|---|
| B1 | PASS | DiD method path: assumptions = ["parallel_trends"], pre-treatment trend comparison logic specified. |
| B2 | PASS | PSM method path: assumptions = ["conditional_independence", "common_support"], propensity fitting and overlap check specified. |
| B3 | PASS | IV method path: assumptions = ["exclusion_restriction", "instrument_relevance"], first-stage F-stat threshold (10) specified. |
| B4 | PASS | RDD method path: assumptions = ["continuity_at_cutoff", "no_manipulation"], McCrary test specified. |
| B5 | PASS | Panel data structure routes to DiD per context classification logic. |
| B6 | PASS | Cross-sectional routes to PSM (default) or IV (if instrument available). |
| B7 | PASS | Natural experiment routes to RDD per context classification logic. |
| B8 | PASS | Standard robustness: placebo_test + alternative_specification = 2 checks. |
| B9 | PASS | Comprehensive robustness: 2 standard + subsample + method-specific = 4+ checks. |

### Category C: Precondition Violations

| ID | Result | Notes |
|---|---|---|
| C1 | PASS | HALT fires: Step 0 `load cohort.json` fails. Upstream validation block specifies assert for each input. |
| C2 | PASS | HALT fires: Step 0 `load feature_set.json; assert schema_version == "1.0"; assert data_ref not null` fails. |
| C3 | PASS | HALT fires: Step 0 `load hypothesis_result.json` fails. |
| C4 | PASS | HALT fires: Step 0 `load comparison_result.json` fails. |
| C5 | PASS | HALT fires: `assert schema_version == "1.0"` fails for cohort. |
| C6 | PASS | HALT fires: `assert schema_version == "1.0"` fails for feature_set. |
| C7 | PASS | HALT fires: `assert schema_version == "1.0"` fails for hypothesis_result. |
| C8 | PASS | HALT fires: `assert schema_version == "1.0"` fails for comparison_result. |
| C9 | PASS | HALT fires: `assert >=1 hypothesis with upgrade_recommendation == "requires_causal_linkage_analysis"` — explicit HALT message: "No hypotheses flagged for causal upgrade." |
| C10 | PASS | HALT fires: Edge case table specifies "Empty source / population_size == 0 / HALT Step 0". |

### Category D: Edge Cases

| ID | Result | Notes |
|---|---|---|
| D1 | PASS | Empty source: HALT Step 0 per edge case table. |
| D2 | PASS | Insufficient data for method: HALT with method-specific message per edge case table. |
| D3 | PASS | No instrument: HALT per "Insufficient data for method" edge case. |
| D4 | PASS | All robustness checks fail: WARN issued, causal_confidence downgraded to "observational". Postcondition explicitly allows this downgrade. |
| D5 | PASS | Weak instrument: WARN with F-stat value. Does not HALT -- appropriate since estimate is still produced with caveat. |
| D6 | PASS | No common support: HALT with explicit message per edge case table. |
| D7 | PASS | Parallel trends violated: WARN with "extreme caution" language. assumptions_validated = false. |
| D8 | CONDITIONAL PASS | Loop retry is declared (supports_loop: true, max 2 iterations, exit_conditions specified). However, Step 4 does not explicitly generate a NEW artifact_id per iteration as required by composition-rules.md section 4 loop rules. The `Generate artifact_id` instruction exists but does not explicitly state "new UUID per iteration." |
| D9 | PASS | Budget exhaustion (max 2 iterations) is specified in exit_conditions. Skill exits with best available estimate. |

---

## Terminal Artifact Validation (5 Envelope Fields)

| Field | Present | Value/Format | Verdict |
|---|---|---|---|
| `schema_version` | Yes | `"1.0"` | PASS |
| `skill_name` | Yes | `"causal-linkage-analysis"` | PASS |
| `timestamp` | Yes | ISO-8601 UTC format | PASS |
| `record_count` | Yes | Integer (example: 6148) | PASS |
| `artifact_id` | Yes | UUID format `{uuid}` | PASS |

**Envelope verdict:** PASS -- all 5 universal envelope fields present and correctly formatted.

**Skill-specific fields validated:**

| Field | Present | Required | Notes |
|---|---|---|---|
| `causal_claim` | Yes | Yes | Human-readable causal statement |
| `method_selected` | Yes | Yes | Maps to variance dimension |
| `method_selection_rationale` | Yes | Yes | Free text explaining choice |
| `data_structure_required` | Yes | Yes | Maps to variance dimension |
| `effect_estimate` | Yes | Yes | Numeric value |
| `effect_estimate_ci_95` | Yes | Yes | 2-element array [lower, upper] |
| `effect_unit` | Yes | Yes | Derived from outcome variable |
| `robustness_checks` | Yes | Yes | Array of {check_name, result, notes} |
| `causal_confidence` | Yes | Yes | "quasi-experimental" or "observational" |
| `assumptions_required` | Yes | Yes | Array of assumption names |
| `assumptions_validated` | Yes | Yes | Boolean |
| `interpretation` | Yes | Yes | Human-readable interpretation |

---

## Coverage Assessment

### Variance Dimension Coverage

| Dimension | Values in Spec | Values with Distinct Behavior | Min Required | Verdict |
|---|---|---|---|---|
| `method` | 4 (diff_in_diff, propensity_matching, instrumental_variables, regression_discontinuity) | 4 -- each has unique assumptions, estimation procedure, and edge cases | 2 | PASS |
| `data_structure` | 3 (panel, cross_sectional, natural_experiment) | 3 -- each routes to a different method via context classification | 2 | PASS |
| `robustness_depth` | 2 (standard, comprehensive) | 2 -- standard = 2 checks, comprehensive = 4+ checks | 2 | PASS |

### Edge Case Coverage

| Edge Case from Spec | Test ID | Covered |
|---|---|---|
| Empty source | D1 | Yes |
| No hypotheses for upgrade | C9 | Yes |
| Schema mismatch | C5-C8 | Yes |
| Insufficient data for method | D2, D3 | Yes |
| All robustness checks fail | D4 | Yes |
| Weak instrument | D5 | Yes |
| No common support | D6 | Yes |
| Parallel trends violated | D7 | Yes |

**Edge case verdict:** All 8 declared edge cases are covered by tests.

### Precondition Coverage

All 5 preconditions have corresponding Category C tests. Each produces HALT at Step 0 when violated.

### Postcondition Coverage

| Postcondition | Verified By | Verdict |
|---|---|---|
| causal_result.json exists with all 5 envelope fields | Terminal Artifact Validation above | PASS |
| causal_confidence is "quasi-experimental" or "observational" | A1-A6 (quasi-experimental), D4 (observational downgrade) | PASS |
| assumptions_required and assumptions_validated documented | B1-B4 verify per-method assumptions | PASS |
| robustness_checks has >=2 entries | B8 (standard=2), B9 (comprehensive=4+) | PASS |

---

## Blueprint Compliance (8 Principles)

| # | Principle | Verdict | Evidence |
|---|---|---|---|
| 1 | Single Job-to-be-Done | PASS | Skill does one thing: upgrade observational associations to causal estimates. Name follows verb-noun pattern. Scope Boundary explicitly lists 4 things the skill refuses to do, each naming the responsible skill. |
| 2 | Precondition / Postcondition Contracts | PASS | 5 testable preconditions with HALT in Step 0. 4 testable postconditions. All assertions are concrete (schema_version, record counts, field existence). |
| 3 | Explicit Variance Surface | PASS | 3 dimensions declared, each with >=2 values. Behavior differs meaningfully per value. Context classification in Step 0 determines routing. |
| 4 | Artifact at Every State Change | PASS | Terminal artifact written in Step 4 with all required fields. Single state change (causal estimation) produces single artifact. |
| 5 | Stateful Operations Are Scoped | N/A | This skill does not fit/train/calibrate persistent models. Propensity model is fitted within the skill execution scope and not persisted separately. |
| 6 | Quality Bar Over Completeness | PASS | Explicit HALT conditions for 6 blocking scenarios. WARN conditions for 3 non-blocking degradations. No silent continuation on degraded input. |
| 7 | Canonical Reference Library | PASS | No shared references are needed or duplicated. Skill is self-contained. |
| 8 | Self-Contained Portability | PASS | Skill directory contains only SKILL.md. No cross-skill imports. No sibling directory dependencies. Can be copied to ~/.claude/skills/ independently. |

---

## Human Review Checkpoint Verification

**CRITICAL CHECK:** Composition-rules.md section 8 declares that `causal-linkage-analysis` output requires human review before `roi-computation` can consume it.

| Location in SKILL.md | Human Review Mentioned | Verdict |
|---|---|---|
| Overview (line 37-38) | "Per composition-rules.md section 8, the output of this skill requires human review before roi-computation can consume it." | PASS |
| Step 4 terminal artifact (line 231) | "NOTE: This artifact requires human review before roi-computation can consume it." | PASS |
| Quality Bar (line 297) | "Human review checkpoint noted for downstream roi-computation" | PASS |
| Downstream (line 313) | "REQUIRES human review before proceeding" | PASS |

**Human review checkpoint verdict:** PASS -- The requirement is documented in 4 separate locations within the skill. The skill makes clear that causal estimates carry significant assumptions that must be validated by a human analyst before being monetized by roi-computation.

---

## 17-Item Checklist Structural Assessment

### Definition and Structure (5)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 1 | Frontmatter: name + description only; description states transformation, trigger, input, output in <=3 sentences | PASS | Frontmatter has name, description (3 sentences covering transformation, trigger, inputs, outputs). Also has inputs/outputs/can_follow/can_precede/supports_loop/exit_conditions -- these are DSE extensions beyond blueprint minimum but do not violate it. |
| 2 | All required sections present in order | PASS | Overview, When to Activate, Preconditions, Prerequisites, Variance Surface, Workflow, Terminal Artifact, Edge Cases, Postconditions, Quality Bar, Scope Boundary, Downstream -- all present in correct order. |
| 3 | SKILL.md <=500 lines; overflow extracted to references/ | PASS | SKILL.md is 315 lines. Well under 500 limit. No references/ directory needed. |
| 4 | scripts/generate_{name}_artifact.py exists | FAIL | No `scripts/` directory or `generate_causal_result_artifact.py` file exists. Terminal artifact section does not reference a generation script -- it uses inline pseudocode instead. |
| 5 | requirements.txt in 4-tier format | PARTIAL | Prerequisites section lists dependencies in tiered format (Tier 2, 3, 4) but as inline comments in SKILL.md rather than a separate requirements.txt file. No standalone requirements.txt file exists. Infrastructure requirements not documented (compute, memory, disk, OS, environment). |

### Contracts and Correctness (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 6 | Preconditions are testable with HALT in Step 0 | PASS | All 5 preconditions have corresponding HALT logic in Step 0 upstream validation. |
| 7 | Terminal artifact has 5 envelope fields + domain fields | PASS | schema_version, skill_name, timestamp, record_count, artifact_id all present. |
| 8 | Stateful operations bounded to declared subset | N/A | No persistent fit/train/calibrate operations. |
| 9 | Degraded upstream produces HALT | PASS | Schema mismatches, missing files, no upgrade recommendations -- all produce HALT. |

### Variance and Testing (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 10 | Variance Surface complete, >=2 values per dimension | PASS | 3 dimensions: method (4 values), data_structure (3 values), robustness_depth (2 values). All have distinct described behavior. |
| 11 | Skill run with >=3 values of each dimension | NOT TESTED | Conceptual walk-through only; no runtime execution performed. Would require actual data and execution environment. |
| 12 | Terminal artifact passes downstream validation | PASS (conceptual) | Artifact structure includes all fields that roi-computation and finding-assembly would need. causal_confidence field enables downstream trust assessment. |
| 13 | Pipeline regression test passes | NOT TESTED | Requires full pipeline execution environment. |

### Documentation and Integration (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 14 | Domain README pipeline diagram updated | NOT ASSESSED | No domain README.md identified in skill directory. This is a pipeline-level concern. |
| 15 | Domain README artifact chain updated | NOT ASSESSED | Same as above. |
| 16 | Domain README variance coverage table updated | NOT ASSESSED | Same as above. |
| 17 | New shared patterns promoted to _shared-references/ | PASS | No new shared patterns introduced. Skill does not duplicate patterns from other skills. |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL PASS -- 2 required fixes, 2 items needing runtime verification**

The skill specification is structurally sound. It demonstrates strong compliance with Blueprint principles, thorough variance coverage, comprehensive edge case handling, and explicit human review checkpoint documentation. The causal methods are well-differentiated with appropriate assumption validation and robustness checking at each branch.

The skill is blocked from merge by 2 structural gaps.

---

## Required Fixes

| Priority | Fix | Checklist Item | Effort |
|---|---|---|---|
| P1 (blocking) | Create `scripts/generate_causal_result_artifact.py` with standalone CLI, `--help` flag, and no cross-skill imports. Script should accept method, effect estimate, CI, robustness checks, assumptions, and output path as arguments. | Checklist item 4 | Medium |
| P2 (blocking) | Create `requirements.txt` in 4-tier format within the skill directory. Add Infrastructure Requirements subsection to Prerequisites (compute, memory, disk, OS packages, environment). | Checklist item 5 | Low |
| P3 (recommended) | In Step 4, add explicit language: "Generate a NEW artifact_id (UUID) for each loop iteration. Downstream skills must reference the most recent artifact_id." This aligns with composition-rules.md section 4 loop rules. | Test D8 | Low |

---

## Tests Still Needed

| Test | Why | Blocker? |
|---|---|---|
| Runtime execution with >=3 values of each variance dimension (checklist item 11) | Conceptual walk-through passed but runtime validation requires actual data and execution environment | Yes -- required before merge per checklist |
| Pipeline regression test (checklist item 13) | Skill must be tested at its declared position in the DAG (after hypothesis-validation, before roi-computation/finding-assembly) | Yes -- required before merge per checklist |
| Domain README updates (checklist items 14-16) | Pipeline diagram, artifact chain, and variance coverage table need updating if a domain README exists | Conditional -- only if domain README exists |
| Downstream validation from roi-computation perspective | Verify roi-computation Step 0 can validate causal_result.json fields and that human review gate is enforced | Recommended |
| Loop iteration artifact_id uniqueness | Verify that on retry (robustness failure), a new UUID is generated and the previous artifact is not overwritten | Recommended (after P3 fix) |
