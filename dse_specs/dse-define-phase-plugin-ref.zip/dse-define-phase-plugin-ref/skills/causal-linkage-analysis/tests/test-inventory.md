# Test Inventory: causal-linkage-analysis

Skill under test: `.claude/skills/causal-linkage-analysis/SKILL.md`
Date: 2026-04-10
Tester: DSE Skill Tester (automated)

---

## Variance Surface (from SKILL.md)

| Dimension | Values | Count |
|---|---|---|
| `method` | `diff_in_diff`, `propensity_matching`, `instrumental_variables`, `regression_discontinuity` | 4 |
| `data_structure` | `panel`, `cross_sectional`, `natural_experiment` | 3 |
| `robustness_depth` | `standard`, `comprehensive` | 2 |

---

## Category A: Happy Path Tests

| ID | Test Name | Variance Combination | Description | Expected Outcome |
|---|---|---|---|---|
| A1 | DiD panel standard | method=diff_in_diff, data=panel, robustness=standard | Panel data with valid parallel trends, 2 robustness checks | causal_result.json with causal_confidence="quasi-experimental", 2 robustness checks |
| A2 | PSM cross-sectional standard | method=propensity_matching, data=cross_sectional, robustness=standard | Cross-sectional data with good common support | causal_result.json with PSM effect estimate and CI |
| A3 | IV cross-sectional comprehensive | method=instrumental_variables, data=cross_sectional, robustness=comprehensive | Strong instrument (F>10), 4+ robustness checks | causal_result.json with 4+ robustness_checks entries |
| A4 | RDD natural-experiment standard | method=regression_discontinuity, data=natural_experiment, robustness=standard | Clear discontinuity, no manipulation at cutoff | causal_result.json with discontinuity estimate |
| A5 | PSM comprehensive | method=propensity_matching, data=cross_sectional, robustness=comprehensive | Full subsample analysis in addition to placebo + alt spec | 4+ robustness checks, subsample entry present |
| A6 | DiD comprehensive | method=diff_in_diff, data=panel, robustness=comprehensive | Panel data with additional pre-treatment window checks | 4+ robustness checks including DiD-specific checks |

---

## Category B: Variance Coverage Tests

| ID | Test Name | Dimension Tested | Values Covered | Description | Expected Outcome |
|---|---|---|---|---|---|
| B1 | Method: DiD | method | diff_in_diff | Verify parallel trends assumption check fires | assumptions_required includes "parallel_trends" |
| B2 | Method: PSM | method | propensity_matching | Verify propensity model fitting and overlap check | assumptions_required includes "conditional_independence", "common_support" |
| B3 | Method: IV | method | instrumental_variables | Verify first-stage F-stat check and 2SLS estimation | assumptions_required includes "exclusion_restriction", "instrument_relevance" |
| B4 | Method: RDD | method | regression_discontinuity | Verify McCrary test and local linear regression | assumptions_required includes "continuity_at_cutoff", "no_manipulation" |
| B5 | Data: panel | data_structure | panel | Panel structure routes to DiD | method_selected reflects DiD or panel-compatible method |
| B6 | Data: cross-sectional | data_structure | cross_sectional | Cross-sectional routes to PSM or IV | method_selected reflects PSM or IV |
| B7 | Data: natural-experiment | data_structure | natural_experiment | Natural experiment routes to RDD | method_selected reflects RDD |
| B8 | Robustness: standard | robustness_depth | standard | Exactly 2 robustness checks (placebo + alt spec) | robustness_checks array length == 2 |
| B9 | Robustness: comprehensive | robustness_depth | comprehensive | 4+ robustness checks including subsample | robustness_checks array length >= 4 |

---

## Category C: Precondition Violation Tests

| ID | Test Name | Precondition Violated | Description | Expected Outcome |
|---|---|---|---|---|
| C1 | Missing cohort.json | cohort.json not present | No cohort artifact exists | HALT at Step 0 upstream validation |
| C2 | Missing feature_set.json | feature_set.json not present | No feature set artifact exists | HALT at Step 0 upstream validation |
| C3 | Missing hypothesis_result.json | hypothesis_result.json not present | No hypothesis result artifact exists | HALT at Step 0 upstream validation |
| C4 | Missing comparison_result.json | comparison_result.json not present | No comparison result artifact exists | HALT at Step 0 upstream validation |
| C5 | Schema mismatch cohort | cohort.json schema_version != "1.0" | Wrong schema version on cohort | HALT at Step 0 upstream validation |
| C6 | Schema mismatch feature_set | feature_set.json schema_version != "1.0" | Wrong schema version on feature set | HALT at Step 0 upstream validation |
| C7 | Schema mismatch hypothesis_result | hypothesis_result.json schema_version != "1.0" | Wrong schema version on hypothesis result | HALT at Step 0 upstream validation |
| C8 | Schema mismatch comparison_result | comparison_result.json schema_version != "1.0" | Wrong schema version on comparison result | HALT at Step 0 upstream validation |
| C9 | No hypotheses for upgrade | hypothesis_result has 0 entries with upgrade_recommendation == "requires_causal_linkage_analysis" | No hypothesis flagged for causal upgrade | HALT: "No hypotheses flagged for causal upgrade." |
| C10 | Empty population | population_size == 0 | Cohort has zero records | HALT at Step 0 |

---

## Category D: Edge Case Tests

| ID | Test Name | Edge Case | Description | Expected Outcome |
|---|---|---|---|---|
| D1 | Empty source | population_size == 0 | Zero records in cohort | HALT Step 0 |
| D2 | Insufficient data for DiD | Panel has <2 time periods | Cannot run diff-in-diff | HALT: "Data structure insufficient for diff_in_diff." |
| D3 | No instrument available | IV selected but no valid instrument | Cannot identify instrument variable | HALT: "Data structure insufficient for instrumental_variables." |
| D4 | All robustness checks fail | Every robustness check result == "fails" | Causal estimate is not robust | WARN; causal_confidence downgraded to "observational" |
| D5 | Weak instrument | First-stage F < 10 | Instrument exists but is weak | WARN: "Weak instrument — IV estimates unreliable." |
| D6 | No common support | Propensity overlap < 0.1 | Treated and control groups do not overlap | HALT: "Insufficient overlap for propensity matching." |
| D7 | Parallel trends violated | Pre-treatment trends diverge significantly | DiD assumption fails | WARN: "DiD assumption violated — interpret with extreme caution." |
| D8 | Loop iteration 1 | Robustness checks fail, first retry | Re-run with different specification | Updated causal_result.json with new artifact_id |
| D9 | Loop iteration 2 (budget exhausted) | Robustness checks fail again on second try | Max iterations reached | causal_result.json written with best available estimate; exit |

---

## Test Count Summary

| Category | Count |
|---|---|
| A: Happy Path | 6 |
| B: Variance Coverage | 9 |
| C: Precondition Violations | 10 |
| D: Edge Cases | 9 |
| **Total** | **34** |
