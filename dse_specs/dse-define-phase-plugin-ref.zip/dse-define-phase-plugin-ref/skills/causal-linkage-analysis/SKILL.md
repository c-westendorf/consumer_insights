---
name: causal-linkage-analysis
description: >
  Applies quasi-experimental methods (diff-in-diff, propensity score matching, instrumental
  variables, regression discontinuity) to upgrade observational associations to causal estimates
  with robustness checks, producing causal_result.json. Activate after hypothesis-validation
  when upgrade_recommendation is 'requires_causal_linkage_analysis'; takes cohort + feature_set
  + hypothesis_result + comparison_result.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; provides treatment/control group structure"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; provides covariates for causal adjustment"
  - type: hypothesis_result
    description: "Validated hypotheses from hypothesis-validation; identifies which associations warrant causal investigation"
  - type: comparison_result
    description: "Statistical comparison from statistical-comparison; provides effect estimates to upgrade"
outputs:
  - type: causal_result
    description: "Causal effect estimate with robustness checks, assumption validation, and interpretation"
can_follow: [hypothesis-validation, statistical-comparison]
can_precede: [finding-assembly, roi-computation]
supports_loop: true
exit_conditions:
  - "causal_result.json written with stable estimate or budget exhausted (max 2 iterations)"
---

## Overview

Hypothesis-validation establishes that an association exists and is statistically significant.
Causal-linkage-analysis asks the harder question: *is this a causal relationship?* Using
quasi-experimental methods appropriate to the data structure, this skill attempts to isolate
the causal effect of a treatment or behavior on an outcome, with explicit robustness checks
and assumption documentation.

**IMPORTANT — Human Review Checkpoint:** Per composition-rules.md §8, the output of this skill
requires human review before `roi-computation` can consume it. Causal estimates carry significant
assumptions that must be validated by a human analyst before being monetized.

**What this skill produces:** `causal_result.json` with causal claim, method selection rationale,
effect estimate with CI, robustness checks, required assumptions, and interpretation.

---

## When to Activate

- `hypothesis_result.json` contains entries with `upgrade_recommendation == "requires_causal_linkage_analysis"`
- `scope_artifact.analytical_pattern == "explain"` and causal understanding is the goal
- User explicitly requests "causal analysis", "establish causation", or "quasi-experimental design"
- `behavioral_impact.causal_confidence == "adjusted"` and upgrade to quasi-experimental is warranted

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` with identifiable treatment/control structure
- [ ] `feature_set.json` exists with `schema_version == "1.0"` with sufficient covariates for adjustment
- [ ] `hypothesis_result.json` exists with `schema_version == "1.0"` with ≥1 hypothesis recommending causal upgrade
- [ ] `comparison_result.json` exists with `schema_version == "1.0"` with significant comparisons to investigate
- [ ] Data structure supports at least one quasi-experimental method (panel data, natural experiment, or instrument)

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: statsmodels>=0.14 (OLS, 2SLS, DiD); sklearn>=1.2 (propensity matching); causalinference>=0.1 (optional); scipy>=1.10; numpy>=1.24; pandas>=2.0
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `method` | `diff_in_diff` / `propensity_matching` / `instrumental_variables` / `regression_discontinuity` | Each requires different data structure and assumptions; method selection depends on available data |
| `data_structure` | `panel` / `cross_sectional` / `natural_experiment` | `panel`: DiD eligible; `cross_sectional`: PSM or IV; `natural_experiment`: RDD eligible |
| `robustness_depth` | `standard` / `comprehensive` | `standard`: 2 robustness checks (placebo + alternative spec); `comprehensive`: 4+ checks including subsample analysis |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify data_structure:
  IF panel data available (multiple time periods per unit) → "panel"
  ELIF natural discontinuity exists → "natural_experiment"
  ELSE → "cross_sectional"

classify method:
  IF data_structure == "panel" → "diff_in_diff"
  ELIF data_structure == "natural_experiment" → "regression_discontinuity"
  ELIF instrument available → "instrumental_variables"
  ELSE → "propensity_matching"

classify robustness_depth:
  IF scope requires high causal confidence → "comprehensive"
  ELSE → "standard"

log: "Running causal-linkage-analysis | method={value} | data={value} | robustness={value}"
```

**Upstream Validation:**
```
load cohort.json; assert schema_version == "1.0"
load feature_set.json; assert schema_version == "1.0"; assert data_ref not null
load hypothesis_result.json; assert schema_version == "1.0"
  assert ≥1 hypothesis with upgrade_recommendation == "requires_causal_linkage_analysis"
    IF not: HALT: "No hypotheses flagged for causal upgrade."
load comparison_result.json; assert schema_version == "1.0"
```

---

### Step 1 — Select and Validate Causal Method

**Goal:** Confirm data supports the selected method and validate required assumptions.

**Actions:**
```
causal_claim = hypothesis_result.hypotheses_tested[0].statement  -- or user-specified

IF method == "diff_in_diff":
  assumptions = ["parallel_trends"]
  -- Validate parallel trends: pre-treatment outcome trends similar for treated/control
  pre_trends = compute_pre_treatment_trends(treated, control)
  IF trends diverge significantly:
    WARN: "Parallel trends assumption may be violated — interpret with caution."
    assumptions_validated = false
  ELSE:
    assumptions_validated = true

ELIF method == "propensity_matching":
  assumptions = ["conditional_independence", "common_support"]
  -- Fit propensity model, check overlap
  propensity_scores = fit_propensity(covariates, treatment)
  IF min(overlap) < 0.1:
    WARN: "Poor common support — PSM estimates may be biased."

ELIF method == "instrumental_variables":
  assumptions = ["exclusion_restriction", "instrument_relevance"]
  -- First-stage F-statistic
  IF first_stage_F < 10:
    WARN: "Weak instrument (F={F}) — IV estimates may be unreliable."

ELIF method == "regression_discontinuity":
  assumptions = ["continuity_at_cutoff", "no_manipulation"]
  -- McCrary density test for manipulation
```

---

### Step 2 — Estimate Causal Effect

**Actions:**
```
IF method == "diff_in_diff":
  -- Y = α + β₁·Treatment + β₂·Post + β₃·(Treatment×Post) + ε
  effect_estimate = β₃ coefficient
  effect_ci = CI for β₃

ELIF method == "propensity_matching":
  -- 1:1 nearest-neighbor matching
  matched = match_propensity(treated, control, propensity_scores)
  effect_estimate = mean(matched_treated_outcome) - mean(matched_control_outcome)
  effect_ci = bootstrap_ci(matched_diff, 1000)

ELIF method == "instrumental_variables":
  -- 2SLS estimation
  effect_estimate = 2sls_coefficient
  effect_ci = CI for 2sls

ELIF method == "regression_discontinuity":
  -- Local linear regression at cutoff
  effect_estimate = discontinuity_at_cutoff
  effect_ci = CI for discontinuity

effect_unit = derive from outcome variable
```

---

### Step 3 — Run Robustness Checks

**Actions:**
```
robustness_checks = []

-- Placebo test (always)
placebo_result = run_method_on_placebo_period_or_outcome()
robustness_checks.append({check_name: "placebo_test", result: "passes" if placebo_insignificant else "fails"})

-- Alternative specification (always)
alt_result = run_method_with_different_covariates()
robustness_checks.append({check_name: "alternative_specification", result: ...})

IF robustness_depth == "comprehensive":
  -- Subsample analysis
  subsample_results = run_on_subsamples(50%, 75%)
  robustness_checks.append({check_name: "subsample", result: ...})

  -- Additional checks per method
  IF method == "diff_in_diff":
    -- Different pre-treatment windows
    ...

-- Assess overall robustness
IF any check fails:
  WARN: "Robustness check '{check_name}' failed — causal estimate may not be reliable."
  -- Loop may retry with different specification
```

---

### Step 4 — Write Terminal Artifact

```
Generate artifact_id  -- NEW UUID for each loop iteration; downstream skills reference the most recent artifact_id

causal_confidence = "quasi-experimental"  -- always for this skill
interpretation = generate_interpretation(effect_estimate, effect_ci, assumptions, robustness)

Write causal_result.json

NOTE: This artifact requires human review before roi-computation can consume it.
Log: "causal_result.json written | method={method} | effect={effect_estimate} | robustness={all_pass}"
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "causal-linkage-analysis",
  "timestamp": "2026-04-10T18:00:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "causal_claim": "Second purchase within 30 days causally increases annual spend by $142",
  "method_selected": "propensity_score_matching",
  "method_selection_rationale": "Cross-sectional data without panel structure; sufficient covariates for propensity model; adequate common support",
  "data_structure_required": "cross_sectional_with_instrument",
  "effect_estimate": 142.30,
  "effect_estimate_ci_95": [98.50, 186.10],
  "effect_unit": "dollars_annual_spend",
  "robustness_checks": [
    {"check_name": "placebo_test", "result": "passes", "notes": "Placebo outcome shows no significant effect"},
    {"check_name": "alternative_specification", "result": "passes", "notes": "Effect stable with extended covariate set"},
    {"check_name": "subsample", "result": "passes", "notes": "Consistent across 50% and 75% subsamples"}
  ],
  "causal_confidence": "quasi-experimental",
  "assumptions_required": ["conditional_independence", "common_support"],
  "assumptions_validated": true,
  "interpretation": "Customers who make a second purchase within 30 days spend approximately $142 more annually than comparable non-repeaters, after adjusting for observable confounders. This is a quasi-experimental estimate; unobserved confounders may remain."
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | population_size == 0 | HALT Step 0 |
| No hypotheses for upgrade | no upgrade_recommendation entries | HALT Step 0 |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| Insufficient data for method | panel has <2 periods, or no instrument available | HALT: "Data structure insufficient for {method}." |
| All robustness checks fail | every check result == "fails" | WARN: "Causal estimate is not robust — report as observational only." Set causal_confidence to "observational" |
| Weak instrument | first-stage F < 10 | WARN: "Weak instrument — IV estimates unreliable." |
| No common support | propensity overlap < 0.1 | HALT: "Insufficient overlap for propensity matching." |
| Parallel trends violated | pre-treatment trends diverge | WARN: "DiD assumption violated — interpret with extreme caution." |

---

## Postconditions

- [ ] `causal_result.json` exists with all 5 universal envelope fields
- [ ] `causal_confidence` is "quasi-experimental" (or downgraded to "observational" if robustness fails)
- [ ] `assumptions_required` and `assumptions_validated` are documented
- [ ] `robustness_checks` has ≥2 entries

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] Method selection rationale is documented
- [ ] All assumptions explicitly listed and validation attempted
- [ ] Robustness checks completed
- [ ] Human review checkpoint noted for downstream roi-computation

---

## Scope Boundary

This skill does NOT:
- Validate hypotheses (observational) → handled by `hypothesis-validation`
- Estimate behavioral impact (observational) → handled by `behavioral-impact-estimation`
- Monetize causal effects → handled by `roi-computation` (after human review)
- Compare groups statistically → handled by `statistical-comparison`

---

## Downstream

1. **`roi-computation`** — reads `causal_result` to monetize the causal effect estimate; REQUIRES human review before proceeding
2. **`finding-assembly`** — includes causal findings with explicit causal_confidence annotation
