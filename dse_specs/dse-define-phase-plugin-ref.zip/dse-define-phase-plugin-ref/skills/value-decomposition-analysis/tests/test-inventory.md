# Test Inventory: value-decomposition-analysis

Skill: `value-decomposition-analysis`
Spec: `.claude/skills/value-decomposition-analysis/SKILL.md`
Blueprint: `skill-blueprint/BLUEPRINT.md`
Generated: 2026-04-10

---

## Category A -- Happy Path

| ID | Test Name | Description | Variance Combo | Expected Outcome |
|---|---|---|---|---|
| A-1 | Standard 3-way aggregate decomposition | Two calendar periods, standard accounts x volume x value frame, aggregate only | `accounts_x_volume_x_value` / `aggregate_only` / `calendar` | `value_decomposition.json` with 5 envelope fields, 3 effects summing to total_value_change, pct_contribution summing to ~1.0 |
| A-2 | Standard 3-way with segment breakdown | Two calendar periods, standard frame, segment-level granularity | `accounts_x_volume_x_value` / `segment_level` / `calendar` | `value_decomposition.json` with aggregate decomposition plus `segment_decompositions` array populated |
| A-3 | Cohort-relative period alignment | Periods defined relative to cohort entry, aggregate only | `accounts_x_volume_x_value` / `aggregate_only` / `cohort_relative` | Artifact produced with periods derived from cohort entry dates rather than fixed calendar |
| A-4 | Full combination: segment + cohort-relative | Segment-level with cohort-relative alignment | `accounts_x_volume_x_value` / `segment_level` / `cohort_relative` | Segment decompositions produced with cohort-relative period derivation |

---

## Category B -- Variance Coverage

Each variance dimension must have >=2 values tested with distinct behavior verified.

| ID | Test Name | Dimension Under Test | Value | Expected Behavior Difference |
|---|---|---|---|---|
| B-1 | decomposition_frame = accounts_x_volume_x_value | `decomposition_frame` | `accounts_x_volume_x_value` | Standard 3-way multiplicative decomposition: accounts_effect + volume_per_account_effect + value_per_transaction_effect |
| B-2 | decomposition_frame = custom | `decomposition_frame` | `custom` | Custom decomposition framework; spec does NOT define what "custom" means, what fields it produces, or how behavior differs -- **gap identified** |
| B-3 | segment_granularity = aggregate_only | `segment_granularity` | `aggregate_only` | Only aggregate decomposition produced; `segment_decompositions` absent or empty |
| B-4 | segment_granularity = segment_level | `segment_granularity` | `segment_level` | Step 3 executes per-segment decomposition loop; `segment_decompositions` array populated |
| B-5 | period_alignment = calendar | `period_alignment` | `calendar` | Periods are fixed date ranges from scope/comparison_result |
| B-6 | period_alignment = cohort_relative | `period_alignment` | `cohort_relative` | Periods computed relative to each cohort member's entry date |
| B-7 | Worst-case combo: custom + segment_level + cohort_relative | All 3 | `custom` / `segment_level` / `cohort_relative` | Skill should still produce valid artifact -- currently underspecified for `custom` frame |

---

## Category C -- Precondition Violations

Each test PASSES only if the skill fires HALT and does NOT produce an artifact.

| ID | Test Name | Violated Precondition | Expected HALT Message |
|---|---|---|---|
| C-1 | Missing cohort.json | `cohort.json` does not exist | HALT at Step 0: upstream artifact missing |
| C-2 | Missing metric_result.json | `metric_result.json` does not exist | HALT at Step 0: upstream artifact missing |
| C-3 | Missing comparison_result.json | `comparison_result.json` does not exist | HALT at Step 0: upstream artifact missing |
| C-4 | cohort.json wrong schema_version | `cohort.json` has `schema_version == "2.0"` | HALT at Step 0: schema_version mismatch |
| C-5 | metric_result.json wrong schema_version | `metric_result.json` has `schema_version == "0.5"` | HALT at Step 0: schema_version mismatch |
| C-6 | comparison_result.json wrong schema_version | `comparison_result.json` has `schema_version == "3.0"` | HALT at Step 0: schema_version mismatch |
| C-7 | Only one period available | Single period in input; no prior period | HALT: "Cannot decompose without two comparable periods." |

---

## Category D -- Edge Cases

| ID | Test Name | Edge Case from Spec | Detection | Expected Action |
|---|---|---|---|---|
| D-1 | Empty source data | No data for either period | record count == 0 for period | HALT |
| D-2 | Single period only (prior missing) | Prior period has no data | Prior period query returns empty | HALT: "Cannot decompose without two comparable periods." |
| D-3 | Schema mismatch on upstream | `schema_version != "1.0"` on any upstream | Version check in Step 0 | HALT Step 0 |
| D-4 | Zero accounts in prior period | `prior.accounts == 0` | Division by zero in VPA/VPT calc | HALT: "Prior period has zero accounts -- division by zero." |
| D-5 | Negative total value | `total_value < 0` in a period | Value sign check | WARN: "Negative total value -- verify data includes returns/refunds." |
| D-6 | Decomposition rounding residual | Effects do not sum to total_value_change within 1% | `abs(total_decomposed - total_change) / total_change > 0.01` | WARN: log residual |
| D-7 | Zero total_value in prior (change_pct undefined) | `prior.total_value == 0` | Division by zero in `total_change_pct` | **Not specified in edge cases -- gap identified** |
| D-8 | Zero transactions in prior | `prior.total_transactions == 0` | Division by zero in `prior_vpt` | **Not specified in edge cases -- gap identified** |
| D-9 | Zero transactions in current | `current.total_transactions == 0` | Division by zero in `current_vpt` | **Not specified in edge cases -- gap identified** |
| D-10 | All segments empty except one | Only one segment has data | Segment loop produces single entry | Should still produce valid artifact; behavior underspecified |

---

## Test Count Summary

| Category | Count |
|---|---|
| A -- Happy Path | 4 |
| B -- Variance Coverage | 7 |
| C -- Precondition Violations | 7 |
| D -- Edge Cases | 10 |
| **Total** | **28** |
