---
name: value-decomposition-analysis
description: >
  Decomposes total value change between periods into accounts effect, volume-per-account effect,
  and value-per-transaction effect using a multiplicative framework, producing
  value_decomposition.json with segment-level breakdowns. Activate when scope involves
  understanding drivers of revenue or value changes; takes cohort + metric_result +
  comparison_result.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; provides population context for decomposition"
  - type: metric_result
    description: "Computed metrics from metric-computation; provides aggregate values for decomposition"
  - type: comparison_result
    description: "Statistical comparison from statistical-comparison; provides period-over-period or group differences"
outputs:
  - type: value_decomposition
    description: "Decomposed value change into accounts, volume, and value effects with segment-level detail"
can_follow: [metric-computation, statistical-comparison]
can_precede: [finding-assembly, roi-computation]
supports_loop: false
exit_conditions:
  - "value_decomposition.json written with accounts/volume/value effects computed"
---

## Overview

Statistical-comparison tells you *whether values changed significantly*. Value-decomposition-analysis tells you *why they changed* — decomposing total value change into the three multiplicative drivers: accounts (how many customers), volume per account (how often they transact), and value per transaction (how much per transaction).

This is the classic "price x volume x mix" decomposition adapted for customer analytics. It answers: "Revenue grew 12% — was that because we had more customers, because existing customers bought more often, or because they spent more per visit?"

**What this skill produces:** `value_decomposition.json` with aggregate and segment-level decomposition of total value change into three effects with direction and contribution percentages.

---

## When to Activate

- Scope involves revenue drivers, value change attribution, or growth decomposition
- `comparison_result.json` shows significant period-over-period changes
- User requests "decompose the value change", "growth drivers", or "accounts x volume x value"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"`
- [ ] `metric_result.json` exists with `schema_version == "1.0"` with period-specific metrics
- [ ] `comparison_result.json` exists with `schema_version == "1.0"` (period comparison data)
- [ ] Two comparable periods available for decomposition

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: numpy>=1.24 (multiplicative decomposition math); pandas>=2.0
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `decomposition_frame` | `accounts_x_volume_x_value` | Standard 3-way multiplicative decomposition (Accounts x Volume/Account x Value/Transaction) |
| `segment_granularity` | `aggregate_only` / `segment_level` | `aggregate`: total decomposition only; `segment`: per-segment breakdown |
| `period_alignment` | `calendar` / `cohort_relative` | `calendar`: fixed date periods; `cohort_relative`: relative to cohort entry |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

```
-- 0a. Classify variance dimensions from scope
decomposition_frame = "accounts_x_volume_x_value"
segment_granularity = classify from scope: "aggregate_only" | "segment_level"
period_alignment = classify from scope: "calendar" | "cohort_relative"

-- 0b. Validate upstream artifacts
load cohort.json
  IF not found: HALT: "Upstream validation failed: cohort.json not found."
assert cohort.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json -- schema_version mismatch."

load metric_result.json
  IF not found: HALT: "Upstream validation failed: metric_result.json not found."
assert metric_result.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: metric_result.json -- schema_version mismatch."
assert metric_result contains period-specific metrics
  IF not: HALT: "Upstream validation failed: metric_result.json -- missing period-specific metrics."

load comparison_result.json
  IF not found: HALT: "Upstream validation failed: comparison_result.json not found."
assert comparison_result.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: comparison_result.json -- schema_version mismatch."
assert comparison_result contains two comparable periods
  IF not: HALT: "Upstream validation failed: comparison_result.json -- two comparable periods required."
```

### Step 1 — Extract Period Metrics

```
-- Identify current and prior period from scope_artifact.timeframe or comparison_result
current_period = {start, end, accounts, total_transactions, total_value}
prior_period = {start, end, accounts, total_transactions, total_value}

IF period_alignment == "calendar":
  Execute SQL for each period:
    SELECT COUNT(DISTINCT customer_id) AS accounts,
           COUNT(*) AS total_transactions,
           SUM(value) AS total_value
    FROM {data_ref}
    WHERE event_date BETWEEN {period.start} AND {period.end}

IF period_alignment == "cohort_relative":
  Execute SQL for each period (relative to cohort entry date):
    SELECT COUNT(DISTINCT c.customer_id) AS accounts,
           COUNT(*) AS total_transactions,
           SUM(d.value) AS total_value
    FROM {data_ref} d
    JOIN cohort c ON d.customer_id = c.customer_id
    WHERE DATEDIFF(day, c.cohort_entry_date, d.event_date)
          BETWEEN {period.relative_start_days} AND {period.relative_end_days}

-- 1b. Guard against division-by-zero before proceeding
IF prior.accounts == 0: HALT: "Prior period has zero accounts — division by zero."
IF prior.total_transactions == 0: HALT: "Prior period total_transactions is zero — cannot compute prior_vpt (division by zero)."
IF prior.total_value == 0: HALT: "Prior period total_value is zero — cannot compute total_change_pct (division by zero)."
IF current.total_transactions == 0: HALT: "Current period total_transactions is zero — cannot compute current_vpt (division by zero)."
```

### Step 2 — Compute Decomposition

```
-- Multiplicative decomposition: Value = Accounts × Volume/Account × Value/Transaction
current_vpa = current.total_transactions / current.accounts  -- volume per account
current_vpt = current.total_value / current.total_transactions  -- value per transaction
prior_vpa = prior.total_transactions / prior.accounts
prior_vpt = prior.total_value / prior.total_transactions

total_change = current.total_value - prior.total_value
total_change_pct = total_change / prior.total_value

-- Additive decomposition of multiplicative effects (log-based or incremental)
accounts_effect = (current.accounts - prior.accounts) * prior_vpa * prior_vpt
volume_effect = prior.accounts * (current_vpa - prior_vpa) * prior_vpt
value_effect = prior.accounts * prior_vpa * (current_vpt - prior_vpt)

-- Normalize to percentage contributions
total_decomposed = accounts_effect + volume_effect + value_effect
accounts_pct = accounts_effect / total_decomposed
volume_pct = volume_effect / total_decomposed
value_pct = value_effect / total_decomposed
```

### Step 3 — Segment-Level Decomposition (if applicable)

```
IF segment_granularity == "segment_level":
  FOR each segment (from maturity_classification or cohort segmentation):
    Repeat Step 2 decomposition within segment
    segment_decompositions.append({segment, total_change, accounts_effect, volume_effect, value_effect})
```

### Step 4 — Write Terminal Artifact

Write value_decomposition.json.

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "value-decomposition-analysis",
  "timestamp": "2026-04-10T17:30:00Z",
  "record_count": 10980,
  "artifact_id": "{uuid}",
  "decomposition_frame": "accounts_x_volume_x_value",
  "periods_compared": [
    {"label": "current", "start": "2025-07-01", "end": "2025-12-31"},
    {"label": "prior", "start": "2025-01-01", "end": "2025-06-30"}
  ],
  "total_value_change": 1250000,
  "total_value_change_pct": 0.12,
  "decomposition": {
    "accounts_effect": {"change": 500000, "pct_contribution": 0.40, "direction": "growth"},
    "volume_per_account_effect": {"change": 437500, "pct_contribution": 0.35, "direction": "growth"},
    "value_per_transaction_effect": {"change": 312500, "pct_contribution": 0.25, "direction": "growth"}
  },
  "segment_decompositions": [
    {"segment": "high_engaged", "total_change": 750000, "accounts_effect": 200000, "volume_effect": 350000, "value_effect": 200000}
  ]
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | no data for either period | HALT |
| Single period only | prior period has no data | HALT: "Cannot decompose without two comparable periods." |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| Zero accounts in prior | prior.accounts == 0 | HALT: "Prior period has zero accounts — division by zero." |
| Zero prior total value | prior.total_value == 0 | HALT: "Prior period total_value is zero — cannot compute total_change_pct (division by zero). Verify data completeness." |
| Zero prior transactions | prior.total_transactions == 0 | HALT: "Prior period total_transactions is zero — cannot compute prior_vpt (division by zero). Verify data completeness." |
| Zero current transactions | current.total_transactions == 0 | HALT: "Current period total_transactions is zero — cannot compute current_vpt (division by zero). Verify data completeness." |
| Negative total value | total_value < 0 | WARN: "Negative total value — verify data includes returns/refunds." |
| Decomposition doesn't sum | rounding error > 1% | WARN: log residual |
| Single segment | segment_decompositions has exactly 1 element | WARN: "Only one segment present — decomposition is equivalent to aggregate. Consider using aggregate_only." |

---

## Postconditions

- [ ] `value_decomposition.json` exists with all 5 universal envelope fields
- [ ] Three effects sum approximately to `total_value_change` (within rounding tolerance)
- [ ] `pct_contribution` values sum to approximately 1.0

---

## Quality Bar

- [ ] Validates against terminal artifact spec (all 5 envelope fields present and correctly typed)
- [ ] Decomposition is mathematically consistent (three effects sum to total_value_change within 1% tolerance)
- [ ] `pct_contribution` values sum to approximately 1.0
- [ ] No NaN or Inf values in any output field
- [ ] All division-by-zero edge cases fire HALT before producing artifacts
- [ ] If `segment_level`: segment effects sum approximately to aggregate effects
- [ ] `artifact_id` is a valid UUID v4
- [ ] Downstream `finding-assembly` and `roi-computation` can validate the artifact

---

## Scope Boundary

This skill does NOT:
- Compare groups statistically → handled by `statistical-comparison`
- Compute aggregate metrics → handled by `metric-computation`
- Monetize as ROI → handled by `roi-computation`
- Discover latent factors → handled by `latent-factor-modeling`

---

## Downstream

1. **`finding-assembly`** — includes decomposition results as growth driver findings
2. **`roi-computation`** — reads decomposition to attribute revenue impact to specific drivers
