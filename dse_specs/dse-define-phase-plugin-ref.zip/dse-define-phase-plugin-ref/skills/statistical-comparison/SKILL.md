---
name: statistical-comparison
description: >
  Performs statistical tests (Welch's t, Mann-Whitney U, chi-squared, ANOVA, Kruskal-Wallis)
  comparing target and reference populations on computed metrics, producing comparison_result.json
  with p-values, effect sizes, and multiple comparison corrections. Activate after
  metric-computation when scope_artifact.analytical_pattern is 'compare'; takes cohort
  (target+reference) + metric_result + feature_set.
inputs:
  - type: cohort
    description: "Population with target and reference groups from cohort-extraction; provides customer_id_ref and reference_customer_id_ref"
  - type: metric_result
    description: "Computed metrics from metric-computation; provides metric values for target and reference populations"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref provides the feature table for statistical testing"
outputs:
  - type: comparison_result
    description: "Statistical test results with raw and adjusted p-values, effect sizes, and significance conclusions for each metric comparison"
can_follow: [metric-computation, exploratory-analysis]
can_precede: [hypothesis-validation, roi-computation, value-decomposition-analysis, finding-assembly]
supports_loop: false
exit_conditions:
  - "comparison_result.json written with all metric comparisons tested and multiple comparison correction applied"
---

## Overview

Metric-computation tells you *what the metric values are* for each population. Statistical-comparison
tells you *whether the differences are statistically significant* and *how large the effects are*.
This skill selects appropriate statistical tests based on data characteristics (normality, sample
size, variable type), computes raw p-values, applies multiple comparison corrections, and
classifies effect sizes per Cohen's conventions.

The skill is critical for the compare analytical pattern — it transforms observed metric
differences into evidence-graded conclusions (significant/not significant/borderline) that
downstream hypothesis-validation and roi-computation can act on.

**What this skill produces:** `comparison_result.json` with a `comparisons` array — each entry
contains test selection rationale, raw and adjusted p-values, effect size with magnitude
classification, confidence intervals, and conclusion.

---

## When to Activate

- A plan task node with `task_type: "statistical_comparison"` is the next unexecuted task
- `scope_artifact.analytical_pattern == "compare"` and metric_result has both target and reference entries
- User explicitly requests "compare groups", "test for significance", or "run statistical tests"
- `metric_result.json` contains metrics with both `population: "target"` and `population: "reference"`
- `exploratory-analysis` has identified group contrasts worth testing formally

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and both `customer_id_ref` and `reference_customer_id_ref` non-null
- [ ] `metric_result.json` exists with `schema_version == "1.0"` and metrics array contains both target and reference entries
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref` (dict with base and comparison keys)
- [ ] `feature_set.data_ref` tables are accessible in the warehouse

---

## Prerequisites

### Library Dependencies
```
# Tier 1: (none -- no organization-private packages)
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.10 (ttest_ind, mannwhitneyu, chi2_contingency, f_oneway, kruskal); statsmodels>=0.14 (multipletests); numpy>=1.24
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; statistical tests run locally on sampled data
- **Memory:** <500 MB (load sample for test computation)
- **Upstream Artifacts:** `cohort.json`, `metric_result.json` (metrics array), `feature_set.json` (data_ref for raw data access)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `test_selection` | `parametric` / `non_parametric` | `parametric`: Welch's t-test (2 groups) or ANOVA (3+); `non_parametric`: Mann-Whitney U (2 groups) or Kruskal-Wallis (3+) |
| `comparison_type` | `pairwise` / `multi_group` | `pairwise`: 2 groups, single test per metric; `multi_group`: 3+ groups, omnibus test + post-hoc pairwise |
| `correction_method` | `benjamini_hochberg` / `bonferroni` / `none` | `BH`: default FDR control for multiple comparisons; `bonferroni`: conservative FWER control; `none`: single comparison only |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify test_selection:
  -- Determine parametric vs non-parametric from data characteristics
  FOR each metric in metric_result.metrics where population == "target":
    sample target data; run Shapiro-Wilk normality test
    IF p_shapiro > 0.05 AND n >= 30 → "parametric"
    ELSE → "non_parametric"
  log: "test_selection={value}"

classify comparison_type:
  groups = distinct population labels in metric_result.metrics
  IF len(groups) == 2 → "pairwise"
  ELSE → "multi_group"
  log: "comparison_type={value}"

classify correction_method:
  n_comparisons = count of unique metrics to compare
  IF n_comparisons == 1 → "none"
  ELIF n_comparisons <= 10 → "benjamini_hochberg"
  ELSE → "bonferroni"
  log: "correction_method={value}"

log: "Running statistical-comparison | test={value} | type={value} | correction={value}"
```

**Upstream Validation:**
```
load cohort.json
assert schema_version == "1.0" AND customer_id_ref is not null AND reference_customer_id_ref is not null
  IF not: HALT: "Upstream validation failed: cohort.json — missing population references."

load metric_result.json
assert schema_version == "1.0"
assert metrics contains entries with population == "target" AND population == "reference"
  IF not: HALT: "Upstream validation failed: metric_result.json — missing target or reference entries.
  Re-run metric-computation with compare pattern."

load feature_set.json
assert schema_version == "1.0" AND data_ref is dict with base and comparison keys
  IF not: HALT: "Upstream validation failed: feature_set.json — data_ref not a base/comparison dict."
```

---

### Step 1 — Select and Execute Tests

**Goal:** Run appropriate statistical test for each metric comparison.

**Actions:**
```
comparisons = []
comparison_counter = 1

FOR each metric_name in unique(metric_result.metrics[*].name):
  target_metric = find metric where name == metric_name AND population == "target"
  reference_metric = find metric where name == metric_name AND population == "reference"

  -- Load raw data for test
  target_data = query {feature_set.data_ref.base} for {metric_column}
  reference_data = query {feature_set.data_ref.comparison} for {metric_column}

  IF metric_type == "categorical":
    test = "chi_squared"
    effect_size_type = "cramers_v"
  ELIF test_selection == "parametric" AND comparison_type == "pairwise":
    stat, p_value = scipy.stats.ttest_ind(target_data, reference_data, equal_var=False)
    test_name = "welch_t"
  ELIF test_selection == "non_parametric" AND comparison_type == "pairwise":
    stat, p_value = scipy.stats.mannwhitneyu(target_data, reference_data)
    test_name = "mann_whitney_u"
  ELIF test_selection == "parametric" AND comparison_type == "multi_group":
    stat, p_value = scipy.stats.f_oneway(group1, group2, ...)
    test_name = "anova"
  ELIF test_selection == "non_parametric" AND comparison_type == "multi_group":
    stat, p_value = scipy.stats.kruskal(group1, group2, ...)
    test_name = "kruskal_wallis"

  IF n_groups > 2:
    -- Omnibus test first (ANOVA / Kruskal-Wallis)
    IF omnibus p < alpha:
      -- Post-hoc pairwise: Tukey HSD for parametric, Dunn's test for non-parametric
      IF parametric: post_hoc_tests = tukey_hsd(groups)
      ELSE: post_hoc_tests = dunns_test(groups, correction="bonferroni")

  -- Compute effect size
  IF metric is continuous:
    pooled_std = sqrt(((n1-1)*s1^2 + (n2-1)*s2^2) / (n1+n2-2))
    effect_size = (mean1 - mean2) / pooled_std
    effect_size_type = "cohens_d"
  ELIF metric is categorical:
    effect_size = cramers_v(contingency_table)
    effect_size_type = "cramers_v"

  effect_magnitude = classify_cohen(|effect_size|)

  comparisons.append({
    comparison_id: "C-{counter:03d}",
    metric: metric_name,
    test_type: comparison_type,
    test_name: test_name,
    groups: ["target", "reference"],
    group_means: {target: target_metric.value, reference: reference_metric.value},
    raw_p_value: p_value,
    effect_size: effect_size,
    effect_size_type: effect_size_type,
    effect_size_magnitude: effect_magnitude,
    confidence_interval_95: compute_ci(target_data, reference_data),
    n_target: target_metric.n_observations,
    n_reference: reference_metric.n_observations
  })
```

**Checkpoint:**
> - [ ] PASS: tests executed for all metrics
> - [ ] HALT: data inaccessible — "Feature tables not found — re-run feature-engineering."
> - [ ] WARN: very small sample sizes may produce unreliable tests

---

### Step 2 — Apply Multiple Comparison Correction

**Goal:** Adjust p-values if multiple comparisons were made.

**Actions:**
```
IF correction_method == "none":
  FOR each comparison: adjusted_p_value = raw_p_value
ELIF correction_method == "benjamini_hochberg":
  raw_pvals = [c.raw_p_value for c in comparisons]
  reject, adjusted_pvals, _, _ = statsmodels.stats.multitest.multipletests(raw_pvals, method='fdr_bh')
  FOR each comparison, adj_p: comparison.adjusted_p_value = adj_p
ELIF correction_method == "bonferroni":
  FOR each comparison: adjusted_p_value = min(1.0, raw_p_value * n_comparisons)

-- Classify conclusions
FOR each comparison:
  IF adjusted_p_value < 0.01: conclusion = "significant"
  ELIF adjusted_p_value < 0.05: conclusion = "significant"
  ELIF adjusted_p_value < 0.10: conclusion = "borderline"
  ELSE: conclusion = "not_significant"
  comparison.conclusion = conclusion
  comparison.adjustment_method = correction_method

Log: "Multiple comparison correction applied | method={correction_method} | significant={count}"
```

**Checkpoint:**
> - [ ] PASS: all comparisons have adjusted p-values and conclusions

---

### Step 3 — Write Terminal Artifact

**Actions:**
```
Generate artifact_id: UUID v4

Write comparison_result.json

Log: "comparison_result.json written | comparisons={len(comparisons)} | significant={count}"
```

**Checkpoint:**
> - [ ] PASS: comparison_result.json written; all 5 universal fields present

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "statistical-comparison",
  "timestamp": "2026-04-10T15:45:00Z",
  "record_count": 10980,          // total observations across all groups in the comparison
  "artifact_id": "{uuid}",
  "comparisons": [
    {
      "comparison_id": "C-001",
      "metric": "repeat_purchase_rate",
      "test_type": "pairwise",
      "test_name": "mann_whitney_u",
      "groups": ["target", "reference"],
      "group_means": {"target": 0.342, "reference": 0.287},
      "raw_p_value": 0.023,
      "p_value_note": null,
      "adjusted_p_value": 0.041,
      "adjustment_method": "benjamini_hochberg",
      "effect_size": 0.45,
      "effect_size_type": "cohens_d",
      "effect_size_magnitude": "medium",
      "confidence_interval_95": [0.012, 0.098],
      "n_target": 6148,
      "n_reference": 4832,
      "conclusion": "significant"
    }
  ],
  "post_hoc_tests": [],
  "multiple_comparisons_corrected": true,
  "correction_method": "benjamini_hochberg",
  "n_comparisons_total": 3
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | cohort.population_size == 0 | HALT Step 0: "Cannot compare empty populations." |
| Single record per group | n_target == 1 OR n_reference == 1 | WARN: "Single observation in group — statistical test unreliable." |
| All-null metric | metric values entirely NULL | HALT: "Metric column entirely NULL." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 |
| Identical distributions | p_value == 1.0 and effect_size == 0 | Conclusion: "not_significant" — groups are indistinguishable |
| Extreme p-value (<1e-15) | raw_p_value < 1e-15 | Clamp raw_p_value to 1e-15; add p_value_note: 'Actual p-value below representable threshold (<1e-15)' |
| Unequal group sizes (>10:1 ratio) | n_target / n_reference > 10 | WARN: "Highly unequal groups — effect size may be inflated." |
| All comparisons non-significant | every conclusion == "not_significant" | Proceed normally — this is a valid finding |

---

## Postconditions

- [ ] `comparison_result.json` exists with all 5 universal envelope fields
- [ ] Every comparison has `raw_p_value`, `adjusted_p_value`, `effect_size`, and `conclusion`
- [ ] `multiple_comparisons_corrected` is true if >1 comparison was made
- [ ] `n_comparisons_total` matches actual number of comparisons

---

## Quality Bar

- [ ] `comparison_result.json` validates against terminal artifact spec
- [ ] P-values are in [0, 1]; effect sizes are finite
- [ ] Correction method is appropriate for the number of comparisons
- [ ] Downstream `hypothesis-validation` Step 0 can load and validate the artifact
- [ ] Test selection matches data characteristics (parametric only when normality holds)

---

## Scope Boundary

This skill does NOT:
- Compute the metric values → handled by `metric-computation`
- Validate hypotheses with confounder adjustment → handled by `hypothesis-validation`
- Estimate causal impact → handled by `behavioral-impact-estimation` and `causal-linkage-analysis`
- Monetize significant differences → handled by `roi-computation`
- Decompose value drivers → handled by `value-decomposition-analysis`

---

## Downstream

1. **`hypothesis-validation`** — reads `comparison_result.comparisons` to validate EDA hypotheses using formal test outcomes
2. **`roi-computation`** — reads significant comparisons to monetize the observed effect sizes
3. **`value-decomposition-analysis`** — reads `comparison_result` to decompose significant differences into component drivers
4. **`finding-assembly`** — includes comparison results as evidence in assembled findings
