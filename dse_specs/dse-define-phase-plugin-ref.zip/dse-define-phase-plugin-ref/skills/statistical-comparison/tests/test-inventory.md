# Test Inventory — statistical-comparison

Skill: `statistical-comparison`
Spec: `.claude/skills/statistical-comparison/SKILL.md` (339 lines)
Date: 2026-04-10
Tester: DSE Skill Tester (automated)

---

## Parsed Spec Elements

### Preconditions (4)
| ID | Precondition |
|----|-------------|
| PC-1 | `cohort.json` exists with `schema_version == "1.0"` and both `customer_id_ref` and `reference_customer_id_ref` non-null |
| PC-2 | `metric_result.json` exists with `schema_version == "1.0"` and metrics array contains both target and reference entries |
| PC-3 | `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref` (dict with base and comparison keys) |
| PC-4 | `feature_set.data_ref` tables are accessible in the warehouse |

### Variance Surface (3 dimensions)
| Dimension | Values | Branching logic confirmed in workflow |
|-----------|--------|--------------------------------------|
| `test_selection` | `parametric` / `non_parametric` | Yes -- Step 0 classifies via Shapiro-Wilk; Step 1 branches to Welch's t or Mann-Whitney U (pairwise) or ANOVA vs Kruskal-Wallis (multi_group) |
| `comparison_type` | `pairwise` / `multi_group` | Yes -- Step 0 classifies by group count; Step 1 selects 2-group vs 3+-group test |
| `correction_method` | `benjamini_hochberg` / `bonferroni` / `none` | Yes -- Step 0 classifies by n_comparisons; Step 2 applies corresponding correction |

### Edge Cases (8)
| ID | Edge Case |
|----|-----------|
| EC-1 | Empty source (population_size == 0) |
| EC-2 | Single record per group |
| EC-3 | All-null metric |
| EC-4 | Schema mismatch |
| EC-5 | Identical distributions |
| EC-6 | Extreme p-value (< 1e-15) |
| EC-7 | Unequal group sizes (>10:1 ratio) |
| EC-8 | All comparisons non-significant |

### Terminal Artifact Envelope Fields (5)
| Field | Present in spec |
|-------|----------------|
| `schema_version` | Yes -- "1.0" |
| `skill_name` | Yes -- "statistical-comparison" |
| `timestamp` | Yes -- ISO-8601 UTC |
| `record_count` | Yes -- 10980 in example |
| `artifact_id` | Yes -- "{uuid}" |

### Postconditions (4)
| ID | Postcondition |
|----|--------------|
| POST-1 | `comparison_result.json` exists with all 5 universal envelope fields |
| POST-2 | Every comparison has `raw_p_value`, `adjusted_p_value`, `effect_size`, and `conclusion` |
| POST-3 | `multiple_comparisons_corrected` is true if >1 comparison was made |
| POST-4 | `n_comparisons_total` matches actual number of comparisons |

### Quality Bar (5)
| ID | Quality Check |
|----|--------------|
| QB-1 | `comparison_result.json` validates against terminal artifact spec |
| QB-2 | P-values are in [0, 1]; effect sizes are finite |
| QB-3 | Correction method is appropriate for the number of comparisons |
| QB-4 | Downstream `hypothesis-validation` Step 0 can load and validate the artifact |
| QB-5 | Test selection matches data characteristics (parametric only when normality holds) |

---

## Test Inventory

### Category A -- Happy Path (4 tests)

| Test ID | Description | Variance Combo | Expected Outcome |
|---------|-------------|---------------|-----------------|
| A-01 | Pairwise parametric with BH correction, 3 continuous metrics, normal data, n>30 per group | parametric / pairwise / benjamini_hochberg | comparison_result.json with 3 comparisons, BH-adjusted p-values, Cohen's d effect sizes, all 5 envelope fields |
| A-02 | Pairwise non-parametric with BH correction, 3 metrics, non-normal data | non_parametric / pairwise / benjamini_hochberg | Mann-Whitney U tests, BH-adjusted p-values, valid conclusions |
| A-03 | Multi-group parametric with Bonferroni, 12 metrics, 3 groups, normal data | parametric / multi_group / bonferroni | ANOVA omnibus tests, Bonferroni correction, post_hoc_tests populated |
| A-04 | Single metric comparison with no correction | parametric / pairwise / none | 1 comparison, adjusted_p_value == raw_p_value, correction_method == "none" |

### Category B -- Variance Coverage (9 tests)

**Dimension: test_selection (2 values, need >=2)**

| Test ID | Description | Value | Expected Outcome |
|---------|-------------|-------|-----------------|
| B-01 | Parametric path: normal data, n>=30 | `parametric` | Shapiro-Wilk p > 0.05, Welch's t selected |
| B-02 | Non-parametric path: skewed data, n>=30 | `non_parametric` | Shapiro-Wilk p <= 0.05, Mann-Whitney U selected |
| B-03 | Non-parametric path: small sample, n<30 | `non_parametric` | Small n forces non-parametric regardless of distribution shape |

**Dimension: comparison_type (2 values, need >=2)**

| Test ID | Description | Value | Expected Outcome |
|---------|-------------|-------|-----------------|
| B-04 | Pairwise: exactly 2 groups (target + reference) | `pairwise` | Single test per metric, no post-hoc |
| B-05 | Multi-group: 3 populations | `multi_group` | Omnibus test + post-hoc pairwise tests |
| B-06 | Multi-group: 5 populations | `multi_group` | Omnibus + post-hoc, higher correction burden |

**Dimension: correction_method (3 values, need >=2)**

| Test ID | Description | Value | Expected Outcome |
|---------|-------------|-------|-----------------|
| B-07 | BH correction: 5 comparisons | `benjamini_hochberg` | FDR-controlled adjusted p-values via multipletests |
| B-08 | Bonferroni correction: 15 comparisons | `bonferroni` | adjusted_p = min(1.0, raw_p * 15) |
| B-09 | No correction: 1 comparison | `none` | adjusted_p == raw_p |

### Category C -- Precondition Violations (6 tests)

| Test ID | Precondition Violated | Input Condition | Expected Outcome |
|---------|----------------------|-----------------|-----------------|
| C-01 | PC-1 | `cohort.json` missing entirely | HALT: "Upstream validation failed: cohort.json -- missing population references." |
| C-02 | PC-1 | `cohort.json` has `schema_version == "0.9"` | HALT: Step 0 schema mismatch |
| C-03 | PC-1 | `cohort.json` has `reference_customer_id_ref == null` | HALT: "Upstream validation failed: cohort.json -- missing population references." |
| C-04 | PC-2 | `metric_result.json` has only target entries, no reference | HALT: "Upstream validation failed: metric_result.json -- missing target or reference entries." |
| C-05 | PC-3 | `feature_set.json` has `data_ref` as string instead of dict with base/comparison keys | HALT: "Upstream validation failed: feature_set.json -- data_ref not a base/comparison dict." |
| C-06 | PC-4 | `feature_set.data_ref` tables do not exist in warehouse | HALT: "Feature tables not found -- re-run feature-engineering." (Step 1 checkpoint) |

### Category D -- Edge Cases (8 tests)

| Test ID | Edge Case | Input Condition | Expected Outcome |
|---------|-----------|-----------------|-----------------|
| D-01 | EC-1: Empty source | cohort.population_size == 0 | HALT Step 0: "Cannot compare empty populations." |
| D-02 | EC-2: Single record per group | n_target == 1 | WARN: "Single observation in group -- statistical test unreliable." Skill proceeds |
| D-03 | EC-3: All-null metric | Metric column entirely NULL | HALT: "Metric column entirely NULL." |
| D-04 | EC-4: Schema mismatch | any schema_version != "1.0" | HALT Step 0 |
| D-05 | EC-5: Identical distributions | Same values in both groups | p_value == 1.0, effect_size == 0, conclusion == "not_significant" |
| D-06 | EC-6: Extreme p-value | Massively different distributions | p_value reported as "<1e-15" |
| D-07 | EC-7: Unequal groups >10:1 | n_target=10000, n_reference=500 | WARN: "Highly unequal groups -- effect size may be inflated." |
| D-08 | EC-8: All non-significant | All p-values > 0.10 | All conclusions == "not_significant", skill proceeds normally |

---

## Test Count Summary

| Category | Count |
|----------|-------|
| A -- Happy Path | 4 |
| B -- Variance Coverage | 9 |
| C -- Precondition Violations | 6 |
| D -- Edge Cases | 8 |
| **Total** | **27** |

### Variance Dimension Coverage

| Dimension | Values in Spec | Values Tested | Meets >=2 |
|-----------|---------------|--------------|-----------|
| `test_selection` | 2 | 3 (B-01, B-02, B-03) | Yes |
| `comparison_type` | 2 | 3 (B-04, B-05, B-06) | Yes |
| `correction_method` | 3 | 3 (B-07, B-08, B-09) | Yes |
