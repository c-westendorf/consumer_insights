# Test Inventory: behavioral-impact-estimation

Skill: `behavioral-impact-estimation`
Spec: `.claude/skills/behavioral-impact-estimation/SKILL.md`
Generated: 2026-04-10

---

## Category A: Happy Path

| ID | Test Name | Description | Expected Outcome |
|---|---|---|---|
| A1 | Standard propensity flow | Valid cohort + feature_set (>=5 covariates) + metric_result; behavior_source=feature_derived; adjustment=propensity_stratification | behavioral_impact.json with adjusted_difference, causal_confidence="adjusted", 5 envelope fields |
| A2 | Scope-defined behaviors, no adjustment | Valid upstream artifacts; plan specifies behaviors; <5 covariates; adjustment=none | behavioral_impact.json with observed_difference only, adjusted_difference=null, causal_confidence="observational" |
| A3 | Covariate matching flow | Valid upstream; plan specifies adjustment_method=covariate_matching; sufficient overlap | behavioral_impact.json with adjustment_method="covariate_matching", causal_confidence="adjusted", CI present |
| A4 | Multiple behaviors evaluated | feature_set with 4 binary columns + 1 categorical (cardinality<=5) | behaviors_evaluated array with 5 entries, each with complete fields |
| A5 | Single binary behavior | feature_set with exactly 1 binary behavioral indicator | behavioral_impact.json with 1 behavior entry, all fields populated |

---

## Category B: Variance Coverage

| ID | Dimension | Value Tested | Test Name | Description | Expected Outcome |
|---|---|---|---|---|---|
| B1 | adjustment_method | none | No adjustment path | <5 covariates, no plan override | adjustment_method="none", adjusted_difference=null, causal_confidence="observational" |
| B2 | adjustment_method | propensity_stratification | Propensity path | >=5 covariates, no plan override | Quintile-weighted adjusted_difference, CI computed, causal_confidence="adjusted" |
| B3 | adjustment_method | covariate_matching | Matching path | Plan specifies covariate_matching, sufficient overlap | 1:1 matched adjusted_difference, CI computed |
| B4 | behavior_source | scope_defined | Scope-specified behaviors | scope_artifact lists specific behaviors | Only listed behaviors evaluated |
| B5 | behavior_source | feature_derived | Auto-derived behaviors | No explicit behavior list | Binary/low-cardinality columns auto-detected |
| B6 | causal_ambition | observational | Observational only | adjustment_method=none | No CI computation, causal_confidence="observational" |
| B7 | causal_ambition | adjusted | Adjusted estimates | adjustment_method != none | CI computed via bootstrap, causal_confidence="adjusted" |
| B8 | adjustment_method x behavior_source | propensity x scope_defined | Cross-dimension combo | Plan specifies behaviors + >=5 covariates | Scope behaviors evaluated with propensity adjustment |
| B9 | adjustment_method x behavior_source | none x feature_derived | Cross-dimension combo 2 | No plan, <5 covariates | Auto-derived behaviors with observational estimates only |

---

## Category C: Precondition Violations

| ID | Precondition Violated | Test Name | Description | Expected Outcome |
|---|---|---|---|---|
| C1 | cohort.json missing | No cohort artifact | cohort.json does not exist | HALT: "Upstream validation failed: cohort.json" |
| C2 | cohort.schema_version != "1.0" | Cohort schema mismatch | cohort.json has schema_version="2.0" | HALT: "Upstream validation failed: cohort.json -- schema_version mismatch." |
| C3 | cohort.population_size == 0 | Empty cohort | cohort.json population_size=0 | HALT: "Upstream validation failed: cohort.json -- population_size=0." |
| C4 | feature_set.json missing | No feature_set artifact | feature_set.json does not exist | HALT: "Upstream validation failed: feature_set.json" |
| C5 | feature_set.schema_version != "1.0" | Feature set schema mismatch | feature_set.json has schema_version="0.5" | HALT: "Upstream validation failed: feature_set.json -- schema_version mismatch." |
| C6 | feature_set.data_ref is null | Missing data_ref | feature_set.json data_ref=null | HALT: "Upstream validation failed: feature_set.json -- data_ref missing." |
| C7 | metric_result.json missing | No metric_result artifact | metric_result.json does not exist | HALT: "Upstream validation failed: metric_result.json" |
| C8 | metric_result.schema_version != "1.0" | Metric schema mismatch | metric_result.json has schema_version="3.0" | HALT: "Upstream validation failed: metric_result.json -- schema_version mismatch." |
| C9 | metric_result.metrics empty | Empty metrics array | metric_result.json metrics=[] | HALT: "Upstream validation failed: metric_result.json -- metrics array empty." |
| C10 | No behavioral indicators | No evaluable behaviors | feature_set has no binary/categorical columns | HALT: "No evaluable behaviors found..." (Step 1) |

---

## Category D: Edge Cases

| ID | Edge Case | Test Name | Description | Expected Outcome |
|---|---|---|---|---|
| D1 | Empty source (record_count==0) | Empty population | cohort.population_size == 0 | HALT Step 0: "Cannot estimate behavioral impact on empty population." |
| D2 | Single record | One observation | n_observations == 1 | WARN: "Single observation -- behavioral impact cannot be estimated." |
| D3 | All-null metric column | Null outcome metric | Outcome column entirely NULL | HALT: "Outcome metric column is entirely NULL." |
| D4 | Schema mismatch | Schema version wrong | Any upstream schema_version != "1.0" | HALT Step 0 with exact artifact name |
| D5 | No evaluable behaviors | Zero behaviors found | No binary/categorical features | HALT Step 1: "No evaluable behaviors found in feature_set." |
| D6 | Behavior with empty group | One-sided behavior | Behavior column all 1s or all 0s | WARN + skip: "Behavior '{name}' has zero members in {group} -- skipping." |
| D7 | Propensity non-convergence | Model fails to converge | LogisticRegression does not converge | WARN + fallback to "none": observational estimates only |
| D8 | Perfect separation | Propensity scores all 0/1 | Perfect linear separation in covariates | WARN: "Perfect separation -- covariate adjustment meaningless. Reporting observational." |
| D9 | Insufficient matched pairs | Matching <10 pairs | Poor covariate overlap in covariate_matching | WARN + fallback to propensity_stratification |
| D10 | Scope behavior not in feature_set | Missing scope behavior | scope_artifact specifies behavior not in feature_set columns | WARN: "Scope-defined behavior '{behavior}' not found in feature_set -- skipping" |
| D11 | All scope behaviors missing | All scope behaviors invalid | All scope-defined behaviors absent from feature_set | Cascades to HALT at Step 1: "No evaluable behaviors found" |

---

## Test Totals

| Category | Count |
|---|---|
| A: Happy Path | 5 |
| B: Variance Coverage | 9 |
| C: Precondition Violations | 10 |
| D: Edge Cases | 11 |
| **Total** | **35** |
