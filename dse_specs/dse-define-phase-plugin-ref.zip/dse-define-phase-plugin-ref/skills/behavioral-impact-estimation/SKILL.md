---
name: behavioral-impact-estimation
description: >
  Estimates the observed and adjusted impact of specific customer behaviors on a business
  outcome metric, producing behavioral_impact.json with per-behavior effect sizes, adjustment
  methods, and causal confidence levels. Activate after metric-computation when scope requires
  understanding which behaviors drive outcome differences; takes cohort + feature_set +
  metric_result.
inputs:
  - type: cohort
    description: "Full filtered population from cohort-extraction; provides population context, observation_window, and customer_id_ref for behavior segmentation"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref and features_applied drive behavior identification"
  - type: metric_result
    description: "Computed aggregate metrics from metric-computation; outcome_metric value serves as the baseline for impact comparison"
outputs:
  - type: behavioral_impact
    description: "Per-behavior impact estimates with observed and adjusted differences, confidence intervals, and causal confidence annotations"
can_follow: [metric-computation, feature-engineering]
can_precede: [roi-computation, causal-linkage-analysis, finding-assembly]
supports_loop: false
exit_conditions:
  - "behavioral_impact.json written with all evaluated behaviors and adjustment methods documented"
  - "every behavior entry has observed_difference, adjusted_difference (or null with justification), and causal_confidence"
---

## Overview

Metric-computation tells you *what the outcome value is*. Behavioral-impact-estimation tells you
*which specific behaviors are associated with better or worse outcomes* and by how much. This
skill segments the population by behavior presence/absence, computes outcome means for each
group, and optionally applies propensity score stratification or covariate matching to adjust
for confounders.

The skill does NOT establish causation — it produces observational or adjusted estimates with
explicit causal confidence annotations. If quasi-experimental analysis is needed, the
`upgrade_recommendation` in downstream `hypothesis-validation` triggers `causal-linkage-analysis`.

**What this skill produces:** `behavioral_impact.json` with a `behaviors_evaluated` array — each
entry contains the behavior name, behavior rate, outcome means with and without the behavior,
observed and adjusted differences, adjustment method, causal confidence level, 95% CI, and
group sizes.

---

## When to Activate

- A plan task node with `task_type: "behavioral_impact_estimation"` is the next unexecuted task
- `scope_artifact` implies understanding behavior-outcome relationships (e.g., "what drives repeat purchases?")
- `metric_result.json` exists and the analyst wants to understand which behaviors predict the outcome
- User explicitly requests "estimate behavioral impact", "which behaviors drive the metric", or "behavior analysis"
- `feature_set.features_applied` contains behavioral indicator columns (binary or categorical)

---

## Preconditions

What must be true before this skill begins:

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `metric_result.json` exists with `schema_version == "1.0"` and `metrics` array non-empty
- [ ] At least one behavioral indicator column is identifiable in feature_set (binary or low-cardinality categorical)
- [ ] `feature_set.data_ref` is accessible in the warehouse

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.10 (CI computation); numpy>=1.24 (propensity stratification); sklearn>=1.2 (LogisticRegression for propensity scores — optional)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; propensity scoring is local Python on summary statistics
- **Memory:** <500 MB (propensity model fitting on feature summaries)
- **Upstream Artifacts:** `cohort.json`, `feature_set.json` (data_ref, features_applied), `metric_result.json` (metrics, outcome baseline)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `adjustment_method` | `none` / `propensity_stratification` / `covariate_matching` | `none`: raw observed differences only; `propensity_stratification`: stratify by propensity quintiles and compute weighted average treatment effect; `covariate_matching`: 1:1 nearest-neighbor matching on covariates |
| `behavior_source` | `scope_defined` / `feature_derived` | `scope_defined`: behaviors specified in scope_artifact or plan; `feature_derived`: behaviors identified from binary/categorical features in feature_set |
| `causal_ambition` | `observational` / `adjusted` | `observational`: report raw differences only; `adjusted`: apply propensity or matching methods for confounder adjustment |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify adjustment_method:
  IF plan_node specifies adjustment_method → use specified
  ELIF feature_set has sufficient covariates (≥5 features) → "propensity_stratification"
  ELSE → "none"
  log: "adjustment_method={value}"

classify behavior_source:
  IF scope_artifact or plan_node specifies behaviors → "scope_defined"
  ELSE → "feature_derived"
  log: "behavior_source={value}"

classify causal_ambition:
  IF adjustment_method != "none" → "adjusted"
  ELSE → "observational"
  log: "causal_ambition={value}"

log: "Running behavioral-impact-estimation | adjustment={value} | source={value} | ambition={value}"
```

**Upstream Validation:**
```
load cohort.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json — schema_version mismatch."
assert population_size > 0
  IF not: HALT: "Upstream validation failed: cohort.json — population_size=0."

load feature_set.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json — schema_version mismatch."
assert data_ref is not null
  IF not: HALT: "Upstream validation failed: feature_set.json — data_ref missing."

load metric_result.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: metric_result.json — schema_version mismatch."
assert metrics array is non-empty
  IF not: HALT: "Upstream validation failed: metric_result.json — metrics array empty."
outcome_metric = metric_result.metrics[0].name
```

---

### Step 1 — Identify Behaviors to Evaluate

**Goal:** Build the list of behaviors to test for outcome impact.

**Pre-step assertion:** feature_set.features_applied is accessible.

**Actions:**
```
behaviors = []

IF behavior_source == "scope_defined":
  -- Extract behaviors from scope_artifact or plan task node
  -- Map each to a column in feature_set
  FOR each behavior in scope_defined_behaviors:
    IF behavior maps to a column in feature_set:
      behaviors.append(behavior)
    ELSE:
      WARN: "Scope-defined behavior '{behavior}' not found in feature_set — skipping"

ELIF behavior_source == "feature_derived":
  -- Scan feature_set.features_applied for binary/low-cardinality columns
  FOR each feature in feature_set.features_applied:
    Query: SELECT COUNT(DISTINCT {feature.name}) FROM {data_ref}
    IF cardinality == 2 (binary): behaviors.append(feature.name)
    ELIF cardinality <= 5 (low-card): behaviors.append(feature.name + " [categorical]")

IF len(behaviors) == 0:
  HALT: "No evaluable behaviors found. Verify feature_set contains binary/categorical
  behavioral indicators or scope specifies behaviors explicitly."

Log: "Behaviors identified | count={len(behaviors)} | source={behavior_source}"
```

**Checkpoint:**
> - [ ] PASS: ≥1 behavior identified for evaluation
> - [ ] HALT: no evaluable behaviors found
> - [ ] WARN: scope-defined behavior not in feature_set — skipped

---

### Step 2 — Compute Observed Differences

**Goal:** For each behavior, segment the population and compute outcome means for each group.

**Pre-step assertion:** behaviors list is non-empty; data_ref is accessible.

**Actions:**
```
behavior_results = []

FOR each behavior in behaviors:
  Execute SQL:
    SELECT
      {behavior} AS has_behavior,
      AVG({outcome_metric_column}) AS outcome_mean,
      COUNT(*) AS n
    FROM {feature_set.data_ref}
    GROUP BY {behavior}

  with_behavior = result where has_behavior = 1 (or TRUE)
  without_behavior = result where has_behavior = 0 (or FALSE)

  IF with_behavior.n == 0 OR without_behavior.n == 0:
    WARN: "Behavior '{behavior}' has zero members in one group — skipping"
    CONTINUE

  observed_difference = with_behavior.outcome_mean - without_behavior.outcome_mean
  behavior_rate = with_behavior.n / (with_behavior.n + without_behavior.n)

  behavior_results.append({
    behavior: behavior,
    behavior_rate: behavior_rate,
    outcome_with: with_behavior.outcome_mean,
    outcome_without: without_behavior.outcome_mean,
    observed_difference: observed_difference,
    n_with: with_behavior.n,
    n_without: without_behavior.n
  })

Log: "Observed differences computed | behaviors={len(behavior_results)}"
```

**Checkpoint:**
> - [ ] PASS: observed differences computed for ≥1 behavior
> - [ ] WARN: behavior skipped due to empty group

---

### Step 3 — Apply Adjustment Method

**Goal:** If causal_ambition is "adjusted", apply propensity or matching to reduce confounding.

**Pre-step assertion:** behavior_results populated from Step 2.

**Branch on `adjustment_method`:**

**IF `none`:**
```
FOR each result in behavior_results:
  result.adjusted_difference = null
  result.adjustment_method = "none"
  result.causal_confidence = "observational"
```

**IF `propensity_stratification`:**
```
FOR each behavior in behavior_results:
  -- Fit propensity model: P(behavior=1 | covariates)
  covariates = [f.name for f in feature_set.features_applied if f.name != behavior]
  Fit LogisticRegression: propensity_scores = model.predict_proba(covariates)[:,1]

  -- Stratify into quintiles
  quintiles = pd.qcut(propensity_scores, 5)
  adjusted_effects = []
  FOR each quintile:
    within_quintile_diff = mean(outcome | behavior=1, quintile) - mean(outcome | behavior=0, quintile)
    weight = n_in_quintile / total_n
    adjusted_effects.append(within_quintile_diff * weight)

  result.adjusted_difference = sum(adjusted_effects)
  result.adjustment_method = "propensity_stratification"
  result.causal_confidence = "adjusted"
```

**IF `covariate_matching`:**
```
FOR each behavior in behavior_results:
  -- 1:1 nearest-neighbor matching on covariates
  matched_pairs = match(treated=behavior_group, control=non_behavior_group, covariates)
  IF matched_pairs.n < 10:
    WARN: "Insufficient matches ({n}) for behavior '{behavior}' — falling back to propensity"
    -- fall through to propensity_stratification

  result.adjusted_difference = mean(matched_outcome_diff)
  result.adjustment_method = "covariate_matching"
  result.causal_confidence = "adjusted"
```

**CI computation for adjusted difference:**
```
FOR each result with adjusted_difference not null:
  se = bootstrap_se(adjusted_difference, n_iterations=1000)
  result.confidence_interval_95 = [adjusted_difference - 1.96*se, adjusted_difference + 1.96*se]
```

**Checkpoint:**
> - [ ] PASS: adjustment applied (or explicitly skipped with "none")
> - [ ] WARN: covariate_matching insufficient matches — fallback to propensity

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist behavioral_impact.json with full behavior evaluation results.

**Pre-step assertion:** All behavior results have observed and adjusted differences.

**Actions:**
```
Generate artifact_id: UUID v4

behaviors_evaluated = []
FOR each result in behavior_results:
  behaviors_evaluated.append({
    behavior: result.behavior,
    behavior_rate: result.behavior_rate,
    outcome_with_behavior_mean: result.outcome_with,
    outcome_without_behavior_mean: result.outcome_without,
    observed_difference: result.observed_difference,
    adjusted_difference: result.adjusted_difference,
    adjustment_method: result.adjustment_method,
    causal_confidence: result.causal_confidence,
    confidence_interval_95: result.confidence_interval_95,
    n_with_behavior: result.n_with,
    n_without_behavior: result.n_without
  })

Write behavioral_impact.json

Log: "behavioral_impact.json written | behaviors_evaluated={len(behaviors_evaluated)}"
```

**Checkpoint:**
> - [ ] PASS: behavioral_impact.json written; all 5 universal envelope fields present

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "behavioral-impact-estimation",
  "timestamp": "2026-04-10T14:45:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "behaviors_evaluated": [
    {
      "behavior": "second_purchase_within_30_days",
      "behavior_rate": 0.23,
      "outcome_with_behavior_mean": 487.50,
      "outcome_without_behavior_mean": 312.00,
      "observed_difference": 175.50,
      "adjusted_difference": 142.30,
      "adjustment_method": "propensity_stratification",
      "causal_confidence": "adjusted",
      "confidence_interval_95": [118.20, 166.40],
      "n_with_behavior": 1414,
      "n_without_behavior": 4734
    }
  ],
  "outcome_metric": "annual_spend",
  "causal_confidence_note": "observational estimates: directional only; adjusted: estimated; quasi-experimental: attributed"
}
```

**Write to:** `behavioral_impact.json` in the project directory.

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source (record_count == 0) | cohort.population_size == 0 | HALT Step 0: "Cannot estimate behavioral impact on empty population." |
| Single record | n_observations == 1 | WARN: "Single observation — behavioral impact cannot be estimated." |
| All-null metric column | outcome values entirely NULL | HALT: "Outcome metric column is entirely NULL." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact artifact name |
| No evaluable behaviors | no binary/categorical columns found | HALT Step 1: "No evaluable behaviors found in feature_set." |
| Behavior with empty group | one group has 0 members | WARN + skip: "Behavior '{name}' has zero members in {group} — skipping." |
| Propensity model fails to converge | LogisticRegression non-convergence | WARN + fallback to "none": "Propensity model failed — reporting observational estimates only." |
| Perfect separation in propensity | propensity scores all 0 or all 1 | WARN: "Perfect separation — covariate adjustment meaningless. Reporting observational." |
| Matching produces <10 pairs | insufficient covariate overlap | WARN + fallback to propensity_stratification |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `behavioral_impact.json` exists with all 5 universal envelope fields
- [ ] Every behavior entry has `observed_difference` (never null)
- [ ] `adjusted_difference` is either a numeric value or explicitly null with `adjustment_method == "none"`
- [ ] `causal_confidence` is one of: "observational", "adjusted", "quasi-experimental"
- [ ] `outcome_metric` matches the metric name from `metric_result.json`

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `behavioral_impact.json` written and validates against terminal artifact spec
- [ ] ≥1 behavior evaluated with complete results
- [ ] `causal_confidence_note` explains each confidence level
- [ ] For adjusted estimates: adjustment_method is documented for each behavior
- [ ] CI bounds are finite and ordered: lower <= adjusted_difference <= upper (when adjusted)
- [ ] Downstream `roi-computation` Step 0 can load and validate `behavioral_impact.json`

---

## Scope Boundary

This skill does NOT:
- Establish causal relationships → handled by `causal-linkage-analysis`
- Monetize impact differences into ROI → handled by `roi-computation`
- Compute the baseline metric values → handled by `metric-computation`
- Compare groups with formal statistical tests (p-values) → handled by `statistical-comparison`
- Engineer behavioral indicator features → handled by `feature-engineering`

---

## Downstream

Run after this skill completes:
1. **`roi-computation`** — reads `behavioral_impact.behaviors_evaluated` to monetize adjusted differences; uses `causal_confidence` to qualify the ROI estimate
2. **`causal-linkage-analysis`** — may be triggered if `causal_confidence == "adjusted"` and quasi-experimental upgrade is warranted
3. **`finding-assembly`** — reads `behavioral_impact.behaviors_evaluated` to include behavior-outcome findings in the narrative
