---
name: roi-computation
description: >
  Quantifies the business value of observed behavioral or analytical differences by computing
  revenue impact, cost per outcome, and ROI ratio. Accepts comparison_result OR behavioral_impact
  OR interval_result OR causal_result plus metric_result as inputs. The impact_qualifier
  (directional/estimated/attributed) is inherited from upstream causal_confidence — this skill
  never upgrades confidence. Activate after any statistical or causal analysis skill produces
  results that can be monetized.
inputs:
  - type: comparison_result
    description: "Statistical comparison output with effect sizes and p-values"
    optional: true
  - type: behavioral_impact
    description: "Behavioral impact estimates with adjustment methods"
    optional: true
  - type: interval_result
    description: "Stickiness or interval analysis results"
    optional: true
  - type: causal_result
    description: "Causal linkage analysis results with validated assumptions"
    optional: true
  - type: metric_result
    description: "Computed aggregate metrics with confidence intervals"
outputs:
  - type: roi_result
    description: "Revenue impact, cost per outcome, ROI ratio with confidence intervals and impact qualifier"
can_follow: [statistical-comparison, behavioral-impact-estimation, retention-curve-analysis, causal-linkage-analysis, stickiness-interval-analysis]
can_precede: [finding-assembly]
supports_loop: false
exit_conditions:
  - "roi_result.json written with revenue_impact, roi_ratio, and inherited impact_qualifier"
  - "confidence intervals computed for revenue impact"
---

## Overview

This is the valuation step of the analytical pipeline. It takes the *what happened* (from
comparison, behavioral impact, interval, or causal analysis) and translates it into *what it's
worth* in business terms.

**Critical design constraint:** This skill NEVER upgrades the causal confidence of its upstream
input. If the upstream evidence is observational (comparison_result without causal validation),
the ROI is labeled "directional." If adjusted (behavioral_impact with propensity matching), it's
"estimated." Only quasi-experimental or causal evidence produces "attributed" ROI. This prevents
stakeholders from treating correlational findings as proven ROI.

**Impact qualifier mapping from upstream:**
- `comparison_result` with no causal validation --> "directional" (association only)
- `behavioral_impact` with `adjustment_method != "none"` --> "estimated" (adjusted)
- `behavioral_impact` with `causal_confidence == "quasi-experimental"` --> "attributed"
- `causal_result` --> "attributed"
- `interval_result` --> inherits from upstream causal note, default "directional"

**What this skill produces:** `roi_result.json` with revenue impact, cost per outcome, ROI ratio,
confidence intervals, and inherited impact qualifier.

---

## When to Activate

- Any upstream analytical skill has produced results that can be monetized (effect sizes, differences, impact estimates)
- `scope_artifact.analytical_pattern` includes ROI, revenue impact, or business value quantification
- User explicitly requests "ROI", "revenue impact", "business value", or "monetize the findings"
- `hypothesis_result` or `comparison_result` contains significant effects worth quantifying

---

## Preconditions

- [ ] At least one upstream analytical artifact exists: `comparison_result.json`, `behavioral_impact.json`, `interval_result.json`, or `causal_result.json`
- [ ] Each upstream artifact has `schema_version == "1.0"`
- [ ] `metric_result.json` exists with `schema_version == "1.0"` providing population-level metrics
- [ ] Effect sizes or differences in upstream artifacts are statistically significant or otherwise actionable

---

## Prerequisites

### Library Dependencies
```
# Tier 3: scipy>=1.10 (CI computation); numpy>=1.24 (revenue impact calculations)
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `upstream_evidence_type` | `observational` / `adjusted` / `quasi_experimental` / `causal` | Determines the impact_qualifier: observational-->"directional", adjusted-->"estimated", quasi_experimental/causal-->"attributed" |
| `computation_basis` | `comparison_result` / `behavioral_impact` / `interval_result` / `causal_result` | Each upstream type provides different effect metrics: comparison gives group_means + effect_size; behavioral gives adjusted_difference; interval gives trajectory metrics; causal gives effect_estimate |
| `multiple_upstream` | `single` / `multiple` | `single`: compute ROI from one upstream; `multiple`: compute ROI independently from each upstream -- do NOT combine or average across upstream types |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:**
```
classify upstream_evidence_type:
  IF causal_result.json exists → "causal"
  ELIF behavioral_impact.json exists AND causal_confidence == "quasi-experimental" → "quasi_experimental"
  ELIF behavioral_impact.json exists AND adjustment_method != "none" → "adjusted"
  ELSE → "observational"

classify computation_basis:
  enumerate available upstream artifacts → list of basis types

classify multiple_upstream:
  IF len(computation_basis) > 1 → "multiple"
  ELSE → "single"

log: "Running roi-computation | evidence={value} | basis={value} | multiple={value}"
```

**Upstream Validation:**
```
upstream_count = 0
FOR each upstream type in [comparison_result, behavioral_impact, interval_result, causal_result]:
  IF {type}.json exists:
    load {type}.json; assert schema_version == "1.0"
    upstream_count += 1

IF upstream_count == 0:
  HALT: "No upstream analytical artifacts found. At least one required."

load metric_result.json; assert schema_version == "1.0"
  IF not found: WARN: "metric_result.json not found; population_size and metric_value must be provided manually."

# Significance gate
FOR each upstream artifact loaded:
  IF upstream artifact contains p_value > 0.10 AND effect_size < 0.2:
    WARN: "Upstream effect is not statistically significant (p={p_value}, d={effect_size}). ROI estimate should be treated as directional only."
    SET impact_qualifier = "not_significant"
```

---

### Step 1 -- Identify Available Upstream

**Goal:** Enumerate which analytical result artifacts exist and validate each.

**Actions:**
```
available_upstream = []

IF comparison_result.json exists:
  validate effect_size not null, p_value not null
  available_upstream.append("comparison_result")

IF behavioral_impact.json exists:
  validate adjusted_difference not null
  available_upstream.append("behavioral_impact")

IF interval_result.json exists:
  validate trajectory_metrics not null
  available_upstream.append("interval_result")

IF causal_result.json exists:
  validate effect_estimate not null, causal_confidence not null
  available_upstream.append("causal_result")

IF len(available_upstream) == 0:
  HALT: "No valid upstream artifacts with required fields."
```

---

### Step 2 -- Extract Effect Metrics

**Goal:** From each upstream type, extract the relevant effect magnitude and confidence interval.

**Actions:**
```
effects = []

FOR each basis in available_upstream:
  IF basis == "comparison_result":
    effect_magnitude = group_a_mean - group_b_mean  -- or effect_size * pooled_sd
    effect_ci = comparison_result.ci_95
    effect_unit = comparison_result.metric_name

  ELIF basis == "behavioral_impact":
    effect_magnitude = behavioral_impact.adjusted_difference
    effect_ci = behavioral_impact.ci_95
    effect_unit = behavioral_impact.outcome_metric

  ELIF basis == "interval_result":
    effect_magnitude = interval_result.trajectory_difference
    effect_ci = interval_result.ci_95
    effect_unit = interval_result.metric_name

  ELIF basis == "causal_result":
    effect_magnitude = causal_result.effect_estimate
    effect_ci = causal_result.effect_estimate_ci_95
    effect_unit = causal_result.effect_unit

  effects.append({basis, effect_magnitude, effect_ci, effect_unit})
```

---

### Step 3 -- Compute Revenue Impact

**Goal:** Translate effect magnitude into revenue terms.

**Actions:**
```
FOR each effect in effects:
  population_size = metric_result.record_count OR scope_artifact.population_size
  metric_value = derive monetary value per unit of effect_unit

  revenue_impact = effect.effect_magnitude * population_size * metric_value

  -- Propagate CI
  revenue_impact_ci_lower = effect.effect_ci[0] * population_size * metric_value
  revenue_impact_ci_upper = effect.effect_ci[1] * population_size * metric_value

  IF revenue_impact_ci_lower > revenue_impact_ci_upper:
    swap(revenue_impact_ci_lower, revenue_impact_ci_upper)

  effect.revenue_impact = revenue_impact
  effect.revenue_impact_ci_95 = [revenue_impact_ci_lower, revenue_impact_ci_upper]
```

---

### Step 4 -- Compute ROI Ratio

**Goal:** Compute cost per outcome and ROI ratio.

**Actions:**
```
FOR each effect in effects:
  cost = scope_artifact.program_cost OR user_provided_cost
  IF cost is null:
    WARN: "No program cost available; ROI ratio cannot be computed. Setting to null."
    effect.roi_ratio = null
    effect.cost_per_outcome = null
    CONTINUE

  effect.cost_per_outcome = cost / (effect.effect_magnitude * population_size)
  effect.roi_ratio = effect.revenue_impact / cost

  IF effect.roi_ratio < 0:
    WARN: "Negative ROI detected ({roi_ratio}). Verify input signs."
```

---

### Step 5 -- Assign Impact Qualifier

**Goal:** Inherit from upstream causal_confidence; never upgrade.

**Actions:**
```
FOR each effect in effects:
  IF effect.basis == "causal_result":
    impact_qualifier = "attributed"
  ELIF effect.basis == "behavioral_impact":
    IF behavioral_impact.causal_confidence == "quasi-experimental":
      impact_qualifier = "attributed"
    ELIF behavioral_impact.adjustment_method != "none":
      impact_qualifier = "estimated"
    ELSE:
      impact_qualifier = "directional"
  ELIF effect.basis == "interval_result":
    IF interval_result has causal_note:
      impact_qualifier = map_causal_note(interval_result.causal_note)
    ELSE:
      impact_qualifier = "directional"
  ELSE:
    impact_qualifier = "directional"

  -- Generate interpretation note
  IF impact_qualifier == "directional":
    effect.interpretation_note = "directional: observational association only — not proven causation"
  ELIF impact_qualifier == "estimated":
    effect.interpretation_note = "estimated: adjusted for confounders — directional magnitude, not proven causation"
  ELIF impact_qualifier == "attributed":
    effect.interpretation_note = "attributed: quasi-experimental or causal evidence supports this estimate"

  PASS: "Impact qualifier assigned: {impact_qualifier}"
```

---

### Step 6 -- Write Terminal Artifact

```
FOR each effect in effects:
  Generate artifact_id  -- NEW UUID

  Write roi_result.json (one per computation_basis, or consolidated if single upstream)

  Log: "roi_result.json written | basis={basis} | impact_qualifier={impact_qualifier} | revenue_impact={revenue_impact}"
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "roi-computation",
  "timestamp": "2026-04-10T18:00:00Z",
  "record_count": 1,
  "artifact_id": "{uuid}",
  "upstream_evidence_type": "adjusted",
  "impact_qualifier": "estimated",
  "metric_name": "repeat_purchase_rate",
  "revenue_impact": 2340000,
  "revenue_impact_ci_95": [1850000, 2830000],
  "cost_per_outcome": 12.50,
  "roi_ratio": 3.2,
  "computation_basis": "behavioral_impact",
  "period": "2025-01-01 to 2025-06-30",
  "population_size": 15000,
  "interpretation_note": "estimated: adjusted for propensity — directional magnitude, not proven causation"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | No upstream artifacts found | HALT Step 0: "No upstream analytical artifacts found." |
| Single record | population_size == 1 | WARN: "Population size of 1 — revenue impact equals single-unit effect. Verify input." |
| All-null dimension | effect_magnitude is null across all upstream | HALT Step 2: "No valid effect magnitudes extracted." |
| Schema mismatch | schema_version != "1.0" on any upstream | HALT Step 0: "Schema mismatch on {artifact}." |
| No cost available | program_cost is null | WARN Step 4: "ROI ratio set to null — no cost provided." Proceed with revenue_impact only. |
| Negative effect magnitude | effect_magnitude < 0 | PASS: Proceed — negative ROI is valid (represents loss). Add interpretation note. |
| CI crosses zero | revenue_impact_ci includes 0 | WARN: "Revenue impact CI crosses zero — effect may not be economically significant." |
| Multiple upstream conflict | Different upstream types give directionally different effects | WARN: "Upstream effects conflict in direction. Compute each independently — do not average." |

---

## Postconditions

- [ ] `roi_result.json` exists with all 5 universal envelope fields
- [ ] `impact_qualifier` matches upstream causal confidence (never upgraded)
- [ ] `revenue_impact_ci_95` is computed and directionally consistent
- [ ] `interpretation_note` accurately reflects the qualifier meaning

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] Impact qualifier correctly inherited from upstream (never upgraded)
- [ ] Revenue impact CI propagated from upstream effect CI
- [ ] ROI ratio uses actual program cost (not fabricated)
- [ ] Interpretation note warns about causal limitations when qualifier is "directional" or "estimated"

---

## Scope Boundary

This skill does NOT:
- Run statistical comparison --> handled by `statistical-comparison`
- Estimate behavioral impact --> handled by `behavioral-impact-estimation`
- Perform causal analysis --> handled by `causal-linkage-analysis`
- Assemble findings --> handled by `finding-assembly`
- Compute aggregate metrics --> handled by `metric-computation`

---

## Downstream

1. **`finding-assembly`** -- reads `roi_result` to include monetized findings with impact qualifier annotation
