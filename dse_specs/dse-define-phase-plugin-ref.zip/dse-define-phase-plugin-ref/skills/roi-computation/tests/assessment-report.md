# Assessment Report: roi-computation (Skill 9)

**Assessed:** 2026-04-10
**Skill Version:** schema_version 1.0
**Assessor:** DSE Skill Tester

---

## Test Inventory

| Category | Count | Description |
|---|---|---|
| A (Happy Path) | 2 | Valid inputs producing expected roi_result |
| B (Variance) | 7 | One per variance dimension value |
| C (Precondition Violations) | 4 | One per precondition |
| D (Edge Cases) | 8 | One per edge case row |
| **Total** | **21** | |

---

## Category A -- Happy Path

### A-1: Single comparison_result with metric_result and program cost

**Input:** comparison_result.json (schema_version=1.0, effect_size=0.45, p_value=0.003, group_a_mean=0.72, group_b_mean=0.665, ci_95=[0.02, 0.09]), metric_result.json (schema_version=1.0, record_count=15000), scope_artifact.program_cost=500000

**Walkthrough:**
- Step 0: upstream_evidence_type="observational", computation_basis=["comparison_result"], multiple_upstream="single". Upstream count=1, passes. metric_result loads OK.
- Step 1: comparison_result validated (effect_size not null, p_value not null). available_upstream=["comparison_result"].
- Step 2: effect_magnitude = 0.72 - 0.665 = 0.055, effect_ci = [0.02, 0.09], effect_unit from metric_name.
- Step 3: revenue_impact = 0.055 * 15000 * metric_value. CI propagated.
- Step 4: cost_per_outcome = 500000 / (0.055 * 15000). roi_ratio = revenue_impact / 500000.
- Step 5: impact_qualifier = "directional". interpretation_note set correctly.
- Step 6: roi_result.json written with all 5 envelope fields (schema_version, skill_name, timestamp, record_count, artifact_id).

**Envelope fields:** schema_version, skill_name, timestamp, record_count, artifact_id -- all present in terminal artifact spec.

**Result:** ✅ PASS

---

### A-2: causal_result with metric_result and program cost

**Input:** causal_result.json (schema_version=1.0, effect_estimate=0.08, causal_confidence="quasi-experimental", effect_estimate_ci_95=[0.04, 0.12], effect_unit="repeat_purchase_rate"), metric_result.json (schema_version=1.0, record_count=20000), scope_artifact.program_cost=300000

**Walkthrough:**
- Step 0: upstream_evidence_type="causal", computation_basis=["causal_result"], multiple_upstream="single".
- Step 1: causal_result validated (effect_estimate not null, causal_confidence not null).
- Step 2: effect_magnitude=0.08, effect_ci=[0.04, 0.12].
- Step 3: revenue_impact computed, CI propagated.
- Step 4: roi_ratio computed.
- Step 5: impact_qualifier="attributed" (causal_result always maps to "attributed"). interpretation_note="attributed: quasi-experimental or causal evidence supports this estimate".
- Step 6: Written with 5 envelope fields.

**Result:** ✅ PASS

---

## Category B -- Variance Dimensions

### B-1: upstream_evidence_type = "observational"

**Input:** comparison_result.json only (no causal validation).

**Walkthrough:** Step 0 classifies as "observational". Step 5 assigns impact_qualifier="directional". interpretation_note warns about observational association only.

**Result:** ✅ PASS

---

### B-2: upstream_evidence_type = "adjusted"

**Input:** behavioral_impact.json with adjustment_method="propensity_matching", causal_confidence="adjusted".

**Walkthrough:** Step 0 classifies as "adjusted". Step 5 assigns impact_qualifier="estimated". interpretation_note includes "adjusted for confounders".

**Result:** ✅ PASS

---

### B-3: upstream_evidence_type = "quasi_experimental"

**Input:** behavioral_impact.json with causal_confidence="quasi-experimental".

**Walkthrough:** Step 0 classifies as "quasi_experimental". Step 5 assigns impact_qualifier="attributed".

**Result:** ✅ PASS

---

### B-4: upstream_evidence_type = "causal"

**Input:** causal_result.json exists.

**Walkthrough:** Step 0 classifies as "causal". Step 5 assigns impact_qualifier="attributed". Covered by A-2.

**Result:** ✅ PASS

---

### B-5: computation_basis = "behavioral_impact"

**Input:** behavioral_impact.json with adjusted_difference=0.035, adjustment_method="propensity_matching".

**Walkthrough:** Step 2 extracts effect_magnitude from adjusted_difference field. Step 3 computes revenue_impact. Step 5 assigns "estimated".

**Result:** ✅ PASS

---

### B-6: computation_basis = "interval_result"

**Input:** interval_result.json with trajectory_metrics, trajectory_difference=0.02.

**Walkthrough:** Step 2 extracts effect_magnitude from trajectory_difference. Step 5 checks for causal_note; if absent, defaults to "directional".

**Result:** ✅ PASS

---

### B-7: multiple_upstream = "multiple"

**Input:** comparison_result.json AND behavioral_impact.json both present.

**Walkthrough:** Step 0 classifies multiple_upstream="multiple". Step 2 extracts effects from each independently. Step 3 computes revenue_impact independently for each. Step 5 assigns separate impact_qualifiers per basis. Step 6 writes separate roi_result per basis or consolidated.

**Spec says:** "compute ROI independently from each upstream -- do NOT combine or average across upstream types."

**Result:** ✅ PASS

---

## Category C -- Precondition Violations

### C-1: No upstream analytical artifacts exist

**Precondition violated:** "At least one upstream analytical artifact exists"

**Walkthrough:** Step 0 upstream_count=0. HALT: "No upstream analytical artifacts found. At least one required."

**Result:** ✅ PASS -- Step 0 correctly HALTs.

---

### C-2: Upstream artifact has schema_version != "1.0"

**Precondition violated:** "Each upstream artifact has schema_version == '1.0'"

**Input:** comparison_result.json with schema_version="2.0".

**Walkthrough:** Step 0 loads comparison_result.json and asserts schema_version=="1.0". Assertion fails.

**Analysis:** The Step 0 pseudocode says `assert schema_version == "1.0"` but does not explicitly specify a HALT message for this case. However, the Edge Cases table specifies: "Schema mismatch | schema_version != '1.0' on any upstream | HALT Step 0: 'Schema mismatch on {artifact}.'"

**Result:** ✅ PASS -- HALT triggered via edge case logic.

---

### C-3: metric_result.json missing

**Precondition violated:** "metric_result.json exists with schema_version == '1.0'"

**Input:** comparison_result.json exists, but no metric_result.json.

**Walkthrough:** Step 0: metric_result not found triggers WARN (not HALT): "metric_result.json not found; population_size and metric_value must be provided manually."

**Analysis:** The precondition states metric_result.json is required, but Step 0 only WARNs rather than HALTing. This is a design choice allowing manual override. However, if population_size and metric_value are not provided manually, Step 3 would fail silently (no explicit HALT for that case).

**Result:** ⚠️ WARN -- Precondition says "required" but workflow only WARNs. Step 3 has no explicit HALT if population_size/metric_value are unavailable after the WARN. Potential for downstream NullPointerError-equivalent.

---

### C-4: Effect sizes not statistically significant or actionable

**Precondition violated:** "Effect sizes or differences in upstream artifacts are statistically significant or otherwise actionable"

**Input:** comparison_result.json with p_value=0.85, effect_size=0.02.

**Walkthrough:** Step 0 does NOT check for statistical significance. Step 1 validates effect_size not null and p_value not null -- both exist, so it passes. No HALT.

**Analysis:** This precondition is not enforced by any HALT in the workflow. The skill will compute ROI on non-significant effects without any HALT or even WARN.

**Result:** 🚫 Critical -- Precondition "Effect sizes or differences are statistically significant or otherwise actionable" is listed but NOT enforced in any workflow step. A non-significant p_value=0.85 would produce an ROI result with no warning, potentially misleading stakeholders.

---

## Category D -- Edge Cases

### D-1: Empty input (no upstream artifacts)

**Edge case:** "No upstream artifacts found"

**Walkthrough:** Step 0: upstream_count=0, HALT: "No upstream analytical artifacts found."

**Result:** ✅ PASS

---

### D-2: Single record (population_size == 1)

**Edge case:** "population_size == 1"

**Walkthrough:** Step 3: revenue_impact = effect_magnitude * 1 * metric_value. The edge case table says WARN: "Population size of 1 -- revenue impact equals single-unit effect. Verify input."

**Analysis:** Step 3 pseudocode does NOT include this WARN check. The edge case table documents the expected behavior, but the workflow steps do not implement it.

**Result:** ⚠️ WARN -- Edge case documented in table but not implemented in Step 3 pseudocode. Missing population_size==1 check.

---

### D-3: All-null dimension (effect_magnitude null across all upstream)

**Edge case:** "effect_magnitude is null across all upstream"

**Walkthrough:** Step 1 would catch null effect_size/adjusted_difference during validation. Step 1 HALT: "No valid upstream artifacts with required fields."

**Result:** ✅ PASS

---

### D-4: Schema mismatch

**Edge case:** "schema_version != '1.0' on any upstream"

**Walkthrough:** Step 0 assert catches this. HALT: "Schema mismatch on {artifact}."

**Result:** ✅ PASS

---

### D-5: No cost available

**Edge case:** "program_cost is null"

**Walkthrough:** Step 4: cost is null, WARN: "ROI ratio set to null -- no cost provided." roi_ratio and cost_per_outcome set to null. revenue_impact still computed.

**Result:** ✅ PASS

---

### D-6: Negative effect magnitude

**Edge case:** "effect_magnitude < 0"

**Walkthrough:** Step 3: revenue_impact will be negative. Step 4: roi_ratio will be negative, triggers WARN: "Negative ROI detected." Edge case says: "Proceed -- negative ROI is valid (represents loss). Add interpretation note."

**Analysis:** Step 4 warns on negative roi_ratio. Step 5 does NOT have explicit logic to add an interpretation note for negative effects -- the interpretation note is based solely on impact_qualifier.

**Result:** ⚠️ WARN -- Edge case says "Add interpretation note" for negative effect, but Step 5 only generates qualifier-based notes, not negative-effect notes. Minor gap.

---

### D-7: CI crosses zero

**Edge case:** "revenue_impact_ci includes 0"

**Walkthrough:** Step 3 computes CI. Edge case says WARN: "Revenue impact CI crosses zero -- effect may not be economically significant."

**Analysis:** Step 3 pseudocode does NOT include a CI-crosses-zero check. The edge case is documented but not implemented in the workflow.

**Result:** ⚠️ WARN -- CI-crosses-zero check documented in edge case table but missing from Step 3 pseudocode.

---

### D-8: Multiple upstream conflict

**Edge case:** "Different upstream types give directionally different effects"

**Walkthrough:** Edge case says WARN: "Upstream effects conflict in direction. Compute each independently -- do not average."

**Analysis:** No step in the workflow explicitly checks for directional conflict across multiple upstream types. The skill computes independently by default (variance dimension multiple_upstream), but the WARN for conflict detection is not implemented.

**Result:** ⚠️ WARN -- Conflict detection documented in edge case table but not implemented in any workflow step.

---

## Postcondition Verification

| Postcondition | Status | Notes |
|---|---|---|
| roi_result.json exists with all 5 universal envelope fields | ✅ PASS | schema_version, skill_name, timestamp, record_count, artifact_id all present in terminal artifact spec |
| impact_qualifier matches upstream causal confidence (never upgraded) | ✅ PASS | Step 5 logic correctly maps each upstream type; never upgrades |
| revenue_impact_ci_95 computed and directionally consistent | ✅ PASS | Step 3 includes swap logic for directional consistency |
| interpretation_note accurately reflects qualifier meaning | ✅ PASS | Three distinct notes for directional/estimated/attributed |

---

## Quality Bar Verification

| Quality Item | Status | Notes |
|---|---|---|
| Validates against terminal artifact spec | ✅ PASS | All required fields present |
| Impact qualifier correctly inherited (never upgraded) | ✅ PASS | Classification logic is sound |
| Revenue impact CI propagated from upstream | ✅ PASS | Step 3 formula correct |
| ROI ratio uses actual program cost (not fabricated) | ✅ PASS | Step 4 reads from scope_artifact or user input |
| Interpretation note warns about causal limitations | ✅ PASS | "directional" and "estimated" notes include limitation language |

---

## Summary

| Category | Total | Pass | Warn | Fail | Critical |
|---|---|---|---|---|---|
| A (Happy Path) | 2 | 2 | 0 | 0 | 0 |
| B (Variance) | 7 | 7 | 0 | 0 | 0 |
| C (Precondition) | 4 | 2 | 1 | 0 | 1 |
| D (Edge Cases) | 8 | 4 | 4 | 0 | 0 |
| **Total** | **21** | **15** | **5** | **0** | **1** |

---

## Critical Issues

1. **C-4 (Precondition not enforced):** The precondition "Effect sizes or differences in upstream artifacts are statistically significant or otherwise actionable" is declared but never checked in any workflow step. Non-significant effects (e.g., p=0.85) will produce ROI results without HALT or WARN, potentially misleading stakeholders into acting on noise.

**Recommended fix:** Add a significance/actionability gate in Step 1 -- if p_value > 0.10 and effect_size < 0.2, WARN: "Upstream effect is not statistically significant. ROI estimate is unreliable." Or remove the precondition if the skill intentionally allows ROI on non-significant effects.

---

## Warnings

1. **C-3:** metric_result.json precondition says "required" but workflow only WARNs. No downstream HALT if manual values aren't provided.
2. **D-2:** population_size==1 edge case documented but not implemented in Step 3.
3. **D-6:** Negative-effect interpretation note documented but not generated by Step 5.
4. **D-7:** CI-crosses-zero check documented in edge case table but not implemented in Step 3.
5. **D-8:** Multiple-upstream directional conflict detection documented but not implemented.
