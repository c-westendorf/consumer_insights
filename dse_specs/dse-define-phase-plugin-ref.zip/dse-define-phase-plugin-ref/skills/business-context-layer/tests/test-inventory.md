# Test Inventory: business-context-layer

**Skill Under Test:** `business-context-layer`
**Date:** 2026-04-10
**Tester:** DSE Skill Tester (automated)

---

## Category A -- Happy Path Tests

| ID | Test Name | Description | Variance Combo | Expected Outcome |
|---|---|---|---|---|
| A-1 | Standard catalog run | profiled_schema with 8 columns, scope_artifact with matching business terms, data catalog available, single_hop lineage, stable definitions | catalog_available / single_hop / stable | context_map.json written; definitions populated from catalog COMMENTs; data_lineage single-hop; known_definition_changes is empty array |
| A-2 | Inferred with multi-hop and definition changes | profiled_schema with 5 columns, no catalog, multi_hop lineage via INFORMATION_SCHEMA, scope_artifact documents a definition change | inferred / multi_hop / has_changes | context_map.json written; definitions inferred via LLM; data_lineage traces through views; known_definition_changes populated |
| A-3 | Minimal valid run | profiled_schema with 1 scope-relevant column, inferred definitions, single_hop, stable | inferred / single_hop / stable | context_map.json written with 1 definition, 1 lineage entry, empty changes array; WARN for single column |

---

## Category B -- Variance Coverage Tests

### Dimension: definition_source (2 values required)

| ID | Test Name | Dimension Value | Description | Expected Outcome |
|---|---|---|---|---|
| B-1a | Catalog definitions | catalog_available | Column COMMENT metadata accessible in INFORMATION_SCHEMA | Definitions pulled from COMMENT; no LLM inference |
| B-1b | Inferred definitions | inferred | No catalog or COMMENT metadata available | Definitions derived from column name, dtype, sample_values via LLM reasoning |

### Dimension: lineage_depth (2 values required)

| ID | Test Name | Dimension Value | Description | Expected Outcome |
|---|---|---|---|---|
| B-2a | Single-hop lineage | single_hop | No VIEW_TABLE_USAGE available | Each lineage entry source_table = profiled_schema.table_name |
| B-2b | Multi-hop lineage | multi_hop | INFORMATION_SCHEMA.VIEW_TABLE_USAGE accessible | Lineage traces through view dependency chain to ultimate source table |

### Dimension: definition_stability (2 values required)

| ID | Test Name | Dimension Value | Description | Expected Outcome |
|---|---|---|---|---|
| B-3a | Stable definitions | stable | No definition changes in scope_artifact.business_context | known_definition_changes is empty array; log confirms stable |
| B-3b | Has definition changes | has_changes | scope_artifact.business_context contains documented definition shifts | known_definition_changes populated with term, changed_on, old_definition, new_definition |

### Cross-Dimension Combinations (worst-case)

| ID | Test Name | Combo | Expected Outcome |
|---|---|---|---|
| B-4 | All-inferred, multi-hop, has-changes | inferred / multi_hop / has_changes | Most complex path; all three arrays populated; no catalog fallback errors |
| B-5 | Catalog, single-hop, stable | catalog_available / single_hop / stable | Simplest path; clean definitions from catalog; minimal lineage; no changes |

---

## Category C -- Precondition Violation Tests (PASS only if HALT fires)

| ID | Test Name | Violated Precondition | Input State | Expected Outcome |
|---|---|---|---|---|
| C-1 | Missing profiled_schema | profiled_schema.json does not exist | No profiled_schema.json on disk | HALT: upstream validation failure |
| C-2 | Schema version mismatch (profiled_schema) | schema_version != "1.0" in profiled_schema | profiled_schema.json with schema_version "2.0" | HALT: "Upstream validation failed: profiled_schema.json -- schema_version mismatch." |
| C-3 | Empty columns array | columns array is empty in profiled_schema | profiled_schema.json with columns: [] | HALT: "Upstream validation failed: profiled_schema.json -- columns array empty." |
| C-4 | Missing scope_artifact | scope_artifact.json does not exist | No scope_artifact.json on disk | HALT: upstream validation failure |
| C-5 | Schema version mismatch (scope_artifact) | schema_version != "1.0" in scope_artifact | scope_artifact.json with schema_version "0.9" | HALT: "Upstream validation failed: scope_artifact.json -- schema_version mismatch." |
| C-6 | No mappable columns | At least one column mappable to business term | All columns are cryptic (col_1, col_2, ...) with no relation to scope terms | WARN (not HALT) -- skill proceeds but definitions array empty. Note: spec says precondition requires mappable columns but Step 1 only issues WARN for zero definitions |

---

## Category D -- Edge Case Tests

| ID | Test Name | Edge Case (from spec table) | Input State | Expected Outcome |
|---|---|---|---|---|
| D-1 | Empty source | profiled_schema.columns is empty | profiled_schema with columns: [] | HALT Step 0: "No columns to map." (overlaps C-3) |
| D-2 | Single column | Only 1 column in schema | profiled_schema with 1 column matching scope | WARN: "Single column -- context map is minimal." Context_map.json still written |
| D-3 | All-null columns | All columns have 100% null rate | profiled_schema where every column null_rate = 1.0 | WARN: "All columns are entirely NULL -- definitions may be unreliable." Proceeds with definitions |
| D-4 | Schema mismatch | schema_version != "1.0" | profiled_schema with schema_version "1.1" | HALT Step 0 with exact artifact name (overlaps C-2) |
| D-5 | No catalog available | INFORMATION_SCHEMA COMMENT returns empty | definition_source classified as catalog_available but COMMENT query returns null | WARN + fallback to inferred definitions |
| D-6 | Cryptic column name | Column name like "col_42" | profiled_schema with column "col_42" among others | WARN: "Column 'col_42' has no discernible business meaning -- excluding from context map." |
| D-7 | Definition change date outside scope | change.date before scope timeframe.start | known_definition_change with date 2020-01-01, scope starts 2025-01-01 | WARN: "Definition change on 2020-01-01 is outside scope window -- included for context but may not affect current analysis." |

---

## Test Count Summary

| Category | Count |
|---|---|
| A -- Happy Path | 3 |
| B -- Variance Coverage | 7 |
| C -- Precondition Violations | 6 |
| D -- Edge Cases | 7 |
| **Total** | **23** |
