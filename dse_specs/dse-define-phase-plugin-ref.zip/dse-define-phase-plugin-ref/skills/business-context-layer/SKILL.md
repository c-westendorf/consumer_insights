---
name: business-context-layer
description: >
  Maps warehouse columns and metrics to business definitions, data lineage, and known definition
  changes, producing context_map.json that downstream narrative-generation and finding-assembly
  use to translate technical findings into stakeholder language. Activate after schema-profiling
  when scope requires business context; takes profiled_schema + scope_artifact.
inputs:
  - type: profiled_schema
    description: "Schema profile from schema-profiling; provides column names, types, cardinality, and sample values for business term mapping"
  - type: scope_artifact
    description: "Approved scope definition; business_context and metric fields inform which terms need definition mapping"
outputs:
  - type: context_map
    description: "Business definition mappings, data lineage traces, and known definition changes for all scope-relevant columns and metrics"
can_follow: [schema-profiling]
can_precede: [exploratory-analysis, narrative-generation, finding-assembly]
supports_loop: false
exit_conditions:
  - "context_map.json written with business definitions mapped to warehouse fields"
  - "data_lineage traced for all scope-relevant columns"
---

## Overview

Schema-profiling tells you *what columns and types exist*. Business-context-layer tells you
*what those columns mean in business terms*. This skill maps warehouse column names to business
definitions, traces data lineage back to source tables, and documents any known definition
changes that could affect interpretation of historical analyses.

Without this context layer, downstream narrative-generation produces technically accurate but
business-opaque outputs — "column_42 increased by 12%" instead of "active member count
grew by 12% (definition changed from 90-day to 60-day activity window in Q3 2025)."

**What this skill produces:** `context_map.json` with three arrays: `definitions` (term-to-column
mappings with business definitions), `data_lineage` (column-to-source-table traces), and
`known_definition_changes` (historical definition shifts that affect interpretation).

---

## When to Activate

- A plan task node with `task_type: "business_context_layer"` is the next unexecuted task
- `profiled_schema.json` exists and scope_artifact references business terms that need mapping
- User explicitly requests "add business context", "map business definitions", or "what do these columns mean"
- Downstream `narrative-generation` requires business-readable labels for technical findings
- `scope_artifact.business_context` contains domain-specific terminology

---

## Preconditions

What must be true before this skill begins:

- [ ] `profiled_schema.json` exists with `schema_version == "1.0"` and non-empty `columns` array
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"`
- [ ] At least one column in profiled_schema has a name that can be mapped to a business term

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0 (optional — for INFORMATION_SCHEMA lineage queries)
# Tier 3: (none — mapping logic is LLM-driven from column names and sample values)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; mapping is LLM reasoning over column metadata
- **Memory:** <100 MB (artifact processing only)
- **Upstream Artifacts:** `profiled_schema.json` (columns, types, sample_values), `scope_artifact.json` (business_context, metric)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `definition_source` | `catalog_available` / `inferred` | `catalog_available`: pull definitions from data catalog or COMMENT ON COLUMN metadata; `inferred`: derive business meaning from column names, types, and sample values using LLM reasoning |
| `lineage_depth` | `single_hop` / `multi_hop` | `single_hop`: map column to its direct source table only; `multi_hop`: trace through views, CTEs, and transformation layers to ultimate source |
| `definition_stability` | `stable` / `has_changes` | `stable`: no known definition changes — known_definition_changes array is empty; `has_changes`: populate known_definition_changes with documented shifts |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify definition_source:
  IF data catalog is accessible OR column COMMENT metadata available → "catalog_available"
  ELSE → "inferred"
  log: "definition_source={value}"

classify lineage_depth:
  IF INFORMATION_SCHEMA.VIEW_TABLE_USAGE available → "multi_hop"
  ELSE → "single_hop"
  log: "lineage_depth={value}"

classify definition_stability:
  IF known definition changes documented in scope_artifact.business_context → "has_changes"
  ELSE → "stable"
  log: "definition_stability={value}"

log: "Running business-context-layer | source={value} | lineage={value} | stability={value}"
```

**Upstream Validation:**
```
load profiled_schema.json
  IF not found: HALT: "Upstream validation failed: profiled_schema.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: profiled_schema.json — schema_version mismatch."
assert columns array is non-empty
  IF not: HALT: "Upstream validation failed: profiled_schema.json — columns array empty."
assert >=1 column mappable to business terms
  IF not: HALT: "No columns mappable to business terms in profiled_schema. Verify schema profiling output."

load scope_artifact.json
  IF not found: HALT: "Upstream validation failed: scope_artifact.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."
```

---

### Step 1 — Map Business Definitions

**Goal:** Create a business definition for each scope-relevant column.

**Pre-step assertion:** profiled_schema.columns and scope_artifact loaded.

**Actions:**
```
definitions = []

-- Identify scope-relevant columns
scope_terms = extract terms from scope_artifact.metric.name, scope_artifact.business_context,
              scope_artifact.population.criteria

FOR each column in profiled_schema.columns:
  IF column.name matches or relates to any scope_term:
    IF definition_source == "catalog_available":
      query: SELECT COMMENT FROM INFORMATION_SCHEMA.COLUMNS
             WHERE column_name = '{column.name}'
      business_definition = result.COMMENT
    ELSE:
      -- Infer from column name, type, sample values, and cardinality
      business_definition = LLM_infer(column.name, column.dtype, column.sample_values,
                                       scope_artifact.business_context)

    definitions.append({
      term: derive_business_term(column.name),
      field_mapping: "{profiled_schema.table_name}.{column.name}",
      business_definition: business_definition,
      version_effective_date: scope_artifact.timeframe.start,
      cgf_lifecycle_stage: scope_artifact.lifecycle_stage
    })

IF len(definitions) == 0:
  WARN: "No scope-relevant columns could be mapped to business definitions."

Log: "Definitions mapped | count={len(definitions)}"
```

**Checkpoint:**
> - [ ] PASS: ≥1 business definition mapped
> - [ ] WARN: no scope-relevant columns mapped

---

### Step 2 — Trace Data Lineage

**Goal:** Document the source table and transformation for each defined column.

**Pre-step assertion:** definitions list populated (or empty).

**Actions:**
```
data_lineage = []

FOR each definition in definitions:
  IF lineage_depth == "multi_hop":
    -- Query INFORMATION_SCHEMA for view dependencies
    query: SELECT * FROM INFORMATION_SCHEMA.VIEW_TABLE_USAGE
           WHERE view_name = '{profiled_schema.table_name}'
    trace through dependency chain
  ELSE:
    -- Single hop: column's source is the profiled table itself
    source_table = profiled_schema.table_name

  data_lineage.append({
    field: definition.field_mapping.split(".")[1],
    source_table: source_table,
    transformation: describe_transformation(column)
  })

Log: "Lineage traced | columns={len(data_lineage)} | depth={lineage_depth}"
```

**Checkpoint:**
> - [ ] PASS: lineage traced for mapped columns
> - [ ] WARN: multi_hop lineage incomplete — some views not traceable

---

### Step 3 — Document Definition Changes

**Goal:** Capture any known historical definition changes that affect data interpretation.

**Pre-step assertion:** definition_stability classified.

**Actions:**
```
known_definition_changes = []

IF definition_stability == "has_changes":
  -- Extract from scope_artifact.business_context or catalog metadata
  FOR each known change:
    IF change.date < scope_artifact.timeframe.start OR change.date > scope_artifact.timeframe.end:
      WARN: "Definition change for '{change.term}' on {change.date} is outside scope timeframe [{scope_artifact.timeframe.start}, {scope_artifact.timeframe.end}] -- skipping."
      CONTINUE
    known_definition_changes.append({
      term: change.term,
      changed_on: change.date,
      old_definition: change.old,
      new_definition: change.new
    })
  Log: "Definition changes documented | count={len(known_definition_changes)}"
ELSE:
  Log: "No known definition changes — stable definitions"
```

**Checkpoint:**
> - [ ] PASS: definition changes documented (or confirmed stable)

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist context_map.json.

**Actions:**
```
Generate artifact_id: UUID v4
record_count = len(definitions)

Write context_map.json

Log: "context_map.json written | definitions={len(definitions)} | lineage={len(data_lineage)} | changes={len(known_definition_changes)}"
```

**Checkpoint:**
> - [ ] PASS: context_map.json written; all 5 universal envelope fields present

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "business-context-layer",
  "timestamp": "2026-04-10T15:15:00Z",
  "record_count": 8,
  "artifact_id": "{uuid}",
  "definitions": [
    {
      "term": "Active Member",
      "field_mapping": "customer_summary.is_active",
      "business_definition": "Customer with at least one transaction in the past 60 days",
      "version_effective_date": "2025-01-01",
      "cgf_lifecycle_stage": "high_engaged"
    }
  ],
  "data_lineage": [
    {"field": "is_active", "source_table": "raw_transactions", "transformation": "CASE WHEN MAX(txn_date) >= DATEADD(day, -60, CURRENT_DATE) THEN 1 ELSE 0 END"}
  ],
  "known_definition_changes": [
    {"term": "Active Member", "changed_on": "2025-07-01", "old_definition": "Transaction in past 90 days", "new_definition": "Transaction in past 60 days"}
  ]
}
```

**Write to:** `context_map.json` in the project directory.

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | profiled_schema.columns is empty | HALT Step 0: "No columns to map." |
| Single column | only 1 column in schema | WARN: "Single column — context map is minimal." |
| All-null columns | all columns have 100% null rate | WARN: "All columns are entirely NULL — definitions may be unreliable." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact artifact name |
| No catalog available | INFORMATION_SCHEMA COMMENT returns empty | WARN + fallback to inferred definitions |
| Column name is cryptic | column name like "col_42" with no discernible meaning | WARN: "Column '{name}' has no discernible business meaning — excluding from context map." |
| Definition change date outside scope | change occurred before scope timeframe | WARN: "Definition change on {date} is outside scope window — included for context but may not affect current analysis." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `context_map.json` exists with all 5 universal envelope fields
- [ ] Every entry in `definitions` has non-null `term`, `field_mapping`, and `business_definition`
- [ ] `data_lineage` entries reference columns present in `definitions`
- [ ] `known_definition_changes` is populated (may be empty for stable definitions)

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `context_map.json` written and validates against terminal artifact spec
- [ ] All scope-relevant columns have business definitions
- [ ] Lineage is traced for mapped columns
- [ ] Downstream `narrative-generation` Step 0 can load and validate `context_map.json`
- [ ] Business definitions are human-readable and stakeholder-appropriate

---

## Scope Boundary

This skill does NOT:
- Profile schema structure or column types → handled by `schema-profiling`
- Generate stakeholder narratives → handled by `narrative-generation`
- Assemble analytical findings → handled by `finding-assembly`
- Compute aggregate metrics → handled by `metric-computation`
- Assess data quality → handled by `data-quality-assessment`

---

## Downstream

Run after this skill completes:
1. **`narrative-generation`** — reads `context_map.definitions` to translate technical column references into business language in the stakeholder narrative
2. **`finding-assembly`** — reads `context_map` to annotate findings with business definitions and flag any definition changes that affect interpretation
3. **`exploratory-analysis`** — may use `context_map` to label features with business meaning during exploration
