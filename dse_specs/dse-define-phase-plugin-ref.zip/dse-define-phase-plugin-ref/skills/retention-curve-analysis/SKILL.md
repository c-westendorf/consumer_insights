---
name: retention-curve-analysis
description: >
  Computes period-over-period retention rates and survival curves (Kaplan-Meier or discrete
  hazard) for a cohort, identifying critical drop-off periods and spend trajectory, producing
  retention_curve.json. Activate after metric-computation when scope involves customer retention
  or churn analysis; takes cohort + metric_result + maturity_classification.
inputs:
  - type: cohort
    description: "Full filtered population from cohort-extraction; provides cohort_size, observation_window, and customer_id_ref"
  - type: metric_result
    description: "Computed metrics from metric-computation; provides aggregate engagement/transaction metrics for period analysis"
  - type: maturity_classification
    description: "Lifecycle state assignments from maturity-state-classification; provides per-customer maturity state for state-specific retention"
outputs:
  - type: retention_curve
    description: "Period-by-period retention rates, survival curve with median survival and inflection points, spend trajectory, and critical drop-off identification"
can_follow: [metric-computation, maturity-state-classification]
can_precede: [stickiness-interval-analysis, roi-computation, finding-assembly]
supports_loop: false
exit_conditions:
  - "retention_curve.json written with retention rates, survival curve, and critical drop-off period identified"
---

## Overview

Metric-computation tells you *aggregate outcome values*. Maturity-state-classification tells you
*where customers are in their lifecycle*. Retention-curve-analysis tells you *how quickly and at
what rate customers disengage over time* — the temporal dimension that static metrics miss.

Using Kaplan-Meier or discrete hazard methods, this skill constructs survival curves showing
what proportion of the cohort remains active at each period. It identifies critical drop-off
periods (where retention falls fastest), computes spend trajectory alongside retention, and
optionally compares against a baseline cohort.

**What this skill produces:** `retention_curve.json` with retention rates by period, survival
curve parameters, spend trajectory, baseline comparison, and the critical drop-off period.

---

## When to Activate

- A plan task node with `task_type: "retention_curve_analysis"` is the next unexecuted task
- Scope involves retention, churn, customer lifetime, or engagement over time
- `maturity_classification.json` exists and lifecycle state distribution shows at_risk or lapsed customers
- User explicitly requests "retention analysis", "churn curve", or "survival analysis"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `metric_result.json` exists with `schema_version == "1.0"`
- [ ] `maturity_classification.json` exists with `schema_version == "1.0"` and non-null `classification_ref`
- [ ] Transaction or event data available for period-over-period analysis

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: lifelines>=0.27 (KaplanMeierFitter); scipy>=1.10 (log-rank test for baseline comparison); numpy>=1.24
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `survival_method` | `kaplan_meier` / `discrete_hazard` | `kaplan_meier`: standard KM estimator with CI bands; `discrete_hazard`: period-by-period hazard rates (good for discrete time intervals) |
| `period_grain` | `daily` / `weekly` / `monthly` | Determines retention period granularity and observation window interpretation |
| `baseline_available` | `true` / `false` | `true`: compare retention curve against baseline cohort with log-rank test; `false`: standalone curve only |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify survival_method:
  IF event times are continuous → "kaplan_meier"
  ELIF event times are discrete periods → "discrete_hazard"
  log: "survival_method={value}"

classify period_grain:
  read scope_artifact.timeframe.granularity
  IF daily/weekly/monthly → use directly
  ELSE → default to "monthly"

classify baseline_available:
  IF cohort has reference population AND scope involves comparison → "true"
  ELSE → "false"

log: "Running retention-curve-analysis | method={value} | grain={value} | baseline={value}"
```

**Upstream Validation:**
```
load cohort.json
  IF not found: HALT: "Upstream validation failed: cohort.json not found."
assert cohort.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json -- schema_version mismatch."
assert cohort.population_size > 0
  IF not: HALT: "Upstream validation failed: cohort.json -- population_size is 0 (empty cohort)."

load metric_result.json
  IF not found: HALT: "Upstream validation failed: metric_result.json not found."
assert metric_result.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: metric_result.json -- schema_version mismatch."

load maturity_classification.json
  IF not found: HALT: "Upstream validation failed: maturity_classification.json not found."
assert maturity_classification.schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: maturity_classification.json -- schema_version mismatch."
assert maturity_classification.classification_ref not null
  IF not: HALT: "Upstream validation failed: maturity_classification.json -- classification_ref is null."
```

---

### Step 1 — Compute Retention Rates

**Goal:** Calculate period-over-period retention for the cohort.

**Actions:**
```
-- Query transaction/event data to build retention table
Execute SQL:
  SELECT period_number, COUNT(DISTINCT customer_id) AS retained_count
  FROM (
    SELECT customer_id,
           DATEDIFF('{period_grain}', cohort_entry_date, event_date) AS period_number
    FROM {event_table}
    WHERE customer_id IN (SELECT customer_id FROM {cohort.customer_id_ref})
  )
  GROUP BY period_number
  ORDER BY period_number

cohort_size = cohort.population_size
retention_rates = []
FOR each period in results:
  retention_rate = period.retained_count / cohort_size
  churned_count = cohort_size - period.retained_count
  retention_rates.append({
    period: period.period_number,
    retained_count: period.retained_count,
    retention_rate: retention_rate,
    churned_count: churned_count
  })

observation_periods = len(retention_rates)
```

**Checkpoint:**
> - [ ] PASS: retention rates computed for ≥2 periods
> - [ ] HALT: no event data available
> - [ ] HALT: `retention_rates[0].retention_rate == 0` — "All customers churned in period 1 — verify cohort definition."
> - [ ] HALT: only 1 period of data — "Single-period data insufficient for curve fitting. Verify observation window covers ≥2 periods."

---

### Step 2 — Fit Survival Curve

**Goal:** Compute survival function and identify inflection points.

**Actions:**
```
IF survival_method == "kaplan_meier":
  from lifelines import KaplanMeierFitter
  kmf = KaplanMeierFitter()
  kmf.fit(durations, event_observed)
  median_survival = kmf.median_survival_time_
  -- Find inflection points: periods where hazard rate changes most
  inflection_periods = detect_inflections(kmf.survival_function_)

ELIF survival_method == "discrete_hazard":
  -- Compute period-specific hazard rates
  hazard_rates = []
  FOR each period:
    h = churned_in_period / at_risk_in_period
    hazard_rates.append(h)
  median_survival = first period where cumulative survival < 0.5
  inflection_periods = detect_inflections(hazard_rates)

survival_curve = {
  method: survival_method,
  median_survival_period: median_survival,
  inflection_periods: inflection_periods
}
```

---

### Step 3 — Compute Spend Trajectory

**Goal:** Track mean and median spend alongside retention.

**Actions:**
```
spend_trajectory = []
FOR each period in retention_rates:
  Execute:
    SELECT AVG(spend) AS mean_spend, APPROX_PERCENTILE(spend, 0.5) AS median_spend
    FROM {event_table}
    WHERE customer_id IN retained_customers AND period = {period}
  spend_trajectory.append({period, mean_spend, median_spend})
```

---

### Step 4 — Baseline Comparison (if available)

**Actions:**
```
IF baseline_available == "true":
  -- Compute retention for baseline cohort
  -- Run log-rank test
  from lifelines.statistics import logrank_test
  result = logrank_test(target_durations, baseline_durations, target_events, baseline_events)
  baseline_comparison = {
    baseline_cohort: "...",
    statistically_worse_than_baseline: result.p_value < 0.05 AND target_median < baseline_median,
    p_value: result.p_value
  }
ELSE:
  baseline_comparison = {baseline_cohort: null, statistically_worse_than_baseline: null, p_value: null}
```

---

### Step 5 — Write Terminal Artifact

**Actions:**
```
critical_dropoff_period = inflection_periods[0] if inflection_periods else null
Generate artifact_id; Write retention_curve.json
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "retention-curve-analysis",
  "timestamp": "2026-04-10T16:15:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "cohort_size": 6148,
  "observation_periods": 12,
  "period_grain": "monthly",
  "retention_rates": [
    {"period": 1, "retained_count": 4427, "retention_rate": 0.72, "churned_count": 1721},
    {"period": 2, "retained_count": 3689, "retention_rate": 0.60, "churned_count": 2459},
    {"period": 3, "retained_count": 3074, "retention_rate": 0.50, "churned_count": 3074}
  ],
  "survival_curve": {
    "method": "kaplan_meier",
    "median_survival_period": 3,
    "inflection_periods": [3, 7]
  },
  "spend_trajectory": [
    {"period": 1, "mean_spend": 87.50, "median_spend": 65.00},
    {"period": 2, "mean_spend": 92.30, "median_spend": 71.00}
  ],
  "baseline_comparison": {
    "baseline_cohort": "prior_year_cohort",
    "statistically_worse_than_baseline": false,
    "p_value": 0.23
  },
  "critical_dropoff_period": 3
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | cohort.population_size == 0 | HALT Step 0 |
| Single record | population_size == 1 | WARN: "Single customer — retention curve trivial." |
| All-null event data | no events found for cohort | HALT: "No event data for retention computation." |
| Single-period data | only 1 period returned from event query | HALT: "Single-period data insufficient for curve fitting. Verify observation window covers ≥2 periods." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 |
| 100% retention (no churn) | all periods have retention_rate == 1.0 | WARN: "Perfect retention — verify observation window covers sufficient time." |
| 0% retention at period 1 | retention_rate[0] == 0 | HALT: "All customers churned in period 1 — verify cohort definition." |
| Baseline cohort empty | reference population has 0 events | WARN: baseline comparison skipped |

---

## Postconditions

- [ ] `retention_curve.json` exists with all 5 universal envelope fields
- [ ] `retention_rates` has ≥2 period entries
- [ ] `survival_curve.median_survival_period` is a positive integer or null (if >50% retained through all periods)
- [ ] `critical_dropoff_period` identifies the steepest decline

---

## Quality Bar

- [ ] `retention_curve.json` validates against terminal artifact spec
- [ ] Retention rates are monotonically non-increasing (or documented exceptions)
- [ ] Downstream `stickiness-interval-analysis` Step 0 can validate the artifact

---

## Scope Boundary

This skill does NOT:
- Classify lifecycle maturity states → handled by `maturity-state-classification`
- Analyze inter-event stickiness intervals → handled by `stickiness-interval-analysis`
- Compute aggregate metrics → handled by `metric-computation`
- Monetize retention impact → handled by `roi-computation`

---

## Downstream

1. **`stickiness-interval-analysis`** — reads `retention_curve` to contextualize interval patterns against overall retention trajectory
2. **`roi-computation`** — reads `retention_curve` to estimate revenue impact of retention changes
3. **`finding-assembly`** — includes retention curve findings (critical drop-off, survival median) in assembled evidence
