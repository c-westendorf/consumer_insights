# Assessment Report: retention-curve-analysis

Skill under test: `.claude/skills/retention-curve-analysis/SKILL.md`
Date: 2026-04-10
Tester: DSE Skill Tester (automated)
Blueprint version: BLUEPRINT.md Section 7 (17-item checklist)

---

## Test Summary

| Category | Tests | Pass | Fail | Warn |
|---|---|---|---|---|
| A: Happy Path | 3 | 3 | 0 | 0 |
| B: Variance Coverage | 7 | 7 | 0 | 0 |
| C: Precondition Violations | 10 | 9 | 1 | 0 |
| D: Edge Cases | 6 | 4 | 1 | 1 |
| **Total** | **26** | **23** | **2** | **1** |

---

## Per-Test Results

### Category A -- Happy Path

| ID | Result | Notes |
|---|---|---|
| A1 | PASS | KM + monthly + no baseline: spec covers full workflow Steps 0-5. Terminal artifact template shows correct structure. baseline_comparison fields correctly nulled. |
| A2 | PASS | KM + monthly + baseline: Step 4 invokes logrank_test, populates baseline_comparison with p_value and boolean comparison. |
| A3 | PASS | Discrete hazard + weekly + no baseline: Step 2 branches correctly to hazard rate computation. Period grain flows through SQL DATEDIFF. |

### Category B -- Variance Coverage

| ID | Result | Notes |
|---|---|---|
| B1 | PASS | kaplan_meier path: Step 2 imports KaplanMeierFitter, calls .fit(), extracts median_survival_time_. Behavior clearly distinct from discrete_hazard. |
| B2 | PASS | discrete_hazard path: Step 2 computes h = churned/at_risk per period. Different median_survival logic (first period cumulative < 0.5). |
| B3 | PASS | daily grain: SQL DATEDIFF parameterized by period_grain. Classified in Step 0 from scope_artifact.timeframe.granularity. |
| B4 | PASS | weekly grain: same parameterization mechanism, different granularity value. |
| B5 | PASS | monthly grain: default fallback if granularity not recognized. |
| B6 | PASS | baseline_available=true: Step 4 executes log-rank test, populates all baseline_comparison fields. |
| B7 | PASS | baseline_available=false: Step 4 sets all baseline_comparison fields to null. Clear behavioral difference. |

### Category C -- Precondition Violations (HALT expected)

| ID | Result | Expected | Actual | Notes |
|---|---|---|---|---|
| C1 | PASS | HALT | HALT | Step 0 upstream validation: "load cohort.json" fails if missing. |
| C2 | PASS | HALT | HALT | Step 0 upstream validation: "load metric_result.json" fails if missing. |
| C3 | PASS | HALT | HALT | Step 0 upstream validation: "load maturity_classification.json" fails if missing. |
| C4 | PASS | HALT | HALT | Step 0: "assert schema_version == '1.0'" fails. Edge case table confirms "Schema mismatch" -> HALT Step 0. |
| C5 | PASS | HALT | HALT | Same schema_version assertion for metric_result.json. |
| C6 | PASS | HALT | HALT | Same schema_version assertion for maturity_classification.json. |
| C7 | PASS | HALT | HALT | Step 0: "assert population_size > 0" fails. Edge case table: "Empty source" -> HALT Step 0. |
| C8 | PASS | HALT | HALT | Step 0: "assert classification_ref not null" fails. |
| C9 | PASS | HALT | HALT | Step 1 checkpoint: "HALT: no event data available." |
| C10 | FAIL | HALT | HALT (misplaced) | Edge case "0% retention at period 1" specifies HALT but this fires AFTER Step 1 completes. The edge case table says HALT but there is no corresponding checkpoint in Step 1 that tests for retention_rate[0] == 0. The Step 1 checkpoint only checks for >=2 periods and no event data. This HALT is specified in the edge case table but not wired into the workflow. |

### Category D -- Edge Cases

| ID | Result | Notes |
|---|---|---|
| D1 | PASS | Edge case table: "Single record / population_size == 1" -> WARN. Spec is clear. |
| D2 | PASS | Edge case table: "100% retention" -> WARN with specific message. Postcondition correctly allows median_survival_period = null when >50% retained through all periods. |
| D3 | FAIL | Step 1 checkpoint says "WARN: only 1 period of data -- curve is degenerate" but postcondition requires retention_rates has >=2 period entries. Contradiction: the skill WARNs and presumably continues, but the postcondition would then fail. Spec does not resolve whether the skill should HALT or produce a degraded artifact when only 1 period exists. |
| D4 | PASS | Edge case table: "Baseline cohort empty" -> WARN, baseline comparison skipped. Consistent with Step 4 logic. |
| D5 | WARN | No explicit scale guidance in spec. SQL uses IN (subquery) which may not scale. No checkpoint or WARN for large cohorts. Acceptable but noted. |
| D6 | PASS | Quality bar: "Retention rates are monotonically non-increasing (or documented exceptions)." The "or documented exceptions" clause handles this case. |

---

## Terminal Artifact Validation (5 Envelope Fields)

| # | Envelope Field | Present | Correct | Notes |
|---|---|---|---|---|
| 1 | schema_version | Yes | "1.0" | Matches universal requirement |
| 2 | skill_name | Yes | "retention-curve-analysis" | Matches frontmatter name |
| 3 | timestamp | Yes | ISO-8601 UTC | Format correct in example |
| 4 | record_count | Yes | 6148 | Present in example artifact |
| 5 | artifact_id | Yes | "{uuid}" | Placeholder shown, generation specified in Step 5 |

**Verdict: All 5 envelope fields present and correct.**

Additional domain-specific fields validated:
- cohort_size: present
- observation_periods: present
- period_grain: present
- retention_rates: array of period objects with retained_count, retention_rate, churned_count
- survival_curve: object with method, median_survival_period, inflection_periods
- spend_trajectory: array of period objects with mean_spend, median_spend
- baseline_comparison: object with baseline_cohort, statistically_worse_than_baseline, p_value
- critical_dropoff_period: present

---

## Coverage Assessment

### Variance Dimension Coverage

| Dimension | Values in Spec | Values Tested | Coverage |
|---|---|---|---|
| survival_method | kaplan_meier, discrete_hazard | 2/2 | 100% |
| period_grain | daily, weekly, monthly | 3/3 | 100% |
| baseline_available | true, false | 2/2 | 100% |

**Cross-product coverage:** 2 x 3 x 2 = 12 combinations. 3 tested in happy path (25% of cross-product). All individual dimension values tested. Acceptable for spec-level assessment.

### Precondition Coverage

| Precondition | HALT Wired in Step 0 | Edge Case Listed |
|---|---|---|
| cohort.json exists, schema_version == "1.0", population_size > 0 | Yes | Yes (Empty source, Schema mismatch) |
| metric_result.json exists, schema_version == "1.0" | Yes | Yes (Schema mismatch) |
| maturity_classification.json exists, schema_version == "1.0", classification_ref not null | Yes | Yes (Schema mismatch) |
| Transaction/event data available | No (Step 1) | Yes (All-null event data) |

### Postcondition Coverage

| Postcondition | Tested By | Verified |
|---|---|---|
| retention_curve.json exists with 5 envelope fields | A1, A2, A3 | Yes |
| retention_rates has >=2 period entries | A1, A2, A3 (happy), D3 (conflict) | Partial -- see D3 |
| survival_curve.median_survival_period positive int or null | A1, D2 | Yes |
| critical_dropoff_period identifies steepest decline | A1 | Yes |

---

## Blueprint Compliance (8 Principles)

| # | Principle | Status | Evidence |
|---|---|---|---|
| 1 | Single Job-to-be-Done | PASS | Name is "retention-curve-analysis" (verb-noun). Scope Boundary lists 4 excluded jobs with responsible skills. |
| 2 | Precondition/Postcondition Contracts | PASS | 4 preconditions, all testable assertions. 4 postconditions, all testable. HALT wired in Step 0 for upstream violations. |
| 3 | Explicit Variance Surface | PASS | 3 dimensions declared, each with >=2 values and distinct behavioral descriptions. Step 0 classifies all dimensions before processing. |
| 4 | Artifact at Every State Change | PASS | Terminal artifact (retention_curve.json) produced at Step 5. Intermediate values stored and referenced. |
| 5 | Stateful Operations Are Scoped | N/A | No fit/train/calibrate operations that learn from data. KM fitting uses the full cohort by design (survival analysis, not prediction). |
| 6 | Quality Bar Over Completeness | PARTIAL | HALTs present for empty source, schema mismatch, no event data, 0% retention. However, 0% retention HALT is in edge case table but not wired as a checkpoint in Step 1 (see C10). |
| 7 | Canonical Reference Library | N/A | No shared references used. Skill is self-contained. No patterns duplicated from other skills identified. |
| 8 | Self-Contained Portability | PASS | No cross-skill imports. Dependencies declared in Prerequisites. SKILL.md references only local skill artifacts. |

---

## 17-Item Checklist (Section 7)

### Definition and Structure (5)

| # | Item | Status | Notes |
|---|---|---|---|
| 1 | Frontmatter: name + description only, <=3 sentences | PASS | Frontmatter has name, description (3 sentences covering transformation, trigger, inputs, output). Also has inputs/outputs/can_follow/can_precede/supports_loop/exit_conditions -- these are extensions beyond the blueprint minimum but do not violate it. |
| 2 | All required sections present in order | PASS | Overview, When to Activate, Preconditions, Prerequisites, Variance Surface, Workflow, Terminal Artifact, Edge Cases, Postconditions, Quality Bar, Scope Boundary, Downstream -- all present in correct order. |
| 3 | SKILL.md <=500 lines | PASS | File is 314 lines. Well under limit. |
| 4 | scripts/generate_{name}_artifact.py exists | FAIL | No scripts/ directory or generate_retention_curve_artifact.py found. Blueprint requires this. |
| 5 | requirements.txt in 4-tier format | FAIL | No requirements.txt file. Prerequisites section lists dependencies inline but not in a standalone requirements.txt. Infrastructure requirements not fully documented (no Compute/Memory/Disk/OS packages/Environment subsections). |

### Contracts and Correctness (4)

| # | Item | Status | Notes |
|---|---|---|---|
| 6 | Preconditions testable with HALT in Step 0 | PASS | All 4 preconditions have corresponding assertions in Step 0 upstream validation with implicit HALT on failure. |
| 7 | Terminal artifact has 5 envelope fields + domain fields | PASS | All 5 universal fields present. Domain-specific fields documented. |
| 8 | Stateful ops bounded to declared subset | N/A | No fit/train/calibrate operations. |
| 9 | Degraded upstream produces explicit HALT | PASS | Schema mismatch, missing artifacts, empty cohort all produce HALT. |

### Variance and Testing (4)

| # | Item | Status | Notes |
|---|---|---|---|
| 10 | Variance Surface complete, >=2 values per dimension | PASS | 3 dimensions, all with >=2 values and distinct behavior descriptions. |
| 11 | Skill run with >=3 values per dimension | CANNOT VERIFY | Spec-level assessment only. No runtime evidence of execution across variance values. |
| 12 | Terminal artifact passes downstream validation | PARTIAL | Postcondition states downstream stickiness-interval-analysis Step 0 can validate. Quality bar includes this assertion. Not runtime-verified. |
| 13 | Pipeline regression test passes | CANNOT VERIFY | Requires runtime execution. |

### Documentation and Integration (4)

| # | Item | Status | Notes |
|---|---|---|---|
| 14 | Domain README pipeline diagram updated | CANNOT VERIFY | No domain README found in scope. |
| 15 | Domain README artifact chain updated | CANNOT VERIFY | Same. |
| 16 | Domain README variance coverage table updated | CANNOT VERIFY | Same. |
| 17 | New shared patterns promoted to _shared-references/ | N/A | No new shared patterns introduced. |

---

## Pre-Merge Readiness Verdict

**NOT READY -- 2 required fixes, 1 specification conflict to resolve.**

The skill specification is structurally sound and covers the core analysis workflow well. Variance surface is complete with clear behavioral differentiation. Precondition/postcondition contracts are largely correct. However, there are concrete gaps that must be addressed before merge.

---

## Required Fixes

### Fix 1 (BLOCKING): Missing generate_retention_curve_artifact.py
**Checklist item:** #4
**Issue:** Blueprint Section 7 requires `scripts/generate_{name}_artifact.py` as a standalone CLI with `--help` and no cross-skill imports. This file does not exist.
**Action:** Create `scripts/generate_retention_curve_artifact.py` that produces retention_curve.json with all declared fields.

### Fix 2 (BLOCKING): Missing requirements.txt
**Checklist item:** #5
**Issue:** Blueprint requires a `requirements.txt` in 4-tier format. Dependencies are listed inline in the Prerequisites section but no standalone file exists. Infrastructure requirements (Compute, Memory, Disk, OS packages, Environment) are also missing from Prerequisites.
**Action:** Create `requirements.txt` with 4-tier format. Add Infrastructure Requirements subsection to Prerequisites.

### Fix 3 (HIGH): Edge case "0% retention at period 1" HALT not wired into workflow
**Test:** C10
**Issue:** Edge case table specifies HALT when `retention_rate[0] == 0`, but Step 1's checkpoint only checks for >=2 periods and no event data. There is no checkpoint that evaluates the first period's retention rate. The HALT exists in documentation but is not reachable through the workflow.
**Action:** Add a checkpoint assertion to Step 1 (or a post-Step 1 check): `IF retention_rates[0].retention_rate == 0: HALT "All customers churned in period 1 -- verify cohort definition."`

### Fix 4 (HIGH): Single-period data creates postcondition contradiction
**Test:** D3
**Issue:** Step 1 checkpoint says WARN on 1 period of data and implies the skill continues. But postcondition #2 requires `retention_rates has >=2 period entries`. If the skill WARNs and continues, the postcondition fails. If the skill should HALT instead of WARN, the checkpoint should say HALT.
**Action:** Either (a) change the Step 1 WARN to HALT for single-period data, or (b) relax postcondition #2 to allow 1 period with a documented exception.

---

## Tests Still Needed

| Priority | Test | Reason |
|---|---|---|
| P1 | Runtime execution across all 12 variance cross-product combinations | Checklist item #11 requires >=3 values per dimension tested at runtime |
| P1 | Downstream validation test: stickiness-interval-analysis Step 0 consuming retention_curve.json | Checklist item #12 |
| P1 | Pipeline regression with skill inserted at declared position | Checklist item #13 |
| P2 | Runtime test with actual Snowflake event data to verify SQL correctness | SQL templates in Steps 1 and 3 are pseudocode; actual query execution untested |
| P2 | Runtime test with lifelines KaplanMeierFitter to verify integration | Library import and .fit() call untested at runtime |
| P2 | Scale test with large cohort (>100K customers) to verify SQL IN-clause performance | D5 flagged as WARN -- no explicit guidance |
| P3 | Domain README integration tests | Checklist items #14-16 cannot be verified without domain README |
