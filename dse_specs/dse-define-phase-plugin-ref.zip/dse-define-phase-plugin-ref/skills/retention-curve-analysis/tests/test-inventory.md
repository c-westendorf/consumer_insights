# Test Inventory: retention-curve-analysis

Skill under test: `.claude/skills/retention-curve-analysis/SKILL.md`
Date: 2026-04-10
Tester: DSE Skill Tester (automated)

---

## Category A -- Happy Path

| ID | Test Name | Variance Config | Expected Outcome |
|---|---|---|---|
| A1 | Standard KM monthly, no baseline | survival_method=kaplan_meier, period_grain=monthly, baseline_available=false | retention_curve.json written with KM survival curve, monotonically non-increasing retention rates, critical_dropoff_period identified, baseline_comparison fields null |
| A2 | Standard KM monthly, with baseline | survival_method=kaplan_meier, period_grain=monthly, baseline_available=true | retention_curve.json written with KM survival curve plus baseline_comparison with non-null p_value and statistically_worse_than_baseline boolean |
| A3 | Discrete hazard weekly, no baseline | survival_method=discrete_hazard, period_grain=weekly, baseline_available=false | retention_curve.json written with discrete hazard rates, period-specific hazard computation, standalone curve |

---

## Category B -- Variance Coverage

Each variance dimension requires >=2 tested values.

### Dimension: survival_method (2 values)

| ID | Test Name | Value | Expected Behavior Difference |
|---|---|---|---|
| B1 | KM estimator path | kaplan_meier | Uses KaplanMeierFitter from lifelines; produces CI bands; median_survival from kmf.median_survival_time_ |
| B2 | Discrete hazard path | discrete_hazard | Computes period-specific hazard h = churned/at_risk; median_survival = first period cumulative survival < 0.5 |

### Dimension: period_grain (3 values)

| ID | Test Name | Value | Expected Behavior Difference |
|---|---|---|---|
| B3 | Daily grain | daily | DATEDIFF uses 'day'; finer observation window; more period entries expected |
| B4 | Weekly grain | weekly | DATEDIFF uses 'week'; moderate granularity |
| B5 | Monthly grain | monthly | DATEDIFF uses 'month'; coarser granularity; fewer period entries |

### Dimension: baseline_available (2 values)

| ID | Test Name | Value | Expected Behavior Difference |
|---|---|---|---|
| B6 | Baseline present | true | Log-rank test executed; baseline_comparison populated with p_value and statistical comparison |
| B7 | No baseline | false | baseline_comparison fields set to null; no log-rank test |

---

## Category C -- Precondition Violations (HALT expected)

| ID | Test Name | Violated Precondition | Expected HALT |
|---|---|---|---|
| C1 | Missing cohort.json | cohort.json does not exist | HALT at Step 0 upstream validation |
| C2 | Missing metric_result.json | metric_result.json does not exist | HALT at Step 0 upstream validation |
| C3 | Missing maturity_classification.json | maturity_classification.json does not exist | HALT at Step 0 upstream validation |
| C4 | cohort.json wrong schema_version | schema_version != "1.0" | HALT at Step 0 ("Schema mismatch" edge case) |
| C5 | metric_result.json wrong schema_version | schema_version != "1.0" | HALT at Step 0 |
| C6 | maturity_classification.json wrong schema_version | schema_version != "1.0" | HALT at Step 0 |
| C7 | Empty cohort (population_size == 0) | population_size == 0 | HALT at Step 0 ("Empty source" edge case) |
| C8 | Null classification_ref | maturity_classification.json has null classification_ref | HALT at Step 0 upstream validation |
| C9 | No event data for cohort | Transaction/event data unavailable | HALT at Step 1 ("No event data for retention computation") |
| C10 | 0% retention at period 1 | retention_rate[0] == 0 | HALT: "All customers churned in period 1 -- verify cohort definition." |

---

## Category D -- Edge Cases

| ID | Test Name | Condition | Expected Action |
|---|---|---|---|
| D1 | Single customer cohort | population_size == 1 | WARN: "Single customer -- retention curve trivial." Skill may proceed but curve is degenerate |
| D2 | 100% retention (no churn) | All periods retention_rate == 1.0 | WARN: "Perfect retention -- verify observation window covers sufficient time." median_survival_period should be null |
| D3 | Only 1 period of data | Retention rates computed for exactly 1 period | WARN: "Only 1 period of data -- curve is degenerate." Postcondition (>=2 periods) may fail |
| D4 | Empty baseline cohort | Reference population has 0 events | WARN: baseline comparison skipped; baseline_comparison fields null |
| D5 | Large cohort scale test | population_size > 1M | Verify SQL performance and retention computation complete without timeout |
| D6 | Non-monotonic retention | Some periods show retention increase | Quality bar requires monotonically non-increasing or documented exceptions |

---

## Test Count Summary

| Category | Count |
|---|---|
| A: Happy Path | 3 |
| B: Variance Coverage | 7 |
| C: Precondition Violations | 10 |
| D: Edge Cases | 6 |
| **Total** | **26** |
