---
name: intent-classification
description: >
  Classifies a business question against the CGF taxonomy to identify the customer lifecycle
  stage and analytical pattern. Activate when a new business question arrives and needs
  mapping to the CGF framework before scoping begins. Takes raw natural language question,
  produces intent_classification with lifecycle_stage, analytical_pattern, confidence, and ambiguities.
inputs:
  - type: raw_question
    description: "User's business question as natural language text"
outputs:
  - type: intent_classification
    description: "Lifecycle stage, analytical pattern, confidence score, and ambiguities list"
can_follow: []
can_precede: [scope-extraction]
supports_loop: false
exit_conditions:
  - "intent_classification produced with lifecycle_stage, analytical_pattern, and confidence >= 0.3"
  - "confidence < 0.3 triggers HALT requesting user rephrase"
---

# intent-classification

## Overview

This is the first skill in the Define Phase Scope Agent pipeline. It takes a raw business
question and classifies it against the CGF (Customer Growth Framework) taxonomy. Without
this classification, downstream skills cannot determine which scope fields are required —
a `profile` question needs different fields than `compare` or `predict`.

The skill reads `cgf-taxonomy.md` to map questions to one of **8 lifecycle stages** and
one of **5 analytical patterns**. It produces a confidence score and surfaces any
ambiguities for user resolution before handing off to `scope-extraction`.

## When to Activate

- A new business question arrives in natural language form.
- No prior `intent_classification` artifact exists for this question.
- The Scope Agent pipeline is beginning the Define Phase.

Do **not** activate when an `intent_classification` artifact already exists and the user
has not changed their question.

## Preconditions

| Condition | Check | On Failure |
|---|---|---|
| Raw question is non-empty string | `len(raw_question.strip()) > 0` | HALT — no input to classify |
| Raw question is natural language | Not a JSON blob or code snippet | WARN — attempt extraction of embedded question text |
| CGF taxonomy reference available | `cgf-taxonomy.md` accessible | HALT — cannot classify without taxonomy |

## Prerequisites

- **Runtime:** CPU-only, no GPU required.
- **Memory:** < 50 MB working set.
- **Dependencies:** None beyond the agent runtime (Tier 1 only). No external APIs,
  no database connections, no heavy libraries.
- **Reference files:** `cgf-taxonomy.md` (bundled with plugin).

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `confidence_level` | `high` (>=0.8) / `medium` (0.3–0.7) / `low` (<0.3) | `high`: proceed directly to terminal artifact; `medium`: present classification to user for confirmation before proceeding; `low`: HALT and ask user to rephrase |
| `analytical_pattern` | `profile` / `compare` / `predict` / `explain` / `segment` | Determines which downstream scope fields are required; `compare` requires comparison reference; `predict` requires prediction_horizon; `explain` requires outcome_variable; `segment` requires segmentation_basis |
| `stage_ambiguity` | `single_match` / `multi_match` | `single_match`: one clear lifecycle stage identified; `multi_match`: multiple plausible stages — present all candidates with reasoning for user selection |

## Workflow

### Step 0 — Context Classification

This is the first skill in the pipeline. There is no upstream artifact to validate.

1. Receive `raw_question` as plain text input.
2. Classify the three variance dimensions from input:
   - `confidence_level`: will be determined in Step 4 after analysis.
   - `analytical_pattern`: preliminary signal from keyword scan.
   - `stage_ambiguity`: will be determined in Step 2.
3. Check input format:
   IF raw_question contains structural markers (`{`, `[`, `SELECT`, `def `, `function `, `import `, `<html`):
     format_flag = "non_NL"
     WARN: "Input appears to be {detected_format}, not natural language."
     Attempt to extract embedded natural language question text.
     IF extraction fails: HALT — "Cannot extract a natural language question from input."
     ELSE: raw_question = extracted_text; log extraction.
4. Checkpoint: **PASS** — raw question received and non-empty.

> If `raw_question` is empty or whitespace-only: **HALT** — request user to provide
> a business question.

### Step 1 — Parse the Question

Extract key entities from the natural language question:

- **Customer segments**: any population references (e.g., "new customers",
  "high-engaged members", "lapsed users").
- **Metrics**: what is being measured (e.g., "retention rate", "purchase frequency",
  "lifetime value").
- **Time periods**: temporal references (e.g., "last 6 months", "Q1 2025",
  "year-over-year").
- **Comparison language**: signals of comparative analysis (e.g., "vs", "compared to",
  "difference between", "better/worse").
- **Causal language**: signals of explanatory analysis (e.g., "why", "drivers",
  "what causes").
- **Predictive language**: signals of forecasting (e.g., "will", "likely", "forecast").

Checkpoint: **PASS** — at least one entity class identified.

> If no entities extractable: **WARN** — question may be too vague. Continue to Steps
> 2-3 but expect low confidence.

### Step 2 — Map to CGF Lifecycle Stage

Match extracted entities against the 8 CGF lifecycle stages:

| Stage | Typical signals |
|---|---|
| `acquisition` | prospect, new signup, first visit, conversion funnel |
| `new_customer` | first purchase, onboarding, initial experience |
| `low_engaged` | infrequent, minimal activity, low usage |
| `medium_engaged` | regular but not heavy, moderate frequency |
| `high_engaged` | power user, frequent, high-value, loyal |
| `reactivated` | returned, win-back, came back, re-engaged |
| `at_risk` | declining, churning, dropping off, disengaging |
| `lapsed` | inactive, dormant, lost, no activity in N months |

If multiple stages are plausible, set `stage_ambiguity = multi_match` and record all
candidates with per-stage confidence and reasoning.

Checkpoint: **PASS** if `single_match`; **WARN** if `multi_match` — user will be asked
to disambiguate.

### Step 3 — Identify Analytical Pattern

Classify the question type against the 5 analytical patterns using trigger keywords:

| Pattern | Trigger keywords / phrases |
|---|---|
| `profile` | "characterize", "describe", "what does X look like", "who are", "tell me about" |
| `compare` | "difference", "vs", "compared to", "better", "worse", "how does X differ" |
| `predict` | "will", "likely", "forecast", "probability", "future", "expect" |
| `explain` | "why", "drivers", "cause", "because", "what leads to", "factors" |
| `segment` | "groups", "clusters", "types of", "segments", "categorize", "buckets" |

If no clear pattern emerges, default to `profile` with a confidence penalty of -0.2.

Checkpoint: **PASS** — analytical pattern assigned.

### Step 4 — Assess Confidence and Output

Calculate overall confidence score (0.0 to 1.0) based on:

- **Stage clarity**: single_match adds +0.3; multi_match adds +0.1.
- **Pattern clarity**: strong keyword match adds +0.3; weak/default adds +0.1.
- **Entity richness**: 3+ entity classes adds +0.2; 1-2 adds +0.1; 0 adds 0.
- **Question specificity**: contains concrete metric or population adds +0.2.

Apply confidence routing:

| Confidence | Action |
|---|---|
| >= 0.8 | **PASS** — produce terminal artifact and proceed |
| 0.3 – 0.7 | **WARN** — present classification to user for confirmation; on confirmation, produce artifact |

> If `stage_ambiguity == multi_match` AND confidence is medium (0.3–0.7), combine both
> interactions into a single prompt: present the stage candidates for selection AND ask
> for overall classification confirmation together. Do not prompt the user twice.
| < 0.3 | **HALT** — ask user to rephrase with more specificity |

## Terminal Artifact

**File:** `intent_classification.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "intent-classification",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 1,
  "artifact_id": "{uuid}",
  "lifecycle_stage": "reactivated",
  "analytical_pattern": "compare",
  "confidence": 0.85,
  "ambiguities": [],
  "stage_candidates": [
    {
      "stage": "reactivated",
      "reasoning": "Question references customers who 'came back' after lapse",
      "confidence": 0.85
    }
  ],
  "pattern_signals": {
    "detected_keywords": ["vs", "compared to"],
    "detected_entities": {
      "population": "reactivated customers",
      "metric": "retention rate",
      "time_period": "last 6 months"
    }
  }
}
```

**Envelope fields** (required on every artifact):

| Field | Type | Description |
|---|---|---|
| `schema_version` | string | Always `"1.0"` for Define Phase v1 |
| `skill_name` | string | `"intent-classification"` |
| `timestamp` | string | ISO-8601 UTC timestamp at artifact creation |
| `record_count` | integer | Always `1` for this skill |
| `artifact_id` | string | UUID v4 unique to this artifact instance |

## Edge Cases

| # | Scenario | Detection | Response |
|---|---|---|---|
| 1 | Empty input | `raw_question` is empty or whitespace | **HALT** — return error requesting a business question |
| 2 | Single record | Only one entity extracted from question | **PASS** — proceed with reduced confidence; note limited signal in `ambiguities` |
| 3 | All-null dimension | No lifecycle stage matches any signal | **HALT** — question does not map to CGF taxonomy; ask user to reframe around a customer lifecycle stage |
| 4 | Schema mismatch | Unexpected input format (JSON, code, SQL) | **WARN** — attempt to extract natural language question from input; if extraction fails, HALT |
| 5 | Multi-intent question | Question contains two distinct analytical intents (e.g., "compare and predict") | **WARN** — classify primary intent by sentence position; surface secondary intent in `ambiguities` for user confirmation |
| 6 | Jargon-heavy question | Domain-specific abbreviations or acronyms not in taxonomy | **WARN** — flag unrecognized terms in `ambiguities`; ask user to clarify before finalizing classification |
| 7 | Negation patterns | Question uses negation ("not lapsed", "never purchased") | **PASS** — invert the stage signal; "not lapsed" maps to an active stage, not `lapsed` |
| 8 | Compound population | Multiple lifecycle stages referenced ("compare lapsed vs reactivated") | **PASS** — set `stage_ambiguity = multi_match`; both stages are valid for a `compare` pattern |

## Postconditions

| Condition | Verification |
|---|---|
| Artifact written | `intent_classification.json` exists with all 5 envelope fields |
| Lifecycle stage valid | `lifecycle_stage` is one of the 8 CGF stages |
| Analytical pattern valid | `analytical_pattern` is one of the 5 defined patterns |
| Confidence scored | `confidence` is a float between 0.0 and 1.0 |
| Ambiguities surfaced | `ambiguities` array present (may be empty) |
| Stage candidates populated | `stage_candidates` array has >= 1 entry |

## Quality Bar

- Confidence score must reflect actual signal strength — never inflated.
- If `stage_ambiguity == multi_match`, all candidates must include reasoning.
- `pattern_signals.detected_keywords` must contain only keywords actually found in the
  input, never hallucinated.
- The skill must never invent entities not present in the original question.
- Classification must be reproducible: same input must yield same output.

## Scope Boundary

This skill **only** classifies the question. It does NOT:

| Out-of-scope action | Responsible skill |
|---|---|
| Extract structured scope fields from question | `scope-extraction` |
| Validate scope completeness | `completeness-validation` |
| Format scope for stakeholder approval | `scope-formatting` |
| Decompose scope into analytical tasks | `task-decomposition` |
| Query databases or warehouses | N/A — Define Phase is pre-warehouse |

## Downstream

- **Primary consumer:** `scope-extraction` — uses `lifecycle_stage` and
  `analytical_pattern` to determine which scope fields to prioritize.
- **Artifact reference:** downstream skills load `intent_classification.json` and
  validate `schema_version == "1.0"` before proceeding.
- **Failure propagation:** if this skill HALTs, the entire Scope Agent pipeline pauses
  until the user provides a valid question.
