# Skill Test Assessment Report
**Skill:** `data-retrieval`
**Tested by:** dse-skill-tester
**Date:** 2026-04-09
**Skill path:** `.claude/skills/data-retrieval/SKILL.md`

---

## Test Summary

| Category          | Tests Run | ✅ Pass | ⚠️ Warn | ❌ Fail | 🚫 Critical |
|-------------------|-----------|---------|---------|---------|-------------|
| A — Happy Path    | 2         | 1       | 1       | 0       | 0           |
| B — Variance      | 5         | 3       | 2       | 0       | 0           |
| C — Precondition  | 6         | 5       | 0       | 0       | 1           |
| D — Edge Cases    | 7         | 4       | 2       | 0       | 1           |
| **Total**         | **20**    | **13**  | **5**   | **0**   | **2**       |

---

## Per-Test Results

| # | Name | Category | Outcome | Step | Notes |
|---|---|---|---|---|---|
| 1 | happy-path-snowflake-windowed | A | ⚠️ Warn | Step 3 | data_volume classified after execution but Step 0 declares it as a Step 0 classification — ordering issue |
| 2 | happy-path-bigquery-windowed | A | ✅ Pass | — | Platform branch confirmed (synthetic); all 17 fields expected |
| 3 | variance-scope-full-table | B | ⚠️ Warn | Step 1 | WARN expected fires; artifact produced |
| 4 | variance-scope-incremental | B | ✅ Pass | — | Fallback to windowed on no prior extraction documented correctly |
| 5 | variance-volume-large | B | ✅ Pass | — | WARN: recommend population-sampling — fires correctly |
| 6 | variance-volume-very-large | B | ⚠️ Warn | Step 0/3 | size_warning documented in Step 3 but classified as variance dimension in Step 0; see Issue 1 |
| 7 | variance-join-multi-table | B | ✅ Pass | — | JOIN clause addition and cardinality logging documented |
| 8 | precond-scope-missing | C | ✅ Pass | Step 0 | HALT fires: file not found |
| 9 | precond-scope-not-approved | C | ✅ Pass | Step 0 | HALT fires: approved_at null |
| 10 | precond-plan-missing | C | ✅ Pass | Step 0 | HALT fires: plan_artifact not found |
| 11 | precond-plan-no-retrieval-task | C | ✅ Pass | Step 0 | HALT fires: no data_retrieval task node |
| 12 | precond-invalid-platform | C | ✅ Pass | Step 0 | HALT fires: "oracle" not supported |
| 13 | precond-invalid-timeframe | C | 🚫 Critical | Step 0 | Date validation not explicitly in Step 0 upstream validation block — precondition stated but HALT code block missing |
| 14 | edge-empty-extraction | D | ✅ Pass | Step 2 | HALT fires at correct step after execution |
| 15 | edge-single-row | D | ✅ Pass | Step 3 | WARN + continue documented |
| 16 | edge-all-null-column | D | ✅ Pass | Step 3 | WARN documented |
| 17 | edge-schema-mismatch | D | 🚫 Critical | Step 0 | Float vs string comparison not type-strict; 1.0 (float) may silently pass |
| 18 | edge-auth-timeout | D | ⚠️ Warn | Step 2 | Requires real environment; HALT documented but unconfirmed |
| 19 | edge-query-timeout | D | ⚠️ Warn | Step 2 | Requires real environment; HALT documented but unconfirmed |
| 20 | edge-very-large | D | ✅ Pass | Step 3 | size_warning=true; WARN documented |

---

## Terminal Artifact Validation

Checked on Tests 1–7 (Category A and B) that completed without HALT:

| Test | schema_version | skill_name | timestamp | record_count | artifact_id | DSE fields |
|---|---|---|---|---|---|---|
| Test 1 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ✅ all 12 DSE fields declared |
| Test 2 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ✅ all 12 DSE fields declared |

---

## Coverage Assessment

### Variance Dimensions Covered

| Dimension | Declared Values | Tested | Result |
|---|---|---|---|
| platform | snowflake / bigquery | ✅ Both | Both paths documented; bigquery path needs real-env confirmation |
| extraction_scope | full_table / windowed_query / incremental | ✅ All 3 | All paths confirmed via synthetic walk-through |
| data_volume | small / large / very_large | ✅ All 3 | small + large ✅; very_large ⚠️ ordering issue |
| join_required | single_table / multi_table_join | ✅ Both | Both paths documented |

### Precondition Coverage

| Precondition | Tested | HALT Fires? | HALT Message Correct? |
|---|---|---|---|
| scope_artifact.json exists | ✅ Yes | ✅ Yes | ✅ Yes |
| approved_at set on scope | ✅ Yes | ✅ Yes | ✅ Yes |
| plan_artifact.json exists | ✅ Yes | ✅ Yes | ✅ Yes |
| data_retrieval task node exists | ✅ Yes | ✅ Yes | ✅ Yes |
| platform in [snowflake, bigquery] | ✅ Yes | ✅ Yes | ✅ Yes |
| timeframe.start and .end valid dates | ✅ Yes | 🚫 No | 🚫 HALT block not explicitly written in Step 0 |

### Edge Case Coverage

| Edge Case | Tested | Outcome Correct? |
|---|---|---|
| Empty extraction (0 rows) | ✅ Yes | ✅ HALT fires at Step 2 |
| Single row | ✅ Yes | ✅ WARN + continue |
| All-null column | ✅ Yes | ✅ WARN + continue |
| Schema version mismatch (wrong string) | ✅ Yes | ✅ HALT fires |
| Schema version float (1.0 not "1.0") | ✅ Yes | 🚫 Type check not strict — may silently pass |
| Auth timeout | ⚠️ Partial | Needs real environment |
| Query timeout | ⚠️ Partial | Needs real environment |
| Very large extraction | ✅ Yes | ✅ WARN + size_warning=true |

---

## Blueprint Compliance

| Principle | Status | Evidence |
|---|---|---|
| 1. Single Job-to-be-Done | CONFIRMED | Skill retrieves data and produces artifact; doesn't clean, profile, or filter |
| 2. Precondition/Postcondition Contracts | VIOLATED | Timeframe date validation: precondition declared but HALT block missing from Step 0 code; see Fix 1 |
| 3. Explicit Variance Surface | CONFIRMED | 4 dimensions declared with distinct behaviors |
| 4. Artifact at Every State Change | CONFIRMED | Terminal artifact written in Step 4 with all 17 fields declared |
| 5. Stateful Operations Scoped | CONFIRMED | No training/fitting; extraction is stateless |
| 6. Quality Bar Over Completeness | VIOLATED | Schema version type-check is lax; float 1.0 may pass string "1.0" assertion; see Fix 2 |
| 7. Canonical Reference Library | CONFIRMED | References data-type-registry.md for raw_dataset type |
| 8. Self-Contained Portability | UNCONFIRMED | Requires real warehouse connection for full confirmation; synthetic tests confirm structure |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL**

**Summary:** The skill is structurally sound and covers all declared variance dimensions and
most preconditions correctly. Two targeted fixes are needed before merge: explicit date
validation HALT in Step 0, and type-strict schema_version assertion. Tests 18 and 19 also
require real-environment pre-merge confirmation. All other precondition violations HALT
correctly.

---

## Required Fixes

### Fix 1: Add explicit timeframe date validation HALT to Step 0 — ⚠️ RECOMMENDED BEFORE MERGE
**Failing test:** Test 13 (precond-invalid-timeframe)
**Blueprint principle violated:** Principle 2 (Precondition Contracts)
**What happened:** Precondition 6 declares "timeframe.start and .end are valid dates" but
the Step 0 Upstream Validation block does not include a HALT assertion for this.

**Add to Step 0 Upstream Validation block after the scope assertions:**
```
assert timeframe.start can be parsed as ISO-8601 date (YYYY-MM-DD)
assert timeframe.end can be parsed as ISO-8601 date (YYYY-MM-DD)
assert timeframe.start < timeframe.end
IF any assertion fails:
  HALT: "Upstream validation failed: scope_artifact.json — timeframe '{start}' to '{end}' 
  is not a valid date range. Dates must be YYYY-MM-DD format with start < end. 
  Run /scope to correct the timeframe."
```

### Fix 2: Make schema_version assertion type-strict — 🚫 BLOCKS MERGE
**Failing test:** Test 17 sub-case (b) — schema_version float
**Blueprint principle violated:** Principle 6 (Quality Bar Over Completeness)
**What happened:** `assert schema_version == "1.0"` may silently pass when schema_version is
the float 1.0 if the implementing code uses loose comparison.

**Replace the schema_version assertion in Step 0 with:**
```
assert type(schema_version) is string
assert schema_version == "1.0"
IF schema_version is numeric type:
  HALT: "Upstream validation failed: schema_version is a number ({actual}), 
  expected string '1.0'. Artifact may be from an incompatible tool version."
IF schema_version != "1.0":
  HALT: "Upstream validation failed: schema_version is '{actual}', 
  expected '1.0'. Artifact may be from an incompatible skill version. 
  Investigate before proceeding."
```

### Fix 3: Clarify data_volume classification timing — ⚠️ RECOMMENDED BEFORE MERGE
**Failing test:** Test 1 (happy-path), Test 6 (variance-very-large)
**Blueprint principle violated:** Principle 3 (Explicit Variance Surface — classification must be observable)
**What happened:** The Variance Surface table declares `data_volume` as a Step 0 dimension,
but row_count isn't known until AFTER Step 2 execution. Step 0 can't classify it.

**Fix:** Remove `data_volume` from Step 0 Context Classification. Add a classification step
in Step 3 Validate and Profile:
```
classify data_volume from row_count:
  IF row_count < 1,000,000: data_volume = "small"
  IF row_count >= 1,000,000 AND < 100,000,000: data_volume = "large"
  IF row_count >= 100,000,000: data_volume = "very_large"
log: "data_volume classified post-extraction: {data_volume} ({row_count} rows)"
```

---

## Tests Still Needed (pre-merge, real environment)

- **Test 18:** auth timeout — run with invalid keypair credentials
- **Test 19:** query timeout — run with SET query_timeout = 1; very large table
- **Test 2 (BigQuery):** run on real BigQuery instance with GOOGLE_APPLICATION_CREDENTIALS
- **Downstream validation:** confirm schema-profiling Step 0 can load raw_dataset.json
  and connect to the data_ref temp table

---

## Assessor Notes

The skill design is clean and well-scoped. The biggest structural insight from testing is
that `data_volume` cannot be a Step 0 classification dimension — it's an output of the
execution, not an input. This is a common mistake when designing skills with dimensions that
are discovered mid-workflow. The fix is straightforward: classify post-execution, not pre.

The platform-branching (Snowflake vs BigQuery) is well-designed and will be important for
correctness. The incremental extraction path (watermark-based) deserves real-environment
testing since fallback behavior (no prior extraction → windowed) is a meaningful code path.
