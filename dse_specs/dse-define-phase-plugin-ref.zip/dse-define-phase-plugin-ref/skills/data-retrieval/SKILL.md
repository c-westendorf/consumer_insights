---
name: data-retrieval
description: >
  Connects to Snowflake or BigQuery and extracts the raw dataset specified by the plan task
  node — handling authentication, query construction, and partition-aware extraction. Produces
  a raw_dataset artifact with full provenance metadata (source, query hash, row count,
  extraction timestamp) that schema-profiling consumes to understand the data structure.
  Activate when a plan task node specifies data_retrieval task_type and connection credentials
  are available in the environment.
inputs:
  - type: scope_artifact
    description: "Approved scope with population criteria, timeframe, and metric definitions that drive query construction"
  - type: plan_artifact
    description: "Plan task node identifying which tables/views to extract and any join requirements"
  - type: connection_config
    description: "Platform credentials and connection parameters for Snowflake or BigQuery"
outputs:
  - type: raw_dataset
    description: "Extracted dataset with provenance metadata — row count, column manifest, query hash, extraction timestamp, and data reference (temp table or file path)"
can_follow: [plan-formatting]
can_precede: [schema-profiling]
supports_loop: false
exit_conditions:
  - "raw_dataset artifact written with row_count > 0 and query_hash populated"
  - "extraction_timestamp recorded in ISO-8601 UTC"
---

## Overview

Every analytical pipeline begins with data retrieval. This skill is the bridge between the
plan-agent's specification (which tables, which time window, which customers) and the raw
data the rest of the pipeline operates on. Without a verified, provenance-tagged raw_dataset,
no downstream skill can establish data lineage or reproduce results.

The skill does not filter, transform, or clean data — it retrieves faithfully and documents
what it retrieved. The `quality_report` (produced by `data-quality-assessment`) is where
fitness judgments happen; `raw_dataset` is only a factual extraction record. If this skill
is skipped, downstream skills have no authoritative data source and no reproducible query.

Platform differences between Snowflake and BigQuery (SQL dialect, cost model, query syntax,
credential mechanism, partition semantics) are significant enough to drive separate code
paths. The skill selects the correct path from `connection_config.platform` in Step 0.

---

## When to Activate

- Plan task node has `task_type: "data_retrieval"` and is the first unexecuted task in the plan
- `scope_artifact.json` exists with `approved_at` set
- `plan_artifact.json` exists with `approved_at` set and a data_retrieval task node
- `connection_config` is available in the environment (credentials file or environment variables)
- A new analytical scope requires fresh data (not reusing a prior extraction)
- The prior raw_dataset is stale relative to the scope's timeframe end date
- User explicitly requests "pull the data" or "refresh the dataset"

---

## Preconditions

What must be true before this skill begins:
- [ ] `scope_artifact.json` exists in the project directory with `approved_at` set
- [ ] `plan_artifact.json` exists in the project directory with `approved_at` set
- [ ] A task node with `task_type: "data_retrieval"` exists in `plan_artifact.execution_view.task_nodes`
- [ ] `connection_config` contains `platform`, `database`, `schema`, and valid auth fields
- [ ] Declared tables/views in the plan task node exist in the target schema
- [ ] The scope's `timeframe.start` and `timeframe.end` are valid dates

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 1 — Domain core
# (none — artifact processing via standard JSON)

# Tier 2 — Domain optional
snowflake-connector-python>=3.0   # used when platform == "snowflake"
google-cloud-bigquery>=3.0        # used when platform == "bigquery"

# Tier 3 — Skill-specific
pyarrow>=12.0                     # columnar serialization for large datasets
sqlglot>=18.0                     # SQL dialect validation and translation

# Tier 4 — Infrastructure
# Python version: >=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; query execution happens in the data warehouse
- **Memory:** <500 MB (metadata only; data stays in warehouse or temp table)
- **Disk:** ~10 KB for raw_dataset artifact JSON (data_ref points to warehouse temp table)
- **Upstream Artifacts:** `scope_artifact.json` (fields: `population`, `timeframe`, `metric`),
  `plan_artifact.json` (fields: `execution_view.task_nodes` with data_retrieval type)
- **Credentials:** SNOWFLAKE_* or GOOGLE_APPLICATION_CREDENTIALS environment variables

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `platform` | `snowflake` / `bigquery` | SQL dialect, auth method, cost model, temp table syntax, connection library all differ |
| `extraction_scope` | `full_table` / `windowed_query` / `incremental` | windowed: adds date filters from scope timeframe; incremental: adds watermark from prior extraction |
| `data_volume` | `small` (<1M rows) / `large` (1M–100M) / `very_large` (>100M) | large: partition pruning required; very_large: WARN and recommend population-sampling downstream |
| `join_required` | `single_table` / `multi_table_join` | multi_table: validates join keys exist, logs join cardinality, adds query cost estimate |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify platform: read connection_config.platform → "snowflake" or "bigquery"
classify extraction_scope: examine plan task node → "full_table", "windowed_query", or "incremental"
classify join_required: examine plan task node input_requirements → "single_table" or "multi_table_join"
NOTE: data_volume cannot be classified here — row_count is unknown until Step 2 executes.
      data_volume will be classified in Step 3 after execution.
log: "Running data-retrieval | platform={value} | extraction_scope={value} | join_required={value}"
```

**Upstream Validation:**
```
load scope_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF schema_version is numeric type:
    HALT: "Upstream validation failed: schema_version is a number ({actual}), expected string '1.0'. Artifact may be from an incompatible tool version."
  IF schema_version != "1.0":
    HALT: "Upstream validation failed: schema_version is '{actual}', expected '1.0'. Investigate before proceeding."
assert approved_at is not null
  IF null: HALT: "Upstream validation failed: scope_artifact.json — approved_at is null. Run /scope and approve before extracting data."
assert population is not null
  IF null: HALT: "Upstream validation failed: scope_artifact.json — population is null. Scope extraction incomplete."
assert timeframe.start and timeframe.end are present
  IF missing: HALT: "Upstream validation failed: scope_artifact.json — timeframe.start or timeframe.end is missing."
assert timeframe.start parses as YYYY-MM-DD format
  IF invalid: HALT: "Upstream validation failed: scope_artifact.json — timeframe.start '{value}' is not a valid date (expected YYYY-MM-DD). Run /scope to correct the timeframe."
assert timeframe.end parses as YYYY-MM-DD format
  IF invalid: HALT: "Upstream validation failed: scope_artifact.json — timeframe.end '{value}' is not a valid date (expected YYYY-MM-DD). Run /scope to correct the timeframe."
assert timeframe.start < timeframe.end
  IF not: HALT: "Upstream validation failed: scope_artifact.json — timeframe.start '{start}' is not before timeframe.end '{end}'."

load plan_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: plan_artifact.json — schema_version mismatch. See scope_artifact fix above."
assert approved_at is not null
  IF null: HALT: "Upstream validation failed: plan_artifact.json — approved_at is null. Run /plan and approve before extracting data."
assert execution_view.task_nodes contains at least one task with task_type == "data_retrieval"
  IF missing: HALT: "Upstream validation failed: plan_artifact.json — no data_retrieval task node found. Re-run /plan to include a data retrieval step."

load connection_config
assert platform is one of ["snowflake", "bigquery"]
  IF not: HALT: "Connection config invalid: platform '{value}' is not supported. Must be 'snowflake' or 'bigquery'."
assert required auth fields present for the platform:
  snowflake: account, warehouse, database, schema, auth_method, role
  bigquery: project, dataset, auth_method
  IF missing: HALT: "Connection config invalid: missing required field '{field}' for platform '{platform}'."
```

---

### Step 1 — Construct Extraction Query

**Goal:** A valid, tested SQL query that retrieves exactly the data the plan specifies.

**Pre-step assertion:** Scope timeframe is valid; plan task node specifies source tables.

**Actions:**

*Branch on extraction_scope:*

**IF `windowed_query`:**
```
Read scope_artifact.timeframe: start, end, granularity, reference
Read plan task node: source_table, population_criteria, join_specifications
Construct SQL WHERE clause: filter on timeframe.reference column between start and end
Apply population criteria from scope_artifact.population.criteria as additional WHERE conditions
Validate date column exists in profiled_schema (if available) — if not, log WARN: "Date column not verified in schema profile"
```

**IF `full_table`:**
```
Read plan task node: source_table
Construct simple SELECT * or SELECT {columns} query
WARN: "Full table extraction requested — consider windowed query if table > 10M rows"
```

**IF `incremental`:**
```
Read prior raw_dataset artifact_id from project directory (if exists)
Read prior extraction_timestamp as watermark
Construct query with WHERE {timestamp_column} > {watermark}
If no prior extraction found: fall back to windowed_query path, log WARN: "No prior extraction found — falling back to full windowed extraction"
```

*Branch on join_required:*

**IF `multi_table_join`:**
```
Read join specifications from plan task node: left_table, right_table, join_key, join_type
Validate join_key exists in both tables (check profiled_schema if available)
Add JOIN clause to constructed query
Log estimated join cardinality as WARN if many-to-many detected
```

**Checkpoint:**
> - [ ] PASS: SQL query is syntactically valid for the target platform
> - [ ] HALT: required source table not found in schema → "Source table {table} not found in {schema}. Verify plan task node."
> - [ ] WARN: full table extraction on large table → "Full table extraction may be expensive. Consider windowed query."

**Post-step assertion:** A complete, platform-appropriate SQL query string exists.

---

### Step 2 — Connect and Execute

**Goal:** Query executes successfully and returns a result set or writes to a temp table.

**Pre-step assertion:** Valid SQL query constructed in Step 1; credentials available.

*Branch on platform:*

**IF `snowflake`:**
```
Connect using snowflake-connector-python with keypair or password auth
Set warehouse, database, schema from connection_config
Execute query with timeout = connection_config.timeout_seconds (default: 300)
Write results to Snowflake temp table: DSE_EXTRACTION_{artifact_id_short}
Record: row_count, query_cost_credits, execution_time_ms
```

**IF `bigquery`:**
```
Connect using google-cloud-bigquery with service account credentials
Set project, dataset from connection_config
Execute query as BigQuery job with timeout = connection_config.timeout_seconds
Write results to BigQuery temp table: DSE_EXTRACTION_{artifact_id_short}
Record: row_count, query_cost_bytes, execution_time_ms
```

**Checkpoint:**
> - [ ] PASS: query executes within timeout and returns row_count > 0
> - [ ] HALT: authentication failure → "Connection to {platform} failed: {error}. Check credentials."
> - [ ] HALT: query execution error → "Query execution failed: {error}. Review constructed SQL."
> - [ ] HALT: row_count == 0 → "Extraction returned 0 rows. Verify population criteria and timeframe in scope_artifact."
> - [ ] WARN: execution_time_ms > 60000 → "Query took >60s. Consider partition optimization."

**Post-step assertion:** Temp table exists with row_count > 0; cost metadata recorded.

---

### Step 3 — Validate and Profile Extraction

**Goal:** Confirm the extraction is complete and representative before writing the artifact.

**Pre-step assertion:** Temp table populated from Step 2.

**Actions:**
```
Count rows in temp table: row_count
Count distinct columns: column_count
Read column names and SQL types from temp table metadata
Sample 5 rows for validation (stored in artifact for downstream inspection)
Compute query_hash: SHA-256 of the constructed SQL query string (for reproducibility)
Check: does row_count match expected range from scope_artifact.population size estimate?
  IF wildly discrepant (>10x difference): WARN with explanation
```

*Branch on data_volume:*

**IF `very_large` (>100M rows):**
```
WARN: "Extraction exceeds 100M rows. population-sampling is strongly recommended downstream."
Record size_warning: true in artifact
```

**IF `large` (1M–100M rows):**
```
Log: "Large extraction: {row_count} rows. population-sampling recommended for iterative analysis."
```

**Checkpoint:**
> - [ ] PASS: column_count > 0 and row_count matches expectation within 10x
> - [ ] WARN: row_count > 100M → recommend population-sampling
> - [ ] WARN: column_count == 0 → "Extraction has no columns. Review query."

**Post-step assertion:** row_count, column_count, column manifest, and query_hash are recorded.

---

### Step 4 — Write Terminal Artifact

**Goal:** raw_dataset artifact written to project directory with full provenance.

**Actions:**
```
Generate artifact_id: UUID v4
Write raw_dataset.json to project directory with:
  schema_version: "1.0"
  skill_name: "data-retrieval"
  timestamp: current UTC in ISO-8601
  record_count: row_count from Step 3
  artifact_id: generated UUID
  source_platform: connection_config.platform
  source_table: plan task node source_table
  query_hash: SHA-256 of SQL query
  extraction_timestamp: current UTC
  row_count: row_count
  column_count: column_count
  columns: [{name, sql_type, nullable} for each column]
  sample_rows: 5 representative rows
  partitions_used: partition columns and values applied
  query_cost_mb: cost in MB or credit-equivalent
  data_ref: "DSE_EXTRACTION_{artifact_id_short}" (temp table name)
  size_warning: true/false
```

**Checkpoint:**
> - [ ] PASS: raw_dataset.json written; all 5 universal envelope fields present
> - [ ] HALT: write failure → "Could not write raw_dataset.json: {error}"

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "data-retrieval",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 847293,
  "artifact_id": "{uuid}",
  "source_platform": "snowflake",
  "source_table": "CUSTOMER_TRANSACTIONS.FACT_PURCHASES",
  "query_hash": "sha256:abc123...",
  "extraction_timestamp": "{ISO-8601 UTC}",
  "row_count": 847293,
  "column_count": 24,
  "columns": [
    {"name": "customer_id", "sql_type": "VARCHAR", "nullable": false},
    {"name": "transaction_date", "sql_type": "DATE", "nullable": false},
    {"name": "revenue", "sql_type": "FLOAT", "nullable": true}
  ],
  "sample_rows": 5,
  "partitions_used": ["transaction_date BETWEEN '2025-01-01' AND '2025-12-31'"],
  "query_cost_mb": 142.3,
  "data_ref": "DSE_EXTRACTION_a1b2c3d4",
  "size_warning": false
}
```

**Write to:** `raw_dataset.json` in the project directory.

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty extraction | `row_count == 0` after execution | HALT: "Extraction returned 0 rows. Verify population criteria and timeframe in scope_artifact. Population may not exist in the specified window." |
| Single row | `row_count == 1` | WARN: "Single row extracted — statistical analysis will not be meaningful. Verify criteria." |
| All-null dimension | Required column is 100% null in sample | WARN: "Column {name} is 100% null. Downstream skills relying on this column will fail quality gate." |
| Schema version mismatch | `scope_artifact.schema_version != "1.0"` | HALT: "Incompatible scope_artifact schema version: {actual}. Expected 1.0. Re-run scope." |
| Authentication timeout | Connection fails within retry limit | HALT: "Authentication to {platform} failed after {max_retries} attempts: {error}. Check credentials." |
| Query timeout | Execution exceeds `timeout_seconds` | HALT: "Query timed out after {timeout}s. Consider adding partition filters or increasing timeout in connection_config." |
| Temp table cleanup needed | Prior DSE_EXTRACTION_* table exists | WARN: "Prior extraction temp table found: {name}. Clean up if reusing session." |
| Very large extraction | `row_count > 100M` | WARN: size_warning set to true; proceed; strongly recommend population-sampling in next stage |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `raw_dataset.json` exists in the project directory with all 5 universal envelope fields
- [ ] `data_ref` points to a populated temp table in the target warehouse
- [ ] `query_hash` is a reproducible SHA-256 of the exact SQL query executed
- [ ] `row_count` matches the actual rows in the temp table
- [ ] `extraction_timestamp` is set so downstream skills can assess data freshness
- [ ] `columns` manifest lists every column extracted with type and nullability

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] All Step checkpoints passed or documented as WARN with explanation
- [ ] `raw_dataset.json` exists and validates against `data-type-registry.md` schema
- [ ] `row_count > 0` and matches temp table row count
- [ ] `query_hash` is populated (reproducibility guarantee)
- [ ] `extraction_timestamp` is within the scope's declared timeframe
- [ ] No blocking issues remain unaddressed
- [ ] `schema-profiling` Step 0 can successfully load `raw_dataset.json` and read `data_ref`

---

## Scope Boundary

This skill does NOT:
- Assess data fitness or quality → handled by `data-quality-assessment`
- Clean, impute, or transform data → handled by `data-remediation`
- Profile column types or relationships → handled by `schema-profiling`
- Define or filter the customer population → handled by `cohort-extraction`
- Optimize query performance → delegate to the data warehouse; this skill constructs valid queries, not optimal ones

---

## Downstream

Run after this skill completes:
1. **`schema-profiling`** — reads `raw_dataset.json`, uses `data_ref` to connect to the temp table and profile column types, cardinality, join candidates, and temporal grains
