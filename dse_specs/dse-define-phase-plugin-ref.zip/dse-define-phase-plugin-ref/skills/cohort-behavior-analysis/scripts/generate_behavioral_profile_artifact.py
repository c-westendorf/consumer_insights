#!/usr/bin/env python3
"""
generate_behavioral_profile_artifact.py
Stub script for cohort-behavior-analysis DSE skill.

Performs end-to-end behavioral profiling of a defined cohort: discovers behavioral segments
via k-means clustering on engineered features, validates them statistically with
Benjamini-Hochberg FDR correction, and writes behavioral_profile.json.

Usage:
    python generate_behavioral_profile_artifact.py \
        --feature-set feature_set.json \
        --cohort cohort.json \
        --scope-artifact scope_artifact.json \
        --output behavioral_profile.json \
        [--dry-run]

    python generate_behavioral_profile_artifact.py --help
"""

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Generate behavioral_profile artifact for DSE cohort-behavior-analysis skill.\n\n"
            "Discovers and validates behavioral segments within a single cohort population.\n"
            "Requires feature_set.json (feature_count > 0) and cohort.json (population_count > 1).\n"
            "Outputs behavioral_profile.json with validated segments and distinguishing behaviors."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exit codes:\n"
            "  0  behavioral_profile.json written successfully\n"
            "  1  HALT condition — upstream validation failed or no usable data\n"
            "  2  argument error\n\n"
            "Examples:\n"
            "  # Standard run\n"
            "  python generate_behavioral_profile_artifact.py \\\n"
            "      --feature-set feature_set.json \\\n"
            "      --cohort cohort.json \\\n"
            "      --scope-artifact scope_artifact.json \\\n"
            "      --output behavioral_profile.json\n\n"
            "  # Dry run — prints classification and segmentation plan without computing\n"
            "  python generate_behavioral_profile_artifact.py \\\n"
            "      --feature-set feature_set.json \\\n"
            "      --cohort cohort.json \\\n"
            "      --scope-artifact scope_artifact.json \\\n"
            "      --dry-run\n"
        ),
    )
    parser.add_argument(
        "--feature-set",
        required=True,
        help="Path to feature_set.json artifact from feature-engineering skill",
    )
    parser.add_argument(
        "--cohort",
        required=True,
        help="Path to cohort.json artifact from cohort-extraction skill",
    )
    parser.add_argument(
        "--scope-artifact",
        required=True,
        help="Path to scope_artifact.json from the DSE Define Phase",
    )
    parser.add_argument(
        "--quality-report",
        default=None,
        help="Path to quality_report.json from data-quality-assessment (advisory; optional)",
    )
    parser.add_argument(
        "--output",
        default="behavioral_profile.json",
        help="Output path for behavioral_profile.json (default: behavioral_profile.json)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "Classify context and print segmentation plan without executing clustering. "
            "No warehouse connection or sklearn computation required."
        ),
    )
    return parser.parse_args()


def load_artifact(path: str, artifact_type: str, required: bool = True) -> dict:
    """Load and minimally validate a DSE artifact (schema_version == '1.0')."""
    p = Path(path)
    if not p.exists():
        if not required:
            return {}
        print(f"ERROR: {artifact_type} not found at {path}", file=sys.stderr)
        sys.exit(1)
    with open(p) as f:
        try:
            artifact = json.load(f)
        except json.JSONDecodeError as e:
            print(f"ERROR: {artifact_type} at {path} is not valid JSON: {e}", file=sys.stderr)
            sys.exit(1)
    if str(artifact.get("schema_version")) != "1.0":
        print(
            f"ERROR: {artifact_type} schema_version must be '1.0' (string). "
            f"Found: {artifact.get('schema_version')!r}. Re-run the producing skill.",
            file=sys.stderr,
        )
        sys.exit(1)
    return artifact


def classify_context(feature_set: dict, cohort: dict) -> dict:
    """
    Step 0 context classification:
    - segmentation_basis: behavioral vs. lifecycle_trajectory
    - feature_richness: transaction_rich (>=6) vs. sparse (<6)
    Returns dict with classification results.
    """
    lifecycle_transform_types = {
        "rfm_velocity", "lifecycle_transition", "maturity_delta",
    }
    behavioral_transform_types = {
        "rate", "temporal_delta", "ratio", "log_transform",
        "ordinal_encoding", "frequency_encoding",
        "rfm_velocity", "lifecycle_transition",
    }

    features_applied = feature_set.get("features_applied", [])

    has_lifecycle = any(
        f.get("transform_type") in lifecycle_transform_types
        for f in features_applied
    )
    segmentation_basis = "lifecycle_trajectory" if has_lifecycle else "behavioral"

    behavioral_count = sum(
        1 for f in features_applied
        if f.get("transform_type") in behavioral_transform_types
    )
    # Fall back to total feature_count if transform_type metadata is absent
    if behavioral_count == 0:
        behavioral_count = feature_set.get("feature_count", len(features_applied))

    feature_richness = "transaction_rich" if behavioral_count >= 6 else "sparse"

    return {
        "segmentation_basis": segmentation_basis,
        "feature_richness": feature_richness,
        "behavioral_feature_count": behavioral_count,
        "has_lifecycle_features": has_lifecycle,
    }


def build_stub_segments(cohort: dict, feature_set: dict, context: dict) -> list:
    """
    Build stub segment structures for the behavioral_profile artifact.
    In a full implementation this is replaced by Steps 1–4 (EDA scan, k-means clustering,
    pattern identification, and Benjamini-Hochberg statistical validation).

    Returns a list of segment dicts matching the terminal artifact schema.
    """
    population_count = cohort.get("population_count") or cohort.get("record_count", 0)
    feature_names = [
        f.get("name", f"feature_{i}")
        for i, f in enumerate(feature_set.get("features_applied", []))
    ]

    # Stub: two segments splitting the cohort 60/40
    segments = [
        {
            "segment_id": "S-001",
            "label": "STUB-segment-1",  # analyst assigns meaningful label after real run
            "size": int(population_count * 0.60),
            "pct_of_cohort": 0.60,
            "distinguishing_behaviors": [
                f"{feature_names[0]}: +N.NN SD from mean" if feature_names else "feature_A: +N.NN SD from mean",
            ],
            "key_metrics": {
                "repeat_rate": None,
                "avg_spend": None,
            },
            "statistical_validation": {
                "method": "anova",
                "adjusted_p_value": None,
                "effect_size": None,
                "effect_size_type": "cohens_f",
                "validation_status": "STUB-not-computed",
            },
        },
        {
            "segment_id": "S-002",
            "label": "STUB-segment-2",
            "size": population_count - int(population_count * 0.60),
            "pct_of_cohort": 0.40,
            "distinguishing_behaviors": [
                f"{feature_names[0]}: -N.NN SD from mean" if feature_names else "feature_A: -N.NN SD from mean",
            ],
            "key_metrics": {
                "repeat_rate": None,
                "avg_spend": None,
            },
            "statistical_validation": {
                "method": "anova",
                "adjusted_p_value": None,
                "effect_size": None,
                "effect_size_type": "cohens_f",
                "validation_status": "STUB-not-computed",
            },
        },
    ]
    return segments


def main():
    args = parse_args()

    # ── Step 0: Load and validate upstream artifacts ──────────────────────────
    feature_set = load_artifact(args.feature_set, "feature_set")
    cohort = load_artifact(args.cohort, "cohort")
    scope = load_artifact(args.scope_artifact, "scope_artifact")

    quality_report = {}
    if args.quality_report:
        quality_report = load_artifact(args.quality_report, "quality_report", required=False)

    # HALT: feature_count == 0
    feature_count = feature_set.get("feature_count", len(feature_set.get("features_applied", [])))
    if feature_count == 0:
        print(
            "ERROR [HALT]: feature_set.feature_count=0. No behavioral features available. "
            "Re-run feature-engineering with a broader transform_scope.",
            file=sys.stderr,
        )
        sys.exit(1)

    # HALT: population_count < 2
    population_count = cohort.get("population_count") or cohort.get("record_count", 0)
    if population_count == 0:
        print(
            "ERROR [HALT]: cohort.population_count=0. Cannot segment an empty cohort. "
            "Re-run cohort-extraction and verify scope criteria.",
            file=sys.stderr,
        )
        sys.exit(1)
    if population_count == 1:
        print(
            "ERROR [HALT]: cohort.population_count=1. Cohort too small for segmentation "
            "(minimum 2 records required).",
            file=sys.stderr,
        )
        sys.exit(1)

    # Advisory: quality_report FAIL verdict
    if quality_report.get("verdict") == "FAIL":
        print(
            "WARN: quality_report.verdict is FAIL — proceeding in advisory mode. "
            "Segment results may be affected by known data quality issues.",
            file=sys.stderr,
        )

    # Context classification
    context = classify_context(feature_set, cohort)

    if context["feature_richness"] == "sparse":
        print(
            f"WARN: Fewer than 6 behavioral features available "
            f"(found={context['behavioral_feature_count']}) — segmentation may be limited.",
            file=sys.stderr,
        )

    # ── Dry run ───────────────────────────────────────────────────────────────
    if args.dry_run:
        print("=== DRY RUN — Cohort Behavior Analysis Plan ===")
        print(f"  feature_set:           {args.feature_set}")
        print(f"  cohort:                {args.cohort}")
        print(f"  scope_artifact:        {args.scope_artifact}")
        print()
        print("  Context Classification:")
        print(f"    segmentation_basis:       {context['segmentation_basis']}")
        print(f"    feature_richness:         {context['feature_richness']}")
        print(f"    behavioral_feature_count: {context['behavioral_feature_count']}")
        print(f"    population_count:         {population_count}")
        print()
        print("  Segmentation Plan:")
        k_range = [2, 3, 4, 5] if context["feature_richness"] == "transaction_rich" else [2, 3]
        print(f"    algorithm:   k-means (BIC-optimized)")
        print(f"    k_range:     {k_range}")
        print(f"    basis:       {context['segmentation_basis']}")
        print(f"    silhouette threshold: 0.25")
        print()
        print("  Statistical Validation:")
        print(f"    continuous features: one-way ANOVA + Cohen's f")
        print(f"    categorical features: chi-squared + Cramér's V")
        print(f"    correction: Benjamini-Hochberg FDR")
        print(f"    significance threshold: adjusted p < 0.05 AND effect_size >= 0.1")
        print()
        print("  Output:")
        print(f"    {args.output}")
        print()
        print("NOTE: No clustering or warehouse computation performed in dry-run mode.")
        return

    # ── Steps 1–4: Stub — replace with real EDA, clustering, and validation ──
    # In a production implementation:
    #   Step 1: Load feature_set.data_ref from warehouse; run univariate + bivariate EDA
    #   Step 2: k-means sweep (k in k_range); evaluate silhouette; set segment_discovery_outcome
    #   Step 3: Per-segment standardized feature diffs; assign interpretive labels
    #   Step 4: ANOVA/chi-squared per segment × feature; BH FDR correction; mark validated/inconclusive

    print("NOTE: Warehouse clustering not implemented in stub — writing stub artifact.", file=sys.stderr)

    # Stub outputs
    segment_discovery_outcome = "segments_found"  # real impl: "no_meaningful_segments" if silhouette < 0.25
    exploration_iterations = 4 if context["feature_richness"] == "transaction_rich" else 2
    silhouette_score = None  # real impl: best silhouette from sweep

    segments = build_stub_segments(cohort, feature_set, context)
    segments_identified = len(segments)

    # ── Step 5: Write terminal artifact ──────────────────────────────────────
    artifact = {
        "schema_version": "1.0",
        "skill_name": "cohort-behavior-analysis",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "record_count": population_count,
        "artifact_id": str(uuid.uuid4()),
        "cohort_artifact_id": cohort.get("artifact_id"),
        "feature_set_artifact_id": feature_set.get("artifact_id"),
        "scope_artifact_id": scope.get("artifact_id"),
        "segmentation_basis": context["segmentation_basis"],
        "feature_richness": context["feature_richness"],
        "segment_discovery_outcome": segment_discovery_outcome,
        "segments_identified": segments_identified,
        "segments": segments,
        "validation_method": "benjamini_hochberg_fdr",
        "exploration_iterations": exploration_iterations,
        "silhouette_score": silhouette_score,
    }

    output_path = Path(args.output)
    with open(output_path, "w") as f:
        json.dump(artifact, f, indent=2)

    print(f"behavioral_profile.json written to {output_path}")
    print(f"  segmentation_basis:        {context['segmentation_basis']}")
    print(f"  feature_richness:          {context['feature_richness']}")
    print(f"  segment_discovery_outcome: {segment_discovery_outcome}")
    print(f"  segments_identified:       {segments_identified}")
    print(f"  record_count:              {population_count}")
    print(f"  artifact_id:               {artifact['artifact_id']}")
    print()
    print("STUB: Replace Steps 1-4 in this script with real EDA, k-means clustering,")
    print("      pattern identification, and Benjamini-Hochberg statistical validation.")


if __name__ == "__main__":
    main()
