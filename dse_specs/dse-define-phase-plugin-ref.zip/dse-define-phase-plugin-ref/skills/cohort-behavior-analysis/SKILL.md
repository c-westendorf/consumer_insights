---
name: cohort-behavior-analysis
description: >
  End-to-end behavioral profiling of a defined cohort that discovers and validates behavioral
  segments within a single population. Activate when a scope_artifact with
  analytical_pattern: profile is ready and feature_set has been built; takes feature_set +
  cohort + quality_report; outputs behavioral_profile.json with validated segments and their
  distinguishing behavioral signatures.
inputs:
  - type: cohort
    description: "Defined and filtered population from cohort-extraction; population_count must be > 1 for segmentation to be meaningful"
  - type: feature_set
    description: "Engineered behavioral features from feature-engineering; data_ref drives all segmentation computation; feature_count must be > 0"
  - type: quality_report
    description: "Upstream quality assessment from data-quality-assessment; consumed as advisory context — issues noted but do not block unless verdict is FAIL"
outputs:
  - type: behavioral_profile
    description: "Validated behavioral segments with distinguishing behaviors, statistical validation results, and segment-level key metrics; written to behavioral_profile.json"
can_follow: [feature-engineering, data-quality-assessment]
can_precede: [finding-assembly, statistical-comparison]
supports_loop: true
exit_conditions:
  - "≥2 validated behavioral segments identified with distinct behavioral signatures"
  - "all segments statistically validated (p < 0.05 on distinguishing features)"
  - "exploration budget exhausted — best available segmentation recorded"
---

## Overview

Cohort-extraction determines who is in the analysis; feature-engineering determines what
signals describe them. Cohort-behavior-analysis asks the essential population question:
*what does this population do?* By applying segmentation to engineered behavioral features,
this skill discovers whether the cohort is behaviorally homogeneous — one undifferentiated
group — or meaningfully stratified into distinct behavioral types that should be understood
and communicated separately.

The skill operates as a full analytical pipeline: exploratory scan → behavioral segmentation
→ pattern identification → statistical validation → terminal artifact. Segmentation is not
applied blindly; the approach is informed by CGF behavioral dimensions (purchase frequency,
spend trajectory, engagement depth, recency). If the feature set includes lifecycle
trajectory features (RFM transition velocity, maturity classification signals), the skill
shifts to lifecycle_trajectory segmentation basis rather than static behavioral patterns.

**What this skill produces:** `behavioral_profile.json` with `segments` — each with a size,
distinguishing behaviors, key metrics, and a statistical validation block. If no meaningful
segmentation exists, the artifact still writes a single-population summary so downstream
skills have a complete, honest picture. The `supports_loop: true` flag means this skill
may be re-run with adjusted k or feature subsets if the initial segmentation is inconclusive.

**What this skill is not:**
- A comparison tool — profiles one cohort; comparing two cohorts belongs to `statistical-comparison`
- A generic clustering algorithm — segmentation is grounded in CGF behavioral dimensions, not
  arbitrary distance minimization
- A prediction model — describes observed behavior; does not forecast future actions

---

## When to Activate

- A plan task node with `task_type: "cohort_behavior_analysis"` is the next unexecuted task
- `feature_set.json` exists with `schema_version == "1.0"`, `feature_count > 0`, and a
  non-null `data_ref` pointing to a live warehouse temp table
- `scope_artifact.analytical_pattern == "profile"` (single-population question)
- User explicitly requests "profile the cohort", "segment the population", "find behavioral
  segments", or "what does this cohort do?"
- A prior run exited with `segment_discovery_outcome: "no_meaningful_segments"` and the
  analyst has added features or adjusted the scope — re-run is warranted

---

## Preconditions

What must be true before this skill begins:

- [ ] `feature_set.json` exists with `schema_version == "1.0"`, non-null `data_ref`, and
  `feature_count > 0`
- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_count > 1`
- [ ] `quality_report.json` exists with `schema_version == "1.0"` (advisory only — a FAIL
  verdict generates a WARN logged in the artifact but does not block execution)
- [ ] `feature_set.data_ref` warehouse temp table is accessible (not expired)
- [ ] `scope_artifact.analytical_pattern == "profile"` — this skill profiles one cohort, not
  two; compare pattern belongs to `statistical-comparison`

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: pandas>=2.0, scikit-learn>=1.3, scipy>=1.11, numpy>=1.25
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU; segmentation computation may require loading feature data locally for
  k-means/hierarchical clustering when warehouse ML functions are unavailable
- **Memory:** 500 MB – 4 GB depending on cohort size and feature_richness
- **Upstream Artifacts:** `feature_set.json` (data_ref, feature manifest), `cohort.json`
  (population_count, artifact_id), `quality_report.json` (verdict, issue log)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `segment_discovery_outcome` | `segments_found` / `no_meaningful_segments` | `segments_found`: full validation pipeline runs; all segment blocks written with statistical_validation; `no_meaningful_segments`: WARN issued; single-population summary written with segments=[], segments_identified=0, feature_count=0 |
| `segmentation_basis` | `behavioral` / `lifecycle_trajectory` | `behavioral`: segments by purchase and engagement patterns (frequency, spend, recency, basket depth); `lifecycle_trajectory`: segments by RFM state transition velocity using maturity_classification signals from feature_set |
| `feature_richness` | `transaction_rich` / `sparse` | `transaction_rich` (≥6 behavioral features): full segmentation attempted with k=2–5 BIC-optimized sweep; `sparse` (<6 features): WARN issued; segmentation limited to available dimensions, k capped at 3 |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify segmentation_basis:
  IF feature_set.features_applied contains any feature with transform_type in
     ["rfm_velocity", "lifecycle_transition", "maturity_delta"]:
    segmentation_basis = "lifecycle_trajectory"
  ELSE:
    segmentation_basis = "behavioral"
  log: "segmentation_basis={value}"

classify feature_richness:
  behavioral_feature_count = count of features in feature_set.features_applied where
    transform_type in ["rate", "temporal_delta", "ratio", "log_transform",
                       "ordinal_encoding", "frequency_encoding", "rfm_velocity",
                       "lifecycle_transition"]
  IF behavioral_feature_count >= 6:
    feature_richness = "transaction_rich"
  ELSE:
    feature_richness = "sparse"
  log: "feature_richness={value} (behavioral_feature_count={behavioral_feature_count})"

-- segment_discovery_outcome is UNKNOWN at Step 0; determined in Step 2
log: "segment_discovery_outcome=unknown (will be determined in Step 2)"

log: "Running cohort-behavior-analysis | basis={value} | richness={value}"
```

**Upstream Validation:**
```
load feature_set.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json — schema_version mismatch.
  Expected '1.0' (string). Re-run feature-engineering."
assert data_ref is not null
  IF null: HALT: "Upstream validation failed: feature_set.json — data_ref is null.
  Re-run feature-engineering to produce a valid warehouse temp table."
assert feature_count > 0
  IF feature_count == 0: HALT: "Upstream validation failed: feature_set.json — feature_count=0.
  No behavioral features available for segmentation. Re-run feature-engineering with a
  broader transform_scope or review scope_artifact.metric."

load cohort.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json — schema_version mismatch.
  Expected '1.0' (string). Re-run cohort-extraction."
assert population_count > 0
  IF population_count == 0: HALT: "Upstream validation failed: cohort.json — population_count=0.
  Cannot segment an empty cohort. Re-run cohort-extraction and verify scope criteria."
assert population_count > 1
  IF population_count == 1: HALT: "Upstream validation failed: cohort.json — population_count=1.
  Cohort size too small for segmentation (minimum 2 records required)."

load quality_report.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: quality_report.json — schema_version mismatch."
IF quality_report.verdict == "FAIL":
  WARN: "quality_report.verdict is FAIL — proceeding in advisory mode. Segment results
  may be affected by known data quality issues. Review quality_report.issues before
  interpreting behavioral_profile output."
```

**Checkpoint:**
> - [ ] PASS: all three artifacts loaded and valid; context classified; log written
> - [ ] HALT: feature_set schema_version mismatch, data_ref null, or feature_count == 0
> - [ ] HALT: cohort schema_version mismatch, population_count == 0, or population_count == 1
> - [ ] HALT: quality_report schema_version mismatch
> - [ ] WARN: quality_report.verdict == "FAIL" — proceed with advisory flag

---

### Step 1 — Exploratory Behavioral Scan

**Goal:** Survey the feature distributions to identify high-variance signals and correlated
feature clusters that form the raw material for segmentation.

**Pre-step assertion:** feature_set.data_ref is accessible; feature_count > 0.

**Actions:**
```
IF feature_richness == "sparse":
  WARN: "Fewer than 6 behavioral features available (found={behavioral_feature_count}) —
  segmentation may be limited to {behavioral_feature_count} dimension(s). Consider
  re-running feature-engineering with transform_scope=extended."

Load behavioral features from feature_set.data_ref:
  SELECT {features_applied[*].name}
  FROM {feature_set.data_ref}

Check for all-null feature columns:
  FOR each feature in features_applied:
    null_rate = COUNT(*) WHERE {feature.name} IS NULL / total_rows
    IF null_rate == 1.0:
      null_features.append(feature.name)
  IF len(null_features) == len(features_applied):
    HALT: "All behavioral features are null — no usable data for segmentation.
    Inspect warehouse temp table {feature_set.data_ref} and re-run feature-engineering."
  IF len(null_features) > 0:
    WARN: "Features with 100% null rate excluded from segmentation: {null_features}"
    active_features = features_applied EXCLUDING null_features
  ELSE:
    active_features = features_applied

Univariate distributions:
  FOR each feature in active_features:
    compute: mean, std, min, p25, p50, p75, max, null_rate
    cv = std / mean IF mean != 0 ELSE null
    IF cv > 1.0: high_variance_features.append(feature.name)
  log: "High-variance features (CV > 1.0): {high_variance_features}"

Bivariate correlation sweep:
  Compute pairwise Pearson correlation matrix on active_features
  Cluster correlated features (|r| > 0.8) into behavioral dimensions:
    FOR each correlation cluster:
      behavioral_dimensions.append({
        "features": [f1, f2, ...],
        "representative": feature with highest variance in cluster
      })
  segmentation_features = [dim.representative for dim in behavioral_dimensions]
    PLUS uncorrelated features not assigned to any cluster
  log: "Behavioral dimensions identified: {len(behavioral_dimensions)} | segmentation_features={N}"
```

**Checkpoint:**
> - [ ] PASS: univariate stats computed; segmentation_features list populated
> - [ ] HALT: all-null behavioral features (no usable data)
> - [ ] WARN: feature_richness=sparse — limited dimensions available
> - [ ] WARN: individual null-rate-100% features excluded from active_features

---

### Step 2 — Behavioral Segmentation

**Goal:** Discover behavioral segments via clustering; determine segment_discovery_outcome.

**Pre-step assertion:** segmentation_features list populated (Step 1).

**Branch on `feature_richness`:**
```
IF feature_richness == "transaction_rich":
  k_range = [2, 3, 4, 5]
  clustering_algorithm = "k-means (BIC-optimized)"
ELSE (sparse):
  k_range = [2, 3]
  clustering_algorithm = "k-means"
```

**Branch on `segmentation_basis`:**
```
IF segmentation_basis == "lifecycle_trajectory":
  feature_matrix = segmentation_features filtered to rfm_velocity and lifecycle_transition
    features PLUS any available maturity_delta features
  IF feature_matrix is empty (no lifecycle features found despite basis classification):
    WARN: "segmentation_basis=lifecycle_trajectory but no lifecycle features found —
    falling back to behavioral basis"
    feature_matrix = segmentation_features (all)
ELSE (behavioral):
  feature_matrix = segmentation_features (all)
```

**Segmentation sweep:**
```
Impute remaining nulls in feature_matrix: median imputation per feature
Standardize feature_matrix: z-score normalization (mean=0, std=1)

silhouette_scores = {}
FOR each k in k_range:
  Fit k-means with k clusters (random_state=42, n_init=10)
  Compute silhouette score on resulting cluster labels
  silhouette_scores[k] = score

best_k = argmax(silhouette_scores)
best_silhouette = max(silhouette_scores.values())

IF best_silhouette < 0.25:
  segment_discovery_outcome = "no_meaningful_segments"
  WARN: "No meaningful behavioral segments found — best silhouette score={best_silhouette:.3f}
  at k={best_k}, below threshold of 0.25. Producing single-population summary.
  Consider reviewing feature set or relaxing scope criteria."
ELSE:
  segment_discovery_outcome = "segments_found"
  k_selected = best_k
  cluster_labels = cluster assignments at k_selected
  log: "Segments found | k={k_selected} | silhouette={best_silhouette:.3f}"

-- Check for trivial segmentation (all customers in one cluster after k > 1 fit)
IF segment_discovery_outcome == "segments_found":
  segment_sizes = {s: COUNT(cluster_labels == s) for s in unique(cluster_labels)}
  dominant_segment_pct = max(segment_sizes.values()) / total_rows
  IF dominant_segment_pct > 0.95:
    WARN: "Trivial segmentation — {dominant_segment_pct:.0%} of cohort falls in a single
    segment. Feature set may not have sufficient discriminative signal. Review feature plan
    or consider re-running feature-engineering with extended scope."

log: "segment_discovery_outcome={value} | exploration_iterations={len(k_range)}"
```

**Checkpoint:**
> - [ ] PASS: segment_discovery_outcome determined; cluster assignments written
> - [ ] WARN: best_silhouette < 0.25 → no_meaningful_segments; proceed to Step 5 (single-
>   population summary)
> - [ ] WARN: dominant_segment_pct > 95% → trivial segmentation flagged

---

### Step 3 — Pattern Identification

**Goal:** For each segment, identify the behavioral behaviors that distinguish it from the
cohort average and assign an interpretive label.

**Pre-step assertion:** segment_discovery_outcome == "segments_found"; cluster_labels assigned.

**Skip condition:** IF segment_discovery_outcome == "no_meaningful_segments": SKIP to Step 5.

**Actions:**
```
cohort_means = mean of each feature in active_features across full cohort

segments = []
FOR each segment_id s in sorted(unique(cluster_labels)):
  segment_rows = rows where cluster_labels == s
  segment_size = len(segment_rows)
  pct_of_cohort = segment_size / total_rows

  -- Compute per-feature standardized differences
  feature_diffs = {}
  FOR each feature in active_features:
    seg_mean = mean of feature in segment_rows
    cohort_mean = cohort_means[feature]
    cohort_std = std of feature across full cohort
    standardized_diff = (seg_mean - cohort_mean) / cohort_std IF cohort_std > 0 ELSE 0
    feature_diffs[feature] = {
      "segment_mean": seg_mean,
      "cohort_mean": cohort_mean,
      "standardized_diff": standardized_diff
    }

  -- Top 3 distinguishing features (highest |standardized_diff|)
  top_3 = sorted(feature_diffs, key=lambda f: abs(feature_diffs[f]["standardized_diff"]),
                 reverse=True)[:3]
  distinguishing_behaviors = [f"{f}: {feature_diffs[f]['standardized_diff']:+.2f} SD from mean"
                               for f in top_3]

  -- Assign interpretive label from CGF behavioral archetypes
  IF segmentation_basis == "lifecycle_trajectory":
    label = derive label from dominant RFM transition direction:
      IF top feature is rfm_velocity AND segment_mean > cohort_mean: "expanding-engagement"
      IF top feature is rfm_velocity AND segment_mean < cohort_mean: "lapsing-trajectory"
      ELSE: "stable-lifecycle"
  ELSE (behavioral):
    label = derive label from combination of distinguishing features:
      IF top distinguishing features skew toward high frequency + low spend: "high-frequency-low-spend"
      IF top features skew toward low frequency + high spend: "low-frequency-high-spend"
      IF recency feature is dominant and segment is recent: "recently-activated"
      IF recency feature is dominant and segment is lapsed: "lapsed-reactivating"
      IF basket diversity feature is dominant: "expanding-basket"
      ELSE: "segment-{s+1}"  -- fallback label; analyst should rename

  -- Key metrics for artifact
  key_metrics = {}
  FOR each feature that maps to a business metric (repeat_rate, avg_spend, basket_size):
    key_metrics[metric_name] = segment_mean of corresponding feature

  segments.append({
    "segment_id": f"S-{s+1:03d}",
    "label": label,
    "size": segment_size,
    "pct_of_cohort": round(pct_of_cohort, 4),
    "distinguishing_behaviors": distinguishing_behaviors,
    "key_metrics": key_metrics,
    "_top_features_for_validation": top_3  -- internal; used in Step 4
  })

log: "Pattern identification complete | segments={len(segments)} | labels={[s.label for s in segments]}"
```

**Checkpoint:**
> - [ ] PASS: all segments have label, size, distinguishing_behaviors, key_metrics
> - [ ] WARN: fallback label "segment-N" used — analyst should assign meaningful label

---

### Step 4 — Statistical Validation

**Goal:** Confirm that distinguishing features differ significantly across segments; apply
FDR correction; mark each segment as validated or inconclusive.

**Pre-step assertion:** segments list populated (Step 3).

**Skip condition:** IF segment_discovery_outcome == "no_meaningful_segments": SKIP to Step 5.

**Actions:**
```
all_p_values = []      -- raw p-values for FDR correction (one per feature per segment)
test_results = []      -- (segment_id, feature, raw_p, effect_size, effect_size_type, method)

FOR each segment in segments:
  FOR each feature_name in segment._top_features_for_validation:
    feature_data = values of feature_name for all rows
    segment_mask = cluster_labels == segment.segment_id numeric index

    IF feature is continuous (type in ["float", "double", "decimal", "integer"]):
      -- One-way ANOVA: segment vs. rest-of-cohort
      group_in  = feature_data[segment_mask]
      group_out = feature_data[~segment_mask]
      F_stat, raw_p = scipy.stats.f_oneway(group_in, group_out)
      -- Cohen's f effect size
      n_in, n_out = len(group_in), len(group_out)
      grand_mean = mean(feature_data)
      ss_between = n_in*(mean(group_in) - grand_mean)**2 + n_out*(mean(group_out) - grand_mean)**2
      ss_within  = sum((group_in - mean(group_in))**2) + sum((group_out - mean(group_out))**2)
      eta_sq = ss_between / (ss_between + ss_within) IF (ss_between + ss_within) > 0 ELSE 0
      cohens_f = sqrt(eta_sq / (1 - eta_sq)) IF eta_sq < 1 ELSE 0
      method = "anova"; effect_size = cohens_f; effect_size_type = "cohens_f"

    ELSE (categorical):
      -- Chi-squared test of independence
      contingency = cross-tabulation of feature_name × segment membership (in / out)
      chi2, raw_p, dof, expected = scipy.stats.chi2_contingency(contingency)
      -- Cramér's V effect size
      n = total_rows
      cramers_v = sqrt(chi2 / (n * (min(contingency.shape) - 1))) IF chi2 > 0 ELSE 0
      method = "chi_squared"; effect_size = cramers_v; effect_size_type = "cramers_v"

    all_p_values.append(raw_p)
    test_results.append((segment.segment_id, feature_name, raw_p,
                         effect_size, effect_size_type, method))

-- Benjamini-Hochberg FDR correction across all p-values
adjusted_p_values = benjamini_hochberg(all_p_values)
  (rank p-values ascending; adjusted_p[i] = raw_p[i] * n_tests / rank[i];
   apply step-down monotonicity enforcement)

-- Assign validation_status per segment
FOR each segment in segments:
  segment_tests = [(adj_p, effect, etype, meth) for tests matching segment.segment_id]
  best_result = result with min adjusted_p in segment_tests
  adj_p, effect_size, etype, method = best_result

  IF adj_p < 0.05 AND effect_size >= 0.1:
    validation_status = "validated"
  ELSE:
    validation_status = "inconclusive"
    WARN: "Segment {segment.segment_id} ({segment.label}): no distinguishing feature
    reached significance after FDR correction (best adj_p={adj_p:.4f}, effect={effect_size:.3f}).
    Segment included in artifact with validation_status=inconclusive."

  segment.statistical_validation = {
    "method": method,
    "adjusted_p_value": round(adj_p, 6),
    "effect_size": round(effect_size, 4),
    "effect_size_type": etype,
    "validation_status": validation_status
  }

log: "Statistical validation complete | validated={count validated} |
inconclusive={count inconclusive} | correction=benjamini_hochberg_fdr"
```

**Checkpoint:**
> - [ ] PASS: all segments have statistical_validation block; at least one segment validated
> - [ ] WARN: one or more segments inconclusive — artifact written with inconclusive flag
> - [ ] WARN: all segments inconclusive — note prominently in artifact; analyst review required

---

### Step 5 — Write Terminal Artifact

**Goal:** Persist behavioral_profile.json with all segments, validation results, and run metadata.

**Pre-step assertion:** Either segments list validated (Step 4) OR
segment_discovery_outcome == "no_meaningful_segments".

**Actions:**
```
Generate artifact_id: UUID v4

record_count = population_count from cohort.json
  (= sum of all segment sizes when segments_found; = full cohort when no_meaningful_segments)

IF segment_discovery_outcome == "segments_found":
  -- Remove internal field before writing
  FOR each segment: remove segment._top_features_for_validation
  segments_payload = segments list
  segments_identified = len(segments)
ELSE:
  -- Single-population summary
  segments_payload = []
  segments_identified = 0
  silhouette_score = best_silhouette (the failing score, for diagnostic use)

Write behavioral_profile.json

Log: "behavioral_profile.json written | segment_discovery_outcome={value} |
segments_identified={segments_identified} | record_count={record_count} |
artifact_id={artifact_id}"
```

**Checkpoint:**
> - [ ] PASS: behavioral_profile.json written; all 5 universal envelope fields present
> - [ ] PASS: all segment blocks include statistical_validation when segments_found
> - [ ] HALT: write failure (disk/permissions error)

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "cohort-behavior-analysis",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 47821,
  "artifact_id": "{uuid}",
  "cohort_artifact_id": "{cohort.artifact_id}",
  "feature_set_artifact_id": "{feature_set.artifact_id}",
  "scope_artifact_id": "{scope_artifact.artifact_id}",
  "segmentation_basis": "behavioral | lifecycle_trajectory",
  "feature_richness": "transaction_rich | sparse",
  "segment_discovery_outcome": "segments_found | no_meaningful_segments",
  "segments_identified": 3,
  "segments": [
    {
      "segment_id": "S-001",
      "label": "high-frequency-low-spend",
      "size": 15302,
      "pct_of_cohort": 0.32,
      "distinguishing_behaviors": [
        "purchase_rate_per_30d: +2.14 SD from mean",
        "annual_spend_log1p: -1.08 SD from mean",
        "days_since_last_purchase: -0.73 SD from mean"
      ],
      "key_metrics": {
        "repeat_rate": 0.78,
        "avg_spend": 34.20
      },
      "statistical_validation": {
        "method": "anova",
        "adjusted_p_value": 0.000012,
        "effect_size": 0.38,
        "effect_size_type": "cohens_f",
        "validation_status": "validated"
      }
    },
    {
      "segment_id": "S-002",
      "label": "lapsed-reactivating",
      "size": 19488,
      "pct_of_cohort": 0.41,
      "distinguishing_behaviors": [
        "days_since_last_purchase: +1.92 SD from mean",
        "purchase_rate_per_30d: -1.31 SD from mean",
        "annual_spend_log1p: -0.44 SD from mean"
      ],
      "key_metrics": {
        "repeat_rate": 0.21,
        "avg_spend": 51.70
      },
      "statistical_validation": {
        "method": "anova",
        "adjusted_p_value": 0.000003,
        "effect_size": 0.42,
        "effect_size_type": "cohens_f",
        "validation_status": "validated"
      }
    },
    {
      "segment_id": "S-003",
      "label": "expanding-basket",
      "size": 13031,
      "pct_of_cohort": 0.27,
      "distinguishing_behaviors": [
        "basket_diversity_encoded: +1.77 SD from mean",
        "annual_spend_log1p: +1.22 SD from mean",
        "purchase_rate_per_30d: +0.61 SD from mean"
      ],
      "key_metrics": {
        "repeat_rate": 0.59,
        "avg_spend": 112.40
      },
      "statistical_validation": {
        "method": "anova",
        "adjusted_p_value": 0.000081,
        "effect_size": 0.31,
        "effect_size_type": "cohens_f",
        "validation_status": "validated"
      }
    }
  ],
  "validation_method": "benjamini_hochberg_fdr",
  "exploration_iterations": 4,
  "silhouette_score": 0.42
}
```

**Write to:** `behavioral_profile.json` in the project directory.

**`record_count`** = sum of all segment sizes (equals cohort population_count).

**`silhouette_score`** = the silhouette at the selected k; present even when
segment_discovery_outcome is "no_meaningful_segments" (records the best-achieved score for
diagnostic purposes).

**Single-population summary (`no_meaningful_segments`):**
```json
{
  "schema_version": "1.0",
  "skill_name": "cohort-behavior-analysis",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 47821,
  "artifact_id": "{uuid}",
  "cohort_artifact_id": "{cohort.artifact_id}",
  "feature_set_artifact_id": "{feature_set.artifact_id}",
  "scope_artifact_id": "{scope_artifact.artifact_id}",
  "segmentation_basis": "behavioral",
  "feature_richness": "sparse",
  "segment_discovery_outcome": "no_meaningful_segments",
  "segments_identified": 0,
  "segments": [],
  "validation_method": "benjamini_hochberg_fdr",
  "exploration_iterations": 2,
  "silhouette_score": 0.14
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty feature set (feature_count == 0) | feature_set.feature_count == 0 | HALT Step 0: "Upstream validation failed: feature_set.json — feature_count=0. No behavioral features available. Re-run feature-engineering." |
| Single-record cohort (population_count == 1) | cohort.population_count == 1 | HALT Step 0: "Upstream validation failed: cohort.json — population_count=1. Cohort size too small for segmentation." |
| All behavioral features are null | null_rate == 1.0 for every feature in active_features | HALT Step 1: "All behavioral features are null — no usable data for segmentation. Inspect warehouse temp table and re-run feature-engineering." |
| Feature set schema version mismatch | feature_set.schema_version != "1.0" | HALT Step 0: "Upstream validation failed: feature_set.json — schema_version mismatch. Expected '1.0' (string). Re-run feature-engineering." |
| No silhouette ≥ 0.25 at any k | best_silhouette < 0.25 across all k in k_range | WARN Step 2: "No meaningful behavioral segments found — best silhouette={score} below threshold 0.25." Set segment_discovery_outcome="no_meaningful_segments"; proceed to Step 5 with single-population summary |
| Trivial segmentation (>95% in one segment) | dominant_segment_pct > 0.95 after k-means | WARN Step 2: "Trivial segmentation — {pct:.0%} of cohort falls in single segment. Feature set may lack discriminative signal. Consider re-running feature-engineering with extended scope." |
| Feature richness sparse (<6 behavioral features) | behavioral_feature_count < 6 | WARN Step 1: "Fewer than 6 behavioral features available — segmentation limited to {N} dimension(s)." Cap k_range at [2, 3]; proceed |
| Segments fail statistical validation (all inconclusive) | all segments have validation_status="inconclusive" | WARN Step 4: "No segment reached statistical significance after FDR correction. Segments included with validation_status=inconclusive. Analyst review required before downstream use." Artifact is still written |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `behavioral_profile.json` exists with all 5 universal envelope fields
- [ ] `segment_discovery_outcome` is set to one of: `segments_found` | `no_meaningful_segments`
- [ ] When `segments_found`: every segment has `segment_id`, `label`, `size`, `pct_of_cohort`,
  `distinguishing_behaviors`, `key_metrics`, and `statistical_validation`
- [ ] When `segments_found`: `statistical_validation.validation_status` is one of:
  `validated` | `inconclusive` for every segment
- [ ] `cohort_artifact_id` and `feature_set_artifact_id` set for lineage tracing
- [ ] `silhouette_score` present regardless of segment_discovery_outcome
- [ ] Sum of `segments[*].size` == `record_count` when `segments_found`

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `behavioral_profile.json` written and validates against the terminal artifact spec
- [ ] `segment_discovery_outcome` determined and recorded
- [ ] When `segments_found`: at least one segment has `validation_status: "validated"`; any
  inconclusive segments are clearly marked and the analyst has acknowledged the WARN
- [ ] When `no_meaningful_segments`: single-population summary written; analyst notified to
  review feature set or reconsider the analytical question before proceeding downstream
- [ ] `silhouette_score` reflects the best k evaluated, not a placeholder
- [ ] `exploration_iterations` equals the number of k values evaluated in Step 2
- [ ] `finding-assembly` Step 0 can load `behavioral_profile.json` and read `segments`

---

## Scope Boundary

This skill does NOT:
- Compare behavioral profiles of two separate cohorts → handled by `statistical-comparison`
- Compute business metrics from raw transactions → handled by `metric-computation`
- Predict future customer behavior → not part of DSE Analyze Phase
- Generate stakeholder narrative from segment findings → handled by `narrative-generation`
- Assemble findings across multiple analyses → handled by `finding-assembly`

---

## Downstream

Run after this skill completes:
1. **`finding-assembly`** — reads `behavioral_profile.segments` for evidence assembly; uses
   `segment.label` and `distinguishing_behaviors` as primary evidence inputs; requires
   `segment_discovery_outcome` to determine whether segment-level or cohort-level evidence
   is assembled
2. **`statistical-comparison`** — may use segment assignments as comparison groups when a
   follow-on comparison question is scoped (e.g., "does segment S-001 differ from S-002 on
   metric X?"); reads `segment_id` list from behavioral_profile
3. **`narrative-generation`** — reads `segment.label`, `distinguishing_behaviors`, and
   `key_metrics` for storytelling; uses `validation_status` to calibrate confidence language
   in the stakeholder narrative
