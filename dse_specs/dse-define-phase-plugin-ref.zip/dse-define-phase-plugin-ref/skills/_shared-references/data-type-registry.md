# Data Type Registry — Analyze Phase

Typed data schemas for all artifacts produced and consumed by Analyze Phase skills.
Every `inputs:` and `outputs:` declaration in a SKILL.md frontmatter must reference a
type defined here. If a new type is needed, it must be registered here as part of the
skill's merge PR — do not improvise types inline.

All terminal artifacts carry the **universal 5-field envelope** (required on every artifact):
```json
{
  "schema_version": "1.0",
  "skill_name": "{verb-noun-identifier}",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": N,
  "artifact_id": "{uuid}"
}
```

---

## Raw Input Types (from Define Phase / external)

### `scope_artifact`
Produced by: `scope-formatting` (Define Phase)
```json
{
  "schema_version": "1.0",
  "skill_name": "scope-formatting",
  "approved_at": "{ISO-8601 UTC}",
  "approved_by": "user",
  "lifecycle_stage": "reactivated | new_customer | low_engaged | ...",
  "analytical_pattern": "profile | compare | predict | explain | segment",
  "confidence": 0.85,
  "population": {
    "description": "...",
    "criteria": [{"field": "...", "operator": "==", "value": "..."}]
  },
  "metric": {
    "name": "...",
    "definition": "...",
    "aggregation": "proportion | mean | count | sum | rate"
  },
  "timeframe": {
    "start": "YYYY-MM-DD",
    "end": "YYYY-MM-DD",
    "granularity": "daily | weekly | monthly",
    "reference": "..."
  },
  "comparison": null,
  "business_context": "...",
  "constraints": [],
  "human_readable_summary": "..."
}
```

### `plan_artifact`
Produced by: `plan-formatting` (Define Phase)
```json
{
  "schema_version": "1.0",
  "skill_name": "plan-formatting",
  "scope_artifact_id": "...",
  "stakeholder_view": [{"step": 1, "description": "..."}],
  "execution_view": {
    "task_nodes": [
      {
        "task_id": "TN-001",
        "task_type": "data_retrieval | schema_profiling | ...",
        "description": "...",
        "skill_ref": "data-retrieval",
        "input_requirements": ["..."],
        "estimated_complexity": "low | medium | high",
        "requires_human_review": false
      }
    ],
    "execution_order": [
      {"stage": 1, "tasks": ["TN-001"], "parallel": false}
    ],
    "dependencies": [
      {"from": "TN-001", "to": "TN-002", "data_type": "raw_dataset"}
    ]
  },
  "plan_metadata": {
    "total_tasks": N,
    "estimated_complexity": "low | medium | high",
    "skill_gaps": [],
    "scope_warnings": [],
    "novel_tasks": []
  }
}
```

### `connection_config`
Provided by: environment / user configuration
```json
{
  "platform": "snowflake | bigquery",
  "account": "...",
  "warehouse": "...",
  "database": "...",
  "schema": "...",
  "auth_method": "keypair | oauth | password",
  "role": "...",
  "timeout_seconds": 300,
  "max_retries": 3
}
```

---

## Group 1: Ingestion & Quality Types

### `raw_dataset`
Produced by: `data-retrieval`
```json
{
  "schema_version": "1.0",
  "skill_name": "data-retrieval",
  "source_platform": "snowflake | bigquery",
  "source_table": "...",
  "query_hash": "...",
  "extraction_timestamp": "{ISO-8601 UTC}",
  "row_count": N,
  "column_count": N,
  "columns": [
    {"name": "...", "sql_type": "...", "nullable": true}
  ],
  "sample_rows": 5,
  "partitions_used": ["..."],
  "query_cost_mb": N,
  "data_ref": "path/to/data or temp_table_name"
}
```

### `profiled_schema`
Produced by: `schema-profiling`
```json
{
  "schema_version": "1.0",
  "skill_name": "schema-profiling",
  "table_name": "...",
  "row_count": N,
  "columns": [
    {
      "name": "...",
      "dtype": "numeric_continuous | numeric_discrete | categorical_low_card | categorical_high_card | datetime | text_free | boolean | unknown",
      "null_rate": 0.02,
      "unique_count": N,
      "cardinality": "low | medium | high",
      "sample_values": ["..."],
      "is_primary_key": false,
      "is_foreign_key": false
    }
  ],
  "temporal_columns": [
    {"name": "...", "grain": "daily | weekly | monthly | transaction", "range_start": "...", "range_end": "..."}
  ],
  "join_candidates": [
    {"column": "...", "likely_joins_to": "...", "join_type": "1:1 | 1:many | many:many"}
  ],
  "profile_warnings": []
}
```

### `quality_report`
Produced by: `data-quality-assessment`
```json
{
  "schema_version": "1.0",
  "skill_name": "data-quality-assessment",
  "overall_fitness_score": 0.87,
  "gate_decision": "proceed | proceed_with_warnings | halt",
  "dimensions": {
    "completeness": {
      "score": 0.92,
      "issues": [{"column": "...", "null_rate": 0.08, "severity": "advisory | blocking"}]
    },
    "consistency": {
      "score": 0.95,
      "issues": [{"check": "...", "violation_rate": 0.05, "severity": "advisory | blocking"}]
    },
    "freshness": {
      "score": 0.90,
      "max_staleness_days": 3,
      "issues": []
    },
    "distributional": {
      "score": 0.85,
      "issues": [{"column": "...", "anomaly_type": "outlier | cardinality_shift | unexpected_null_spike", "severity": "advisory | blocking"}]
    }
  },
  "blocking_issues": [],
  "remediation_manifest": [
    {
      "issue_id": "...",
      "column": "...",
      "issue_type": "missing_values | outliers | type_mismatch | duplicates",
      "severity": "blocking | advisory",
      "recommended_treatment": "imputation | capping | removal | flag",
      "missingness_mechanism": "MCAR | MAR | MNAR | unknown"
    }
  ]
}
```

### `remediated_dataset`
Produced by: `data-remediation`
```json
{
  "schema_version": "1.0",
  "skill_name": "data-remediation",
  "source_raw_dataset_id": "...",
  "source_quality_report_id": "...",
  "row_count_before": N,
  "row_count_after": N,
  "columns_modified": N,
  "change_log": [
    {
      "issue_id": "...",
      "column": "...",
      "treatment_applied": "mean_imputation | median_imputation | multiple_imputation | regression_imputation | domain_constant | winsorizing | capping | removal | flag",
      "missingness_mechanism_detected": "MCAR | MAR | MNAR",
      "rows_affected": N,
      "justification": "..."
    }
  ],
  "data_ref": "path/to/remediated_data or temp_table_name",
  "remediation_warnings": []
}
```

---

## Group 2: Population Types

### `cohort`
Produced by: `cohort-extraction`
```json
{
  "schema_version": "1.0",
  "skill_name": "cohort-extraction",
  "lifecycle_stage": "...",
  "analytical_pattern": "...",
  "population_size": N,
  "reference_population_size": N,
  "extraction_criteria": [
    {"field": "...", "operator": "...", "value": "..."}
  ],
  "observation_window": {
    "start": "YYYY-MM-DD",
    "end": "YYYY-MM-DD",
    "anchor_event": "..."
  },
  "size_validation": {
    "meets_minimum": true,
    "minimum_required": 100,
    "power_notes": "..."
  },
  "customer_id_ref": "temp_table_name or path",
  "reference_customer_id_ref": "..."
}
```

### `sample_set`
Produced by: `population-sampling`
```json
{
  "schema_version": "1.0",
  "skill_name": "population-sampling",
  "sampling_method": "stratified | temporal | matched | random",
  "source_population_size": N,
  "sample_size": N,
  "target_effect_size": 0.2,
  "achieved_power": 0.85,
  "strata": [
    {"label": "...", "population_n": N, "sample_n": N, "coverage_pct": 0.95}
  ],
  "underpowered_cells": [],
  "temporal_window": {
    "direction": "pre | post | matched",
    "days": 90,
    "anchor_event": "..."
  },
  "sample_ref": "temp_table_name or path",
  "sampling_manifest": {
    "mece_validation": true,
    "query_cost_mb": N,
    "governance_log": "..."
  }
}
```

---

## Group 3: Transformation & Context Types

### `feature_set`
Produced by: `feature-engineering`
```json
{
  "schema_version": "1.0",
  "skill_name": "feature-engineering",
  "source_data_ref": "SAMPLE_COHORT_... or COHORT_...",
  "source_artifact_type": "sample_set | cohort",
  "source_artifact_id": "...",
  "scope_artifact_id": "...",
  "analytical_pattern": "profile | compare",
  "data_ref": "FEATURES_{source_data_ref}",
  "feature_count": N,
  "transform_scope": "standard | extended",
  "feature_derivability": "all_derivable | partial | none",
  "features_applied": [
    {
      "name": "...",
      "transform_type": "temporal_delta | rate | log_transform | ordinal_encoding | datetime_extraction | frequency_encoding",
      "source_columns": ["..."],
      "sql_expression": "...",
      "rationale": "..."
    }
  ],
  "features_skipped": [
    {"feature": "...", "reason": "column_not_found | type_mismatch", "missing_columns": ["..."]}
  ],
  "zero_variance_dropped": [
    {"name": "...", "reason": "zero_variance"}
  ],
  "column_count_original": N,
  "column_count_final": N
}
```
**Note on `data_ref` for compare pattern:**
```json
"data_ref": {
  "base":       "FEATURES_..._BASE",
  "comparison": "FEATURES_..._COMP"
}
```

### `metric_result`
Produced by: `metric-computation`
```json
{
  "schema_version": "1.0",
  "skill_name": "metric-computation",
  "metrics": [
    {
      "name": "...",
      "definition": "...",
      "aggregation_type": "proportion | mean | median | count | sum | rate | percentile | weighted_mean | rolling_mean | cohort_indexed",
      "grain": "customer | transaction | period",
      "value": N,
      "confidence_interval_95": [N, N],
      "ci_method": "bootstrap | normal_approx | wilson",
      "population": "target | reference",
      "period": "YYYY-MM-DD to YYYY-MM-DD",
      "n_observations": N
    }
  ],
  "computation_warnings": []
}
```

### `context_map`
Produced by: `business-context-layer`
```json
{
  "schema_version": "1.0",
  "skill_name": "business-context-layer",
  "definitions": [
    {
      "term": "...",
      "field_mapping": "table.column",
      "business_definition": "...",
      "version_effective_date": "YYYY-MM-DD",
      "cgf_lifecycle_stage": "..."
    }
  ],
  "data_lineage": [
    {"field": "...", "source_table": "...", "transformation": "..."}
  ],
  "known_definition_changes": [
    {"term": "...", "changed_on": "YYYY-MM-DD", "old_definition": "...", "new_definition": "..."}
  ]
}
```

### `maturity_classification`
Produced by: `maturity-state-classification`
```json
{
  "schema_version": "1.0",
  "skill_name": "maturity-state-classification",
  "classification_method": "cgf_rfm_threshold",
  "lifecycle_stages_used": ["reactivated", "at_risk", "high_engaged"],
  "customer_count": N,
  "state_distribution": {
    "acquisition": N,
    "new_customer": N,
    "low_engaged": N,
    "medium_engaged": N,
    "high_engaged": N,
    "reactivated": N,
    "at_risk": N,
    "lapsed": N
  },
  "trajectory_annotation": {
    "improving": N,
    "stable": N,
    "declining": N
  },
  "thresholds_applied": {
    "recency_days": {"at_risk": 60, "lapsed": 365},
    "frequency_min": {"low_engaged": 1, "medium_engaged": 3, "high_engaged": 6},
    "monetary_min": {"low_engaged": 10.0}
  },
  "classification_ref": "temp_table_name or path"
}
```

### `behavioral_impact`
Produced by: `behavioral-impact-estimation`
```json
{
  "schema_version": "1.0",
  "skill_name": "behavioral-impact-estimation",
  "behaviors_evaluated": [
    {
      "behavior": "second_purchase_within_30_days | cross_category_expansion | digital_adoption | subscription_upgrade",
      "behavior_rate": 0.23,
      "outcome_with_behavior_mean": N,
      "outcome_without_behavior_mean": N,
      "observed_difference": N,
      "adjusted_difference": N,
      "adjustment_method": "propensity_stratification | covariate_matching | none",
      "causal_confidence": "observational | adjusted | quasi-experimental",
      "confidence_interval_95": [N, N],
      "n_with_behavior": N,
      "n_without_behavior": N
    }
  ],
  "outcome_metric": "...",
  "causal_confidence_note": "observational estimates: directional only; adjusted: estimated; quasi-experimental: attributed"
}
```

---

## Group 4: Statistical Analysis Types

### `hypothesis_set`
Produced by: `exploratory-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "exploratory-analysis",
  "hypotheses": [
    {
      "hypothesis_id": "H-001",
      "statement": "...",
      "evidence_type": "distribution_gap | correlation | anomaly | cluster_separation",
      "observed_effect_size": 0.32,
      "effect_size_type": "cohens_d | cramers_v | pearson_r | eta_squared",
      "effect_size_magnitude": "small | medium | large",
      "supporting_features": ["..."],
      "rank": 1,
      "priority": "high | medium | low"
    }
  ],
  "exploration_iterations": N,
  "patterns_examined": N,
  "hypotheses_meeting_threshold": N
}
```

### `comparison_result`
Produced by: `statistical-comparison`
```json
{
  "schema_version": "1.0",
  "skill_name": "statistical-comparison",
  "comparisons": [
    {
      "comparison_id": "C-001",
      "metric": "...",
      "test_type": "pairwise | multi_group",
      "test_name": "welch_t | mann_whitney_u | chi_squared | ks_test | anova | kruskal_wallis",
      "groups": ["target", "reference"],
      "group_means": {"target": N, "reference": N},
      "raw_p_value": 0.023,
      "adjusted_p_value": 0.041,
      "adjustment_method": "benjamini_hochberg | bonferroni | none",
      "effect_size": 0.45,
      "effect_size_type": "cohens_d | cramers_v | eta_squared",
      "effect_size_magnitude": "small | medium | large",
      "confidence_interval_95": [N, N],
      "n_target": N,
      "n_reference": N,
      "conclusion": "significant | not_significant | borderline"
    }
  ],
  "post_hoc_tests": [],
  "multiple_comparisons_corrected": true,
  "correction_method": "benjamini_hochberg | bonferroni",
  "n_comparisons_total": N
}
```

### `hypothesis_result`
Produced by: `hypothesis-validation`
```json
{
  "schema_version": "1.0",
  "skill_name": "hypothesis-validation",
  "hypotheses_tested": [
    {
      "hypothesis_id": "...",
      "statement": "...",
      "verdict": "supported | not_supported | inconclusive",
      "evidence_strength": "strong | moderate | weak",
      "test_applied": "...",
      "adjusted_p_value": N,
      "effect_size": N,
      "confounders_checked": ["..."],
      "confounder_adjustment_method": "stratification | regression | none",
      "alternative_explanations_assessed": ["..."],
      "upgrade_recommendation": "none | requires_causal_linkage_analysis"
    }
  ],
  "hypotheses_count": N,
  "supported_count": N,
  "inconclusive_count": N
}
```

### `retention_curve`
Produced by: `retention-curve-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "retention-curve-analysis",
  "cohort_size": N,
  "observation_periods": N,
  "period_grain": "daily | weekly | monthly",
  "retention_rates": [
    {"period": 1, "retained_count": N, "retention_rate": 0.72, "churned_count": N}
  ],
  "survival_curve": {
    "method": "kaplan_meier | discrete_hazard",
    "median_survival_period": N,
    "inflection_periods": [3, 7]
  },
  "spend_trajectory": [
    {"period": 1, "mean_spend": N, "median_spend": N}
  ],
  "baseline_comparison": {
    "baseline_cohort": "...",
    "statistically_worse_than_baseline": false,
    "p_value": N
  },
  "critical_dropoff_period": 3
}
```

---

## Group 5: Advanced Analytical Types

### `interval_result`
Produced by: `stickiness-interval-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "stickiness-interval-analysis",
  "analysis_level": "individual_customer",
  "customer_count": N,
  "stickiness_scores": {
    "mean": 0.62,
    "median": 0.67,
    "p25": 0.41,
    "p75": 0.81,
    "distribution_ref": "path/to/scores"
  },
  "interval_patterns": [
    {
      "pattern_label": "regular_weekly | irregular | accelerating | decelerating | dormant",
      "customer_count": N,
      "mean_inter_event_days": N,
      "cv_inter_event": N
    }
  ],
  "trajectory_classifications": {
    "deepening_engagement": N,
    "stable": N,
    "decelerating": N,
    "at_risk": N
  }
}
```

### `behavioral_profile`
Produced by: `cohort-behavior-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "cohort-behavior-analysis",
  "cohort_size": N,
  "segments_identified": N,
  "segments": [
    {
      "segment_id": "S-001",
      "label": "...",
      "size": N,
      "pct_of_cohort": 0.32,
      "distinguishing_behaviors": ["..."],
      "key_metrics": {"repeat_rate": N, "avg_spend": N},
      "statistical_validation": {"method": "...", "p_value": N, "effect_size": N}
    }
  ],
  "validation_method": "chi_squared | anova | permutation_test",
  "exploration_iterations": N
}
```

### `decay_profile`
Produced by: `engagement-decay-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "engagement-decay-analysis",
  "non_engagement_threshold_weeks": 13,
  "scoring_grain": "week",
  "cohort_size": N,
  "decay_inflection_points": [
    {
      "week": N,
      "avg_engagement_score": N,
      "pct_showing_decay": 0.34,
      "is_critical_inflection": true
    }
  ],
  "pre_decay_behaviors": ["..."],
  "customer_decay_trajectories": "path/to/individual_scores"
}
```

### `reactivation_profile`
Produced by: `reactivation-behavior-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "reactivation-behavior-analysis",
  "churn_threshold_weeks": 52,
  "cohort_size": N,
  "reactivation_triggers_identified": [
    {
      "trigger": "...",
      "trigger_rate": 0.18,
      "confidence": "high | medium | low"
    }
  ],
  "post_reactivation_behavior": {
    "repeat_purchase_rate_90d": N,
    "avg_spend_90d": N,
    "category_expansion_rate": N,
    "comparison_to_pre_lapse": {"spend_recovery_pct": N, "frequency_recovery_pct": N}
  },
  "value_recovery_sustainability": "strong | moderate | weak | declining"
}
```

### `factor_model`
Produced by: `latent-factor-modeling`
```json
{
  "schema_version": "1.0",
  "skill_name": "latent-factor-modeling",
  "method": "factor_analysis | pca",
  "method_selection_rationale": "...",
  "n_factors": N,
  "factor_selection_method": "scree_plot | parallel_analysis | bic",
  "rotation": "varimax | promax | none",
  "factorability_tests": {
    "kmo_score": 0.78,
    "bartletts_p_value": 0.001
  },
  "model_fit": {
    "cfi": 0.96,
    "rmsea": 0.05,
    "srmr": 0.04
  },
  "factors": [
    {
      "factor_id": "F-001",
      "label": "...",
      "top_loading_features": [{"feature": "...", "loading": 0.82}],
      "variance_explained_pct": 0.23,
      "interpretive_notes": "..."
    }
  ],
  "cluster_assignments_ref": "path/to/assignments"
}
```

### `value_decomposition`
Produced by: `value-decomposition-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "value-decomposition-analysis",
  "decomposition_frame": "accounts_x_volume_x_value",
  "periods_compared": [
    {"label": "current", "start": "...", "end": "..."},
    {"label": "prior", "start": "...", "end": "..."}
  ],
  "total_value_change": N,
  "total_value_change_pct": 0.12,
  "decomposition": {
    "accounts_effect": {"change": N, "pct_contribution": 0.40, "direction": "growth | shrink"},
    "volume_per_account_effect": {"change": N, "pct_contribution": 0.35, "direction": "growth | shrink"},
    "value_per_transaction_effect": {"change": N, "pct_contribution": 0.25, "direction": "growth | shrink"}
  },
  "segment_decompositions": [
    {"segment": "...", "total_change": N, "accounts_effect": N, "volume_effect": N, "value_effect": N}
  ]
}
```

### `signal_result`
Produced by: `leading-indicator-development`
```json
{
  "schema_version": "1.0",
  "skill_name": "leading-indicator-development",
  "outcome_variable": "...",
  "outcome_horizon_days": 90,
  "indicators": [
    {
      "indicator_id": "I-001",
      "feature": "...",
      "predictive_method": "mutual_information | logistic_auc | survival_concordance",
      "predictive_score": 0.72,
      "lead_time_days": 30,
      "confidence": "high | medium | low",
      "validation_holdout_score": 0.69,
      "causal_note": "association only | adjusted | quasi-experimental"
    }
  ],
  "exploration_iterations": N,
  "indicators_meeting_threshold": N
}
```

### `causal_result`
Produced by: `causal-linkage-analysis`
```json
{
  "schema_version": "1.0",
  "skill_name": "causal-linkage-analysis",
  "causal_claim": "...",
  "method_selected": "diff_in_diff | propensity_score_matching | instrumental_variables | regression_discontinuity",
  "method_selection_rationale": "...",
  "data_structure_required": "panel_data | cross_sectional_with_instrument | natural_experiment",
  "effect_estimate": N,
  "effect_estimate_ci_95": [N, N],
  "effect_unit": "...",
  "robustness_checks": [
    {"check_name": "placebo_test | alternative_specification | subsample", "result": "passes | fails", "notes": "..."}
  ],
  "causal_confidence": "quasi-experimental",
  "assumptions_required": ["parallel_trends | exclusion_restriction | ..."],
  "assumptions_validated": true,
  "interpretation": "..."
}
```

---

## Group 6: Synthesis & Delivery Types

### `roi_result`
Produced by: `roi-computation`
```json
{
  "schema_version": "1.0",
  "skill_name": "roi-computation",
  "upstream_evidence_type": "observational | adjusted | quasi-experimental | causal",
  "impact_qualifier": "directional | estimated | attributed",
  "metric_name": "...",
  "revenue_impact": N,
  "revenue_impact_ci_95": [N, N],
  "cost_per_outcome": N,
  "roi_ratio": N,
  "computation_basis": "comparison_result | behavioral_impact | causal_result | interval_result",
  "period": "...",
  "population_size": N,
  "interpretation_note": "directional: association only; estimated: adjusted; attributed: quasi-experimental"
}
```

### `finding_set`
Produced by: `finding-assembly`
```json
{
  "schema_version": "1.0",
  "skill_name": "finding-assembly",
  "scope_covered": true,
  "scope_gaps": [],
  "findings": [
    {
      "finding_id": "F-001",
      "statement": "...",
      "evidence_strength": "strong | moderate | weak",
      "evidence_sources": ["comparison_result", "hypothesis_result"],
      "rank": 1,
      "contradictions_with": [],
      "causal_confidence": "observational | adjusted | quasi-experimental | causal"
    }
  ],
  "contradictions_found": [],
  "total_findings": N,
  "scope_coverage_assessment": "complete | partial | insufficient"
}
```

### `narrative`
Produced by: `narrative-generation`
```json
{
  "schema_version": "1.0",
  "skill_name": "narrative-generation",
  "executive_summary": "...",
  "sections": [
    {
      "section_id": "S-001",
      "title": "...",
      "body": "...",
      "evidence_refs": ["F-001"],
      "visualization_specs": [
        {"chart_type": "bar | line | scatter | heatmap | funnel", "x": "...", "y": "...", "title": "..."}
      ]
    }
  ],
  "recommendations": [
    {"recommendation": "...", "supporting_finding": "F-001", "confidence": "high | medium | low"}
  ],
  "stakeholder_context": "...",
  "caution_flags": []
}
```

### `delivery_record`
Produced by: `notify-schedule`
```json
{
  "schema_version": "1.0",
  "skill_name": "notify-schedule",
  "channels_used": ["email | teams | slack"],
  "deliveries": [
    {
      "channel": "email",
      "recipients": ["..."],
      "sent_at": "{ISO-8601 UTC}",
      "subject": "...",
      "status": "delivered | failed | pending"
    }
  ],
  "scheduled_deliveries": [
    {
      "cadence": "daily | weekly | monthly",
      "next_delivery": "{ISO-8601 UTC}",
      "channel": "...",
      "recipients": ["..."]
    }
  ]
}
```
