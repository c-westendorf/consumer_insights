# CGF Taxonomy — Stub

CGF lifecycle stages and analytical patterns. See `dse-define-phase-spec-local-agent.md` §CGF Alignment.
