# Skill Registry — Analyze Phase

Available skills, their typed interfaces, pipeline position, and current build status.
Each entry corresponds to a `SKILL.md` file in the appropriate plugin directory.

**Registry format:**
- 🔴 NOT BUILT — does not exist yet
- 🟡 IN PROGRESS — stub or draft SKILL.md exists, not governance-compliant
- 🟠 REFACTOR NEEDED — exists with content but missing DSE frontmatter
- 🟢 COMPLIANT — passes 17-item pre-merge checklist

---

## Group 1 — Data Ingestion & Quality

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `data-retrieval` | 🟡 CONDITIONAL (pending real-env tests 18, 19) | `scope_artifact`, `plan_artifact`, `connection_config` | `raw_dataset` | `plan-formatting` | `schema-profiling` |
| `schema-profiling` | 🟡 CONDITIONAL (pending real-env tests 14, 15, BigQuery) | `raw_dataset`, `plan_artifact` (optional) | `profiled_schema` | `data-retrieval` | `data-quality-assessment`, `business-context-layer`, `cohort-extraction`, `feature-engineering` |
| `data-quality-assessment` | 🟡 CONDITIONAL (pending real-env tests: drift detection with real prior report, APPROX_PERCENTILE on ≥1M rows, data-remediation handoff validation) | `raw_dataset`, `profiled_schema`, `scope_artifact`, `quality_report` (optional prior) | `quality_report` (with `remediation_manifest`) | `schema-profiling` | `data-remediation`, `cohort-extraction` |
| `data-remediation` | 🟡 CONDITIONAL (dse-skill-tester done; 4 critical fixes applied; pending real-env tests: all variance dimensions, imputation paths, large-volume SQL CTAS; script stub only) | `raw_dataset`, `quality_report` | `remediated_dataset` | `data-quality-assessment` | `data-quality-assessment` (re-assess), `cohort-extraction`, `feature-engineering`, `exploratory-analysis` |

---

## Group 2 — Population & Sampling

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `cohort-extraction` | 🟡 CONDITIONAL (dse-skill-tester done; 1 critical fix applied; pending real-env tests: warehouse SQL execution, compare pattern, multi-operator predicates; script stub only) | `raw_dataset` or `remediated_dataset`, `quality_report`, `scope_artifact` | `cohort` | `data-quality-assessment`, `data-remediation` | `population-sampling`, `feature-engineering`, `metric-computation`, `exploratory-analysis` |
| `population-sampling` | 🟡 CONDITIONAL (dse-skill-tester done; 1 critical fix applied — random sampling path now unblocked; pending real-env tests: warehouse census SQL, scipy power analysis, stratified UNION ALL, compare pattern; stub script only) | `cohort`, `scope_artifact` | `sample_set` | `cohort-extraction` | `feature-engineering`, `metric-computation`, `exploratory-analysis` |

---

## Group 3 — Transformation & Context

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `feature-engineering` | 🟡 CONDITIONAL (dse-skill-tester done 13✅/4⚠️; Fix 1 applied: INFORMATION_SCHEMA fallback added; Fix 2 applied: plan_artifact declared as optional input for extended scope; Fix 3 applied: P4/EC7 text aligned; pending real-env tests: warehouse SQL execution, extended scope, compare column mismatch, log1p-negative path; script stub only) | `sample_set` or `cohort`, `scope_artifact`, `plan_artifact` (optional) | `feature_set` | `population-sampling`, `cohort-extraction` | `metric-computation`, `exploratory-analysis` |
| `metric-computation` | 🟡 CONDITIONAL (dse-skill-tester done; 2 fixes applied: C4 cohort existence check, D10 weighted mean null-weight guard; pending real-env tests, script, requirements.txt) | `cohort` or `sample_set`, `feature_set`, `scope_artifact` | `metric_result` | `feature-engineering`, `cohort-extraction` | `statistical-comparison`, `exploratory-analysis`, `behavioral-impact-estimation`, `roi-computation` |
| `exploratory-analysis` | 🟡 CONDITIONAL (dse-skill-tester done 30✅/0❌; pending real-env tests, script, requirements.txt) | `feature_set`, `metric_result`, `quality_report` | `hypothesis_set` | `feature-engineering`, `metric-computation` | `hypothesis-validation`, `statistical-comparison` |
| `behavioral-impact-estimation` | 🟡 CONDITIONAL (dse-skill-tester done 34✅/1⚠️; D2 single-record continuation advisory; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set`, `metric_result` | `behavioral_impact` | `metric-computation`, `feature-engineering` | `roi-computation`, `causal-linkage-analysis`, `finding-assembly` |
| `maturity-state-classification` | 🟡 CONDITIONAL (dse-skill-tester done; 2 fixes applied: D7 custom threshold validation, D1 HALT message reconciliation; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set` | `maturity_classification` | `feature-engineering` | `retention-curve-analysis`, `engagement-decay-analysis`, `exploratory-analysis`, `finding-assembly` |
| `business-context-layer` | 🟡 CONDITIONAL (dse-skill-tester done; 3 fixes applied: unmappable columns HALT, date bounds check, file-not-found HALTs; pending real-env tests, script, requirements.txt) | `profiled_schema`, `scope_artifact` | `context_map` | `schema-profiling` | `exploratory-analysis`, `narrative-generation`, `finding-assembly` |

---

## Group 4 — Statistical Analysis

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `statistical-comparison` | 🟡 CONDITIONAL (dse-skill-tester done; 5 fixes applied: p-value representation, record_count semantics, Tier 1 deps, post-hoc test, categorical test; pending real-env tests, script, requirements.txt) | `cohort` (target + reference), `metric_result`, `feature_set` | `comparison_result` | `metric-computation`, `exploratory-analysis` | `hypothesis-validation`, `roi-computation`, `value-decomposition-analysis`, `finding-assembly` |
| `hypothesis-validation` | 🟡 CONDITIONAL (dse-skill-tester done; 4 fixes applied: not_supported_count field, warehouse check, loop mechanics, effect size thresholds; pending real-env tests, script, requirements.txt) | `hypothesis_set`, `feature_set`, `metric_result` | `hypothesis_result` | `exploratory-analysis`, `statistical-comparison` | `finding-assembly`, `causal-linkage-analysis` |
| `retention-curve-analysis` | 🟡 CONDITIONAL (dse-skill-tester done; 3 fixes applied: Step 0 expansion, 0% retention HALT, single-period contradiction resolved; pending real-env tests, script, requirements.txt) | `cohort`, `metric_result`, `maturity_classification` | `retention_curve` | `metric-computation`, `maturity-state-classification` | `stickiness-interval-analysis`, `roi-computation`, `finding-assembly` |

---

## Group 5 — Advanced Analytical Skills

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `cohort-behavior-analysis` | 🔴 NOT BUILT | `cohort`, `feature_set`, `quality_report` | `behavioral_profile` | `feature-engineering`, `data-quality-assessment` | `finding-assembly`, `statistical-comparison` |
| `stickiness-interval-analysis` | 🟡 CONDITIONAL (dse-skill-tester done; 7 fixes applied: interval_granularity branches, trajectory_window branches, all-null HALT, testable precondition, boundary thresholds, classification precedence, Step 0 expansion; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set`, `metric_result`, `retention_curve` | `interval_result` | `feature-engineering`, `retention-curve-analysis` | `finding-assembly`, `roi-computation` |
| `engagement-decay-analysis` | 🟡 CONDITIONAL (dse-skill-tester done; 3 fixes applied: all-null HALT wired, precondition 4 testable, Step 0 expansion; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set`, `maturity_classification` | `decay_profile`, `signal_result` | `maturity-state-classification`, `feature-engineering` | `leading-indicator-development`, `finding-assembly` |
| `reactivation-behavior-analysis` | 🟡 CONDITIONAL (dse-skill-tester done; 3 fixes applied: Step 0 expansion, sustainability verdict fallback, infrastructure requirements; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set`, `metric_result` | `reactivation_profile` | `feature-engineering`, `metric-computation` | `finding-assembly`, `roi-computation` |
| `latent-factor-modeling` | 🟡 CONDITIONAL (dse-skill-tester done; 3 fixes applied: Step 0 HALT pseudocode, fit index enforcement, loop mechanics; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set` | `factor_model` | `feature-engineering` | `finding-assembly`, `value-decomposition-analysis` |
| `value-decomposition-analysis` | 🟡 CONDITIONAL (dse-skill-tester done; 4 fixes applied: removed custom frame, division-by-zero guards, Step 0 expansion, cohort-relative SQL + Quality Bar expansion; pending real-env tests, script, requirements.txt) | `cohort`, `metric_result`, `comparison_result` | `value_decomposition` | `metric-computation`, `statistical-comparison` | `finding-assembly`, `roi-computation` |
| `leading-indicator-development` | 🟡 CONDITIONAL (dse-skill-tester done; 2 fixes applied: outcome/temporal HALT conditions, loop mechanics; pending real-env tests, script, requirements.txt) | `feature_set`, `metric_result`, `cohort` | `signal_result` | `feature-engineering`, `metric-computation`, `engagement-decay-analysis` | `finding-assembly`, `hypothesis-validation` |
| `causal-linkage-analysis` | 🟡 CONDITIONAL (dse-skill-tester done 33✅/1⚠️; 1 fix applied: loop artifact_id renewal; human review checkpoint verified in 4 locations; pending real-env tests, script, requirements.txt) | `cohort`, `feature_set`, `hypothesis_result`, `comparison_result` | `causal_result` | `hypothesis-validation`, `statistical-comparison` | `finding-assembly`, `roi-computation` |

---

## Group 6 — Synthesis & Delivery

| Skill | Status | Inputs | Outputs | Can Follow | Can Precede |
|---|---|---|---|---|---|
| `roi-computation` | 🟡 CONDITIONAL (dse-skill-tester pending; pending real-env tests, script, requirements.txt) | `comparison_result` or `behavioral_impact` or `interval_result` or `causal_result`, `metric_result` | `roi_result` | `statistical-comparison`, `behavioral-impact-estimation`, `retention-curve-analysis`, `causal-linkage-analysis`, `stickiness-interval-analysis` | `finding-assembly` |
| `finding-assembly` | 🟡 CONDITIONAL (dse-skill-tester pending; pending real-env tests, script, requirements.txt) | any Group 4 or Group 5 output type, `scope_artifact` | `finding_set` | any Group 4 or Group 5 skill, `roi-computation` | `narrative-generation` |
| `narrative-generation` | 🟡 CONDITIONAL (dse-skill-tester pending; pending real-env tests, script, requirements.txt) | `finding_set`, `scope_artifact`, `context_map` | `narrative` | `finding-assembly` | `notify-schedule` |
| `notify-schedule` | 🔴 NOT BUILT | `narrative`, `scope_artifact` | `delivery_record` | `narrative-generation` | (terminal) |

---

## Define Phase Skills (reference only — maintained in Define Phase plugin)

| Skill | Status | Outputs Consumed By Analyze Phase |
|---|---|---|
| `intent-classification` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `scope-extraction` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `completeness-validation` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `scope-formatting` | 🟡 CONDITIONAL (dse-skill-tester pending) | produces `scope_artifact` consumed by `data-retrieval`, `cohort-extraction`, `metric-computation`, `business-context-layer`, `narrative-generation` |
| `task-decomposition` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `dependency-resolution` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `budget-allocation` | 🟡 CONDITIONAL (dse-skill-tester pending) | — |
| `plan-formatting` | 🟡 CONDITIONAL (dse-skill-tester pending) | produces `plan_artifact` consumed by `data-retrieval` |
