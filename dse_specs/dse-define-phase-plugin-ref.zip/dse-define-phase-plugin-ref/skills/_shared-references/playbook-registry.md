# Playbook Registry — Stub

Playbook templates with trigger conditions and subgraph definitions. See `dse-task-registry.md` Layer 4.
