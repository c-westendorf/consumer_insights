# Composition Rules — Analyze Phase DAG

Rules governing how Analyze Phase skills combine into valid pipelines. These rules are
enforced by the plan-agent's dependency-resolution skill when building `plan_artifact.json`.

---

## 1. Ordering Rules

Skills must be invoked in dependency order. A skill may not run until all its declared
inputs are available as validated terminal artifacts from upstream skills.

**Required ordering (partial order — parallelism within stages is allowed):**
```
Stage 1 (Sequential):
  data-retrieval → schema-profiling → data-quality-assessment

Stage 2 (Conditional fan):
  IF quality_report.gate_decision == "halt":         STOP — escalate to analyst
  IF quality_report.remediation_manifest is not empty: data-remediation
  THEN: cohort-extraction
  OPTIONAL: population-sampling (if population > 1M or matching required)

Stage 3 (Fan-out — all can run in parallel after cohort is available):
  feature-engineering
  business-context-layer (runs from schema-profiling output, parallel to Stage 2+)
  metric-computation (requires feature_set)

Stage 4 (Fan-out — run in parallel based on analytical pattern):
  profile pattern:  exploratory-analysis → cohort-behavior-analysis
  compare pattern:  statistical-comparison → hypothesis-validation
  explain pattern:  exploratory-analysis → hypothesis-validation → causal-linkage-analysis
  predict pattern:  leading-indicator-development
  segment pattern:  latent-factor-modeling → cohort-behavior-analysis
  ALL:              maturity-state-classification, retention-curve-analysis, behavioral-impact-estimation

Stage 5 (Advanced — uses Stage 4 outputs):
  stickiness-interval-analysis (requires retention_curve)
  engagement-decay-analysis (requires maturity_classification)
  reactivation-behavior-analysis (requires metric_result)
  value-decomposition-analysis (requires comparison_result)

Stage 6 (Join — waits for all active branches):
  roi-computation (waits for: comparison_result OR behavioral_impact OR interval_result OR causal_result)
  finding-assembly (waits for: all active analytical outputs)

Stage 7 (Sequential):
  narrative-generation → notify-schedule
```

---

## 2. Fan-Out Rules

A fan-out occurs when multiple skills can run in parallel because they have no mutual dependency.

**Declared fan-out points:**

| Fan-out Point | Parallel Skills | Condition |
|---|---|---|
| After `cohort-extraction` | `feature-engineering`, `population-sampling` | population-sampling only if scope requires sampling |
| After `feature-engineering` | `metric-computation`, `maturity-state-classification`, `exploratory-analysis`, `behavioral-impact-estimation` | metric-computation required before behavioral-impact-estimation |
| After `schema-profiling` | `data-quality-assessment`, `business-context-layer` | business-context-layer is optional |
| After Stage 4 skills | all Group 5 skills that have inputs available | each checks its own input availability |

**Rule:** Skills in the same parallel stage MUST NOT read each other's terminal artifacts.
Cross-stage dependencies are the only valid data flow.

---

## 3. Join Rules

A join point is a skill that must wait for multiple parallel branches to complete.

**Declared join points:**

| Join Point | Waits For | Minimum Required |
|---|---|---|
| `roi-computation` | `comparison_result` OR `behavioral_impact` OR `interval_result` OR `causal_result` | At least one upstream result |
| `finding-assembly` | All active analytical branch outputs | All non-skipped branches |
| `narrative-generation` | `finding_set` | Required |

**Rule:** A join skill MUST validate every upstream artifact via its Step 0 upstream
validation before proceeding. Missing inputs → HALT, not silent omission.

---

## 4. Loop Rules

Skills that declare `supports_loop: true` may execute more than once within a plan.

| Skill | Loop Trigger | Max Iterations | Exit Conditions |
|---|---|---|---|
| `exploratory-analysis` | Plan node specifies exploration budget | 5 | ≥3 hypotheses ranked by effect size (≥ small per Cohen's) |
| `hypothesis-validation` | Hypotheses remain inconclusive | 3 | All hypotheses resolved or budget exhausted |
| `data-remediation` | Quality re-assessment reveals new issues | 2 | All blocking issues resolved or escalate |
| `cohort-behavior-analysis` | Segment structure unstable | 3 | ≥2 stable, validated behavioral segments |
| `reactivation-behavior-analysis` | Trigger identification incomplete | 2 | Triggers identified or budget exhausted |
| `stickiness-interval-analysis` | Interval patterns incomplete | 3 | Patterns validated for all segments |
| `leading-indicator-development` | <3 valid indicators found | 3 | ≥3 validated indicators or budget exhausted |
| `causal-linkage-analysis` | Robustness checks fail | 2 | Stable estimate or budget exhausted |
| `latent-factor-modeling` | Factor structure unstable | 3 | Fit indices acceptable or budget exhausted |
| `narrative-generation` | Stakeholder revision requested | 2 | Stakeholder review complete |

**Rule:** All looping skills must write an updated terminal artifact at the end of each
iteration. The `artifact_id` must be a new UUID each iteration. Downstream skills must
reference the MOST RECENT artifact_id.

---

## 5. Conditional Edge Rules

Some edges in the DAG are conditional — they fire only when a specific condition is met.

| Condition | Edge Fires | Edge Skipped |
|---|---|---|
| `quality_report.gate_decision == "halt"` | — | All downstream (escalate to analyst) |
| `quality_report.remediation_manifest` not empty | `data-quality-assessment → data-remediation` | `data-remediation` skipped |
| `cohort.population_size > 1,000,000` | `cohort-extraction → population-sampling` | `population-sampling` skipped |
| `scope_artifact.analytical_pattern == "compare"` | `statistical-comparison` activated | — |
| `scope_artifact.analytical_pattern == "explain"` | `causal-linkage-analysis` eligible | — |
| `hypothesis_result.upgrade_recommendation == "requires_causal_linkage_analysis"` | `hypothesis-validation → causal-linkage-analysis` | — |
| `behavioral_impact.causal_confidence == "quasi-experimental"` | `behavioral-impact-estimation → causal-linkage-analysis` | — |

---

## 6. Completeness Rules

A plan is complete when:
1. `finding-assembly` has consumed outputs from all analytical branches activated in the plan
2. `finding_set.scope_coverage_assessment` is `"complete"` or `"partial"` with documented gaps
3. Every declared skill has produced a terminal artifact with a valid 5-field envelope
4. The `finding_set` has been consumed by `narrative-generation`

**Incompleteness handling:**
- `"partial"` coverage: proceed to narrative, document gaps as explicit caveats
- `"insufficient"` coverage: narrative-generation HALTS and returns to finding-assembly for
  additional analytical branches

---

## 7. Data Type Compatibility Rules

A skill's declared output type must match the declared input type of the consuming skill.
Type mismatches are validation failures at the consuming skill's Step 0.

**Allowed type coercions** (implicit, logged):
- `cohort` → `sample_set`: population-sampling reads cohort, produces sample_set
- `raw_dataset` → `remediated_dataset`: data-remediation reads raw, produces remediated

**Prohibited coercions** (hard failures):
- `sample_set` → `cohort`: sample sets cannot substitute for full cohorts in population-defining skills
- `hypothesis_set` → `hypothesis_result`: EDA output cannot substitute for validated hypotheses
- `observational behavioral_impact` → `causal_result`: impact estimates cannot be used where causal results are required

---

## 8. Human Review Checkpoints

The following transitions require explicit human approval before the next skill executes:

| After | Before | Review Required |
|---|---|---|
| `data-quality-assessment` (gate = halt) | Any downstream skill | Analyst must assess blocking issues |
| `causal-linkage-analysis` | `roi-computation` | Human must validate causal assumptions before monetizing |
| `finding-assembly` | `narrative-generation` | Human must approve finding set before stakeholder narrative |
| `narrative-generation` | `notify-schedule` | Human must approve narrative before delivery |

These checkpoints are declared in the plan_artifact as `"requires_human_review": true` on
the relevant task nodes.

---

## 9. Cross-Cutting Principles

Analytical decisions that apply across multiple skills. Skills that violate these principles
fail Blueprint Principle 6 (Quality Bar Over Completeness).

### 9.1 Data Freshness is Scope-Relative

**Origin:** Identified during `data-quality-assessment` test walk-through (Test 20, Fix 2).

**Principle:** In DSE, "data freshness" is a scope-relative concept, not an absolute calendar
concept. A skill assessing temporal properties of data MUST compare against
`scope_artifact.timeframe.end`, not against today's date.

**Why it matters:** CVS analyses are predominantly historical (calendar-year, quarter).
A dataset covering 2025-01-01 to 2025-12-31, reviewed in April 2026, has
`freshness_lag_days ≈ 99` — not because the data is stale, but because the scope period
ended 99 days ago. Comparing against today's date produces false positives for ALL
historical analyses.

**Correct pattern:**
```
scope_end_lag_days = DATEDIFF(today, scope_artifact.timeframe.end)
data_lag_beyond_scope = max(0, freshness_lag_days - scope_end_lag_days)

IF data_lag_beyond_scope == 0: no freshness issue (data covers full scope window)
IF data_lag_beyond_scope > 0: flag based on days of missing coverage relative to scope end
```

**Skills that must apply this principle:**
- `data-quality-assessment` (Step 3 — freshness assessment)
- Any future skill that computes or evaluates temporal coverage against a declared timeframe

### 9.2 Artifact at Every State Change (HALT-After-Write)

**Origin:** Identified during `data-quality-assessment` test walk-through (Test 3, Fix 1).

**Principle:** A HALT instruction must NEVER fire before the terminal artifact for the
current state is written. If a skill's verdict is FAIL, write the artifact FIRST, then HALT.
This ensures downstream remediation skills can read the diagnostic output they need to act.

**Why it matters:** A HALT before artifact write leaves the pipeline in an unrecoverable
state — the remediation skill can't read the data it needs to fix, and the analyst has no
record of what was found.

**Correct pattern:**
```
Step N (terminal): Write artifact
  Generate artifact_id
  Write artifact to disk
  Log: "artifact written | verdict={verdict}"

AFTER artifact write:
  IF verdict requires HALT:
    HALT: "{message explaining what the downstream skill should do with the artifact}"
    NOTE: HALT fires after artifact write so downstream skills can read the artifact.
```
