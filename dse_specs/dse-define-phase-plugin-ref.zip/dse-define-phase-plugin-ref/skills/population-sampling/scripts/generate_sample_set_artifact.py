#!/usr/bin/env python3
"""
generate_sample_set_artifact.py — Stub script for population-sampling skill.

Draws a statistically powered sample from a labeled cohort by partitioning
across decomposition dimensions and computing required sample sizes via power
analysis. All census and sampling SQL executes in the warehouse.

This script implements the standalone CLI interface for population-sampling.
No cross-skill imports. Run with --dry-run to validate inputs and preview
the census and sampling SQL without executing warehouse queries.
"""

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Draw a statistically powered sample from a labeled cohort.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_sample_set_artifact.py \\
    --cohort cohort.json \\
    --scope-artifact scope_artifact.json \\
    --output sample_set.json

  python generate_sample_set_artifact.py \\
    --cohort cohort.json \\
    --scope-artifact scope_artifact.json \\
    --sampling-method random \\
    --output sample_set.json \\
    --dry-run
        """,
    )
    parser.add_argument("--cohort", required=True, help="Path to cohort.json from cohort-extraction")
    parser.add_argument("--scope-artifact", required=True, help="Path to scope_artifact.json")
    parser.add_argument("--sampling-method", choices=["stratified", "random"], default="stratified",
                        help="Sampling method (default: stratified)")
    parser.add_argument("--output", default="sample_set.json", help="Output path (default: sample_set.json)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview census and sampling SQL without executing warehouse queries")
    return parser.parse_args()


def load_json(path: str, name: str) -> dict:
    p = Path(path)
    if not p.exists():
        print(f"HALT: {name} not found at '{path}'", file=sys.stderr)
        sys.exit(1)
    with open(p) as f:
        return json.load(f)


def validate_schema_version(artifact: dict, name: str) -> None:
    sv = artifact.get("schema_version")
    if not isinstance(sv, str) or sv != "1.0":
        print(f"HALT: {name} — schema_version is {repr(sv)}, expected string '1.0'", file=sys.stderr)
        sys.exit(1)


def compute_sample_size(effect_size: float = 0.05, alpha: float = 0.05, power: float = 0.80) -> int:
    """Compute required n per cell for a two-proportion z-test.
    Uses scipy.stats if available; falls back to conservative rule-of-thumb.
    """
    try:
        from scipy.stats import norm
        import numpy as np
        z_alpha = norm.ppf(1 - alpha / 2)
        z_beta = norm.ppf(power)
        p = 0.5  # conservative: maximum variance
        n = int(((z_alpha + z_beta) ** 2 * 2 * p * (1 - p)) / (effect_size ** 2)) + 1
        return max(n, 30)  # CLT minimum
    except ImportError:
        # Rule of thumb: n ≈ 16/effect_size^2 for proportions at 80% power, 5% alpha
        return max(int(16 / (effect_size ** 2)), 30)


def build_census_sql(data_ref: str, dimensions: list[str]) -> str:
    dim_cols = ", ".join(dimensions)
    return (
        f"SELECT {dim_cols}, COUNT(DISTINCT customer_id) AS cell_count\n"
        f"FROM {data_ref}\n"
        f"GROUP BY {dim_cols}\n"
        f"ORDER BY cell_count DESC"
    )


def build_random_sample_sql(data_ref: str, required_n: int, new_ref: str) -> str:
    return (
        f"CREATE TEMP TABLE {new_ref} AS\n"
        f"SELECT * FROM {data_ref}\n"
        f"ORDER BY RANDOM()\n"
        f"LIMIT {required_n}"
    )


def main():
    args = parse_args()

    # Load artifacts
    cohort = load_json(args.cohort, "cohort.json")
    scope = load_json(args.scope_artifact, "scope_artifact.json")

    # Validate schema versions
    validate_schema_version(cohort, "cohort.json")
    validate_schema_version(scope, "scope_artifact.json")

    # Check cohort preconditions
    data_ref = cohort.get("data_ref")
    if not data_ref:
        print("HALT: cohort.json — data_ref is missing", file=sys.stderr)
        sys.exit(1)

    population_count = cohort.get("population_count", 0)
    if population_count < 50:
        print(f"HALT: cohort.population_count={population_count} — below minimum of 50 for sampling", file=sys.stderr)
        sys.exit(1)

    # Check decomposition dimensions
    dimensions = scope.get("population", {}).get("decomposition_dimensions", [])
    if not dimensions and args.sampling_method == "stratified":
        print("HALT: scope_artifact — no decomposition_dimensions defined; cannot stratify", file=sys.stderr)
        sys.exit(1)

    # Power analysis
    target_effect_size = scope.get("metric", {}).get("target_effect_size", None)
    if target_effect_size is None:
        print("WARN: target_effect_size not specified — defaulting to 0.05", file=sys.stderr)
        target_effect_size = 0.05

    required_n = compute_sample_size(effect_size=target_effect_size)
    print(f"Power analysis: effect_size={target_effect_size}, required_n_per_cell={required_n}")

    # Build new data ref
    new_data_ref = f"SAMPLE_{data_ref}"
    analytical_pattern = scope.get("analytical_pattern", "profile")
    sampling_method = args.sampling_method

    if args.dry_run:
        print("\n[DRY RUN] Census SQL preview:")
        if sampling_method == "stratified" and dimensions:
            print(build_census_sql(data_ref, dimensions))
        print("\n[DRY RUN] Sampling SQL preview:")
        print(build_random_sample_sql(data_ref, required_n * len(dimensions) if dimensions else required_n, new_data_ref))
        print("\nDry run complete — no warehouse queries executed.")
    else:
        # TODO: Execute warehouse census and sampling queries
        # conn = get_warehouse_connection(...)
        # census = conn.execute(build_census_sql(data_ref, dimensions)).fetchall()
        # conn.execute(build_sampling_sql(...))
        print(f"TODO: Execute census and sampling for {data_ref} → {new_data_ref}")

    # Write artifact (stub values for population_count and partition_cells)
    artifact = {
        "schema_version": "1.0",
        "skill_name": "population-sampling",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "record_count": 0,  # Stub — replace with actual sample_count
        "artifact_id": str(uuid.uuid4()),
        "cohort_artifact_id": cohort.get("artifact_id"),
        "scope_artifact_id": scope.get("artifact_id"),
        "sampling_method": sampling_method,
        "analytical_pattern": analytical_pattern,
        "data_ref": new_data_ref,
        "sample_count": 0,  # Stub
        "cohort_population_count": population_count,
        "sampling_rate": None,  # Stub
        "target_effect_size": target_effect_size,
        "power_outcome": "stub",
        "partition_cells": [],  # Stub
        "cells_powered": 0,
        "cells_underpowered": 0,
        "observation_window": scope.get("observation_window"),
    }

    if not args.dry_run:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            json.dump(artifact, f, indent=2)
        print(f"sample_set.json written to {output_path}")


if __name__ == "__main__":
    main()
