---
name: population-sampling
description: >
  Draws a statistically powered sample from a labeled cohort by partitioning across
  decomposition dimensions and computing required sample sizes via power analysis — pushing
  all census and sampling SQL to the warehouse to avoid loading 100M+ rows locally. Activate
  after cohort-extraction when the population is too large for full-population analysis or when
  structured comparison across segments (lifecycle_stage, value_decile, etc.) is required; takes
  cohort + scope_artifact; outputs sample_set.json with a data_ref pointing to the sampled
  warehouse temp table, per-cell power achieved, and full sampling audit trail.
inputs:
  - type: cohort
    description: "Extracted population from cohort-extraction — provides data_ref (filtered warehouse temp table) and population_count"
  - type: scope_artifact
    description: "Approved scope definition — decomposition_dimensions, metric, timeframe, and optional observation_window drive partition and power analysis"
outputs:
  - type: sample_set
    description: "Sampled population artifact with data_ref pointing to warehouse temp table, per-cell sizes, power achieved, and full sampling audit trail"
can_follow: [cohort-extraction]
can_precede: [feature-engineering, metric-computation, exploratory-analysis]
supports_loop: false
exit_conditions:
  - "sample_set.json written; all partition cells meet minimum power threshold OR underpowered cells documented with caveats"
  - "sample_count >= 50; data_ref points to accessible warehouse SAMPLE_ temp table"
  - "all partition cells logged with cell_count, required_n, sampled_n, powered status"
---

## Overview

Sampling is a precision instrument, not a shortcut. At cohort sizes of 100K–10M, pulling the
full population through feature-engineering and metric-computation is wasteful and creates
spurious precision — small differences become statistically "significant" only because n is
enormous. Population-sampling selects the minimum statistically powered sample needed to detect
the target effect size, partitioned across decomposition dimensions to guarantee MECE coverage.

The census step is critical: rather than loading rows, this skill first counts customers per
partition cell via a warehouse GROUP BY. This gives the partition distribution so minimum sample
sizes can be computed before any data is pulled. Sparse cells — those below minimum cell size —
are either collapsed into adjacent cells or flagged as underpowered, preserving analytical
integrity.

**What this skill produces:** `sample_set.json` with a `data_ref` pointing to a warehouse
`SAMPLE_{cohort.data_ref}` temp table, per-cell power achieved, partition cell summary, and
a complete sampling audit trail so any analyst can reproduce the sample independently.

---

## When to Activate

- Cohort population_count > 50,000 and full-population analysis is impractical
- Scope requires structured comparison across decomposition dimensions (lifecycle_stage, value_decile, etc.)
- A plan task node with `task_type: "population_sampling"` is the next unexecuted task
- Scope defines a target metric with an effect size that requires a powered sample
- Scope includes an observation window (pre/post event) that requires temporal cohort construction
- User requests "sample from the cohort", "get a powered sample", or "analyze by segment"

---

## Preconditions

What must be true before this skill begins:
- [ ] `cohort.json` exists with `schema_version == "1.0"` and `data_ref` non-null
- [ ] `cohort.population_count >= 50` — undersized cohorts cannot support structured sampling
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"` and `metric` field present
- [ ] `scope_artifact.population.decomposition_dimensions` is a non-empty list — required when `sampling_method == "stratified"`; not required for `random`
- [ ] `scope_artifact.metric.target_effect_size` is present (required for power analysis); defaults to 0.05 if absent with WARN

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.11 (power analysis), numpy>=1.24, pandas>=2.0
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; heavy compute is warehouse SQL
- **Memory:** <200 MB (partition census aggregates only; no row-level data loaded locally)
- **Upstream Artifacts:** `cohort.json` (data_ref, population_count), `scope_artifact.json` (decomposition_dimensions, metric, timeframe)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `sampling_method` | `stratified` / `random` | `stratified`: partition by decomposition dimensions, compute power per cell, sample proportionally; `random`: simple random sample from cohort, no cell partitioning |
| `analytical_pattern` | `profile` / `compare` | `compare`: separate stratified samples drawn from base and comparison cohorts (both data_refs must be in cohort.data_ref); `profile`: single cohort sample |
| `power_outcome` | `all_powered` / `partial` / `underpowered` | `all_powered`: proceed; `partial`: some cells below threshold, document and proceed with WARN; `underpowered`: all cells below threshold — HALT |
| `observation_window` | `none` / `anchored` | `anchored`: temporal filtering added to sampling SQL (pre_event, post_event, or matched_pre_post relative to scope anchor event); `none`: no temporal filter |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify sampling_method:
  IF scope_artifact.sampling_method == "random" → "random"
  ELSE (default) → "stratified"

classify analytical_pattern: read scope_artifact.analytical_pattern
  IF == "compare" AND cohort.data_ref is dict (has "base" and "comparison" keys) → "compare"
  ELSE → "profile"

classify observation_window:
  IF scope_artifact.observation_window is defined and non-null → "anchored"
  ELSE → "none"

log: "Running population-sampling | method={value} | pattern={value} | window={value}"
```

**Upstream Validation:**
```
load cohort.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json — schema_version mismatch.
  Re-run cohort-extraction."
assert data_ref is not null
  IF null: HALT: "Upstream validation failed: cohort.json — data_ref missing."
assert population_count >= 50
  IF not: HALT: "Upstream validation failed: cohort.json — population_count={N} is below
  minimum of 50. Cannot produce a powered sample from this cohort."

load scope_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."
IF sampling_method == "stratified":
  assert decomposition_dimensions is a non-empty list
    IF empty or missing: HALT: "Upstream validation failed: scope_artifact — no decomposition
    dimensions defined. Stratified sampling requires at least one partition dimension.
    To sample without partitioning, set sampling_method='random' in scope."
assert metric field is present
  IF missing: HALT: "Upstream validation failed: scope_artifact — metric field absent."

IF scope_artifact.metric.target_effect_size is missing:
  WARN: "target_effect_size not specified — defaulting to 0.05 (5pp minimum detectable difference)"
  target_effect_size = 0.05
ELSE:
  target_effect_size = scope_artifact.metric.target_effect_size
```

---

### Step 1 — Power Analysis: Compute Required Sample Size Per Cell

**Goal:** Determine minimum n required per partition cell to detect the target effect size.

**Pre-step assertion:** `target_effect_size` and `decomposition_dimensions` loaded.

**Branch on `sampling_method`:**

**IF `random`:**
```
Use scipy.stats power analysis:
  required_n_total = compute_sample_size(
    effect_size=target_effect_size,
    alpha=0.05,
    power=0.80,
    test="two-tailed proportions"
  )
required_n_per_cell = N/A (no cells)
Log: "Random sampling — required n_total: {required_n_total}"
```

**IF `stratified`:**
```
dimensions = scope_artifact.population.decomposition_dimensions
n_cells = product of cardinality of each dimension (estimated from cohort schema)
required_n_per_cell = compute_sample_size(
  effect_size=target_effect_size, alpha=0.05, power=0.80
)
min_cell_size = max(required_n_per_cell, 30)  -- at least 30 per cell for CLT
Log: "Stratified sampling — {n_cells} estimated cells, required_n_per_cell={min_cell_size}"
```

**Checkpoint:**
> - [ ] PASS: required_n computed; logged
> - [ ] WARN: target_effect_size defaulted to 0.05

---

### Step 2 — Census: Count Customers Per Partition Cell

**Goal:** Count actual population per partition cell via warehouse GROUP BY, without loading
row-level data. Identify sparse cells for collapsing or flagging.

**Pre-step assertion:** `decomposition_dimensions` list ready; `cohort.data_ref` accessible.

**IF `random`:** SKIP this step — no partitioning needed.

**IF `stratified`:**
```
Build census SQL:
  SELECT {dimension_cols}, COUNT(DISTINCT customer_id) AS cell_count
  FROM {cohort.data_ref}
  [WHERE {observation_window_filter if observation_window == "anchored"}]
  GROUP BY {dimension_cols}

Execute census query → cell_census (list of {cell_key, cell_count})

For each cell in cell_census:
  IF cell_count < min_cell_size:
    WARN: "Cell {cell_key} has {cell_count} customers < required {min_cell_size} — marking underpowered"
    cell.powered = false
  ELSE:
    cell.powered = true

Classify power_outcome:
  IF all cells powered → "all_powered"
  IF some cells powered → "partial"
  IF no cells powered → "underpowered"

IF power_outcome == "underpowered":
  HALT: "All partition cells are underpowered (max cell size: {max_cell_count},
  required: {min_cell_size}). Cohort is too small for stratified sampling at this
  effect size. Options: reduce dimensions, increase effect_size threshold, or use
  random sampling."

Log: "Census complete | {N} cells | {N_powered} powered | {N_underpowered} underpowered"
```

**Checkpoint:**
> - [ ] PASS: census complete; power_outcome is "all_powered" or "partial"
> - [ ] WARN: some cells underpowered — will be flagged in artifact
> - [ ] HALT: all cells underpowered, or cohort.data_ref inaccessible

---

### Step 3 — Execute Sampling

**Goal:** Create a warehouse temp table containing the sampled population.

**Pre-step assertion:** Census complete (if stratified); required_n computed.

*Branch on `sampling_method`:*

**IF `random`:**
```
new_data_ref = "SAMPLE_{cohort.data_ref}"
Execute:
  CREATE TEMP TABLE {new_data_ref} AS
  SELECT * FROM {cohort.data_ref}
  ORDER BY RANDOM()
  LIMIT {required_n_total}
sample_count = required_n_total
```

**IF `stratified` (profile):**
```
new_data_ref = "SAMPLE_{cohort.data_ref}"
Build UNION ALL of per-cell samples:
  For each powered cell:
    sampled_n = min(cell.cell_count, min_cell_size)
    Add: SELECT * FROM {cohort.data_ref}
         WHERE {cell_predicates}
         [AND {observation_window_filter}]
         ORDER BY RANDOM()
         LIMIT {sampled_n}
Execute: CREATE TEMP TABLE {new_data_ref} AS {UNION ALL query}
sample_count = SUM(sampled_n across powered cells)
```

**IF `compare` (analytical_pattern == "compare"):**
```
base_data_ref  = "SAMPLE_{cohort.data_ref.base}"
comp_data_ref  = "SAMPLE_{cohort.data_ref.comparison}"
Apply stratified or random sampling independently to each cohort
new_data_ref = {base: base_data_ref, comparison: comp_data_ref}
```

**Checkpoint:**
> - [ ] PASS: SAMPLE_ temp table(s) created; sample_count >= 50
> - [ ] HALT: warehouse error or sample_count == 0

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist sample_set.json with full partition cell audit trail and lineage.

**Pre-step assertion:** All sampling complete; sample_count >= 50.

**Actions:**
```
Generate artifact_id: UUID v4

Write sample_set.json (see Terminal Artifact spec)
Log: "sample_set.json written | sample_count={sample_count} | method={sampling_method} |
cells_powered={N_powered}/{N_total} | data_ref={new_data_ref}"
```

**Checkpoint:**
> - [ ] PASS: sample_set.json written; all 5 universal envelope fields present
> - [ ] HALT: write failure or sample_count == 0

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "population-sampling",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 12840,
  "artifact_id": "{uuid}",
  "cohort_artifact_id": "{cohort.artifact_id}",
  "scope_artifact_id": "{scope_artifact.artifact_id}",
  "sampling_method": "stratified",
  "analytical_pattern": "profile",
  "data_ref": "SAMPLE_COHORT_REMEDIATED_DSE_EXTRACTION_rd001",
  "sample_count": 12840,
  "cohort_population_count": 47821,
  "sampling_rate": 0.268,
  "target_effect_size": 0.05,
  "power_outcome": "partial",
  "partition_cells": [
    {
      "cell_key": {"lifecycle_stage": "reactivated", "value_decile": "top_20"},
      "cell_count": 8420,
      "required_n": 1536,
      "sampled_n": 1536,
      "powered": true
    },
    {
      "cell_key": {"lifecycle_stage": "reactivated", "value_decile": "bottom_20"},
      "cell_count": 210,
      "required_n": 1536,
      "sampled_n": 210,
      "powered": false,
      "note": "Underpowered — included but flagged"
    }
  ],
  "cells_powered": 6,
  "cells_underpowered": 2,
  "observation_window": null
}
```

**Write to:** `sample_set.json` in the project directory.

**`record_count`** = `sample_count` (rows in the sampled temp table).

**Compare pattern `data_ref`:**
```json
"data_ref": {
  "base":       "SAMPLE_COHORT_..._BASE",
  "comparison": "SAMPLE_COHORT_..._COMP"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Cohort empty | cohort.population_count == 0 | HALT Step 0: already caught by cohort-extraction — should not reach this skill |
| Cohort below minimum | cohort.population_count < 50 | HALT Step 0: "cohort.population_count={N} — below minimum for sampling" |
| No decomposition dimensions | scope_artifact.decomposition_dimensions == [] | HALT Step 0: "no decomposition dimensions — cannot stratify" |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact mismatch message |
| All cells underpowered | every cell_count < min_cell_size | HALT Step 2: "all cells underpowered — reduce dimensions or increase effect_size" |
| Single-dimension cohort | only 1 decomposition dimension | WARN Step 2: "single dimension — consider adding a second for richer segmentation" |
| Compare pattern missing comparison cohort | cohort.data_ref has no "comparison" key | HALT Step 0: "compare pattern but cohort has no comparison data_ref — re-run cohort-extraction with compare scope" |
| Sample smaller than required_n_total | random sampling and cohort.population_count < required_n_total | WARN Step 3: "cohort smaller than required sample — using full cohort; results may be underpowered" |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `sample_set.json` exists with all 5 universal envelope fields
- [ ] `data_ref` temp table is accessible (downstream can SELECT COUNT(*) from it)
- [ ] `sample_count >= 50`
- [ ] Every partition cell has an entry in `partition_cells` with `cell_count`, `required_n`, `sampled_n`, `powered` status
- [ ] `cohort_artifact_id` and `scope_artifact_id` set for lineage tracing

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `sample_set.json` written and validates against the terminal artifact spec
- [ ] `sample_count >= 50`
- [ ] All partition cells documented in `partition_cells` (none silently excluded)
- [ ] `power_outcome` is "all_powered" or "partial" (not "underpowered")
- [ ] Underpowered cells explicitly flagged in `partition_cells[].powered == false`
- [ ] `feature-engineering` Step 0 can load `sample_set.json` and read `data_ref`
- [ ] `sampling_rate` is logged (analyst reviews if < 1% or > 80% — may indicate cohort or scope issue)

---

## Scope Boundary

This skill does NOT:
- Extract or filter the target population → handled by `cohort-extraction` (upstream)
- Define decomposition dimensions → handled by `scope-formatting` in the Define Phase
- Assess data quality of the source data → handled by `data-quality-assessment`
- Engineer features from the sample → handled by `feature-engineering` (downstream)
- Compute metrics across the sample → handled by `metric-computation` (downstream)
- Run statistical comparisons → handled by `statistical-comparison` (downstream)

---

## Downstream

Run after this skill completes:
1. **`feature-engineering`** — reads `sample_set.data_ref`; constructs behavioral and demographic feature vectors per sampled customer
2. **`metric-computation`** — reads `sample_set.data_ref`; computes the scope-defined metric across the sampled population
3. **`exploratory-analysis`** — reads `sample_set.data_ref`; explores distributions and patterns within the stratified sample
