---
name: finding-assembly
description: >
  Collects, ranks, and validates analytical findings from any combination of Group 4 (statistical
  analysis) and Group 5 (advanced analytical) skill outputs. Detects contradictions between
  findings from different upstream skills and assesses scope coverage against scope_artifact.
  Activate after analytical skills complete. Produces finding_set consumed by narrative-generation.
inputs:
  - type: comparison_result
    description: "Statistical comparison output"
    optional: true
  - type: hypothesis_result
    description: "Hypothesis validation results"
    optional: true
  - type: retention_curve
    description: "Retention curve analysis results"
    optional: true
  - type: behavioral_impact
    description: "Behavioral impact estimates"
    optional: true
  - type: interval_result
    description: "Stickiness/interval analysis results"
    optional: true
  - type: decay_profile
    description: "Engagement decay analysis results"
    optional: true
  - type: reactivation_profile
    description: "Reactivation behavior analysis results"
    optional: true
  - type: factor_model
    description: "Latent factor modeling results"
    optional: true
  - type: value_decomposition
    description: "Value decomposition analysis results"
    optional: true
  - type: signal_result
    description: "Leading indicator results"
    optional: true
  - type: causal_result
    description: "Causal linkage analysis results"
    optional: true
  - type: roi_result
    description: "ROI computation results"
    optional: true
  - type: behavioral_profile
    description: "Cohort behavior analysis results"
    optional: true
  - type: scope_artifact
    description: "Approved scope for coverage assessment"
outputs:
  - type: finding_set
    description: "Ranked findings with evidence sources, contradictions, and scope coverage assessment"
can_follow: [statistical-comparison, hypothesis-validation, retention-curve-analysis, behavioral-impact-estimation, stickiness-interval-analysis, engagement-decay-analysis, reactivation-behavior-analysis, latent-factor-modeling, value-decomposition-analysis, leading-indicator-development, causal-linkage-analysis, roi-computation, cohort-behavior-analysis]
can_precede: [narrative-generation]
supports_loop: false
exit_conditions:
  - "finding_set.json written with ranked findings and scope_coverage_assessment"
  - "contradictions between upstream results documented, not suppressed"
---

## Overview

This is the synthesis join point. It collects outputs from potentially many upstream analytical
skills (13 possible input types) and synthesizes them into a coherent, ranked set of findings.
Each finding has an evidence_strength rating, source attribution, and causal_confidence qualifier.

The skill detects contradictions between findings (e.g., one skill suggests improvement, another
suggests decline) and documents them explicitly -- contradictions are never suppressed. It also
assesses whether the findings collectively cover the original scope: partial or insufficient
coverage triggers warnings that narrative-generation respects.

**What this skill produces:** `finding_set.json` with ranked findings, contradiction detection,
and scope coverage assessment.

---

## When to Activate

- One or more Group 4/5/6 analytical skills have completed and produced result artifacts
- `scope_artifact.json` exists and the user is ready to synthesize findings
- User explicitly requests "assemble findings", "synthesize results", or "summarize analysis"
- Downstream `narrative-generation` is planned and requires a `finding_set` input

---

## Preconditions

- [ ] At least one upstream analytical artifact exists (any of the 13 input types)
- [ ] Each upstream artifact has `schema_version == "1.0"`
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"` for coverage assessment
- [ ] Upstream analytical skills have completed (no in-progress artifacts) -- NOTE: completion is enforced by the pipeline orchestrator, not by this skill

---

## Prerequisites

### Library Dependencies
```
# Tier 3: numpy>=1.24 (ranking computations)
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `evidence_diversity` | `single_source` / `multi_source` | `single_source`: findings from one upstream skill -- lower evidence_strength ceiling (max "moderate"); `multi_source`: findings from multiple upstream skills -- can achieve "strong" evidence when multiple sources converge |
| `scope_coverage` | `complete` / `partial` / `insufficient` | `complete`: all scope requirements addressed; `partial`: most addressed, proceed with caution_flags; `insufficient`: HALT downstream narrative-generation |
| `contradiction_presence` | `none` / `detected` | `none`: findings are internally consistent; `detected`: contradictions documented in contradictions_found array -- include both sides in finding_set, do not suppress |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:**
```
classify evidence_diversity:
  upstream_types = scan for all analytical result artifacts
  IF len(upstream_types) > 1 → "multi_source"
  ELSE → "single_source"

classify scope_coverage:
  -- deferred to Step 5 after findings are extracted

classify contradiction_presence:
  -- deferred to Step 4 after findings are compared

log: "Running finding-assembly | evidence_diversity={value} | upstream_count={len(upstream_types)}"
```

**Upstream Validation:**
```
upstream_artifacts = []
FOR each type in [comparison_result, hypothesis_result, retention_curve, behavioral_impact,
                   interval_result, decay_profile, reactivation_profile, factor_model,
                   value_decomposition, signal_result, causal_result, roi_result,
                   behavioral_profile]:
  IF {type}.json exists:
    load {type}.json; assert schema_version == "1.0"
    upstream_artifacts.append(type)

IF len(upstream_artifacts) == 0:
  HALT: "No upstream analytical artifacts found. At least one required."

load scope_artifact.json; assert schema_version == "1.0"
  IF not found: WARN: "scope_artifact.json not found; scope coverage assessment will be skipped."
```

---

### Step 1 -- Enumerate Available Upstream

**Goal:** Confirm which analytical results are available and log the inventory.

**Actions:**
```
FOR each artifact in upstream_artifacts:
  log: "Found upstream: {artifact.type} | artifact_id={artifact.artifact_id}"

total_upstream = len(upstream_artifacts)
log: "Total upstream artifacts: {total_upstream}"

IF total_upstream == 0:
  HALT: "No upstream artifacts after validation."
```

---

### Step 2 -- Extract Findings

**Goal:** From each upstream artifact, extract key conclusions as finding objects.

**Actions:**
```
findings = []
finding_counter = 0

FOR each artifact in upstream_artifacts:
  -- Extract primary conclusion(s) from each artifact type
  IF artifact.type == "comparison_result":
    FOR each comparison in artifact.comparisons:
      finding_counter += 1
      findings.append({
        finding_id: "F-{finding_counter:03d}",
        statement: summarize(comparison.metric, comparison.difference, comparison.p_value, comparison.effect_size),
        evidence_type: "statistical_comparison",
        effect_size: comparison.effect_size,
        p_value: comparison.p_value,
        evidence_sources: ["comparison_result"],
        causal_confidence: "observational"
      })

  ELIF artifact.type == "hypothesis_result":
    FOR each hypothesis in artifact.hypotheses_tested:
      finding_counter += 1
      findings.append({
        finding_id: "F-{finding_counter:03d}",
        statement: hypothesis.conclusion,
        evidence_type: "hypothesis_test",
        effect_size: hypothesis.effect_size,
        p_value: hypothesis.p_value,
        evidence_sources: ["hypothesis_result"],
        causal_confidence: hypothesis.causal_confidence OR "observational"
      })

  -- (Similar extraction for each upstream type)
  -- Each type maps to its relevant conclusion fields

  ELIF artifact.type == "causal_result":
    finding_counter += 1
    findings.append({
      finding_id: "F-{finding_counter:03d}",
      statement: artifact.interpretation,
      evidence_type: "causal_estimate",
      effect_size: artifact.effect_estimate,
      evidence_sources: ["causal_result"],
      causal_confidence: artifact.causal_confidence
    })

  ELIF artifact.type == "roi_result":
    finding_counter += 1
    findings.append({
      finding_id: "F-{finding_counter:03d}",
      statement: "Revenue impact of {roi_result.metric_name}: ${roi_result.revenue_impact} ({roi_result.impact_qualifier})",
      evidence_type: "roi_estimate",
      effect_size: artifact.roi_ratio,
      evidence_sources: ["roi_result"],
      causal_confidence: map_qualifier_to_confidence(artifact.impact_qualifier)
    })

  -- Remaining types follow same pattern: extract statement, effect, sources, confidence
```

---

### Step 3 -- Rank Findings

**Goal:** Rank by evidence_strength based on statistical significance, effect size, causal confidence, and multi-source convergence.

**Actions:**
```
FOR each finding in findings:
  -- Compute evidence_strength score
  strength_score = 0

  -- Statistical significance
  IF finding.p_value is not null AND finding.p_value < 0.01: strength_score += 3
  ELIF finding.p_value is not null AND finding.p_value < 0.05: strength_score += 2
  ELIF finding.p_value is not null AND finding.p_value < 0.10: strength_score += 1

  -- Effect size magnitude (null-safe)
  IF finding.effect_size is null:
    -- Fallback: rank using evidence_count and confidence_interval_width as fallback criteria
    IF finding.evidence_count is not null AND finding.evidence_count >= 3: strength_score += 2
    IF finding.confidence_interval_width is not null AND finding.confidence_interval_width < 0.1: strength_score += 1
  ELIF abs(finding.effect_size) >= 0.8: strength_score += 3
  ELIF abs(finding.effect_size) >= 0.5: strength_score += 2
  ELIF abs(finding.effect_size) >= 0.2: strength_score += 1

  -- Causal confidence
  IF finding.causal_confidence == "quasi-experimental": strength_score += 3
  ELIF finding.causal_confidence == "adjusted": strength_score += 2
  ELIF finding.causal_confidence == "observational": strength_score += 1

  -- Multi-source convergence (checked in next pass)
  -- Assign categorical strength
  IF strength_score >= 7: finding.evidence_strength = "strong"
  ELIF strength_score >= 4: finding.evidence_strength = "moderate"
  ELSE: finding.evidence_strength = "weak"

  -- Cap single_source at "moderate"
  IF evidence_diversity == "single_source" AND finding.evidence_strength == "strong":
    finding.evidence_strength = "moderate"

-- Check for convergence: if multiple upstream types support same direction
FOR each finding_a in findings:
  converging_sources = find_findings_with_same_direction(finding_a, findings)
  IF len(converging_sources) > 1:
    finding_a.evidence_sources = union(all converging source types)
    -- Boost strength if multi-source convergence
    IF finding_a.evidence_strength == "moderate": finding_a.evidence_strength = "strong"

-- Sort by evidence_strength (strong > moderate > weak), then by effect_size descending
findings.sort(key=lambda f: (strength_order[f.evidence_strength], abs(f.effect_size)), reverse=True)

-- Assign rank
FOR i, finding in enumerate(findings):
  finding.rank = i + 1
```

---

### Step 4 -- Detect Contradictions

**Goal:** Compare findings for logical consistency; flag contradictory pairs.

**Actions:**
```
contradictions_found = []

FOR each pair (finding_a, finding_b) in findings where a != b:
  IF same_metric(finding_a, finding_b) AND opposite_direction(finding_a, finding_b):
    contradictions_found.append({
      finding_a: finding_a.finding_id,
      finding_b: finding_b.finding_id,
      description: "Conflicting direction: {finding_a.statement} vs {finding_b.statement}"
    })
    finding_a.contradictions_with.append(finding_b.finding_id)
    finding_b.contradictions_with.append(finding_a.finding_id)

IF len(contradictions_found) > 0:
  WARN: "Contradictions detected between {n} finding pairs. Both sides preserved in finding_set."
  contradiction_presence = "detected"
ELSE:
  contradiction_presence = "none"
  PASS: "No contradictions detected."
```

---

### Step 5 -- Assess Scope Coverage

**Goal:** Compare finding topics against scope_artifact requirements.

**Actions:**
```
IF scope_artifact is null:
  scope_coverage = "partial"  -- conservative default
  scope_gaps = ["scope_artifact not available for coverage assessment"]
  WARN: "Cannot assess scope coverage without scope_artifact."
ELSE:
  scope_requirements = scope_artifact.analytical_questions OR scope_artifact.objectives
  covered = []
  gaps = []

  FOR each requirement in scope_requirements:
    IF any finding addresses requirement:
      covered.append(requirement)
    ELSE:
      gaps.append(requirement)

  coverage_ratio = len(covered) / len(scope_requirements)

  IF coverage_ratio == 1.0:
    scope_coverage = "complete"
    PASS: "All scope requirements addressed."
  ELIF coverage_ratio >= 0.5:
    scope_coverage = "partial"
    WARN: "Partial scope coverage ({coverage_ratio:.0%}). Gaps: {gaps}"
  ELSE:
    scope_coverage = "insufficient"
    WARN: "Insufficient scope coverage ({coverage_ratio:.0%}). Narrative-generation will HALT."

  scope_gaps = gaps
```

---

### Step 6 -- Write Terminal Artifact

```
Generate artifact_id  -- NEW UUID

Write finding_set.json:
  scope_covered = (scope_coverage == "complete")
  scope_gaps = scope_gaps
  findings = findings (ranked list)
  contradictions_found = contradictions_found
  total_findings = len(findings)
  scope_coverage_assessment = scope_coverage

Log: "finding_set.json written | total_findings={total_findings} | scope_coverage={scope_coverage} | contradictions={len(contradictions_found)}"
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "finding-assembly",
  "timestamp": "2026-04-10T18:00:00Z",
  "record_count": 5,
  "artifact_id": "{uuid}",
  "scope_covered": true,
  "scope_gaps": [],
  "findings": [
    {
      "finding_id": "F-001",
      "statement": "Reactivated customers show 5.5pp lower repeat purchase rate than continuously active customers (p<0.01, d=0.45)",
      "evidence_strength": "strong",
      "evidence_sources": ["comparison_result", "hypothesis_result"],
      "rank": 1,
      "contradictions_with": [],
      "causal_confidence": "observational"
    }
  ],
  "contradictions_found": [],
  "total_findings": 5,
  "scope_coverage_assessment": "complete"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | No upstream artifacts found | HALT Step 0: "No upstream analytical artifacts found." |
| Single record | Only one finding extracted from one upstream | PASS: Proceed with single finding; evidence_strength capped at "moderate". |
| All-null dimension | All upstream artifacts have null effect sizes | WARN Step 2: "No effect sizes available for ranking. Rank by p-value only." |
| Schema mismatch | schema_version != "1.0" on any upstream | HALT Step 0: "Schema mismatch on {artifact}." |
| All findings contradict | Every finding pair is contradictory | WARN Step 4: "All findings contradict -- report all with explicit contradiction notes." |
| Scope artifact missing | scope_artifact.json not found | WARN Step 5: "Scope coverage assessment skipped. Default to partial." |
| Duplicate findings | Same conclusion from same source appears twice | Deduplicate in Step 2; merge evidence_sources. |
| Insufficient scope coverage | coverage_ratio < 0.5 | WARN Step 5: "Insufficient coverage. Downstream narrative-generation will HALT." |

---

## Postconditions

- [ ] `finding_set.json` exists with all 5 universal envelope fields
- [ ] `findings` array is ranked by evidence_strength descending
- [ ] `contradictions_found` is populated (may be empty) -- contradictions are never suppressed
- [ ] `scope_coverage_assessment` is one of: "complete", "partial", "insufficient"
- [ ] Every finding has `evidence_sources` tracing back to upstream artifact type(s)

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] All upstream artifacts enumerated and findings extracted
- [ ] Evidence strength scoring is consistent and reproducible
- [ ] Contradictions detected and documented (not suppressed)
- [ ] Scope coverage accurately reflects which requirements are addressed
- [ ] Single-source findings correctly capped at "moderate" evidence_strength

---

## Scope Boundary

This skill does NOT:
- Compute ROI --> handled by `roi-computation`
- Generate narrative --> handled by `narrative-generation`
- Run statistical analysis --> handled by `statistical-comparison`
- Validate hypotheses --> handled by `hypothesis-validation`
- Perform any analytical computation -- it only collects and ranks existing results

---

## Downstream

1. **`narrative-generation`** -- reads `finding_set` to produce stakeholder-ready narrative; respects scope_coverage_assessment
