# Assessment Report: finding-assembly (Skill 10)

**Assessed:** 2026-04-10
**Skill Version:** schema_version 1.0
**Assessor:** DSE Skill Tester

---

## Test Inventory

| Category | Count | Description |
|---|---|---|
| A (Happy Path) | 2 | Valid inputs producing expected finding_set |
| B (Variance) | 6 | One per variance dimension value |
| C (Precondition Violations) | 4 | One per precondition |
| D (Edge Cases) | 8 | One per edge case row |
| **Total** | **20** | |

---

## Category A -- Happy Path

### A-1: Multi-source with complete scope coverage, no contradictions

**Input:** comparison_result.json (schema_version=1.0, comparisons with effect_size=0.45, p_value=0.003), hypothesis_result.json (schema_version=1.0, hypothesis conclusion supporting same direction), scope_artifact.json (schema_version=1.0, 2 analytical_questions both addressed by findings).

**Walkthrough:**
- Step 0: evidence_diversity="multi_source", upstream_artifacts=["comparison_result","hypothesis_result"]. Loads OK. scope_artifact loads OK.
- Step 1: Enumerates 2 upstream artifacts. Logs inventory.
- Step 2: Extracts findings from comparison_result (F-001) and hypothesis_result (F-002). Each has finding_id, statement, evidence_type, effect_size, p_value, evidence_sources, causal_confidence.
- Step 3: Ranks by strength_score. comparison finding: p<0.01(+3) + effect_size 0.45(+2) + observational(+1) = 6 -> "moderate". Multi-source convergence check: if same direction, boost to "strong". Rankings assigned.
- Step 4: No contradictions detected. contradiction_presence="none".
- Step 5: Both scope requirements addressed. coverage_ratio=1.0, scope_coverage="complete".
- Step 6: finding_set.json written with all 5 envelope fields.

**Envelope fields:** schema_version, skill_name, timestamp, record_count, artifact_id -- all present.

**Result:** ✅ PASS

---

### A-2: Single source with roi_result

**Input:** roi_result.json (schema_version=1.0, revenue_impact=2340000, impact_qualifier="estimated", roi_ratio=3.2), scope_artifact.json (schema_version=1.0, 1 analytical_question addressed).

**Walkthrough:**
- Step 0: evidence_diversity="single_source". upstream_artifacts=["roi_result"].
- Step 2: Extracts finding: statement="Revenue impact of {metric}: $2340000 (estimated)", evidence_type="roi_estimate", effect_size=3.2 (roi_ratio), causal_confidence mapped from impact_qualifier.
- Step 3: Ranks. Single source caps at "moderate" even if score>=7.
- Step 5: scope_coverage="complete" if question addressed.
- Step 6: Written.

**Result:** ✅ PASS

---

## Category B -- Variance Dimensions

### B-1: evidence_diversity = "single_source"

**Input:** Only comparison_result.json exists.

**Walkthrough:** Step 0 classifies as "single_source". Step 3: evidence_strength capped at "moderate" even if score >= 7. This is correctly implemented: "IF evidence_diversity == 'single_source' AND finding.evidence_strength == 'strong': finding.evidence_strength = 'moderate'".

**Result:** ✅ PASS

---

### B-2: evidence_diversity = "multi_source"

**Input:** comparison_result.json + behavioral_impact.json + causal_result.json.

**Walkthrough:** Step 0 classifies as "multi_source". Step 3: no cap on evidence_strength. Multi-source convergence boosts "moderate" to "strong" if same direction.

**Result:** ✅ PASS

---

### B-3: scope_coverage = "complete"

**Input:** scope_artifact with 3 analytical_questions, all 3 addressed by findings.

**Walkthrough:** Step 5: coverage_ratio=1.0, scope_coverage="complete". PASS logged.

**Result:** ✅ PASS

---

### B-4: scope_coverage = "partial"

**Input:** scope_artifact with 4 analytical_questions, 3 addressed.

**Walkthrough:** Step 5: coverage_ratio=0.75 >= 0.5, scope_coverage="partial". WARN with gaps listed.

**Result:** ✅ PASS

---

### B-5: scope_coverage = "insufficient"

**Input:** scope_artifact with 4 analytical_questions, 1 addressed.

**Walkthrough:** Step 5: coverage_ratio=0.25 < 0.5, scope_coverage="insufficient". WARN: "Insufficient scope coverage. Narrative-generation will HALT."

**Analysis:** The skill correctly classifies and warns but does NOT HALT itself -- it writes the finding_set with scope_coverage_assessment="insufficient" and lets downstream narrative-generation HALT. This is the correct design per the spec.

**Result:** ✅ PASS

---

### B-6: contradiction_presence = "detected"

**Input:** comparison_result shows Group A > Group B for metric X. behavioral_impact shows negative adjusted_difference for same metric X.

**Walkthrough:** Step 4: same_metric=true, opposite_direction=true. Contradiction appended. WARN logged. Both findings preserved in finding_set. contradiction_presence="detected".

**Result:** ✅ PASS

---

## Category C -- Precondition Violations

### C-1: No upstream analytical artifacts exist

**Precondition violated:** "At least one upstream analytical artifact exists"

**Walkthrough:** Step 0: scans all 13 types, none found. upstream_artifacts=[]. HALT: "No upstream analytical artifacts found. At least one required."

**Result:** ✅ PASS -- Step 0 correctly HALTs.

---

### C-2: Upstream artifact has schema_version != "1.0"

**Precondition violated:** "Each upstream artifact has schema_version == '1.0'"

**Input:** comparison_result.json with schema_version="2.0".

**Walkthrough:** Step 0: loads comparison_result.json, asserts schema_version=="1.0", assertion fails.

**Analysis:** Step 0 pseudocode has `assert schema_version == "1.0"` but does not explicitly show a HALT message. Edge case table says: "HALT Step 0: 'Schema mismatch on {artifact}.'"

**Result:** ✅ PASS -- HALT triggered.

---

### C-3: scope_artifact.json missing

**Precondition violated:** "scope_artifact.json exists with schema_version == '1.0'"

**Input:** comparison_result.json exists but no scope_artifact.json.

**Walkthrough:** Step 0: scope_artifact not found. WARN: "scope_artifact.json not found; scope coverage assessment will be skipped." Step 5: scope_artifact is null, scope_coverage defaults to "partial", scope_gaps=["scope_artifact not available for coverage assessment"].

**Analysis:** Precondition says scope_artifact is required, but the workflow only WARNs and proceeds with a conservative default. This is a soft precondition -- reasonable design choice since the skill's primary job is finding assembly, not scope assessment.

**Result:** ⚠️ WARN -- Precondition says "required" but workflow degrades gracefully with WARN. Not a critical issue since scope assessment is secondary function.

---

### C-4: Upstream analytical skills have not completed (in-progress artifacts)

**Precondition violated:** "Upstream analytical skills have completed (no in-progress artifacts)"

**Input:** comparison_result.json exists but contains a field like status="in_progress" or is partially written.

**Walkthrough:** Step 0 checks schema_version and loads artifact. Step 1 validates effect_size not null, p_value not null.

**Analysis:** There is NO explicit check for in-progress status in any workflow step. If a partially-written artifact has schema_version="1.0" but incomplete data, Step 1 would catch null fields. However, if the artifact has all fields populated but the upstream skill hasn't finalized (e.g., it's mid-iteration), there's no detection mechanism.

**Result:** 🚫 Critical -- Precondition "Upstream analytical skills have completed (no in-progress artifacts)" is declared but never enforced. No step checks for completion status. A partially-complete artifact with valid-looking data would pass all gates.

---

## Category D -- Edge Cases

### D-1: Empty input (no upstream artifacts)

**Edge case:** "No upstream artifacts found"

**Walkthrough:** Step 0: HALT: "No upstream analytical artifacts found."

**Result:** ✅ PASS

---

### D-2: Single record (one finding from one upstream)

**Edge case:** "Only one finding extracted from one upstream"

**Walkthrough:** Step 2 extracts 1 finding. Step 3: evidence_diversity="single_source", so evidence_strength capped at "moderate". Proceed with single finding.

**Result:** ✅ PASS

---

### D-3: All-null dimension (all upstream have null effect sizes)

**Edge case:** "All upstream artifacts have null effect sizes"

**Walkthrough:** Step 2: effect_size is null for all extracted findings. Edge case says WARN Step 2: "No effect sizes available for ranking. Rank by p-value only."

**Analysis:** Step 3 ranking pseudocode uses abs(finding.effect_size) for scoring. If effect_size is null, this would error unless there's null-safety. The WARN is documented in the edge case table but Step 3 pseudocode does not show null-handling for effect_size.

**Result:** ⚠️ WARN -- Edge case documented but Step 3 ranking logic does not show null-safe handling of effect_size. Could cause runtime error.

---

### D-4: Schema mismatch

**Edge case:** "schema_version != '1.0' on any upstream"

**Walkthrough:** Step 0: assert fails. HALT: "Schema mismatch on {artifact}."

**Result:** ✅ PASS

---

### D-5: All findings contradict

**Edge case:** "Every finding pair is contradictory"

**Walkthrough:** Step 4: all pairs flagged. WARN: "All findings contradict -- report all with explicit contradiction notes." All findings preserved with contradiction_with populated. contradiction_presence="detected".

**Result:** ✅ PASS

---

### D-6: Scope artifact missing

**Edge case:** "scope_artifact.json not found"

**Walkthrough:** Step 0: WARN. Step 5: scope_coverage="partial" (conservative default). scope_gaps populated.

**Result:** ✅ PASS

---

### D-7: Duplicate findings

**Edge case:** "Same conclusion from same source appears twice"

**Walkthrough:** Edge case says: "Deduplicate in Step 2; merge evidence_sources."

**Analysis:** Step 2 pseudocode does NOT include deduplication logic. The extraction loop processes each artifact's conclusions sequentially but has no duplicate detection or merging.

**Result:** ⚠️ WARN -- Deduplication documented in edge case table but not implemented in Step 2 pseudocode.

---

### D-8: Insufficient scope coverage (coverage_ratio < 0.5)

**Edge case:** "coverage_ratio < 0.5"

**Walkthrough:** Step 5: coverage_ratio < 0.5, scope_coverage="insufficient". WARN: "Insufficient coverage. Downstream narrative-generation will HALT." Skill proceeds to write finding_set with scope_coverage_assessment="insufficient".

**Result:** ✅ PASS

---

## Postcondition Verification

| Postcondition | Status | Notes |
|---|---|---|
| finding_set.json exists with all 5 universal envelope fields | ✅ PASS | schema_version, skill_name, timestamp, record_count, artifact_id all present |
| findings array ranked by evidence_strength descending | ✅ PASS | Step 3 sort logic: strength_order then abs(effect_size) descending |
| contradictions_found populated (may be empty) | ✅ PASS | Step 4 always populates; never suppresses |
| scope_coverage_assessment is one of complete/partial/insufficient | ✅ PASS | Step 5 logic covers all three values |
| Every finding has evidence_sources tracing to upstream | ✅ PASS | Step 2 always sets evidence_sources per extraction |

---

## Quality Bar Verification

| Quality Item | Status | Notes |
|---|---|---|
| Validates against terminal artifact spec | ✅ PASS | All required fields present |
| All upstream artifacts enumerated and findings extracted | ✅ PASS | Step 1 + Step 2 cover this |
| Evidence strength scoring consistent and reproducible | ✅ PASS | Deterministic scoring formula in Step 3 |
| Contradictions detected and documented | ✅ PASS | Step 4 is explicit about preservation |
| Scope coverage accurately reflects requirements | ✅ PASS | Step 5 ratio-based assessment is sound |
| Single-source findings capped at "moderate" | ✅ PASS | Step 3 explicit cap logic present |

---

## Summary

| Category | Total | Pass | Warn | Fail | Critical |
|---|---|---|---|---|---|
| A (Happy Path) | 2 | 2 | 0 | 0 | 0 |
| B (Variance) | 6 | 6 | 0 | 0 | 0 |
| C (Precondition) | 4 | 2 | 1 | 0 | 1 |
| D (Edge Cases) | 8 | 6 | 2 | 0 | 0 |
| **Total** | **20** | **16** | **3** | **0** | **1** |

---

## Critical Issues

1. **C-4 (Precondition not enforced):** The precondition "Upstream analytical skills have completed (no in-progress artifacts)" is declared but never checked. No workflow step inspects a status or completion field on upstream artifacts. If a partially-complete artifact has valid-looking schema_version and non-null fields, it would pass all gates undetected.

**Recommended fix:** Either (a) add a `status` field to upstream artifact schemas that this skill checks in Step 0, or (b) remove the precondition if completion is guaranteed by the pipeline orchestrator.

---

## Warnings

1. **C-3:** scope_artifact.json precondition says "required" but workflow degrades gracefully with WARN.
2. **D-3:** Null effect_size handling documented in edge case table but Step 3 ranking pseudocode lacks null-safe logic.
3. **D-7:** Deduplication documented in edge case table but Step 2 extraction does not implement it.
