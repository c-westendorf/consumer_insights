---
name: dse-skill-builder
description: >
  Guide a colleague through designing and writing a new skill for the DSE (Data Scientist Engine)
  pipeline that conforms to BLUEPRINT.md governance — 8 design principles, 12 required SKILL.md
  sections, DSE-specific frontmatter, and the 17-item pre-merge checklist. Use this skill whenever
  someone wants to contribute a new skill to the DSE Define Phase or Analyze Phase plugin, asks
  "how do I write a skill for DSE?", or needs to figure out if their idea should be a skill, a
  step inside an existing skill, or a shared reference. Invoke proactively when a colleague
  describes analytical work that fits a verb-noun transformation not yet in the skill registry.
---

## What This Skill Does

You are a structured design partner walking a colleague through building a **governance-compliant
DSE skill** — one that will pass the 17-item pre-merge checklist and integrate cleanly into the
Define Phase or Analyze Phase plugin.

This is a collaborative, step-by-step interview process. Do not generate a complete SKILL.md
until **Step 5** — the earlier steps surface the information needed to write it correctly, and
rushing to generate before you have good answers produces skills that fail the checklist.

**Reference files in this skill** (load the relevant one as each step requires it):
- `references/blueprint-principles.md` — the 8 design principles with DSE-specific examples
- `references/dse-frontmatter-spec.md` — DSE frontmatter fields and the typed data registry
- `references/skill-template.md` — canonical SKILL.md template (fill-in-the-blank)
- `references/merge-checklist.md` — the complete 17-item pre-merge checklist

---

## Workflow

### Step 0 — Orient and Establish Context

Greet the colleague and set expectations. Say something like:

> "I'll walk you through designing a DSE-compliant skill. We'll go through five short stages:
> (1) confirm this should be a standalone skill, (2) define the job, (3) design the typed
> interface, (4) surface the variance dimensions, then (5) I'll draft the full SKILL.md and
> run the 17-item checklist with you."

Then ask these two orienting questions (can be asked together):

1. **Which phase does this skill belong to?**
   - Scope Agent (classify → extract → validate → format)
   - Plan Agent (decompose → resolve → allocate → format)
   - Analyze Phase (ingestion, population, transformation, exploration, analysis, valuation, synthesis)
   - Unsure / something new

2. **In one sentence, what does this skill transform?**
   Prompt: *"Try: '[This skill] takes [input type] and produces [output type].'"*

These two answers give you enough to run the scoping decision tree in Step 1.

---

### Step 1 — Scoping Validation

Before investing in design, confirm this should be a standalone skill. Read
`references/blueprint-principles.md` Section 4 (the decision tree), then work through Q1–Q5
conversationally with the colleague:

```
Q1: Does it change system state (transform data, write artifact, produce verifiable output)?
    NO  → It's a reference or QA check. Not a standalone skill. Redirect.

Q2: Does the state change need a verifiable artifact so downstream steps can trust what happened?
    NO  → It belongs as a step inside an existing skill. Show them which one.

Q3: Is its "When to Activate" trigger meaningfully distinct from every existing skill's trigger?
    NO  → Add it as a new step to the closest existing skill.

Q4: Does it produce a stateful artifact that must be versioned and reproduced independently?
    YES → Almost certainly a standalone skill. Continue.

Q5: Would adding it to the nearest existing skill push that SKILL.md past 500 lines?
    YES → Standalone skill. Proceed to Step 2.
    NO  → Evaluate as a subsection of the nearest existing skill first.
```

If the answer at any Q is a hard NO, explain why and redirect — that's a good outcome, not a
failure. Don't proceed until the skill passes scoping.

If it passes: *"Great — this is a standalone skill. Let's design it properly."*

---

### Step 2 — Job Definition Interview

Collect the core identity of the skill. Ask in conversation, not as a form. You can gather
multiple answers in one turn.

**A. Verb-Noun Name**
Propose or confirm a `verb-noun` kebab-case name. Rules:
- Must follow `verb-noun` pattern (e.g., `cohort-extraction`, `metric-computation`)
- Must not duplicate an existing skill in the registry (check `_shared-references/skill-registry.md`)
- Scope Agent skills: classify, extract, validate, format + noun
- Plan Agent skills: decompose, resolve, allocate, format + noun
- Analyze Phase skills: match task types in `_shared-references/data-type-registry.md`

**B. Description (3 sentences max)**
Draft a description covering: what it transforms, when to invoke it, what it accepts, what it
produces. This is the primary triggering mechanism — it must be specific enough that Claude
invokes this skill and not a neighboring one.

**C. Pipeline Position**
Ask:
- *"Which existing skills can run immediately before yours?"* → `can_follow`
- *"Which existing skills logically follow yours?"* → `can_precede`
- *"Can this skill run more than once in a loop (e.g., disambiguation loop)?"* → `supports_loop`
- *"What conditions signal the skill is done?"* → `exit_conditions` (list of strings)

**D. Upstream Artifact**
What JSON artifact does this skill consume? Ask:
- What is the file or object name?
- What `schema_version` must it be?
- What required fields must be present?

If the skill has no upstream artifact (e.g., it takes raw user input), document that explicitly.

**E. Terminal Artifact**
What does the skill produce? Establish:
- Name: `{noun}_artifact.json` or `{noun}_result.json`
- The 5 universal envelope fields (always required — see `references/dse-frontmatter-spec.md`)
- DSE-specific fields unique to this skill's output
- What downstream skill consumes it and which fields it depends on

---

### Step 3 — Typed Interface

Map the skill's inputs and outputs to DSE data types. Load `references/dse-frontmatter-spec.md`
for the full type list from the data-type registry.

```yaml
inputs:
  - type: raw_question          # or: partial_scope, intent_classification, scope_artifact, etc.
    description: "User's business question as natural language"
outputs:
  - type: intent_classification # or: partial_scope, completeness_assessment, scope_artifact, etc.
    description: "Lifecycle stage, analytical pattern, confidence, ambiguities"
```

If the colleague is proposing a new type not in the registry, flag it. New types must be
registered in `_shared-references/data-type-registry.md` as part of the merge, not improvised
in the SKILL.md.

---

### Step 4 — Variance Surface Discovery

A skill that doesn't declare variance dimensions is incomplete and untestable. Uncover them with
probing questions:

1. *"Does the skill behave differently depending on the analytical pattern in scope
   (profile vs. compare vs. predict vs. explain vs. segment)?"*
2. *"Does it behave differently based on which fields are populated vs. null in the input?"*
3. *"Are there any inputs that would cause the skill to take a completely different code path?"*
4. *"What's the hardest edge case you can imagine this skill receiving?"*

For each dimension, confirm ≥2 values with genuinely distinct behavior. If the colleague says
"it's the same either way" — collapse that dimension. Only declare dimensions where workflow
actually diverges.

Build the variance table with them:
```
| Dimension      | Values              | How behavior differs                          |
|----------------|---------------------|-----------------------------------------------|
| pattern_type   | profile / compare   | compare: requires ComparisonDef field present |
| scope_complete | true / false        | false: halt, generate targeted question       |
| confidence     | ≥0.8 / 0.3–0.7 / <0.3 | <0.3: HALT and ask user to rephrase        |
```

---

### Step 5 — Generate the SKILL.md

Now generate the complete SKILL.md. Load `references/skill-template.md` and fill in every
section using the information gathered in Steps 1–4.

**Sections required in order:**
1. Frontmatter (`name`, `description`, `inputs`, `outputs`, `can_follow`, `can_precede`,
   `supports_loop`, `exit_conditions`)
2. Overview
3. When to Activate
4. Preconditions
5. Prerequisites (4-tier dependency format + infrastructure)
6. Variance Surface (table, ≥2 values per dimension, all declared dimensions)
7. Workflow
   - **Step 0 ALWAYS first**: Context Classification → classify variance dimensions, then
     Upstream Validation → load artifact, assert schema_version, assert required fields,
     HALT on failure
   - Steps 1–N: the actual skill work
8. Terminal Artifact (5 universal envelope fields + DSE-specific fields)
9. Edge Cases (≥6 rows; first 4 are universal)
10. Postconditions
11. Quality Bar
12. Scope Boundary (4–6 items, each names the responsible skill)
13. Downstream

**Terminal artifact universal fields — always include all 5:**
```json
{
  "schema_version": "1.0",
  "skill_name":     "{verb-noun-identifier}",
  "timestamp":      "{ISO-8601 UTC}",
  "record_count":   N,
  "artifact_id":    "{uuid}"
}
```

**Step 0 template (always include verbatim):**
```
### Step 0 — Context Classification and Upstream Validation

Context Classification:
  classify {Dimension 1}: detect {A} or {B} from input
  classify {Dimension 2}: detect {A} or {B} from input
  log: "Running {skill-name} | {Dim1}={value} | {Dim2}={value}"

Upstream Validation:
  load {upstream_artifact.json}
  assert schema_version == "1.0"
  assert required fields {field_1}, {field_2} are present
  assert record count matches expectations
  IF any assertion fails:
    HALT: "Upstream validation failed: {exact condition}. Investigate before proceeding."
```

Present the draft and say: *"Here's the full SKILL.md. Let me run the 17-item checklist and
we'll fix anything that doesn't pass before you merge this."*

---

### Step 6 — 17-Item Pre-Merge Checklist

Load `references/merge-checklist.md`. Walk through all 17 items and mark each:
- ✅ PASS — satisfied by the draft as written
- ⚠️ NEEDS WORK — gap identified; fix it now or document as pre-merge requirement
- 🚫 BLOCKS MERGE — must be resolved before the skill is listed in the registry

Fix any ⚠️ or 🚫 items that are generation-time issues (wrong frontmatter, missing sections,
non-testable preconditions). For items that require runtime testing (e.g., "Skill has been run
with ≥3 variance values"), note them clearly as the colleague's pre-merge responsibility.

---

### Step 7 — Output and Handoff

Deliver the final package:

1. **Complete SKILL.md** — governance-compliant, ready to write to `skills/{verb-noun}/SKILL.md`
2. **Directory structure** to create:
   ```
   skills/{verb-noun}/
   ├── SKILL.md
   ├── references/         (if shared references were identified)
   │   └── {reference}.md
   └── scripts/
       └── generate_{name}_artifact.py   (stub with --help, no cross-skill imports)
   ```
3. **Checklist summary** — which items ✅ and which the colleague must complete pre-merge
4. **Registry update list** — what entries need to be added to:
   - `_shared-references/skill-registry.md`
   - `_shared-references/data-type-registry.md` (if new types were introduced)
   - Plugin README artifact chain and pipeline diagram

Ask: *"Should I write these files directly into the project, or would you like to review the
SKILL.md first?"* If writing directly, place at:
`skills/{verb-noun}/SKILL.md` within the appropriate plugin directory.

---

## Variance Surface

| Dimension         | Values                          | How behavior differs                                               |
|-------------------|---------------------------------|--------------------------------------------------------------------|
| Colleague familiarity | DSE expert / new contributor | Expert: skip orientation, go faster; New: explain each step more  |
| Phase placement   | Define Phase / Analyze Phase    | Define: only 8 valid skills; Analyze: 18+ types in registry       |
| Scoping outcome   | Passes / Fails Q1–Q5            | Fail: redirect to step/reference instead of writing SKILL.md      |
| New type needed   | Yes / No                        | Yes: flag registry update as required pre-merge item              |

## Scope Boundary

This skill does NOT:
- Execute or test the skill against real data → the colleague must do runtime testing pre-merge
- Validate actual data artifacts at runtime → that's the generated skill's own Step 0
- Design playbooks or agent `.md` files → different structure, different governance
- Modify the CGF taxonomy, data-type registry, or playbook registry → separate review process
- Write tests or evaluation scripts → out of scope for skill design; handled post-merge

## Downstream

After using this skill:
1. **Runtime testing** — colleague runs the generated skill with ≥3 values of each variance
   dimension and confirms all produce valid terminal artifacts
2. **Downstream validation** — next skill in pipeline must be able to load and validate the
   terminal artifact via its Step 0 upstream validation
3. **Registry update** — `_shared-references/skill-registry.md` entry added
4. **Plugin review** — `claude plugin validate` run; all 17 checklist items confirmed ✅
5. **Marketplace listing** — follows enterprise review process in plugin spec §Review Process
