# DSE SKILL.md — Canonical Template

Fill in every placeholder `{...}` using the information gathered in Steps 1–4 of the
dse-skill-builder workflow. Do not leave any placeholder blank — if a section has no
content yet, mark it `TBD: [what is needed]` so the colleague knows to complete it.

---

```markdown
---
name: {verb-noun-identifier}
description: >
  {What this skill transforms. When to invoke it. What it accepts and produces.
  ≤3 sentences. Observable behavior — no internal jargon.}
inputs:
  - type: {data_type_from_registry}
    description: "{human-readable description of the input}"
outputs:
  - type: {data_type_from_registry}
    description: "{human-readable description of the output}"
can_follow: [{skill-name}]    # [] if this starts a pipeline branch
can_precede: [{skill-name}]   # [] if this ends a pipeline branch
supports_loop: false           # true if this skill runs multiple times in a loop
exit_conditions: [{condition_string}]
---

## Overview

{Why this step exists in the pipeline. What breaks if it is skipped. What guarantee
it provides to whatever runs next. 3–5 sentences of prose. Explain the "why", not
just the "what".}

---

## When to Activate

{5–8 observable trigger conditions. Each must be detectable from context or system
state without asking the user. Concrete signals, not vague categories.}
- {Observable signal 1 — e.g., "scope_session.json exists and status == 'classifying'"}
- {Observable signal 2}
- {Observable signal 3}
- {Observable signal 4}
- {Observable signal 5}

---

## Preconditions

What must be true before this skill begins:
- [ ] {Testable assertion — e.g., "upstream_artifact.json exists in project directory"}
- [ ] {Testable assertion — e.g., "schema_version == '1.0'"}
- [ ] {Testable assertion — e.g., "required field {field_name} is not null"}

Each precondition must have a HALT condition in Step 0 if violated.

---

## Prerequisites

### Library Dependencies
```
# Tier 1 — Domain core (required by all DSE skills)
# (none currently — DSE skills operate on JSON artifacts and conversation context)

# Tier 2 — Domain optional (if applicable)
# {package}>={version}   # used when {condition}

# Tier 3 — Skill-specific
# {package}>={version}   # used by this skill only — e.g., jsonschema>=4.0 for validation

# Tier 4 — Infrastructure
# Python version: >=3.10
# Base environment: python:3.10-slim (if scripts are used)
```

### Infrastructure Requirements
- **Compute:** CPU-only
- **Memory:** minimal (JSON artifact processing)
- **Disk:** scratch space for artifact output (~1 KB)
- **Upstream Artifacts:** `{artifact_name.json}` produced by `{skill-name}` — required fields:
  `{field_1}`, `{field_2}`

---

## Variance Surface

Declare every dimension this skill branches on. Every declared dimension must have ≥2 values
with genuinely distinct behavior. Remove any dimension where behavior is identical across values.

| Dimension      | Values              | How behavior differs                              |
|----------------|---------------------|---------------------------------------------------|
| {Dimension 1}  | {A / B}             | {what actually changes in the workflow}           |
| {Dimension 2}  | {A / B / C}         | {what changes per value}                          |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:** Before any processing, classify the variance dimensions declared
above. This determines which code paths the remaining steps follow.

```
classify {Dimension 1}: detect {A} or {B} from input
classify {Dimension 2}: detect {A} or {B} or {C} from input
log: "Running {skill-name} | {Dim1}={value} | {Dim2}={value}"
```

**Upstream Validation:** If this skill consumes an upstream artifact:
```
load {upstream_artifact.json}
assert schema_version == "1.0"
assert artifact contains required fields: {field_1}, {field_2}
assert {additional assertion specific to this skill}
IF any assertion fails:
  HALT: "Upstream validation failed: {exact condition}. Investigate before proceeding."
```

---

### Step 1 — {Name: verb phrase}

**Goal:** {One sentence: what state the system is in after this step completes.}

**Pre-step assertion:** {What must be true before this step runs — testable.}

**Reference:** `references/{reference-file.md}` *(omit if not applicable)*

**Actions:**

*Branch on {Dimension}:*

**IF {value A}:**
```
{Concrete instructions — not pseudocode. What Claude does, in order.}
```

**IF {value B}:**
```
{Instructions for this branch.}
```

**Checkpoint:**
> - [ ] PASS: {specific, testable assertion that this step succeeded}
> - [ ] HALT: {condition} → "Exact halt message text."
> - [ ] WARN: {condition where proceed-but-document is correct}

**Post-step assertion:** {What is guaranteed to be true after this step completes.}

---

### Step 2 — {Name}

{Repeat Step 1 structure. A well-scoped skill has 4–8 steps total.}

---

### Step 3 — {Name}

{...}

---

### Step N — {Name}

{...}

---

## Terminal Artifact

The skill's permanent output. The next skill in the pipeline validates this in its Step 0
before processing.

**Required fields — include all 5 universal envelope fields + DSE-specific fields:**

```json
{
  "schema_version": "1.0",
  "skill_name":     "{verb-noun-identifier}",
  "timestamp":      "{ISO-8601 UTC}",
  "record_count":   N,
  "artifact_id":    "{uuid}",
  "{dse-field-1}":  "{...}",
  "{dse-field-2}":  "{...}"
}
```

**Write to:** `{noun}_artifact.json` in the project directory (not the plugin directory).

---

## Edge Cases

| Edge Case               | Detection                              | Action                                         |
|-------------------------|----------------------------------------|------------------------------------------------|
| Empty input             | record count == 0 / null input         | HALT: "Input is empty. Skill cannot proceed."  |
| Single record           | count == 1                             | WARN: "Single record — statistical steps skipped." |
| All-null dimension      | required field 100% missing            | HALT or WARN per pattern rules                 |
| Schema mismatch         | schema_version != "1.0"               | WARN: log, proceed with reduced trust          |
| {Skill-specific case 1} | {detection}                            | {action}                                       |
| {Skill-specific case 2} | {detection}                            | {action}                                       |

*(minimum 6 rows; first 4 are universal — include in every skill)*

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] Terminal artifact exists in the project directory
- [ ] Terminal artifact is valid JSON containing all 5 universal envelope fields
- [ ] {Testable DSE-specific guarantee 1}
- [ ] {Testable DSE-specific guarantee 2}

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] All checkpoints passed or explicitly documented as WARN
- [ ] Terminal artifact exists and validates against its declared schema
- [ ] {DSE-specific assertion 1}
- [ ] {DSE-specific assertion 2}
- [ ] Downstream skill's Step 0 can successfully load and validate the artifact
*(aim for 6–9 items total)*

---

## Scope Boundary

This skill does NOT:
- {Job 1} → handled by `{other-skill-name}`
- {Job 2} → handled by `{other-skill-name}`
- {Job 3} → handled by `{other-skill-name}`
- {Job 4} → handled by `{other-skill-name}`
*(4–6 items; each names the responsible skill)*

---

## Downstream

Run after this skill completes:
1. **`{next-skill}`** — {why it comes next; which fields of the terminal artifact it consumes}
```

---

## Notes on Filling Out This Template

**Step 0 is non-negotiable.** Every DSE skill must have Context Classification + Upstream
Validation as its first step. Even skills that take raw user input (no artifact upstream)
must classify their variance dimensions in Step 0.

**HALT vs. WARN vs. PASS:**
- HALT: blocking condition — the skill cannot produce a valid artifact. Stop immediately.
- WARN: non-blocking — proceed, but log the issue and note it in the artifact metadata.
- PASS: the assertion is satisfied. Document it in the checkpoint so it's auditable.

**Quality Bar vs. Postconditions:**
- Postconditions are what the skill guarantees (output state assertions).
- Quality Bar is the human-readable "done" criteria (includes process + output).

**Scope Boundary — always name names:**
Don't write "this skill doesn't validate the scope" — write "validation → handled by
`completeness-validation`". The responsible skill name makes the boundary navigable.
