# DSE Frontmatter Specification

Every DSE skill SKILL.md must have these frontmatter fields. The first two (`name`, `description`)
are Claude Code native. The rest are DSE-specific declarations for pipeline composition and
future Stage 3 compatibility.

---

## Required Frontmatter Fields

```yaml
---
name: {verb-noun-kebab-case}
description: >
  {What it transforms. When to invoke it. What it accepts. What it produces.
  ≤3 sentences. Observable behavior — no jargon.}
inputs:
  - type: {data_type}
    description: "{human-readable description}"
  - type: {data_type}         # add more if needed
    description: "{...}"
outputs:
  - type: {data_type}
    description: "{human-readable description}"
can_follow: [{skill-name}, {skill-name}]   # empty list [] if this starts a pipeline
can_precede: [{skill-name}, {skill-name}]  # empty list [] if this ends a pipeline
supports_loop: false   # true if this skill can run multiple times in a disambiguation loop
exit_conditions: [{string}, {string}]      # conditions that mark the skill as done
---
```

---

## Field Reference

### `name`
Verb-noun kebab-case. Max 3 words. Must be unique in the skill registry.

**Define Phase names:** `intent-classification`, `scope-extraction`, `completeness-validation`,
`scope-formatting`, `task-decomposition`, `dependency-resolution`, `budget-allocation`,
`plan-formatting`

**Analyze Phase convention:** Match the `task_type` field in `dse-task-registry.md` Layer 2.
Examples: `data-extraction`, `cohort-extraction`, `metric-computation`, `trend-detection`,
`roi-computation`, `finding-assembly`

### `description`
This is the primary mechanism Claude uses to decide whether to activate this skill. It must be:
- Specific enough to not conflict with neighboring skills
- Inclusive of "when to use" signals (not just "what it does")
- Max 3 sentences, observable behavior, no internal jargon

### `inputs` / `outputs`
Map to the DSE data type registry. Use these canonical types:

**Raw input types:**
- `raw_question` — user's natural language business question
- `conversation_context` — prior conversation turns
- `session_metadata` — session ID, attempt counts, timestamps

**Scope Agent types:**
- `intent_classification` — `{lifecycle_stage, analytical_pattern, confidence, ambiguities}`
- `partial_scope` — `{population, metric, timeframe, comparison, business_context, constraints}`
- `completeness_assessment` — `{is_complete, missing_fields, warnings, disambiguation_questions}`
- `scope_artifact` — the fully formatted, approved scope JSON

**Plan Agent types:**
- `cgf_task_templates` — task templates from CGF taxonomy
- `skill_registry` — available skills and typed interfaces
- `task_node_list` — list of atomic task nodes
- `ordered_task_plan` — dependency-resolved plan
- `budgeted_task_plan` — plan with exploration budgets assigned
- `plan_artifact` — the final formatted plan JSON

**Analyze Phase types (Layer 1 of task registry):**
- `raw_dataset` — unprocessed source data
- `profiled_dataset` — dataset with schema and quality assessment
- `cohort` — population defined by extraction criteria
- `sample_set` — sampled subset of a population
- `feature_set` — engineered features ready for analysis
- `metric_result` — computed metric values
- `signal_result` — detected signals or anomalies
- `interval_result` — confidence intervals or range estimates
- `comparison_result` — statistical comparison output
- `hypothesis_result` — hypothesis test outcome
- `roi_result` — ROI computation output
- `finding_set` — assembled analytical findings
- `narrative` — stakeholder-ready narrative output

**If your type isn't listed:** You are introducing a new type. It must be added to
`_shared-references/data-type-registry.md` as part of your pre-merge work.

### `can_follow`
List of skill names that can immediately precede this one. Used by agents and the composition
rules to validate pipeline ordering. Use `[]` if this skill starts a pipeline branch.

```yaml
can_follow: [intent-classification]    # scope-extraction follows intent-classification
can_follow: []                          # intent-classification starts the pipeline
```

### `can_precede`
List of skill names that logically follow this one. The mirror of `can_follow`.

```yaml
can_precede: [scope-extraction]        # intent-classification precedes scope-extraction
can_precede: []                         # scope-formatting ends the Scope Agent pipeline
```

### `supports_loop`
Boolean. Set `true` if this skill can be called multiple times in a loop (e.g.,
disambiguation: user answers a question, scope-extraction re-runs with new context,
completeness-validation re-runs, loop repeats until complete).

```yaml
supports_loop: true    # scope-extraction (called each disambiguation turn)
supports_loop: false   # scope-formatting (called once, writes final artifact)
```

### `exit_conditions`
String list of conditions that mark the skill as successfully complete. Must be observable
from the system state, not vague goals.

```yaml
exit_conditions: [classification_complete]
exit_conditions: [all_extractable_fields_populated]
exit_conditions: [assessment_complete]
exit_conditions: [artifact_written]
exit_conditions: [decomposition_complete]
exit_conditions: [dependencies_resolved]
```

---

## Terminal Artifact Universal Envelope

All DSE terminal artifacts must include these 5 fields. Downstream skills assert on them
in Step 0. Never omit any of them.

```json
{
  "schema_version": "1.0",
  "skill_name":     "{verb-noun-identifier}",
  "timestamp":      "{ISO-8601 UTC}",
  "record_count":   N,
  "artifact_id":    "{uuid}"
}
```

Add DSE-specific fields after these. Downstream skills may depend on domain-specific fields
from the same skill but should NOT depend on another skill's domain-specific fields — only
the 5 universal fields cross skill boundaries safely.

---

## Naming Convention Summary

| Component         | Convention                          | Example                          |
|-------------------|-------------------------------------|----------------------------------|
| Skill name        | verb-noun, kebab-case               | `metric-computation`             |
| Skill directory   | same as skill name                  | `skills/metric-computation/`     |
| Terminal artifact | `{noun}_artifact.json` or `_result` | `scope_artifact.json`            |
| Generate script   | `generate_{noun}_artifact.py`       | `generate_scope_artifact.py`     |
| References        | descriptive-noun, kebab-case        | `cgf-patterns.md`                |

---

## Example: Complete Frontmatter

```yaml
---
name: completeness-validation
description: >
  Evaluate whether a partial scope meets the minimum requirements for plan generation
  by checking required fields against the identified analytical pattern. Generates
  targeted disambiguation questions for any missing or ambiguous fields. Use after
  scope-extraction to determine if the scope is complete or needs more user input.
inputs:
  - type: partial_scope
    description: "Structured scope fields extracted from conversation so far"
  - type: intent_classification
    description: "Identified lifecycle stage and analytical pattern with confidence score"
outputs:
  - type: completeness_assessment
    description: "is_complete flag, missing fields with suggested questions, warnings"
can_follow: [scope-extraction]
can_precede: [scope-formatting]
supports_loop: false
exit_conditions: [assessment_complete]
---
```
