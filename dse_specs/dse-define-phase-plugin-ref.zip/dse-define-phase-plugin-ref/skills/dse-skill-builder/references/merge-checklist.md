# DSE Skill Pre-Merge Checklist — 17 Items

Source: `skill-blueprint/BLUEPRINT.md` § Section 7

All 17 items must be checked before a skill is listed in the enterprise marketplace.
Mark each: ✅ PASS | ⚠️ NEEDS WORK | 🚫 BLOCKS MERGE

---

## Group 1 — Definition and Structure (5 items)

**1. Frontmatter is complete and correct**
- [ ] `name` and `description` present (Claude Code native)
- [ ] DSE fields present: `inputs`, `outputs`, `can_follow`, `can_precede`, `supports_loop`, `exit_conditions`
- [ ] `description` states transformation, trigger, input, output in ≤3 sentences

**2. All 12 required sections present in order**
Required order:
1. Overview
2. When to Activate
3. Preconditions
4. Prerequisites
5. Variance Surface
6. Workflow (Step 0 + Steps 1–N)
7. Terminal Artifact
8. Edge Cases
9. Postconditions
10. Quality Bar
11. Scope Boundary
12. Downstream

**3. SKILL.md ≤ 500 lines**
- [ ] Count the lines: `wc -l SKILL.md`
- [ ] If over 500: extract long sections to named files in `references/` with `**Reference:**`
  links at the point of use in the workflow

**4. Artifact generation script exists**
- [ ] `scripts/generate_{name}_artifact.py` exists
- [ ] Has a `--help` flag (standalone CLI)
- [ ] Contains no cross-skill imports (no `from ..other_skill.scripts import ...`)
- [ ] Can be run independently: `python scripts/generate_{name}_artifact.py --help`

**5. Dependencies declared in 4-tier format**
- [ ] `requirements.txt` at skill root (or confirming none needed)
- [ ] Tier 1 (domain core), Tier 2 (domain optional), Tier 3 (skill-specific), Tier 4 (infra)
- [ ] Infrastructure requirements documented in `## Prerequisites`

---

## Group 2 — Contracts and Correctness (4 items)

**6. Preconditions are testable with explicit HALT**
- [ ] Each precondition is a testable assertion (not a vague goal)
  - ✅ `"scope_artifact.json exists and schema_version == '1.0'"`
  - ❌ `"the scope is good enough"`
- [ ] Each precondition has a matching HALT in Step 0 if violated
- [ ] HALT message is exact (not generic "something went wrong")

**7. Terminal artifact has all 5 universal envelope fields**
- [ ] `schema_version: "1.0"` present
- [ ] `skill_name` present
- [ ] `timestamp` (ISO-8601 UTC) present
- [ ] `record_count` present
- [ ] `artifact_id` (UUID) present
- [ ] DSE-specific required fields declared and documented

**8. Stateful operations are bounded**
- [ ] Any operation that learns from data (fit, train, calibrate) is bounded to a declared subset
- [ ] The boundary is verified before the terminal artifact is written
- [ ] For DSE Define Phase: this usually means verifying scope completeness before writing
  `scope_artifact.json`

**9. Degraded upstream produces explicit HALT**
- [ ] If upstream artifact is malformed (wrong schema, missing fields, failed QA), the skill
  halts with a clear message
- [ ] There is NO silent continuation on degraded input — this would contaminate downstream work
- [ ] Test this: provide a broken upstream artifact and confirm the HALT fires

---

## Group 3 — Variance and Testing (4 items)

**10. Variance Surface table is complete**
- [ ] Every declared dimension has ≥2 values described
- [ ] Behavior actually differs per value (if not, collapse the dimension)
- [ ] The table in `## Variance Surface` matches the branching logic in `## Workflow`

**11. Skill tested with ≥3 values of each declared variance dimension**
- [ ] Run the skill with each major variance value and confirm output is a valid terminal artifact
- [ ] Example: if `analytical_pattern` is a dimension, test with `profile`, `compare`, and
  `predict` before merging
- [ ] Document test results (even informally) — "tested with profile: ✅, compare: ✅, predict: ✅"

**12. Terminal artifact passes downstream validation**
- [ ] Take the terminal artifact and run it through the next skill's Step 0 upstream validation
- [ ] Confirm: schema_version asserts pass, required fields are present, no HALT fires
- [ ] If the next skill doesn't exist yet, manually verify the artifact meets the declared schema

**13. Pipeline regression test passes**
- [ ] Insert this skill at its declared position in the pipeline
- [ ] Run an end-to-end test of the pipeline with a real business question
- [ ] Confirm the pipeline produces valid outputs at every stage

---

## Group 4 — Documentation and Integration (4 items)

**14. Plugin README pipeline diagram updated**
- [ ] The skill appears at its correct position in the pipeline diagram in `README.md`
- [ ] Position matches `can_follow` and `can_precede` declarations

**15. Plugin README artifact chain updated**
- [ ] The skill's terminal artifact is documented in the README artifact chain
- [ ] Shows: what produces it (this skill) and what consumes it (next skill)

**16. Plugin README variance coverage table updated**
- [ ] If the README has a variance coverage table, the new skill has a column
- [ ] Column shows which variance dimensions this skill handles

**17. Shared patterns promoted to `_shared-references/`**
- [ ] Any pattern, function, or reference used by ≥2 skills has been extracted to
  `_shared-references/` as the canonical source
- [ ] Each consuming skill carries its own copy in its `references/` directory
- [ ] The `_shared-references/` copy is updated whenever the pattern changes; local copies
  are derived from it

---

## Quick Checklist Summary

Use this condensed version during the Step 7 walkthrough:

| # | Item | Status |
|---|------|--------|
| 1 | Frontmatter complete (name, description + all DSE fields) | |
| 2 | All 12 required sections present in order | |
| 3 | SKILL.md ≤ 500 lines | |
| 4 | Artifact generation script exists, standalone, no cross-skill imports | |
| 5 | requirements.txt in 4-tier format | |
| 6 | Preconditions testable with explicit HALT in Step 0 | |
| 7 | Terminal artifact has all 5 universal envelope fields | |
| 8 | Stateful operations bounded to declared subset | |
| 9 | Degraded upstream produces explicit HALT (not silent continuation) | |
| 10 | Variance Surface has ≥2 values per dimension with distinct behavior | |
| 11 | Skill tested with ≥3 values of each variance dimension | |
| 12 | Terminal artifact passes downstream validation | |
| 13 | Pipeline regression test passes at declared position | |
| 14 | Plugin README pipeline diagram updated | |
| 15 | Plugin README artifact chain updated | |
| 16 | Plugin README variance coverage table updated | |
| 17 | Shared patterns promoted to `_shared-references/` | |

---

## Common Failure Patterns

**Fails item 1:** Description is ≥4 sentences, or triggers ambiguously with a neighboring skill.
Fix: tighten the description to 3 sentences; differentiate the "When to Activate" signals.

**Fails item 6:** Precondition says "data is clean" — untestable.
Fix: rewrite as `"upstream_artifact.json exists; schema_version == '1.0'; field X is not null"`.

**Fails item 7:** Missing `record_count` or `artifact_id` from terminal artifact.
Fix: add both fields to the `generate_{name}_artifact.py` script output.

**Fails item 9:** Skill logs a warning when upstream schema_version is wrong and continues.
Fix: change to HALT with exact message. Warnings are for non-blocking conditions only.

**Fails item 10:** Variance Surface lists `confidence_level: high/medium/low` but the workflow
treats all three identically.
Fix: either show genuinely different behavior per level, or collapse to `sufficient / insufficient`.

**Fails item 17:** Two skills both define the same validation function inline.
Fix: extract to `_shared-references/`, add local copies to each skill's `references/` directory.
