# BLUEPRINT.md — 8 Design Principles (DSE Reference)

Source: `skill-blueprint/BLUEPRINT.md` § Section 2

These apply to every DSE skill. Each principle includes the rule, what a violation looks like,
and a DSE-specific example to make it concrete.

---

## Principle 1 — Single Job-to-be-Done

**Rule:** One skill = one transformation of system state. Name it as `verb-noun`.
The Scope Boundary section explicitly lists what it refuses.

**Violation:** A skill called `scope-and-plan` that classifies intent AND decomposes tasks.
No clear handoff point; the Plan Agent can't trust the output.

**DSE example:** `scope-extraction` extracts structured fields from a business question.
It does NOT validate completeness (→ `completeness-validation`) or format the artifact
(→ `scope-formatting`).

---

## Principle 2 — Precondition / Postcondition Contracts

**Rule:** Every skill declares verifiable preconditions (what must be true before it starts)
and postconditions (what it guarantees after it ends). These are testable assertions.

**Violation:** Prerequisites listed as "scope is good enough to plan." Not testable.

**Correct DSE precondition:** 
```
scope_artifact.json exists in project directory
schema_version == "1.0"
partial_scope.population is not null
```

**DSE example:** `completeness-validation` precondition: `intent_classification.confidence >= 0.3`
(if below, intent-classification should have already halted upstream).

---

## Principle 3 — Explicit Variance Surface

**Rule:** Every skill declares the dimensions it branches on and shows how behavior differs
per dimension value. A skill that handles only one variant is incomplete.

**Violation:** `completeness-validation` that only documents "profile" pattern behavior,
silently ignoring "compare" (which requires a ComparisonDef field).

**DSE example:** `scope-extraction` must declare `analytical_pattern` as a variance dimension
because a "compare" pattern requires extracting `comparison.type` and `comparison.reference`,
while "profile" does not.

---

## Principle 4 — Artifact at Every State Change

**Rule:** Any step that irreversibly changes system state produces a named, verifiable terminal
artifact. The artifact is the only way downstream steps know what happened.

**Violation:** `scope-formatting` that prints a scope summary to stdout but writes no JSON.
The Plan Agent has nothing to validate.

**DSE example:** Every Scope Agent skill feeds into `scope_session.json` (transient state).
`scope-formatting` alone writes the final `scope_artifact.json` — the immutable terminal artifact
that triggers the handoff to the Plan Agent.

---

## Principle 5 — Stateful Operations Are Scoped

**Rule:** Any operation that learns from data must be bounded to a declared subset.
The boundary is verified before the terminal artifact is written.

**Violation:** A feature engineering skill that fits a scaler on the full dataset before splitting.

**DSE example (Analyze Phase):** `cohort-extraction` must declare its population filter
criteria before any downstream metric computation. The cohort definition must be written to
the artifact before `metric-computation` runs — so the metric is always computable back to
the declared cohort.

---

## Principle 6 — Quality Bar Over Completeness

**Rule:** A skill halts loudly on blocking conditions. Every checkpoint has an explicit HALT
message. Partial output is worse than no output.

**Violation:** `intent-classification` catches a low-confidence result (< 0.3), logs a warning,
and continues. The scope is now built on a misclassified intent.

**DSE example:** `completeness-validation` must HALT if a required field for the analytical
pattern is missing AND the disambiguation question limit has been reached — not silently produce
an incomplete scope.

---

## Principle 7 — Canonical Reference Library

**Rule:** Any pattern used by two or more skills lives in `_shared-references/` as the single
source of truth. Each skill carries its own copy for portability.

**DSE `_shared-references/` contents:**
- `cgf-taxonomy.md` — consumed by: scope-agent, plan-agent, intent-classification
- `skill-registry.md` — consumed by: plan-agent, task-decomposition
- `playbook-registry.md` — consumed by: plan-agent, task-decomposition
- `data-type-registry.md` — consumed by: dependency-resolution, all skills
- `composition-rules.md` — consumed by: dependency-resolution

**Violation:** Two skills with slightly different versions of the CGF lifecycle stage list
because one was edited in place.

---

## Principle 8 — Self-Contained Portability

**Rule:** A skill directory must function when copied in isolation to `~/.claude/skills/`.
It must not depend on sibling skills, parent directory structure, or runtime imports from
other skills.

**DSE example:** `dependency-resolution` carries its own copy of `composition-rules.md` in
its `references/` directory. Even if the plugin's `_shared-references/` is unavailable, the
skill can still run. The `_shared-references/` copy is the canonical source; the local copy
is a derived snapshot.

---

## Section 4 — Scoping Decision Tree

Use this to determine if a new capability should be a standalone skill, a step, or a reference.

```
Q1: Does this procedure change the state of the system
    (transform data, write artifact, produce verifiable output)?
    NO  → It is a reference pattern or a QA check. Not a standalone skill.

Q2: Does the state change need a verifiable artifact so downstream steps
    can trust what happened?
    NO  → It belongs as a step inside an existing skill, not a standalone skill.

Q3: Is its "When to Activate" trigger meaningfully distinct from every
    existing skill's trigger in this domain?
    NO  → Add it as a new step to the closest existing skill.

Q4: Does it produce a stateful artifact (fitted model, trained weights,
    calibrated config, approved scope) that must be versioned and
    reproduced independently of other skills?
    YES → Almost certainly a standalone skill. Continue to Q5.

Q5: Adding it to an existing skill would push SKILL.md past 500 lines?
    YES → Standalone skill. Use the SKILL.md template.
    NO  → Evaluate as a subsection of the nearest existing skill first.
```

**What belongs in `_shared-references/`:** Any pattern called identically by ≥2 skills,
producing no terminal artifact. Examples: upstream validation logic, CGF taxonomy lookups,
shared glossary entries.
