---
name: engagement-decay-analysis
description: >
  Tracks engagement score trajectories over time to identify decay inflection points and
  pre-decay behavioral signatures, producing decay_profile.json with critical inflection
  weeks and pre-decay behaviors. Activate after maturity-state-classification when scope
  involves understanding engagement decline patterns; takes cohort + feature_set +
  maturity_classification.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; provides customer_id_ref and observation_window"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref for engagement signal computation"
  - type: maturity_classification
    description: "Lifecycle states from maturity-state-classification; trajectory_annotation identifies declining customers"
outputs:
  - type: decay_profile
    description: "Engagement decay inflection points, pre-decay behavioral signatures, and per-customer decay trajectories"
can_follow: [maturity-state-classification, feature-engineering]
can_precede: [leading-indicator-development, finding-assembly]
supports_loop: false
exit_conditions:
  - "decay_profile.json written with inflection points and pre-decay behaviors identified"
---

## Overview

Maturity-state-classification identifies *who is declining*. Engagement-decay-analysis identifies *when and how engagement declines* — the temporal pattern of disengagement that precedes churn. By tracking engagement scores week-over-week, this skill pinpoints inflection weeks where decay accelerates and identifies the behavioral signatures visible before decay begins.

These pre-decay behaviors are the inputs that `leading-indicator-development` uses to build early warning signals.

**What this skill produces:** `decay_profile.json` with `decay_inflection_points` array, `pre_decay_behaviors` list, and a reference to per-customer decay trajectory scores.

---

## When to Activate

- Scope involves engagement decline, churn prevention, or early warning signals
- `maturity_classification.json` shows customers in "declining" trajectory
- User requests "engagement decay analysis" or "pre-churn behavior patterns"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `maturity_classification.json` exists with `schema_version == "1.0"`
- [ ] `feature_set.json` `data_ref` contains >= 4 distinct time periods for engagement metrics

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: scipy>=1.10 (change-point detection); numpy>=1.24 (time series); pandas>=2.0
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `scoring_method` | `composite` / `single_metric` | `composite`: multi-signal engagement score (visits + purchases + interactions); `single_metric`: one engagement metric only |
| `decay_detection` | `threshold_based` / `trend_based` | `threshold`: below X for Y weeks = decaying; `trend`: slope of engagement score over sliding window |
| `temporal_depth` | `short` (13w) / `long` (52w) | Observation window for decay pattern detection |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

Classify variance dimensions. Validate all upstream artifacts.

```
load cohort.json
  IF not found: HALT: "Upstream validation failed: cohort.json not found."
  assert schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: cohort.json -- schema_version mismatch."
  assert population_size > 0
    IF not: HALT: "Upstream validation failed: cohort.json -- population_size=0."

load feature_set.json
  IF not found: HALT: "Upstream validation failed: feature_set.json not found."
  assert schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: feature_set.json -- schema_version mismatch."
  assert data_ref is not null
    IF not: HALT: "Upstream validation failed: feature_set.json -- data_ref missing."

load maturity_classification.json
  IF not found: HALT: "Upstream validation failed: maturity_classification.json not found."
  assert schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: maturity_classification.json -- schema_version mismatch."

-- Validate temporal depth
Execute: SELECT COUNT(DISTINCT time_period) AS n_periods FROM {data_ref}
IF n_periods < 4:
  HALT: "Insufficient temporal depth: {n_periods} periods found, minimum 4 required for decay analysis."
```

### Step 1 — Compute Engagement Scores

Build weekly (or daily) engagement scores for each customer using the scoring method.
```
-- Check for all-null engagement
IF all engagement signal columns are NULL across all rows:
  HALT: "All engagement signals are NULL -- cannot compute decay scores."

IF scoring_method == "composite":
  engagement_score = weighted_sum(visit_frequency, purchase_recency, interaction_depth)
ELIF scoring_method == "single_metric":
  engagement_score = single engagement metric from feature_set
```

### Step 2 — Detect Decay Inflection Points

```
FOR each week in observation window:
  avg_score = mean engagement score across all customers at that week
  pct_decaying = proportion of customers showing week-over-week decline
  IF week-over-week decline in avg_score > threshold OR pct_decaying > 0.3:
    is_critical_inflection = true
  decay_inflection_points.append({week, avg_score, pct_decaying, is_critical_inflection})
```

### Step 3 — Identify Pre-Decay Behaviors

```
-- Compare behavior patterns in weeks preceding inflection vs stable periods
pre_decay_customers = customers showing decay starting at inflection weeks
stable_customers = customers not showing decay

FOR each feature in feature_set:
  diff = mean(feature, pre_decay) - mean(feature, stable)
  IF |diff| > threshold: pre_decay_behaviors.append(feature)
```

### Step 4 — Write Terminal Artifact

Write decay_profile.json with inflection points, pre-decay behaviors, and trajectory reference.

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "engagement-decay-analysis",
  "timestamp": "2026-04-10T16:45:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "non_engagement_threshold_weeks": 13,
  "scoring_grain": "week",
  "cohort_size": 6148,
  "decay_inflection_points": [
    {"week": 4, "avg_engagement_score": 0.72, "pct_showing_decay": 0.18, "is_critical_inflection": false},
    {"week": 8, "avg_engagement_score": 0.54, "pct_showing_decay": 0.34, "is_critical_inflection": true},
    {"week": 13, "avg_engagement_score": 0.31, "pct_showing_decay": 0.52, "is_critical_inflection": true}
  ],
  "pre_decay_behaviors": ["reduced_visit_frequency", "narrowing_category_breadth", "declining_basket_size"],
  "customer_decay_trajectories": "path/to/individual_scores"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | cohort.population_size == 0 | HALT Step 0 |
| Single record | population_size == 1 | WARN |
| All-null engagement | engagement signals entirely NULL | HALT Step 1: "All engagement signals are NULL -- cannot compute decay scores." |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| No decay detected | all customers stable or improving | WARN: "No engagement decay detected — cohort is stable." |
| Insufficient temporal periods | n_periods < 4 | HALT Step 0: "Insufficient temporal depth for decay analysis." |

---

## Postconditions

- [ ] `decay_profile.json` exists with all 5 universal envelope fields
- [ ] `decay_inflection_points` has ≥1 entry (even if none are critical)
- [ ] `pre_decay_behaviors` list is populated (may be empty if no discriminating behaviors found)

---

## Quality Bar

- [ ] `decay_profile.json` validates against terminal artifact spec
- [ ] Inflection points are ordered chronologically
- [ ] Downstream `leading-indicator-development` can validate the artifact

---

## Scope Boundary

This skill does NOT:
- Classify lifecycle states → handled by `maturity-state-classification`
- Build predictive indicators → handled by `leading-indicator-development`
- Compute aggregate metrics → handled by `metric-computation`
- Analyze retention curves → handled by `retention-curve-analysis`

---

## Downstream

1. **`leading-indicator-development`** — reads `pre_decay_behaviors` as candidate leading indicators
2. **`finding-assembly`** — includes decay inflection findings in assembled evidence
