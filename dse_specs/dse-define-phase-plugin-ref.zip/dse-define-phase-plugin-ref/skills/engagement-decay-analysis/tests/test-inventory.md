# Test Inventory: engagement-decay-analysis

Skill under test: `.claude/skills/engagement-decay-analysis/SKILL.md`
Generated: 2026-04-10

---

## Category A — Happy Path

| ID | Test Name | Variance Config | Input | Expected Outcome |
|---|---|---|---|---|
| A1 | Composite scoring, threshold decay, short window | `scoring_method=composite`, `decay_detection=threshold_based`, `temporal_depth=short (13w)` | Valid cohort (N=6148), valid feature_set, valid maturity_classification, 13 weeks of weekly engagement data | `decay_profile.json` written with all 5 envelope fields, `decay_inflection_points` array with >=1 entry, `pre_decay_behaviors` list populated |
| A2 | Single metric scoring, trend decay, long window | `scoring_method=single_metric`, `decay_detection=trend_based`, `temporal_depth=long (52w)` | Valid cohort (N=3000), valid feature_set, valid maturity_classification, 52 weeks of weekly engagement data | `decay_profile.json` written, inflection points detected via slope-based method, `pre_decay_behaviors` populated |
| A3 | Composite scoring, trend decay, short window | `scoring_method=composite`, `decay_detection=trend_based`, `temporal_depth=short (13w)` | Valid cohort (N=1500), valid upstream artifacts, 13 weeks of data | `decay_profile.json` with trend-based inflection points over short window |

---

## Category B — Variance Coverage

Each variance dimension requires >=2 tested values. 3 dimensions x 2 values each = 6 minimum tests.

| ID | Dimension | Value | Config | Expected Behavior Difference |
|---|---|---|---|---|
| B1 | `scoring_method` | `composite` | composite + threshold_based + short | Engagement score = weighted_sum(visit_frequency, purchase_recency, interaction_depth) |
| B2 | `scoring_method` | `single_metric` | single_metric + threshold_based + short | Engagement score = single metric from feature_set |
| B3 | `decay_detection` | `threshold_based` | composite + threshold_based + short | Decay = below X for Y weeks |
| B4 | `decay_detection` | `trend_based` | composite + trend_based + short | Decay = negative slope over sliding window |
| B5 | `temporal_depth` | `short` (13w) | composite + threshold_based + short | 13-week observation window |
| B6 | `temporal_depth` | `long` (52w) | composite + threshold_based + long | 52-week observation window |

---

## Category C — Precondition Violations

Category C tests PASS only if the skill HALTs (refuses to proceed).

| ID | Violated Precondition | Input Condition | Expected Behavior |
|---|---|---|---|
| C1 | `cohort.json` missing | No cohort.json provided | HALT at Step 0: upstream validation failure |
| C2 | `cohort.json` wrong schema_version | `schema_version = "2.0"` | HALT at Step 0: "Schema mismatch" |
| C3 | `cohort.json` population_size == 0 | Empty cohort | HALT at Step 0: "Empty source" |
| C4 | `feature_set.json` missing | No feature_set.json provided | HALT at Step 0: upstream validation failure |
| C5 | `feature_set.json` null data_ref | `data_ref = null` | HALT at Step 0: precondition violation |
| C6 | `feature_set.json` wrong schema_version | `schema_version = "0.5"` | HALT at Step 0: "Schema mismatch" |
| C7 | `maturity_classification.json` missing | No maturity_classification.json provided | HALT at Step 0: upstream validation failure |
| C8 | `maturity_classification.json` wrong schema_version | `schema_version = "3.0"` | HALT at Step 0: "Schema mismatch" |
| C9 | No temporal engagement data | Upstream data has no time-series engagement signals | HALT: temporal data unavailable |

---

## Category D — Edge Cases

| ID | Edge Case (from spec) | Input Condition | Expected Behavior |
|---|---|---|---|
| D1 | Empty source | `cohort.population_size == 0` | HALT Step 0 |
| D2 | Single record | `population_size == 1` | WARN — proceed with caveat |
| D3 | All-null engagement | All engagement signals are NULL | HALT |
| D4 | Schema mismatch | `schema_version != "1.0"` on any upstream artifact | HALT Step 0 |
| D5 | No decay detected | All customers stable or improving | WARN: "No engagement decay detected -- cohort is stable." Output still valid with empty/minimal inflection points |
| D6 | Insufficient temporal depth | <4 weeks of data available | HALT: "Insufficient temporal depth for decay detection." |

---

## Coverage Matrix

| Variance Dimension | Values Tested | Minimum Required | Status |
|---|---|---|---|
| `scoring_method` | composite, single_metric | 2 | COVERED |
| `decay_detection` | threshold_based, trend_based | 2 | COVERED |
| `temporal_depth` | short (13w), long (52w) | 2 | COVERED |

| Test Category | Count | Purpose |
|---|---|---|
| A — Happy Path | 3 | Confirm end-to-end execution produces valid terminal artifact |
| B — Variance Coverage | 6 | Confirm each dimension value produces distinct, valid behavior |
| C — Precondition Violations | 9 | Confirm HALT fires on every invalid input combination |
| D — Edge Cases | 6 | Confirm spec-declared edge cases are handled correctly |
| **Total** | **24** | |
