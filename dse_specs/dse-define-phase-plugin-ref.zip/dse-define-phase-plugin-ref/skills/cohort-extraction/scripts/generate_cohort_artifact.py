#!/usr/bin/env python3
"""
generate_cohort_artifact.py — Stub script for cohort-extraction skill.

Applies scope criteria as SQL WHERE predicates against a quality-validated
warehouse dataset to extract a labeled cohort.

This script implements the standalone CLI interface for cohort-extraction.
No cross-skill imports. Run with --dry-run to validate inputs without
executing warehouse queries.
"""

import argparse
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(
        description="Extract a labeled cohort from a quality-validated dataset using scope criteria.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_cohort_artifact.py \\
    --scope-artifact scope_artifact.json \\
    --raw-dataset raw_dataset.json \\
    --quality-report quality_report.json \\
    --output cohort.json

  python generate_cohort_artifact.py \\
    --scope-artifact scope_artifact.json \\
    --remediated-dataset remediated_dataset.json \\
    --quality-report quality_report.json \\
    --output cohort.json \\
    --dry-run
        """,
    )
    parser.add_argument("--scope-artifact", required=True, help="Path to scope_artifact.json")
    parser.add_argument("--raw-dataset", default=None, help="Path to raw_dataset.json (use if no remediated)")
    parser.add_argument("--remediated-dataset", default=None, help="Path to remediated_dataset.json (takes precedence)")
    parser.add_argument("--quality-report", required=True, help="Path to quality_report.json")
    parser.add_argument("--output", default="cohort.json", help="Output path for cohort artifact (default: cohort.json)")
    parser.add_argument("--override-quality-gate", action="store_true", help="Analyst override: allow extraction even if quality_report verdict is FAIL")
    parser.add_argument("--dry-run", action="store_true", help="Validate inputs and translate criteria without executing warehouse query")
    return parser.parse_args()


def load_json(path: str, artifact_name: str) -> dict:
    p = Path(path)
    if not p.exists():
        print(f"HALT: {artifact_name} not found at '{path}'", file=sys.stderr)
        sys.exit(1)
    with open(p) as f:
        return json.load(f)


def validate_schema_version(artifact: dict, name: str) -> None:
    sv = artifact.get("schema_version")
    if not isinstance(sv, str):
        print(f"HALT: {name} — schema_version is {type(sv).__name__}, expected string '1.0'", file=sys.stderr)
        sys.exit(1)
    if sv != "1.0":
        print(f"HALT: {name} — schema_version is '{sv}', expected '1.0'", file=sys.stderr)
        sys.exit(1)


def translate_criterion(criterion: dict) -> str | None:
    """Translate a scope criterion dict to a SQL WHERE predicate string."""
    field = criterion.get("field")
    op = criterion.get("operator")
    value = criterion.get("value")

    op_map = {
        "==": f"{field} = '{value}'",
        "!=": f"{field} != '{value}'",
        ">": f"{field} > {value}",
        ">=": f"{field} >= {value}",
        "<": f"{field} < {value}",
        "<=": f"{field} <= {value}",
        "IS NULL": f"{field} IS NULL",
        "IS NOT NULL": f"{field} IS NOT NULL",
    }

    if op in ["IN", "NOT IN"]:
        values_str = ", ".join(f"'{v}'" for v in value) if isinstance(value[0], str) else ", ".join(str(v) for v in value)
        return f"{field} {op} ({values_str})"

    if op == "BETWEEN":
        return f"{field} BETWEEN {value[0]} AND {value[1]}"

    if op in op_map:
        return op_map[op]

    print(f"WARN: Unrecognized operator '{op}' for criterion on '{field}' — skipping", file=sys.stderr)
    return None


def main():
    args = parse_args()

    # Load artifacts
    scope = load_json(args.scope_artifact, "scope_artifact.json")
    quality_report = load_json(args.quality_report, "quality_report.json")

    # Determine source dataset (remediated takes precedence)
    if args.remediated_dataset:
        source = load_json(args.remediated_dataset, "remediated_dataset.json")
        source_type = "remediated"
    elif args.raw_dataset:
        source = load_json(args.raw_dataset, "raw_dataset.json")
        source_type = "raw"
    else:
        print("HALT: Must provide --raw-dataset or --remediated-dataset", file=sys.stderr)
        sys.exit(1)

    # Validate schema versions
    validate_schema_version(scope, "scope_artifact.json")
    validate_schema_version(quality_report, "quality_report.json")
    validate_schema_version(source, f"{source_type}_dataset.json")

    # Check data_ref
    data_ref = source.get("data_ref")
    if not data_ref:
        print(f"HALT: {source_type}_dataset.json — data_ref is missing", file=sys.stderr)
        sys.exit(1)

    # Quality gate check
    verdict = quality_report.get("verdict")
    if verdict == "FAIL" and not args.override_quality_gate:
        print(
            "HALT: quality_report.verdict is FAIL — cannot extract cohort from unvalidated dataset. "
            "Run data-remediation then re-run data-quality-assessment, or use --override-quality-gate.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Translate criteria to SQL predicates
    criteria = scope.get("population", {}).get("criteria", [])
    predicate_list = []
    criteria_applied = []
    criteria_skipped = []

    if not criteria:
        print("WARN: scope_artifact.population.criteria is empty — extracting full population", file=sys.stderr)
    else:
        for c in criteria:
            predicate = translate_criterion(c)
            if predicate:
                predicate_list.append(predicate)
                criteria_applied.append({**c, "predicate": predicate})
            else:
                criteria_skipped.append(c)

    where_clause = " AND ".join(predicate_list) if predicate_list else ""
    new_data_ref = f"COHORT_{data_ref}"
    analytical_pattern = scope.get("analytical_pattern", "profile")

    print(f"Running cohort-extraction | source={source_type} | pattern={analytical_pattern}")
    print(f"Criteria translated: {len(predicate_list)} predicates, {len(criteria_skipped)} skipped")
    if where_clause:
        print(f"WHERE clause: {where_clause}")

    if args.dry_run:
        print("\n[DRY RUN] Extraction SQL preview:")
        print(f"  CREATE TEMP TABLE {new_data_ref} AS")
        print(f"  SELECT * FROM {data_ref}")
        if where_clause:
            print(f"  WHERE {where_clause}")
        print("\nDry run complete — no warehouse queries executed.")
    else:
        # TODO: Execute warehouse query
        # conn = get_warehouse_connection(source.get("source_platform"))
        # conn.execute(f"CREATE TEMP TABLE {new_data_ref} AS SELECT * FROM {data_ref} {'WHERE ' + where_clause if where_clause else ''}")
        # population_count = conn.execute(f"SELECT COUNT(*) FROM {new_data_ref}").fetchone()[0]
        population_count = 0  # Stub — replace with actual warehouse count
        print(f"TODO: Execute extraction and query population_count from {new_data_ref}")

    # Write artifact
    artifact = {
        "schema_version": "1.0",
        "skill_name": "cohort-extraction",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "record_count": 0,  # Stub — replace with actual population_count
        "artifact_id": str(uuid.uuid4()),
        "source_dataset_type": source_type,
        "source_dataset_artifact_id": source.get("artifact_id"),
        "scope_artifact_id": scope.get("artifact_id"),
        "quality_report_artifact_id": quality_report.get("artifact_id"),
        "analytical_pattern": analytical_pattern,
        "data_ref": new_data_ref,
        "population_count": 0,  # Stub — replace with actual count
        "criteria_applied": criteria_applied,
        "criteria_skipped": criteria_skipped,
        "population_size_outcome": "stub",
        "scope_coverage_rate": None,
    }

    if not args.dry_run:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            json.dump(artifact, f, indent=2)
        print(f"cohort.json written to {output_path}")


if __name__ == "__main__":
    main()
