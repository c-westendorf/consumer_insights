---
name: cohort-extraction
description: >
  Applies population criteria from scope_artifact as SQL WHERE predicates against a
  quality-validated dataset to produce a labeled cohort — the primary filter determining
  who is in the analysis. Activate after data-quality-assessment PASS or data-remediation;
  takes raw_dataset or remediated_dataset + scope_artifact + quality_report; outputs
  cohort.json with data_ref pointing to a filtered warehouse temp table and population_count.
inputs:
  - type: raw_dataset
    description: "Source data artifact from data-retrieval; used as extraction source if no remediated_dataset is present"
  - type: remediated_dataset
    description: "Quality-repaired data artifact from data-remediation; takes precedence over raw_dataset when present"
  - type: scope_artifact
    description: "Approved scope definition — population.criteria list drives the SQL WHERE predicate construction"
  - type: quality_report
    description: "Quality gate output from data-quality-assessment; verdict must be PASS or quality gate skipped via analyst override"
outputs:
  - type: cohort
    description: "Filtered customer population artifact with data_ref pointing to warehouse temp table, population_count, and full criteria trace"
can_follow: [data-quality-assessment, data-remediation]
can_precede: [population-sampling, feature-engineering, metric-computation, exploratory-analysis]
supports_loop: false
exit_conditions:
  - "cohort.json written; population_count >= 50; data_ref points to accessible warehouse temp table"
  - "all population_criteria translated to SQL predicates; criteria_applied and criteria_skipped lists complete"
  - "cohort too small — population_count < 50; artifact written with WARN; analyst must approve before proceeding"
---

## Overview

Data-quality-assessment confirms the data is fit for analysis. Cohort-extraction determines
*who* gets analyzed. Scope criteria that exist only as natural language in the scope_artifact
must be converted into executable SQL predicates — this translation is the skill's core job.
Without this step, downstream skills like population-sampling and feature-engineering would
operate on the full extraction rather than the target population, producing invalid cohort
metrics and misleading segmentation.

The skill also acts as a quality gate: it refuses to extract from a dataset whose quality
verdict is FAIL unless the analyst has explicitly overridden. This prevents scope contamination
— if 42% of revenue values are null and uncorrected, extracting a revenue-filtered cohort
produces a biased population.

**What this skill produces:** `cohort.json` with a new `data_ref` pointing to a filtered
warehouse temp table (`COHORT_{source_data_ref}`), population_count, full list of criteria
applied, and lineage tracing back to the source dataset and scope_artifact.

---

## When to Activate

- `quality_report.json` exists with `verdict == "PASS"` — dataset is cleared for cohort extraction
- `remediated_dataset.json` exists (overrides raw_dataset; data-remediation has been applied)
- A plan task node with `task_type: "cohort_extraction"` is the next unexecuted task
- Scope artifact defines at least one population criterion (`scope_artifact.population.criteria` non-empty)
- User explicitly requests "extract the cohort", "apply the population filter", or "get the customers who..."
- Post-remediation re-assessment passed and pipeline resumes at cohort-extraction

---

## Preconditions

What must be true before this skill begins:
- [ ] At least one of `raw_dataset.json` or `remediated_dataset.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"` and `population` field present
- [ ] `quality_report.json` exists with `schema_version == "1.0"` and `verdict` field present
- [ ] `quality_report.verdict == "PASS"` OR analyst has explicitly set `override_quality_gate: true` in the plan node
- [ ] All column names referenced in `scope_artifact.population.criteria` exist in the source dataset's column manifest

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: pandas>=2.0 (small volume only)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; heavy lifting is warehouse SQL
- **Memory:** <100 MB (artifact processing only; no data loaded locally for large volumes)
- **Upstream Artifacts:** `scope_artifact.json` (population.criteria), `quality_report.json` (verdict), `raw_dataset.json` or `remediated_dataset.json` (data_ref, column manifest)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `source_type` | `raw` / `remediated` | `remediated`: use remediated_dataset.data_ref as source; `raw`: use raw_dataset.data_ref; if both present, remediated takes precedence |
| `analytical_pattern` | `profile` / `compare` | `compare`: extracts two cohorts (base + comparison populations) per scope_artifact.comparison definition; both data_refs written to artifact |
| `criteria_complexity` | `simple` / `complex` | `simple` (≤3 criteria, equality/range only): single WHERE clause; `complex` (4+ criteria or date arithmetic or cross-column logic): multi-step CTE construction |
| `population_size_outcome` | `viable` / `undersized` / `empty` | `viable` (≥50 records): proceed; `undersized` (<50): WARN + write artifact; `empty` (0 records): HALT |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify source_type: IF remediated_dataset.json exists → "remediated"; ELSE → "raw"
classify analytical_pattern: read scope_artifact.analytical_pattern
  IF == "compare": → "compare"; ELSE → "profile"
log: "Running cohort-extraction | source={value} | pattern={value}"
```

**Upstream Validation:**
```
IF source_type == "remediated":
  load remediated_dataset.json
  assert type(schema_version) is string AND schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: remediated_dataset.json — schema_version
    mismatch. Re-run data-remediation."
  assert data_ref is not null
    IF null: HALT: "Upstream validation failed: remediated_dataset.json — data_ref missing."
  source_artifact = remediated_dataset
ELSE:
  load raw_dataset.json
  assert type(schema_version) is string AND schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: raw_dataset.json — schema_version mismatch.
    Re-run data-retrieval."
  assert data_ref is not null
    IF null: HALT: "Upstream validation failed: raw_dataset.json — data_ref missing."
  source_artifact = raw_dataset

assert source_artifact.row_count > 0
  IF row_count == 0:
    HALT: "Source dataset is empty (row_count=0) — re-run data-retrieval to verify
    extraction produced data. Do not proceed with empty source."

load scope_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."
assert population field is present
  IF missing: HALT: "Upstream validation failed: scope_artifact.json — population field absent.
  Re-run scope-formatting."

load quality_report.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: quality_report.json — schema_version mismatch."
assert quality_report.verdict == "PASS" OR plan_node.override_quality_gate == true
  IF verdict == "FAIL" AND no override:
    HALT: "Quality gate FAIL — cannot extract cohort from unvalidated dataset.
    Run data-remediation to resolve blocking issues, then re-run data-quality-assessment."
```

---

### Step 1 — Translate Scope Criteria to SQL Predicates

**Goal:** Convert every entry in `scope_artifact.population.criteria` into an executable
SQL WHERE predicate; classify complexity.

**Pre-step assertion:** scope_artifact.population.criteria is a list (may be empty).

**Actions:**
```
criteria = scope_artifact.population.criteria
predicate_list = []
criteria_skipped = []

IF criteria is empty:
  WARN: "scope_artifact.population.criteria is empty — no filters applied.
  Cohort will be the full source population."
  criteria_complexity = "simple"
  SKIP to Step 2 (full population extraction)

FOR each criterion in criteria:
  column = criterion.field
  op = criterion.operator  # ==, !=, >, >=, <, <=, IN, NOT IN, BETWEEN, IS NULL, IS NOT NULL
  value = criterion.value

  Validate column exists in source_artifact.columns:
    IF not found: HALT: "Criterion references unknown column '{column}' — not in source
    dataset column manifest. Review scope criteria or re-run schema-profiling."

  Validate type compatibility:
    IF column type is numeric AND value is string (non-castable):
      HALT: "Type mismatch: criterion '{column} {op} {value}' — column is {type},
      value cannot be cast. Correct scope_artifact criteria."

  Translate to SQL predicate:
    IF op == "==": "{column} = '{value}'"  (or without quotes for numeric)
    IF op in [">", ">=", "<", "<="]: "{column} {op} {value}"
    IF op == "IN": "{column} IN ({comma-joined values})"
    IF op == "BETWEEN": "{column} BETWEEN {value[0]} AND {value[1]}"
    IF op == "IS NULL": "{column} IS NULL"
    IF op == "IS NOT NULL": "{column} IS NOT NULL"
    IF op unrecognized: WARN + criteria_skipped.append(criterion); CONTINUE

  predicate_list.append(translated predicate)

Classify complexity:
  IF len(criteria) <= 3 AND no date arithmetic predicates → criteria_complexity = "simple"
  ELSE → criteria_complexity = "complex"

Log: "Criteria translated: {N} predicates, {M} skipped | complexity={criteria_complexity}"
```

**Checkpoint:**
> - [ ] PASS: all criteria translated to SQL predicates; predicate_list non-empty OR empty with WARN
> - [ ] HALT: unknown column or type mismatch in any criterion
> - [ ] WARN: unrecognized operator, or empty criteria list

---

### Step 2 — Execute Extraction Query

**Goal:** Create a warehouse temp table containing only records that satisfy all criteria;
for compare pattern, create both base and comparison temp tables.

**Pre-step assertion:** predicate_list ready; source_artifact.data_ref accessible.

**Branch on `analytical_pattern`:**

**IF `profile` (single cohort):**
```
base_ref = source_artifact.data_ref
new_data_ref = "COHORT_{base_ref}"
WHERE_clause = " AND ".join(predicate_list)  -- empty if no criteria → no WHERE

Execute:
  CREATE TEMP TABLE {new_data_ref} AS
  SELECT * FROM {base_ref}
  [WHERE {WHERE_clause}]

Log: "Extracted cohort | source={base_ref} | filters={N} | new_ref={new_data_ref}"
```

**IF `compare` (two cohorts):**
```
base_criteria  = scope_artifact.population.criteria
comp_criteria  = scope_artifact.comparison.population.criteria (if defined)

Build WHERE_base from base_criteria predicates
Build WHERE_comp from comp_criteria predicates (if defined; WARN if absent)

base_ref = "COHORT_{source_artifact.data_ref}_BASE"
comp_ref = "COHORT_{source_artifact.data_ref}_COMP"

Execute:
  CREATE TEMP TABLE {base_ref} AS SELECT * FROM {source_artifact.data_ref} WHERE {WHERE_base}
  CREATE TEMP TABLE {comp_ref} AS SELECT * FROM {source_artifact.data_ref} WHERE {WHERE_comp}

Log: "Extracted compare cohorts | base_ref={base_ref} | comp_ref={comp_ref}"
```

**Checkpoint:**
> - [ ] PASS: temp table(s) created; row counts logged
> - [ ] HALT: warehouse error (table not found, connection dropped) → "Temp table
>   {source_ref} not found. Restart warehouse session and re-run data-retrieval."
> - [ ] WARN: predicate_list empty — full population extracted

---

### Step 3 — Validate Cohort Size

**Goal:** Confirm the extracted cohort is large enough for the intended analysis.

**Pre-step assertion:** Temp table(s) created in Step 2.

**Actions:**
```
SELECT COUNT(*) FROM {new_data_ref} → population_count

IF analytical_pattern == "compare":
  SELECT COUNT(*) FROM {base_ref} → base_count
  SELECT COUNT(*) FROM {comp_ref} → comp_count
  population_count = base_count  (base cohort drives the viability check)
  WARN if comp_count < 50: "Comparison cohort has {comp_count} records — underpowered
  for statistical comparison. Consider relaxing comparison criteria."

Classify population_size_outcome:
  IF population_count == 0: "empty"
  IF 0 < population_count < 50: "undersized"
  IF population_count >= 50: "viable"

IF population_size_outcome == "empty":
  HALT: "Cohort extraction produced 0 records — all source rows were filtered out.
  Review scope criteria: {predicate_list}. Criteria may be too restrictive."

IF population_size_outcome == "undersized":
  WARN: "Cohort has only {population_count} records — below minimum of 50 for reliable
  analysis. Proceeding with artifact write; analyst must approve before running
  population-sampling or feature-engineering."
```

**Checkpoint:**
> - [ ] PASS: population_count >= 50; proceed to Step 4
> - [ ] WARN: 0 < population_count < 50 — write artifact, flag for analyst
> - [ ] HALT: population_count == 0

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist cohort.json with full lineage and criteria trace.

**Pre-step assertion:** population_size_outcome is "viable" or "undersized" (not "empty").

**Actions:**
```
Generate artifact_id: UUID v4

Write cohort.json:
  IF analytical_pattern == "profile": data_ref = new_data_ref
  IF analytical_pattern == "compare": data_ref = {base: base_ref, comparison: comp_ref}

Log: "cohort.json written | population_count={population_count} |
data_ref={new_data_ref} | criteria_applied={len(predicate_list)} |
criteria_skipped={len(criteria_skipped)}"
```

**Checkpoint:**
> - [ ] PASS: cohort.json written; all 5 universal envelope fields present
> - [ ] HALT: write failure

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "cohort-extraction",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 47821,
  "artifact_id": "{uuid}",
  "source_dataset_type": "remediated",
  "source_dataset_artifact_id": "{remediated_dataset.artifact_id}",
  "scope_artifact_id": "{scope_artifact.artifact_id}",
  "quality_report_artifact_id": "{quality_report.artifact_id}",
  "analytical_pattern": "profile",
  "data_ref": "COHORT_REMEDIATED_DSE_EXTRACTION_rd001",
  "population_count": 47821,
  "criteria_applied": [
    {"field": "customer_lifecycle_stage", "operator": "==", "value": "reactivated", "predicate": "customer_lifecycle_stage = 'reactivated'"},
    {"field": "lapse_days_before_reactivation", "operator": ">", "value": 90, "predicate": "lapse_days_before_reactivation > 90"}
  ],
  "criteria_skipped": [],
  "population_size_outcome": "viable",
  "scope_coverage_rate": 0.565
}
```

**Write to:** `cohort.json` in the project directory.

**`record_count`** = `population_count` (rows in extracted cohort).

**`scope_coverage_rate`** = `population_count / source_artifact.row_count` — the proportion of
source records that matched scope criteria. Very low rates (<5%) may indicate overly restrictive
criteria; very high rates (>95%) may indicate criteria are not filtering meaningfully.

**Compare pattern `data_ref`:**
```json
"data_ref": {
  "base":       "COHORT_REMEDIATED_DSE_EXTRACTION_rd001_BASE",
  "comparison": "COHORT_REMEDIATED_DSE_EXTRACTION_rd001_COMP"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source dataset | source_artifact.row_count == 0 | HALT Step 0: "Source dataset is empty — re-run data-retrieval." |
| Single record in source | source_artifact.row_count == 1 | WARN Step 3: "Single-record source — criteria may produce empty cohort; statistical analysis unreliable." |
| Empty criteria list | scope_artifact.population.criteria == [] | WARN Step 1 + SKIP filtering — full population extracted; flag in artifact |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact mismatch message |
| Unknown column in criteria | criterion.field not in source columns | HALT Step 1: "Criterion references unknown column '{field}'" |
| Type mismatch in criteria | string value for numeric column (non-castable) | HALT Step 1: "Type mismatch: criterion '{field} {op} {value}'" |
| Zero-record cohort | population_count == 0 after extraction | HALT Step 3: "Cohort extraction produced 0 records — criteria too restrictive" |
| Compare pattern with no comparison definition | scope_artifact.comparison missing | WARN Step 2: "compare pattern but scope has no comparison population — extracting base cohort only; comp_ref omitted from artifact" |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `cohort.json` exists with all 5 universal envelope fields
- [ ] `data_ref` points to an accessible warehouse temp table (or base/comparison pair)
- [ ] `population_count >= 50` OR artifact includes WARN flag and `population_size_outcome == "undersized"`
- [ ] `criteria_applied` list contains one entry per successfully translated criterion
- [ ] `source_dataset_artifact_id`, `scope_artifact_id`, `quality_report_artifact_id` all set for lineage

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `cohort.json` written and validates against the terminal artifact spec
- [ ] `data_ref` temp table is queryable (downstream can SELECT COUNT(*) from it)
- [ ] `population_count >= 50` OR analyst explicitly approved undersized cohort
- [ ] Every criterion in `scope_artifact.population.criteria` appears in either `criteria_applied` or `criteria_skipped` — none silently dropped
- [ ] `scope_coverage_rate` logged and reasonable (analyst reviews if <5% or >95%)
- [ ] For compare pattern: both base and comparison data_refs populated
- [ ] `population-sampling` Step 0 can load `cohort.json` and read `data_ref`

---

## Scope Boundary

This skill does NOT:
- Assess data quality → handled by `data-quality-assessment` (verdict must be PASS before cohort-extraction runs)
- Repair data issues → handled by `data-remediation` (upstream of this skill)
- Select a statistical sample from the cohort → handled by `population-sampling` (consumes this skill's cohort)
- Define population criteria → handled by `scope-formatting` in the Define Phase (criteria come from scope_artifact, not computed here)
- Engineer features from the cohort → handled by `feature-engineering` (next group)
- Profile the schema of the source data → handled by `schema-profiling` (upstream)

---

## Downstream

Run after this skill completes:
1. **`population-sampling`** — takes `cohort.data_ref`; draws a stratified or random sample for analysis; requires `population_count >= 50`
2. **`feature-engineering`** — can run directly on `cohort.data_ref` if sampling is not required; consumes `criteria_applied` as context for feature selection
3. **`metric-computation`** — reads `cohort.data_ref`; computes scope-defined metric across the extracted population
4. **`exploratory-analysis`** — reads `cohort.data_ref`; explores distributions across the labeled cohort
