# skills/sampling/SKILL.md
---
name: cgf-population-sampling
description: Sample customers from a large population (100M+) for structured
  behavioral analysis across CGF decomposition dimensions. Pushes sampling
  logic to the data warehouse for efficiency. Supports pre-stratified,
  post-stratified, and random windowed sampling methods — configurable per
  plan node. Handles temporal observation windows (pre/post/matched relative
  to an anchor event), customer vintage and tenure stratification, and
  MECE partition validation. Produces a statistically powered sample set
  with full audit trail. Use when the plan requires a representative or
  powered sample before analysis, either at plan start or mid-plan when
  a new segmentation needs structured comparison.

# DSE-Compatible Declarations
inputs:
  - type: scope_artifact
    description: "Population definition, decomposition dimensions, metric targets,
                  timeframe, vintage/tenure constraints, treatment/event anchors"
  - type: profiled_dataset
    description: "Schema and quality profile of source tables"
  - type: connection_config
    description: "Data warehouse connection (Snowflake/BigQuery/Azure Synapse)"
  - type: plan_node_config
    description: "Sampling method, observation window direction and duration,
                  target effect size and power requirements"
outputs:
  - type: sample_set
    description: "Sampled population with partition assignments, temporal windows,
                  and per-entity observation anchors"
  - type: sampling_manifest
    description: "Full audit trail: method chosen, cell sizes, power achieved,
                  coverage validation, query cost, governance log, temporal
                  window specification, vintage distribution"
can_follow:
  - schema-profiling
  - data-quality-assessment
  - cohort-builder
  - segmentation-probe
can_precede:
  - feature-engineering
  - eda-comprehensive
  - behavioral-profiling
  - statistical-comparison
  - hypothesis-validation
  - engagement-state-classification
  - retention-stickiness-analysis
  - behavior-valuation
  - interval-analysis
supports_loop: false
exit_conditions:
  - type: sample_validated
    description: "All partition cells meet minimum power threshold"
  - type: sample_validated_with_warnings
    description: "Most cells powered; underpowered cells documented with caveats"
---

## Overview

At 100M+ active customers, the analytical challenge is efficiency and structure — not volume. This skill handles both by pushing sampling logic to the data warehouse via SQL and partitioning the sample across CGF decomposition dimensions to guarantee MECE coverage.

The skill also manages temporal observation windows. Many consumer insights questions are anchored to an event — a first purchase, a reactivation, a campaign exposure — and the analysis needs to observe behavior before, after, or across that event. This skill constructs per-customer temporal windows relative to the scope-defined anchor and pulls only the relevant observation period.

Every decision the skill makes is logged in the sampling manifest. The manifest is the governance artifact — it records what was sampled, how, why, what power was achieved, what cells were underpowered, and what the query cost was. Any principal can audit the sampling decisions from the manifest alone.

If this skill is skipped, downstream analysis either operates on the full population (wasteful at 100M) or on an ad-hoc sample that may miss entire customer segments, lack statistical power for comparison, or observe the wrong temporal window.

---

## When to Activate

- Plan node specifies a sampling task (beginning or mid-plan)
- Population exceeds 1M and full-population analysis is impractical
- Scope requires structured comparison across CGF decomposition dimensions
- Scope defines a treatment/event anchor with pre/post observation windows
- A mid-plan exploration discovers a segmentation needing powered comparison
- Stakeholder asks for analysis "across all customer types" or "by segment"
- Plan references MECE coverage, collective group analysis, or treatment effect

---

## Preconditions

- [ ] Connection to data warehouse is established and authenticated
- [ ] Source tables identified and schema profiled (profiled_dataset available)
- [ ] Data quality assessment is PASS or CONDITIONAL_PASS (not FAIL)
- [ ] Scope artifact defines population criteria
- [ ] Scope artifact defines at least one decomposition dimension
- [ ] Scope artifact defines timeframe (observation period)
- [ ] Plan node specifies sampling method (pre_stratified | post_stratified | random_windowed)
- [ ] If temporal windowing: scope defines anchor event and window direction
- [ ] Target metric defined for power calculation

On FAIL of any precondition → HALT with specific missing requirement.

---

## Prerequisites

### Library Dependencies

```
# Tier 1 — Core
pandas>=2.0
numpy>=1.23
scipy>=1.10

# Tier 2 — Skill-specific
sqlalchemy>=2.0
statsmodels>=0.14          # power analysis

# Tier 3 — Warehouse-specific (conditional)
snowflake-connector-python>=3.0    # when warehouse == snowflake
google-cloud-bigquery>=3.0         # when warehouse == bigquery
pyodbc>=5.0                        # when warehouse == azure_synapse
```

### Infrastructure Requirements

- **Compute:** CPU only
- **Memory:** 4 GB minimum (sample is pulled, not full population)
- **Network:** Access to data warehouse endpoint
- **Credentials:** Warehouse authentication configured

---

## Variance Surface

| Dimension | Values | Behavior Difference |
|-----------|--------|---------------------|
| Sampling method | pre_stratified, post_stratified, random_windowed | Query construction, validation sequence, and partition logic differ (see Step 2) |
| Warehouse type | snowflake, bigquery, azure_synapse | SQL dialect, native sampling functions, approximate count functions, and cost estimation differ |
| Plan position | beginning (full population), mid_plan (sub-population from upstream) | Source is base table vs. upstream cohort/segment; partition dimensions may be narrower mid-plan |
| Observation window | pre_event, post_event, matched_pre_post, none | Determines temporal SQL construction and whether paired customer records are produced |
| Vintage framing | calendar (e.g., "2024 customers"), tenure (e.g., "6-12 month customers"), none | Adds a temporal stratification dimension; calendar uses date ranges, tenure uses calculated durations |
| Decomposition complexity | single dimension, multi-dimensional cross (2-4 dims), high-dimensional (5+ dims) | Higher dimensionality → more cells → more sparse cells → more collapsing decisions |

---

## Workflow

### Step 0 — Validate Preconditions and Load Configuration

**Goal:** Load the scope, plan node config, and warehouse connection. Validate all preconditions. Initialize the governance log.

```python
import json
import datetime
from pathlib import Path

# ── Load scope ──
scope = json.load(open('scope_artifact.json'))
population_def = scope['definition']['population']
metric_def = scope['definition']['metric']
timeframe = scope['definition']['timeframe']
constraints = scope['definition'].get('constraints', [])

# ── Load plan node configuration ──
# This comes from the plan_artifact.json task node that invoked this skill
plan_node = json.load(open('plan_node_config.json'))
sampling_method = plan_node['sampling_method']     # pre_stratified | post_stratified | random_windowed
decomposition_dims = plan_node['decomposition_dimensions']
observation_window = plan_node.get('observation_window', None)  # see below
vintage_config = plan_node.get('vintage', None)     # see below
power_config = plan_node.get('power', {
    'target_effect_size': 0.05,   # minimum detectable difference
    'alpha': 0.05,
    'power': 0.80,
    'ci_width': None              # alternative: target confidence interval width
})

# ── Observation window schema ──
# observation_window: {
#   "anchor_event": "reactivation_date",      # column name in data
#   "direction": "pre_event | post_event | matched_pre_post",
#   "window_days": 90,                         # how far to look
#   "anchor_filter": {                         # optional: constrain which events
#     "field": "reactivation_channel",
#     "op": "in",
#     "value": ["email", "organic"]
#   }
# }

# ── Vintage schema ──
# vintage: {
#   "type": "calendar | tenure",
#   "calendar": { "field": "first_purchase_date", "periods": ["2023-H1", "2023-H2", "2024-H1"] },
#   "tenure":   { "field": "first_purchase_date", "buckets_months": [0,6,12,24,60,999] }
# }

# ── CGF governance validation ──
GOVERNED_DIMENSIONS = [
    'demographic', 'lifecycle_stage', 'customer_type',
    'engagement_maturity', 'weekly_engagement_classification',
    'value_decile', 'behavioral_pattern', 'temporal_trajectory',
    'value_trajectory', 'reactivation_history'
]

# ── Initialize governance log ──
governance_log = {
    'skill': 'cgf-population-sampling',
    'invoked_at': datetime.datetime.utcnow().isoformat(),
    'scope_id': scope.get('scope_id'),
    'sampling_method': sampling_method,
    'decomposition_dimensions': decomposition_dims,
    'observation_window': observation_window,
    'vintage_config': vintage_config,
    'power_config': power_config,
    'decisions': [],
    'warnings': [],
    'errors': []
}

# Log ungoverned dimensions (advisory, not blocking)
ungoverned = [d for d in decomposition_dims if d not in GOVERNED_DIMENSIONS]
if ungoverned:
    governance_log['warnings'].append({
        'type': 'ungoverned_dimensions',
        'dimensions': ungoverned,
        'note': 'These dimensions are not in the CGF governed set. '
                'They will be included but flagged for principal review.'
    })

# Validate minimum requirements
assert len(decomposition_dims) >= 1, "HALT: At least one decomposition dimension required"
assert sampling_method in ['pre_stratified', 'post_stratified', 'random_windowed'], \
    f"HALT: Unknown sampling method: {sampling_method}"
if observation_window:
    assert observation_window['direction'] in ['pre_event', 'post_event', 'matched_pre_post'], \
        f"HALT: Unknown window direction: {observation_window['direction']}"

print(f"Sampling method: {sampling_method}")
print(f"Decomposition: {decomposition_dims}")
print(f"Observation window: {observation_window['direction'] if observation_window else 'none'}")
print(f"Vintage: {vintage_config['type'] if vintage_config else 'none'}")
```

> **Checkpoint — Step 0**
> - [ ] Scope artifact loaded with population, metric, timeframe
> - [ ] Plan node config loaded with sampling method and dimensions
> - [ ] Decomposition dimensions present (minimum 1)
> - [ ] Observation window validated if present
> - [ ] Vintage config validated if present
> - [ ] Governance log initialized
> - [ ] Ungoverned dimensions flagged (warning, not HALT)
> - [ ] Warehouse connection verified
> - [ ] HALT if: no dimensions, invalid method, invalid window direction, no connection

---

### Step 1 — Census the Population

**Goal:** Count customers per partition cell across all decomposition dimensions without loading row-level data. Runs entirely in SQL.

**Why:** At 100M+ we cannot pull the full population to count it. The census query gives us the partition distribution so we can compute required sample sizes and detect sparse cells before pulling any data.

```python
def build_census_query(population_def, decomposition_dims, vintage_config,
                       observation_window, warehouse_type):
    """
    Generate a GROUP BY count query across all decomposition dimensions,
    including vintage bucketing and observation window anchoring.
    Pushes all logic to the warehouse.
    """

    # ── Population WHERE clause ──
    where_parts = []
    for c in population_def.get('criteria', []):
        if c['op'] == 'eq':
            where_parts.append(f"{c['field']} = '{c['value']}'")
        elif c['op'] == 'between':
            where_parts.append(f"{c['field']} BETWEEN '{c['value'][0]}' AND '{c['value'][1]}'")
        elif c['op'] == 'in':
            vals = ", ".join(f"'{v}'" for v in c['value'])
            where_parts.append(f"{c['field']} IN ({vals})")
    where_sql = " AND ".join(where_parts) if where_parts else "1=1"

    # ── Vintage as a computed column ──
    vintage_col = ""
    if vintage_config:
        if vintage_config['type'] == 'calendar':
            # Calendar vintage: bucket by date field into named periods
            field = vintage_config['calendar']['field']
            cases = []
            for period in vintage_config['calendar']['periods']:
                # Expect period format: "2024-H1", "2024-Q3", "2024", etc.
                # The scope should define the mapping; here we use year extraction
                cases.append(f"WHEN {field} LIKE '{period}%' THEN '{period}'")
            vintage_col = f", CASE {' '.join(cases)} ELSE 'other' END AS vintage_bucket"
        elif vintage_config['type'] == 'tenure':
            # Tenure vintage: months since first event
            field = vintage_config['tenure']['field']
            buckets = vintage_config['tenure']['buckets_months']
            cases = []
            for i in range(len(buckets) - 1):
                lo, hi = buckets[i], buckets[i+1]
                label = f"{lo}-{hi}m"
                cases.append(
                    f"WHEN DATEDIFF('month', {field}, CURRENT_DATE) >= {lo} "
                    f"AND DATEDIFF('month', {field}, CURRENT_DATE) < {hi} THEN '{label}'"
                )
            vintage_col = f", CASE {' '.join(cases)} ELSE 'other' END AS vintage_bucket"

    # ── Observation window filter ──
    window_filter = ""
    if observation_window:
        anchor = observation_window['anchor_event']
        days = observation_window['window_days']
        direction = observation_window['direction']
        if direction == 'pre_event':
            window_filter = f"AND {anchor} IS NOT NULL"
            # We don't filter the observation period here — we filter
            # behavioral data in the sample pull (Step 3). Census counts
            # customers who HAVE the anchor event.
        elif direction == 'post_event':
            window_filter = f"AND {anchor} IS NOT NULL"
        elif direction == 'matched_pre_post':
            # Need customers with enough history on both sides
            window_filter = (
                f"AND {anchor} IS NOT NULL "
                f"AND DATEDIFF('day', {anchor}, CURRENT_DATE) >= {days}"
            )
        # Apply anchor filter if specified
        af = observation_window.get('anchor_filter')
        if af:
            if af['op'] == 'in':
                vals = ", ".join(f"'{v}'" for v in af['value'])
                window_filter += f" AND {af['field']} IN ({vals})"

    # ── Build GROUP BY ──
    dim_cols = ", ".join(decomposition_dims)
    if vintage_config:
        dim_cols += ", vintage_bucket"

    # ── Approximate counts for efficiency ──
    count_fn = "COUNT(DISTINCT customer_id)"
    if warehouse_type in ('snowflake', 'bigquery'):
        count_fn = "APPROX_COUNT_DISTINCT(customer_id)"

    query = f"""
    SELECT
        {dim_cols},
        {count_fn} AS cell_count
    FROM customer_base
    WHERE {where_sql}
    {window_filter}
    GROUP BY {dim_cols}
    ORDER BY cell_count DESC
    """

    return query


# Execute census
census_query = build_census_query(
    population_def, decomposition_dims, vintage_config,
    observation_window, warehouse_type
)
governance_log['decisions'].append({
    'step': 'census',
    'action': 'Executed population census query',
    'query_hash': hash(census_query),  # don't log full query — may contain PII filters
    'warehouse': warehouse_type,
    'used_approximate_counts': warehouse_type in ('snowflake', 'bigquery')
})

# census_df = execute_query(connection, census_query)
# total_population = census_df['cell_count'].sum()
# n_cells = len(census_df)

print(f"Population: {total_population:,} customers across {n_cells} partition cells")
print(f"Largest cell: {census_df['cell_count'].max():,}")
print(f"Smallest cell: {census_df['cell_count'].min():,}")
print(f"Median cell: {census_df['cell_count'].median():,.0f}")
```

> **Checkpoint — Step 1**
> - [ ] Census query executed successfully
> - [ ] Total population count is reasonable (not 0, not wildly different from expected ~100M)
> - [ ] All decomposition dimensions appear in results
> - [ ] Vintage buckets populated if vintage_config was specified
> - [ ] Census results stored; governance log updated with query metadata
> - [ ] HALT if census returns 0 rows or query fails

---

### Step 2 — Compute Required Sample Sizes

**Goal:** Determine how many customers to sample per partition cell to achieve the target statistical power. Flag cells that are too small.

**Why:** The plan's analysis tasks need sufficient sample size per cell to detect meaningful differences. A cell with 50 customers cannot support a comparison that requires detecting a 5% lift with 80% power. This step computes the minimum n per cell and flags underpowered cells before we pull any data.

```python
from statsmodels.stats.power import NormalIndPower, TTestIndPower
import numpy as np

def compute_required_n_per_cell(power_config, metric_type='rate'):
    """
    Compute minimum sample size per cell for the target power.
    Uses the plan's power configuration.
    """
    effect_size = power_config['target_effect_size']
    alpha = power_config['alpha']
    power = power_config['power']

    if power_config.get('ci_width'):
        # Alternative: target confidence interval width
        # n = (z * sigma / margin)^2
        from scipy.stats import norm
        z = norm.ppf(1 - alpha / 2)
        margin = power_config['ci_width'] / 2
        # Assume sigma ~ 0.5 for rates (conservative)
        sigma = 0.5 if metric_type == 'rate' else 1.0
        required_n = int(np.ceil((z * sigma / margin) ** 2))
    else:
        # Standard power analysis for two-group comparison
        analysis = TTestIndPower()
        required_n = int(np.ceil(analysis.solve_power(
            effect_size=effect_size,
            alpha=alpha,
            power=power,
            alternative='two-sided'
        )))

    return required_n

required_n = compute_required_n_per_cell(power_config)
print(f"Required sample size per cell: {required_n:,}")

# ── Classify cells ──
census_df['required_n'] = required_n
census_df['is_powered'] = census_df['cell_count'] >= required_n
census_df['sample_n'] = census_df.apply(
    lambda row: min(row['cell_count'], required_n), axis=1
)

powered_cells = census_df['is_powered'].sum()
underpowered_cells = (~census_df['is_powered']).sum()
total_cells = len(census_df)

print(f"Powered cells: {powered_cells} / {total_cells}")
print(f"Underpowered cells: {underpowered_cells}")

if underpowered_cells > 0:
    small_cells = census_df[~census_df['is_powered']]
    print(f"\nUnderpowered cells (population < {required_n:,}):")
    for _, row in small_cells.iterrows():
        dims = {d: row[d] for d in decomposition_dims}
        print(f"  {dims} → {row['cell_count']:,} customers (need {required_n:,})")

    governance_log['warnings'].append({
        'type': 'underpowered_cells',
        'count': int(underpowered_cells),
        'cells': small_cells[decomposition_dims + ['cell_count']].to_dict('records'),
        'required_n': required_n,
        'note': 'These cells have insufficient population for the target power. '
                'Downstream analysis should caveat findings from these cells. '
                'Consider collapsing adjacent cells if analytically appropriate.'
    })

governance_log['decisions'].append({
    'step': 'power_analysis',
    'required_n_per_cell': required_n,
    'total_cells': total_cells,
    'powered_cells': int(powered_cells),
    'underpowered_cells': int(underpowered_cells),
    'power_config': power_config
})
```

**Decision point — handling underpowered cells:**

| Situation | Action |
|-----------|--------|
| All cells powered | Proceed to sampling |
| < 20% cells underpowered | Proceed; flag cells in manifest; downstream analysis adds caveats |
| 20-50% cells underpowered | Warn; suggest collapsing adjacent dimension values; proceed if user confirms |
| > 50% cells underpowered | HALT — decomposition is too granular for this population. Recommend reducing dimensions or widening the population criteria |

> **Checkpoint — Step 2**
> - [ ] Required n per cell computed from power config
> - [ ] Every cell classified as powered or underpowered
> - [ ] Underpowered cells documented with population counts
> - [ ] Decision on proceeding/collapsing/halting made and logged
> - [ ] Governance log updated with power analysis results
> - [ ] HALT if > 50% cells underpowered (decomposition too granular)

---

### Step 3 — Build and Execute the Sampling Query

**Goal:** Pull the sample from the warehouse using the plan-specified sampling method. Construct temporal observation windows per customer. Return only the sampled rows with partition assignments and window boundaries.

**Why:** This is the only step that pulls row-level data. Everything before this was counts and metadata. The sampling query must be efficient — it pulls only the required n per cell and only the columns needed for downstream analysis.

**Reference:** Sampling method behavior differs fundamentally:

| Method | How It Works | When to Use |
|--------|-------------|-------------|
| **pre_stratified** | Define partition grid from census, sample n per cell using warehouse-native sampling within each stratum | Default for structured decomposition; guarantees coverage |
| **post_stratified** | Draw a large random sample, then validate and rebalance representation per cell | When partition grid is complex or cell boundaries are fuzzy |
| **random_windowed** | Random sample within a temporal window, then assign partition labels post-hoc | When the observation window is the primary constraint and partition is secondary |

```python
def build_sample_query(sampling_method, census_df, decomposition_dims,
                       population_def, observation_window, vintage_config,
                       warehouse_type, required_n):
    """
    Build the SQL that pulls the actual sample.
    Method-specific construction.
    """

    # ── Common: population filter ──
    where_parts = []
    for c in population_def.get('criteria', []):
        if c['op'] == 'eq':
            where_parts.append(f"{c['field']} = '{c['value']}'")
        elif c['op'] == 'between':
            where_parts.append(f"{c['field']} BETWEEN '{c['value'][0]}' AND '{c['value'][1]}'")
        elif c['op'] == 'in':
            vals = ", ".join(f"'{v}'" for v in c['value'])
            where_parts.append(f"{c['field']} IN ({vals})")
    where_sql = " AND ".join(where_parts) if where_parts else "1=1"

    # ── Common: observation window columns ──
    window_cols = ""
    window_join = ""
    if observation_window:
        anchor = observation_window['anchor_event']
        days = observation_window['window_days']
        direction = observation_window['direction']

        if direction == 'pre_event':
            window_cols = f""",
                {anchor} AS anchor_date,
                DATEADD('day', -{days}, {anchor}) AS window_start,
                {anchor} AS window_end,
                'pre_event' AS window_direction"""
        elif direction == 'post_event':
            window_cols = f""",
                {anchor} AS anchor_date,
                {anchor} AS window_start,
                DATEADD('day', {days}, {anchor}) AS window_end,
                'post_event' AS window_direction"""
        elif direction == 'matched_pre_post':
            window_cols = f""",
                {anchor} AS anchor_date,
                DATEADD('day', -{days}, {anchor}) AS pre_window_start,
                {anchor} AS pre_window_end,
                {anchor} AS post_window_start,
                DATEADD('day', {days}, {anchor}) AS post_window_end,
                'matched_pre_post' AS window_direction"""

    # ── Method: pre_stratified ──
    if sampling_method == 'pre_stratified':
        # Use ROW_NUMBER() partitioned by cell to sample n per cell
        dim_cols = ", ".join(decomposition_dims)
        partition_by = dim_cols

        query = f"""
        WITH ranked AS (
            SELECT *,
                {dim_cols}
                {window_cols},
                ROW_NUMBER() OVER (
                    PARTITION BY {partition_by}
                    ORDER BY RANDOM()
                ) AS row_rank
            FROM customer_base
            WHERE {where_sql}
        )
        SELECT *
        FROM ranked
        WHERE row_rank <= {required_n}
        """

    # ── Method: post_stratified ──
    elif sampling_method == 'post_stratified':
        # Pull a large random sample (3x total required), then validate coverage
        total_required = required_n * len(census_df)
        oversample_n = total_required * 3  # 3x oversample for rebalancing headroom

        if warehouse_type == 'snowflake':
            sample_clause = f"SAMPLE ({oversample_n} ROWS)"
        elif warehouse_type == 'bigquery':
            # BigQuery uses TABLESAMPLE or RAND()
            sample_pct = min(100, (oversample_n / total_population) * 100)
            sample_clause = f"WHERE RAND() < {sample_pct / 100}"
        else:
            sample_clause = f"TABLESAMPLE ({min(100, int(oversample_n / total_population * 100))} PERCENT)"

        dim_cols = ", ".join(decomposition_dims)
        query = f"""
        SELECT
            {dim_cols},
            customer_id,
            *
            {window_cols}
        FROM customer_base
        {sample_clause}
        {'AND' if 'WHERE' in sample_clause else 'WHERE'} {where_sql}
        """

    # ── Method: random_windowed ──
    elif sampling_method == 'random_windowed':
        # Random sample within the observation window, assign partitions post-hoc
        if not observation_window:
            raise ValueError("random_windowed method requires an observation_window")

        anchor = observation_window['anchor_event']
        days = observation_window['window_days']
        direction = observation_window['direction']
        total_required = required_n * len(census_df)

        if direction == 'pre_event':
            time_filter = f"AND {anchor} BETWEEN DATEADD('day', -{days}, CURRENT_DATE) AND CURRENT_DATE"
        elif direction == 'post_event':
            time_filter = f"AND {anchor} IS NOT NULL AND DATEDIFF('day', {anchor}, CURRENT_DATE) >= {days}"
        else:
            time_filter = f"AND {anchor} IS NOT NULL AND DATEDIFF('day', {anchor}, CURRENT_DATE) >= {days}"

        dim_cols = ", ".join(decomposition_dims)
        query = f"""
        SELECT
            {dim_cols},
            customer_id,
            *
            {window_cols}
        FROM customer_base
        WHERE {where_sql}
        {time_filter}
        ORDER BY RANDOM()
        LIMIT {total_required * 3}
        """

    return query

sample_query = build_sample_query(
    sampling_method, census_df, decomposition_dims,
    population_def, observation_window, vintage_config,
    warehouse_type, required_n
)

# ── Execute and log ──
# query_start = time.time()
# sample_df = execute_query(connection, sample_query)
# query_duration = time.time() - query_start

governance_log['decisions'].append({
    'step': 'sample_pull',
    'method': sampling_method,
    'query_hash': hash(sample_query),
    'rows_returned': len(sample_df),
    'query_duration_seconds': query_duration,
    'warehouse': warehouse_type
})

print(f"Sample pulled: {len(sample_df):,} rows in {query_duration:.1f}s")
```

> **Checkpoint — Step 3**
> - [ ] Sampling query executed successfully
> - [ ] Row count is reasonable (not 0, within expected range of required_n × n_cells)
> - [ ] Observation window columns present if temporal windowing was specified
> - [ ] Vintage bucket column present if vintage was specified
> - [ ] Governance log updated with query metadata and duration
> - [ ] HALT if query fails or returns 0 rows

---

### Step 4 — Validate MECE Coverage and Power

**Goal:** Confirm the sample covers every partition cell, achieves the target power, and partitions are mutually exclusive and collectively exhaustive.

**Why:** This is the quality gate. If the sample doesn't cover a cell, downstream analysis has a blind spot. If a cell is underpowered, conclusions from it carry large variance. If partitions overlap, the MECE property is violated and aggregate conclusions are unreliable.

```python
def validate_sample(sample_df, census_df, decomposition_dims, required_n,
                    sampling_method, governance_log):
    """
    Validate MECE coverage, sample sizes, and partition integrity.
    """
    results = {
        'mece_valid': True,
        'all_cells_covered': True,
        'all_cells_powered': True,
        'coverage_pct': 0.0,
        'cell_details': [],
        'issues': []
    }

    # ── Check: every customer belongs to exactly one cell (MECE) ──
    dim_cols = decomposition_dims
    cell_assignments = sample_df.groupby(dim_cols).size().reset_index(name='sample_n')

    # Check for null values in dimension columns (breaks MECE)
    for dim in dim_cols:
        null_count = sample_df[dim].isnull().sum()
        if null_count > 0:
            results['mece_valid'] = False
            results['issues'].append({
                'type': 'null_dimension_values',
                'dimension': dim,
                'null_count': int(null_count),
                'note': f'{null_count} customers have NULL {dim} — '
                        f'they fall outside all partition cells'
            })

    # Check for duplicate customer IDs across cells
    customer_cell_counts = sample_df.groupby('customer_id')[dim_cols[0]].count()
    duplicates = (customer_cell_counts > 1).sum()
    if duplicates > 0:
        results['mece_valid'] = False
        results['issues'].append({
            'type': 'overlapping_partitions',
            'duplicate_customers': int(duplicates),
            'note': 'Customers appear in multiple partition cells — MECE violated'
        })

    # ── Check: all census cells represented in sample ──
    census_cells = set(census_df[dim_cols].apply(tuple, axis=1))
    sample_cells = set(cell_assignments[dim_cols].apply(tuple, axis=1))
    missing_cells = census_cells - sample_cells
    if missing_cells:
        results['all_cells_covered'] = False
        results['issues'].append({
            'type': 'missing_cells',
            'count': len(missing_cells),
            'cells': [dict(zip(dim_cols, cell)) for cell in list(missing_cells)[:20]],
            'note': 'These cells exist in the population but have no samples'
        })

    # ── Check: power per cell ──
    cell_details = []
    underpowered = 0
    for _, row in cell_assignments.iterrows():
        cell_key = {d: row[d] for d in dim_cols}
        n = row['sample_n']
        powered = n >= required_n
        if not powered:
            underpowered += 1
        cell_details.append({
            'cell': cell_key,
            'sample_n': int(n),
            'required_n': required_n,
            'powered': powered,
            'power_ratio': round(n / required_n, 2)
        })

    results['all_cells_powered'] = underpowered == 0
    results['cell_details'] = cell_details
    results['coverage_pct'] = round(len(sample_cells) / len(census_cells) * 100, 1)

    if underpowered > 0:
        results['issues'].append({
            'type': 'underpowered_cells',
            'count': underpowered,
            'note': f'{underpowered} cells below required n={required_n}. '
                    f'Downstream analysis cannot conclude on these cells — '
                    f'large variance makes findings unreliable.'
        })

    # ── Post-stratification rebalancing (if method == post_stratified) ──
    if sampling_method == 'post_stratified' and not results['all_cells_powered']:
        governance_log['decisions'].append({
            'step': 'post_stratification_rebalance',
            'action': 'Identified cells needing oversampling',
            'cells_to_oversample': underpowered
        })
        # In practice: re-query for underpowered cells with targeted WHERE clause
        # This is a second query, not a full re-pull

    # ── Log everything ──
    governance_log['decisions'].append({
        'step': 'validation',
        'mece_valid': results['mece_valid'],
        'all_cells_covered': results['all_cells_covered'],
        'all_cells_powered': results['all_cells_powered'],
        'coverage_pct': results['coverage_pct'],
        'total_cells': len(census_cells),
        'sample_cells': len(sample_cells),
        'underpowered_cells': underpowered,
        'issues_count': len(results['issues'])
    })

    return results

validation = validate_sample(
    sample_df, census_df, decomposition_dims, required_n,
    sampling_method, governance_log
)

print(f"\nMECE valid: {validation['mece_valid']}")
print(f"Coverage: {validation['coverage_pct']}% of cells")
print(f"All cells powered: {validation['all_cells_powered']}")
if validation['issues']:
    print(f"Issues: {len(validation['issues'])}")
    for issue in validation['issues']:
        print(f"  [{issue['type']}] {issue['note']}")
```

> **Checkpoint — Step 4**
> - [ ] MECE validation: no nulls in dimension columns, no duplicate customers across cells
> - [ ] Coverage: all census cells represented in sample (or gaps documented)
> - [ ] Power: all cells meet required_n (or underpowered cells documented with caveats)
> - [ ] If post_stratified: rebalancing triggered for underpowered cells
> - [ ] All issues logged in governance log
> - [ ] PASS → proceed to manifest generation
> - [ ] WARN → proceed with caveats documented
> - [ ] HALT if MECE is violated (overlapping partitions or >50% cells missing)

---

### Step 5 — Generate Sampling Manifest

**Goal:** Produce the terminal artifact — a complete audit trail of every sampling decision, the final sample statistics, power validation, and governance log. This manifest is consumed by all downstream skills and is the primary governance document for the sampling process.

```python
def generate_manifest(sample_df, census_df, validation, governance_log,
                      scope, plan_node, decomposition_dims,
                      observation_window, vintage_config, power_config):
    """
    Produce the sampling_manifest.json — the full audit trail.
    """
    manifest = {
        'schema_version': '1.0',
        'skill_name': 'cgf-population-sampling',
        'artifact_id': f"sample_{scope.get('scope_id', 'unknown')}",
        'timestamp': datetime.datetime.utcnow().isoformat(),
        'record_count': len(sample_df),

        # ── What was sampled ──
        'population': {
            'scope_id': scope.get('scope_id'),
            'total_population': int(census_df['cell_count'].sum()),
            'sample_size': len(sample_df),
            'sampling_ratio': round(len(sample_df) / census_df['cell_count'].sum(), 6)
        },

        # ── How it was sampled ──
        'method': {
            'sampling_method': plan_node['sampling_method'],
            'warehouse_type': governance_log.get('warehouse', 'unknown'),
            'decomposition_dimensions': decomposition_dims,
            'power_config': power_config,
            'required_n_per_cell': validation['cell_details'][0]['required_n']
                if validation['cell_details'] else None
        },

        # ── Temporal configuration ──
        'temporal': {
            'observation_window': observation_window,
            'vintage_config': vintage_config,
            'timeframe': scope['definition']['timeframe']
        },

        # ── Partition coverage ──
        'partition': {
            'total_cells': len(census_df),
            'covered_cells': sum(1 for c in validation['cell_details'] if c['sample_n'] > 0),
            'powered_cells': sum(1 for c in validation['cell_details'] if c['powered']),
            'underpowered_cells': sum(1 for c in validation['cell_details'] if not c['powered']),
            'coverage_pct': validation['coverage_pct'],
            'mece_valid': validation['mece_valid'],
            'cell_details': validation['cell_details']
        },

        # ── Governance ──
        'governance': governance_log,

        # ── Validation summary ──
        'validation': {
            'status': 'PASS' if (validation['mece_valid'] and validation['all_cells_powered'])
                      else 'PASS_WITH_CAVEATS' if validation['mece_valid']
                      else 'FAIL',
            'issues': validation['issues'],
            'caveats': [
                f"Cell {issue['cell']} has {issue['sample_n']} samples "
                f"(need {issue['required_n']}): findings carry large variance"
                for issue in validation['cell_details']
                if not issue['powered']
            ]
        },

        # ── Output locations ──
        'outputs': {
            'sample_data': 'output/sample_set.parquet',
            'manifest': 'sampling_manifest.json'
        }
    }

    return manifest

manifest = generate_manifest(
    sample_df, census_df, validation, governance_log,
    scope, plan_node, decomposition_dims,
    observation_window, vintage_config, power_config
)

# Write outputs
sample_df.to_parquet('output/sample_set.parquet', index=False)
with open('sampling_manifest.json', 'w') as f:
    json.dump(manifest, f, indent=2, default=str)

print(f"\nSampling complete.")
print(f"  Status: {manifest['validation']['status']}")
print(f"  Sample: {manifest['population']['sample_size']:,} customers")
print(f"  Cells: {manifest['partition']['powered_cells']} powered / "
      f"{manifest['partition']['total_cells']} total")
print(f"  Manifest: sampling_manifest.json")
print(f"  Data: output/sample_set.parquet")
```

> **Checkpoint — Step 5**
> - [ ] sampling_manifest.json written with all required fields
> - [ ] sample_set.parquet written
> - [ ] Manifest contains full governance log
> - [ ] Manifest contains cell-level power details
> - [ ] Manifest status is PASS, PASS_WITH_CAVEATS, or FAIL
> - [ ] All caveats explicitly documented for downstream skills
> - [ ] Underpowered cell findings annotated: "cannot conclude — large variance"

---

## Edge Case Handling

| Edge Case | Detection | Action |
|-----------|-----------|--------|
| Census returns 0 rows | `census_df` is empty | HALT — population criteria match no customers. Check scope filters. |
| Single-cell partition | Only 1 unique combination across all dimensions | WARN — decomposition produces no comparison groups. Suggest adding a dimension or widening criteria. Proceed if user confirms. |
| >500 cells (high-dimensional cross) | `len(census_df) > 500` | WARN — decomposition is very granular. Many cells will be underpowered. Suggest collapsing low-cardinality dimensions. |
| Anchor event column has >30% nulls | `null_rate > 0.3` on anchor column | WARN — temporal windowing will exclude >30% of population. Document in manifest. Consider whether null-anchor customers need separate analysis. |
| Warehouse query timeout | Query exceeds connection timeout | Retry with APPROX_COUNT_DISTINCT if exact counts were used. If still failing, suggest narrowing population or reducing dimensions. |
| Post-stratified oversample insufficient | After 3x oversample, cells still underpowered | Execute targeted queries for underpowered cells. Log the supplementary pull in governance. |
| Vintage buckets produce "other" category >20% | >20% of population falls outside defined vintage periods | WARN — vintage definition may be incomplete. Document "other" bucket size. Suggest expanding vintage periods. |
| Matched pre/post has insufficient post-window | Customer's anchor event is too recent for full post-window | Exclude customer from sample. Log exclusion count. WARN if >10% excluded. |

---

## Quality Bar

A sample is "done" when ALL of the following are true:

- [ ] `sampling_manifest.json` exists and contains all required fields
- [ ] `sample_set.parquet` exists and row count matches manifest
- [ ] MECE validation passes — no customer appears in multiple cells
- [ ] Coverage >= 90% of census cells represented in sample
- [ ] >= 80% of cells meet the required_n for target power
- [ ] Underpowered cells explicitly documented with "cannot conclude" caveats
- [ ] Governance log contains every decision with timestamp and rationale
- [ ] Temporal windows are correct (spot-check: anchor dates, window boundaries)
- [ ] Vintage buckets sum to 100% of sample (if vintage configured)

---

## Scope Boundary

This skill does NOT:

- Perform any analysis on the sampled data (downstream skills do that)
- Decide which decomposition dimensions to use (the scope and plan define that)
- Modify the population criteria (reads scope as-is)
- Build features or compute metrics (that's feature-engineering / metric-computation)
- Evaluate whether the decomposition dimensions are analytically meaningful (that's the Scope Agent's job)
- Handle A/B test randomization or experimental design (separate skill)

---

## Downstream Skills

After this skill completes, the following can consume `sample_set.parquet` and `sampling_manifest.json`:

1. **feature-engineering** — build behavioral features on the sampled population
2. **eda-comprehensive** — explore patterns within and across partition cells
3. **behavioral-profiling** — characterize behavioral signatures per cell
4. **engagement-state-classification** — assign CGF lifecycle states
5. **statistical-comparison** — compare cells against each other or baseline
6. **hypothesis-validation** — test hypotheses per cell with powered samples
7. **retention-stickiness-analysis** — measure retention dynamics per cell
8. **interval-analysis** — use temporal windows for lifecycle trajectory analysis
9. **behavior-valuation** — quantify behavioral value per cell

Downstream skills MUST read the sampling manifest to:
- Check which cells are powered vs. underpowered
- Apply appropriate caveats to underpowered cell findings
- Use the temporal window boundaries for observation period alignment
