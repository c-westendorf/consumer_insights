---
name: budget-allocation
description: >
  Assigns exploration budgets, exit conditions, and priority to each task node. Iterative
  tasks (exploration, hypothesis testing, feature engineering) receive max_iterations and
  convergence criteria. One-shot tasks receive a fixed budget of 1. Activate after
  dependency-resolution. Takes ordered_task_plan; produces budgeted_task_plan.
inputs:
  - type: ordered_task_plan
    description: "Dependency-resolved execution order with stages and fan-out/join annotations"
outputs:
  - type: budgeted_task_plan
    description: "Execution plan enriched with iteration budgets, exit conditions, and task priority"
can_follow: [dependency-resolution]
can_precede: [plan-formatting]
supports_loop: false
exit_conditions:
  - "budgeted_task_plan produced with every task having a budget and priority assignment"
  - "iterative tasks have exit_conditions and fallback defined"
---

## Overview

Dependency-resolution determines *in what order* tasks execute. Budget-allocation
enriches each task with resource constraints. Without explicit budgets, iterative
tasks (exploration loops, hypothesis testing, feature engineering) could run
indefinitely, consuming unbounded cycles. This skill classifies each task as
iterative or one-shot, assigns max_iterations and exit_conditions to iterative
tasks, fixes one-shot tasks at budget 1, and labels every task with a priority
level (critical / standard / optional) derived from the DAG critical path. The
output is a budgeted_task_plan consumed by plan-formatting for final rendering.

---

## When to Activate

- ordered_task_plan.json exists in the working directory with a valid artifact_id
- Plan Agent pipeline has completed dependency-resolution and no budgeted_task_plan.json exists
- ordered_task_plan.json has been regenerated since the last budgeted_task_plan.json timestamp
- A prior budgeted_task_plan.json was rejected and ordered_task_plan.json is unchanged
- The Plan Agent receives a `budget` or `allocate-budgets` command referencing a valid ordered_task_plan

---

## Preconditions

What must be true before this skill begins:

- [ ] `ordered_task_plan.json` exists and `schema_version == "1.0"`
- [ ] `ordered_task_plan.json` contains `execution_order` array with >= 1 stage
- [ ] Every task in `execution_order` has a resolvable entry in the source task_node_list
- [ ] `ordered_task_plan.json` contains a valid `artifact_id`
- [ ] `dag_metadata` is present with `critical_path_length` and `graph_shape`

Each precondition has a corresponding HALT condition in Step 0.

---

## Prerequisites

### Library Dependencies

```
# Tier 1 -- Core (required)
python>=3.10

# Tier 2 -- Skill-specific
json (stdlib)
uuid (stdlib)
datetime (stdlib)
```

No external library dependencies. CPU-only, minimal memory.

### Infrastructure Requirements

- **Compute:** CPU-only
- **Memory:** < 128 MB (metadata enrichment only)
- **Disk:** < 1 MB scratch (JSON artifacts only)
- **OS packages:** None
- **Environment:** Any Python 3.10+ runtime

### Upstream Artifacts

- `ordered_task_plan.json`: produced by `dependency-resolution` -- required fields: `schema_version`, `artifact_id`, `execution_order`, `dependencies`, `dag_metadata`

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `loop_presence` | `has_iterative` / `no_iterative` | `has_iterative`: assign exploration_budget, exit_conditions, and fallback per iterative task; `no_iterative`: all tasks get budget of 1, skip iterative budget logic |
| `budget_strategy` | `conservative` / `balanced` | Derived from the cost_reward_model phase_weights. `conservative`: lower iteration caps (exploration: 3, hypothesis: 2, feature: 2); `balanced`: standard caps (exploration: 5, hypothesis: 3, feature: 3) |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:** Classify variance dimensions from ordered_task_plan.

```
load ordered_task_plan.json

# Determine loop_presence
iterative_types = {"exploration", "hypothesis_test", "feature_engineering"}
task_types_present = collect task_type from all tasks across execution_order stages
has_iterative = any(t in iterative_types for t in task_types_present)

classify loop_presence:
  IF has_iterative -> "has_iterative"
  ELSE -> "no_iterative"

# Determine budget_strategy (default balanced; conservative if total tasks > 12)
task_count = sum of tasks across all stages
classify budget_strategy:
  IF task_count > 12 -> "conservative"
  ELSE -> "balanced"

log: "Running budget-allocation | loop_presence={value} | budget_strategy={value} | task_count={N}"
```

**Upstream Validation:**

```
assert ordered_task_plan.schema_version == "1.0"
  HALT: "Schema version mismatch: expected 1.0, got {value}."
assert ordered_task_plan.execution_order is array with length >= 1
  HALT: "execution_order is empty. Nothing to budget."
assert ordered_task_plan.artifact_id is present
  HALT: "ordered_task_plan missing artifact_id. Cannot establish provenance chain."
assert ordered_task_plan.dag_metadata is present
  HALT: "ordered_task_plan missing dag_metadata. Cannot determine critical path."
assert ordered_task_plan.dag_metadata.critical_path_length is present
  HALT: "dag_metadata missing critical_path_length."

FOR each stage in execution_order:
  FOR each task_id in stage.tasks:
    assert task has resolvable task_type
      HALT: "Task {task_id} has no resolvable task_type."
```

**Checkpoint:**
> - [ ] PASS: All upstream assertions pass, loop_presence and budget_strategy classified
> - [ ] HALT: Any assertion failure -- stop with exact message

---

### Step 1 -- Classify Task Iteration Types

**Goal:** For each task node, determine if it is iterative or one-shot based on task_type.

**Pre-step assertion:** All tasks validated with resolvable task_type.

**Actions:**

```
iterative_types = {"exploration", "hypothesis_test", "feature_engineering"}
one_shot_types = {"ingestion", "profiling", "population", "transformation",
                  "synthesis", "validation", "valuation"}

classified_tasks = []
FOR each stage in execution_order:
  FOR each task_id in stage.tasks:
    task_type = resolve task_type for task_id
    IF task_type in iterative_types:
      iteration_type = "iterative"
    ELIF task_type in one_shot_types:
      iteration_type = "one_shot"
    ELSE:
      WARN: "Unknown task_type '{task_type}' for {task_id}. Defaulting to one_shot."
      iteration_type = "one_shot"
    classified_tasks.append({task_id, task_type, iteration_type, stage})
```

**Checkpoint:**
> - [ ] Assert: every task_id has an iteration_type assignment
> - [ ] PASS: Classification complete
> - [ ] WARN: Unknown task_type encountered -- logged and defaulted

---

### Step 2 -- Assign Exit Conditions

**Goal:** For each iterative task, select appropriate exit condition(s) from the five types.

**Pre-step assertion:** classified_tasks populated with iteration_type.

**Actions:**

```
exit_condition_map = {
  "exploration": ["hypothesis_stable", "coverage_complete", "budget_exhausted"],
  "hypothesis_test": ["confidence_threshold", "hypothesis_stable", "budget_exhausted"],
  "feature_engineering": ["performance_plateau", "coverage_complete", "budget_exhausted"]
}

fallback_map = {
  "exploration": "Report partial findings with coverage assessment",
  "hypothesis_test": "Report inconclusive result with confidence interval",
  "feature_engineering": "Return best-performing feature set to date"
}

FOR each task in classified_tasks:
  IF task.iteration_type == "iterative":
    task.exit_conditions = exit_condition_map[task.task_type]
    task.fallback = fallback_map[task.task_type]
  ELSE:
    task.exit_conditions = null  # one-shot uses singular exit_condition
    task.fallback = null
```

**Checkpoint:**
> - [ ] Assert: every iterative task has >= 2 exit_conditions (including budget_exhausted)
> - [ ] Assert: every iterative task has a non-null fallback
> - [ ] PASS: Exit conditions assigned

---

### Step 3 -- Assign Budgets

**Goal:** Apply per-category iteration defaults based on budget_strategy.

**Pre-step assertion:** Exit conditions assigned to all iterative tasks.

**Actions:**

```
budget_defaults = {
  "conservative": {"exploration": 3, "hypothesis_test": 2, "feature_engineering": 2},
  "balanced":     {"exploration": 5, "hypothesis_test": 3, "feature_engineering": 3}
}

phase_weight_defaults = {
  "exploration": 0.35, "hypothesis_test": 0.25, "feature_engineering": 0.20
}

FOR each task in classified_tasks:
  IF task.iteration_type == "iterative":
    task.budget = {
      max_iterations: budget_defaults[budget_strategy][task.task_type],
      exit_conditions: task.exit_conditions,
      fallback: task.fallback,
      phase_weight: phase_weight_defaults[task.task_type]
    }
  ELSE:
    task.budget = {
      max_iterations: 1,
      exit_condition: "task_complete",
      fallback: null,
      phase_weight: 0.0
    }

  # Mark tasks blocked when skill_ref is unresolved (tool taxonomy gap)
  IF task.skill_ref is null:
    task.budget.blocked_pending_tooling = true

total_iteration_budget = sum(task.budget.max_iterations for all tasks)
total_budget = sum(task.budget.max_iterations * max(task.budget.phase_weight, 0.05) for all tasks)
iterative_task_count = count tasks where iteration_type == "iterative"
one_shot_task_count = count tasks where iteration_type == "one_shot"
```

**Budget Insufficiency Check:**

```
FOR each task in classified_tasks:
  IF task.priority == "critical" AND task.iteration_type == "iterative":
    IF task.budget.max_iterations < 2:
      WARN: "Budget insufficient for critical path: {task.task_id} has max_iterations={task.budget.max_iterations}. Suggest scope reduction or strategy change. Do not silently drop tasks."
```

**Checkpoint:**
> - [ ] Assert: every task has a budget with max_iterations >= 1
> - [ ] Assert: one-shot tasks have max_iterations == 1
> - [ ] WARN: Budget insufficient for critical path -- logged per affected task
> - [ ] PASS: Budgets assigned

---

### Step 4 -- Assign Priority

**Goal:** Use DAG critical path from ordered_task_plan to assign critical/standard/optional.

**Pre-step assertion:** Budgets assigned. dag_metadata available.

**Actions:**

```
# Determine critical path tasks
# Critical path = longest path through the DAG (by stage count)
# Tasks on the critical path are "critical"
# Tasks required but not on the critical path are "standard"
# Tasks that can be deferred without blocking synthesis/validation are "optional"

critical_path_tasks = compute_critical_path(execution_order, dependencies)

FOR each task in classified_tasks:
  IF task.task_id in critical_path_tasks:
    task.priority = "critical"
  ELIF task.task_type in {"validation", "valuation"}:
    task.priority = "standard"  # always required even if off critical path
  ELIF task.task_type == "exploration" AND task.task_id not in critical_path_tasks:
    task.priority = "optional"
  ELSE:
    task.priority = "standard"
```

**Checkpoint:**
> - [ ] Assert: every task has a priority in {critical, standard, optional}
> - [ ] Assert: at least one task is critical
> - [ ] PASS: Priority assignment complete
> - [ ] WARN: Zero critical tasks -- "No tasks on critical path. Review DAG structure."

---

### Step 5 -- Write Terminal Artifact

**Goal:** Assemble and write budgeted_task_plan.json.

**Pre-step assertion:** All tasks have budget and priority. Metadata computed.

**Actions:**

```
generate artifact_id (uuid v4)

budgeted_task_plan = {
  schema_version: "1.0",
  skill_name: "budget-allocation",
  timestamp: current ISO-8601 UTC,
  record_count: len(classified_tasks),
  artifact_id: new_uuid,
  source_ordered_plan_id: ordered_task_plan.artifact_id,
  budget_strategy: budget_strategy,
  budgeted_tasks: [format each classified_task with task_id, task_type,
                    iteration_type, budget, priority],
  budget_metadata: {
    iterative_task_count,
    one_shot_task_count,
    critical_path_tasks: list of critical task_ids,
    total_iteration_budget,
    total_budget,
    phase_weights: {task_id: phase_weight for each iterative task}
  }
}

write budgeted_task_plan.json
```

**Checkpoint:**
> - [ ] Assert: budgeted_task_plan.json is valid JSON
> - [ ] Assert: record_count matches total task count
> - [ ] Assert: all 5 universal envelope fields present
> - [ ] PASS: Artifact written successfully
> - [ ] HALT: Write failure -- "{exact error}"

---

## Terminal Artifact

**File:** `budgeted_task_plan.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "budget-allocation",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 9,
  "artifact_id": "{uuid}",
  "source_ordered_plan_id": "{uuid}",
  "budget_strategy": "balanced",
  "budgeted_tasks": [
    {
      "task_id": "TN-001",
      "task_type": "ingestion",
      "iteration_type": "one_shot",
      "budget": {
        "max_iterations": 1,
        "exit_condition": "data_loaded",
        "fallback": null,
        "phase_weight": 0.0
      },
      "priority": "critical"
    },
    {
      "task_id": "TN-005",
      "task_type": "exploration",
      "iteration_type": "iterative",
      "budget": {
        "max_iterations": 5,
        "exit_conditions": ["hypothesis_stable", "coverage_complete", "budget_exhausted"],
        "fallback": "Report partial findings with coverage assessment",
        "phase_weight": 0.35
      },
      "priority": "standard"
    }
  ],
  "budget_metadata": {
    "iterative_task_count": 2,
    "one_shot_task_count": 7,
    "critical_path_tasks": ["TN-001", "TN-002", "TN-004", "TN-007", "TN-009"],
    "total_iteration_budget": 11,
    "total_budget": 2.1,
    "phase_weights": {"TN-005": 0.35, "TN-006": 0.25}
  }
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | execution_order array is empty | HALT: "execution_order is empty. Nothing to budget." |
| Single record | execution_order has exactly 1 stage with 1 task | WARN: "Single task -- trivial budget with 1 iteration." Produce plan with budget 1, priority critical. |
| All-null dimension | task_type is null or missing for all tasks | HALT: "No tasks have resolvable task_type. Cannot classify iteration types." |
| Schema mismatch | schema_version != "1.0" | HALT: "Upstream schema_version mismatch: expected 1.0, got {value}." |
| All tasks iterative | every task classifies as iterative | WARN: "All tasks are iterative. Verify plan includes ingestion and synthesis steps. Proceeding with iterative budgets for all." |
| Unknown task_type | task_type not in iterative_types or one_shot_types | WARN: "Unknown task_type '{value}' for {task_id}. Defaulting to one_shot with budget 1." |
| No critical path data | dag_metadata.critical_path_length missing or 0 | HALT: "Cannot assign priority without critical path data." |
| Budget overflow | total_iteration_budget exceeds 50 | WARN: "Total iteration budget ({N}) is high. Consider switching to conservative strategy." |
| Budget insufficient for critical path | Critical iterative task has max_iterations < 2 | WARN: "Budget insufficient for critical path. Suggest scope reduction. Do not silently drop tasks." |
| Tool taxonomy gap | task.skill_ref is null | Mark task `blocked_pending_tooling: true`. WARN: "Task {task_id} has no skill_ref. Marked blocked_pending_tooling." |

---

## Postconditions

After successful completion, this skill guarantees:

- [ ] `budgeted_task_plan.json` exists and is valid JSON
- [ ] Every task from ordered_task_plan has a budget with max_iterations >= 1
- [ ] Every iterative task has exit_conditions (array) and a non-null fallback
- [ ] Every one-shot task has max_iterations == 1
- [ ] Every task has a priority in {critical, standard, optional}
- [ ] Terminal artifact contains all 5 universal envelope fields
- [ ] source_ordered_plan_id traces back to the source ordered_task_plan
- [ ] total_budget is computed and present in budget_metadata
- [ ] Tasks with null skill_ref are marked `blocked_pending_tooling: true`

---

## Quality Bar

This skill run is "done" when ALL of the following are true:

- [ ] All Step 0 upstream assertions passed
- [ ] Every task classified as iterative or one_shot
- [ ] Iterative tasks have exit_conditions with budget_exhausted as final fallback
- [ ] Budget defaults applied per budget_strategy (conservative or balanced)
- [ ] Priority assigned to every task based on critical path analysis
- [ ] budget_metadata accurately reflects counts and totals
- [ ] Terminal artifact validates: schema_version, skill_name, timestamp, record_count, artifact_id present
- [ ] budgeted_task_plan.json is consumable by plan-formatting (budgeted_tasks array with budget and priority)

---

## Scope Boundary

This skill does NOT:

- Decompose scope into task nodes -> handled by `task-decomposition`
- Resolve task dependencies or execution order -> handled by `dependency-resolution`
- Format the plan for human approval -> handled by `plan-formatting`
- Execute any tasks in the plan -> handled by Analyze Phase skills
- Modify task node definitions (task_type, skill_ref, description) -> immutable from task-decomposition
- Determine which skills are available in the registry -> handled by task-decomposition skill matching

---

## Downstream

Run after this skill completes:

1. **`plan-formatting`** -- Consumes `budgeted_task_plan.json` to render the final plan_artifact.json with stakeholder and execution views. Reads `budgeted_tasks` for budget and priority per task, `budget_strategy` for metadata, and `budget_metadata` for plan summary statistics.
