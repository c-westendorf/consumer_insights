---
name: task-decomposition
description: >
  Breaks a validated scope_artifact into atomic analytical task nodes by matching against
  CGF task templates and the skill registry. Activate when scope_artifact.json exists with
  approved_at timestamp. Takes scope_artifact, CGF task templates, and skill registry;
  produces task_node_list with up to 50 typed task nodes, each referencing a skill from the
  registry or flagged as novel with requires_human_review.
inputs:
  - type: scope_artifact
    description: "Human-approved scope definition with lifecycle_stage, analytical_pattern, and all scope fields"
  - type: cgf_task_templates
    description: "CGF analytical pattern templates defining standard task sequences per pattern"
  - type: skill_registry
    description: "Available skills with typed interfaces for task-to-skill matching"
outputs:
  - type: task_node_list
    description: "Array of atomic task nodes with task_id, task_type, skill_ref, and dependencies"
can_follow: []
can_precede: [dependency-resolution]
supports_loop: false
exit_conditions:
  - "task_node_list produced with all scope requirements covered by at least one task node"
  - "novel tasks flagged with skill_ref null and requires_human_review true"
  - "task count <= 50"
---

## Overview

Task-decomposition is the first skill in the Plan Agent pipeline. It translates a
human-approved scope_artifact into concrete analytical work items that downstream
skills can schedule and execute. The skill reads the CGF taxonomy to select the
appropriate task template for the scope's analytical pattern, then instantiates that
template into atomic task nodes. Each node maps to a skill in the registry; if no
matching skill exists, the node is flagged as novel with `requires_human_review: true`.
The Plan Agent never interacts with the user -- it works exclusively from
scope_artifact.json. Without this skill, the pipeline has no executable work breakdown.

---

## When to Activate

- scope_artifact.json exists in the working directory with `approved_at` timestamp present
- Plan Agent pipeline is invoked and no task_node_list.json exists yet
- scope_artifact.json has been updated since the last task_node_list.json timestamp
- A prior task_node_list.json was rejected and scope_artifact.json was re-approved
- The Plan Agent receives a `decompose` command referencing a valid scope_artifact_id
- scope_artifact.json contains a recognized `analytical_pattern` value (profile, compare, explain, predict, segment)

---

## Preconditions

What must be true before this skill begins:

- [ ] `scope_artifact.json` exists and `schema_version == "1.0"`
- [ ] `scope_artifact.json` contains `approved_at` with a valid ISO-8601 timestamp
- [ ] `scope_artifact.json` contains a non-null `analytical_pattern` field
- [ ] `scope_artifact.json` contains at least one `scope_dimension` (population, metric, or constraint)
- [ ] CGF task templates are accessible (embedded or file-based)
- [ ] Skill registry is accessible with at least one registered skill

Each precondition has a corresponding HALT condition in Step 0.

---

## Prerequisites

### Library Dependencies

```
# Tier 1 -- Core (required)
python>=3.10

# Tier 2 -- Skill-specific
json (stdlib)
uuid (stdlib)
datetime (stdlib)
```

No external library dependencies. CPU-only, minimal memory.

### Infrastructure Requirements

- **Compute:** CPU-only
- **Memory:** < 256 MB (metadata-only processing)
- **Disk:** < 1 MB scratch (JSON artifacts only)
- **OS packages:** None
- **Environment:** Any Python 3.10+ runtime

### Upstream Artifacts

- `scope_artifact.json`: produced by `scope-formatting` -- required fields: `schema_version`, `approved_at`, `analytical_pattern`, `lifecycle_stage`, `scope_dimensions`, `artifact_id`

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `analytical_pattern` | `profile` / `compare` / `predict` / `explain` / `segment` | Selects which CGF task template to instantiate; `compare` generates fan-out nodes for parallel cohort extraction; `predict` generates while-loop nodes for model iteration; `segment` composes profile + compare sub-templates |
| `scope_complexity` | `simple` (<=10 tasks) / `standard` (<=30) / `complex` (<=50) | `simple`: basic template instantiation, minimal enrichment; `standard`: template + supplementary constraint tasks; `complex`: composed templates with maximum consolidation effort to stay under 50 |
| `skill_coverage` | `full` / `partial` | `full`: every task node matches a registry skill, no gaps; `partial`: >=1 novel task with no matching skill -- skill_gaps populated in metadata, requires_human_review set to true |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:** Classify variance dimensions from scope_artifact.

```
load scope_artifact.json
classify analytical_pattern: read scope_artifact.analytical_pattern
classify scope_complexity:
  IF scope_dimensions count <= 3 AND no constraints -> "simple"
  IF scope_dimensions count <= 8 OR has constraints -> "standard"
  IF scope_dimensions count > 8 OR has composed patterns -> "complex"
log: "Running task-decomposition | pattern={value} | complexity={value}"
```

**Upstream Validation:**

```
assert scope_artifact.schema_version == "1.0"
  HALT: "Schema version mismatch: expected 1.0, got {value}."
assert scope_artifact.approved_at is not null and is valid ISO-8601
  HALT: "scope_artifact missing approved_at. Human approval required before decomposition."
assert scope_artifact.analytical_pattern in [profile, compare, explain, predict, segment]
  HALT: "Unrecognized analytical_pattern: {value}. Cannot select CGF template."
assert scope_artifact.scope_dimensions is non-empty
  HALT: "scope_artifact has no scope_dimensions. Nothing to decompose."
assert scope_artifact.artifact_id is present
  HALT: "scope_artifact missing artifact_id. Cannot establish provenance chain."
```

**Checkpoint:**
> - [ ] PASS: All upstream assertions pass, variance dimensions classified
> - [ ] HALT: Any assertion failure -- stop with exact message

---

### Step 1 -- Select CGF Template

**Goal:** Identify the correct CGF task template for the scope's analytical pattern.

**Pre-step assertion:** analytical_pattern is classified and valid.

**Actions:**

**CGF Task Templates:**

| Pattern | Template Sequence |
|---|---|
| `profile` | Cohort extraction -> Metric computation -> Distribution characterization -> Benchmark comparison (if defined) -> Finding synthesis |
| `compare` | Cohort extraction [fan-out: both populations] -> Metric computation [parallel] -> Statistical comparison [join] -> Effect size estimation -> Finding synthesis |
| `explain` | Cohort extraction -> Feature engineering -> Hypothesis generation -> Hypothesis testing [fan-out per hypothesis] -> Assessment [join] -> Finding synthesis |
| `predict` | Cohort extraction -> Feature engineering -> Target definition -> Train/validation split -> Model fitting [while-loop] -> Validation -> Interpretation -> Finding synthesis |
| `segment` | Cohort extraction -> Feature engineering -> Clustering -> Profile per segment [fan-out] -> Cross-segment comparison [join] -> Finding synthesis |

```
selected_template = CGF_TEMPLATES[analytical_pattern]
log: "Selected template: {analytical_pattern} with {len(selected_template)} steps"
```

**Checkpoint:**
> - [ ] PASS: Template selected with >=2 steps
> - [ ] HALT: analytical_pattern has no matching template

---

### Step 2 -- Instantiate Task Nodes

**Goal:** Create atomic task nodes from the selected template steps.

**Pre-step assertion:** selected_template is loaded with ordered steps.

**Actions:**

For each template step, create a task node:

```
task_id: "TN-{NNN}" (zero-padded sequential, TN-001, TN-002, ...)
task_type: map template step to one of:
  ingestion | profiling | population | transformation |
  exploration | analysis | valuation | synthesis
description: human-readable description derived from template step + scope context
input_requirements: list of data types this task consumes
output_type: data type this task produces
estimated_complexity: low | medium | high (based on template step nature)
requires_human_review: false (default; set in Step 3 if no skill match)
tool_types_needed: [] (populated in Step 3 from task_type mapping)
playbook_ref: null (populated in Step 3 via playbook matching)
```

**Branch on scope_complexity:**

**IF simple:** Instantiate template steps 1:1 as task nodes. No supplementary nodes.

**IF standard:** Instantiate template steps. Add constraint-handling nodes where
scope_artifact.constraints exist (e.g., date filtering, exclusion criteria).

**IF complex:** Instantiate template steps. Add constraint nodes. If the pattern
composes sub-patterns, instantiate sub-template steps and consolidate shared steps
(e.g., two cohort extraction steps that share a data source become one).

> **At task_count approaching 50:** Consolidate low-complexity adjacent nodes of the
> same task_type into a single node. Log consolidation decisions.

**Checkpoint:**
> - [ ] Assert: Each task node has task_id, task_type, description, input_requirements
> - [ ] Assert: task_count <= 50
> - [ ] PASS: All template steps represented by at least one task node
> - [ ] HALT: task_count > 50 after consolidation -- "Scope too complex for single plan. Consider splitting."
> - [ ] WARN: Consolidation was applied -- log which nodes were merged

---

### Step 3 -- Match Skills from Registry

**Goal:** Link each task node to an executable skill or flag as novel.

**Pre-step assertion:** task_nodes array is populated with all required fields.

**Actions:**

```
skill_gaps = []
novel_tasks = []
playbook_gaps = []

TOOL_TYPE_MAP = {
  "ingestion":       ["ingestion"],
  "profiling":       ["ingestion"],
  "population":      ["ingestion"],
  "transformation":  ["transformation"],
  "exploration":     ["exploration"],
  "analysis":        ["statistical_testing"],
  "valuation":       ["modeling"],
  "synthesis":       ["delivery"]
}

FOR each task_node in task_nodes:
  # Skill matching
  candidates = skill_registry.search(
    task_type = task_node.task_type,
    input_types = task_node.input_requirements,
    output_type = task_node.output_type
  )
  IF len(candidates) >= 1:
    task_node.skill_ref = best_match(candidates)  # highest input/output compatibility
  ELSE:
    task_node.skill_ref = null
    task_node.requires_human_review = true
    skill_gaps.append(task_node.task_type)
    novel_tasks.append(task_node.task_id)

  # Assign tool_types_needed from task_type mapping
  task_node.tool_types_needed = TOOL_TYPE_MAP[task_node.task_type]

  # Attempt playbook matching
  playbook = playbook_registry.search(
    analytical_pattern = scope_artifact.analytical_pattern,
    task_type = task_node.task_type
  )
  IF playbook is not null:
    task_node.playbook_ref = playbook.id
  ELSE:
    task_node.playbook_ref = null
    playbook_gaps.append(task_node.task_type)
```

**Classify skill_coverage:**
```
IF len(skill_gaps) == 0 -> skill_coverage = "full"
ELSE -> skill_coverage = "partial"
```

**Checkpoint:**
> - [ ] Assert: Every task node has skill_ref set or requires_human_review == true
> - [ ] Assert: Every task node has tool_types_needed populated
> - [ ] PASS: skill_coverage == "full" -- all tasks matched
> - [ ] WARN: skill_coverage == "partial" -- "{len(skill_gaps)} tasks have no matching skill: {novel_tasks}"
> - [ ] WARN: playbook_gaps non-empty -- "{len(playbook_gaps)} task types have no known playbook"

---

### Step 4 -- Handle Scope Extensions

**Goal:** Ensure scope requirements not covered by the base template have task nodes.

**Pre-step assertion:** task_nodes cover all template steps; scope_artifact is loaded.

**Actions:**

```
covered_requirements = set of scope_dimensions addressed by existing task_nodes
all_requirements = set of scope_dimensions + constraints from scope_artifact

uncovered = all_requirements - covered_requirements

FOR each uncovered requirement:
  create supplementary task node:
    task_id: next sequential TN-NNN
    task_type: inferred from requirement type
    description: "Handle scope extension: {requirement}"
    estimated_complexity: medium
  attempt skill match (same as Step 3)

assert total task_count <= 50
```

**Checkpoint:**
> - [ ] Assert: all scope_dimensions covered by at least one task node
> - [ ] PASS: scope_coverage == "complete"
> - [ ] WARN: Supplementary nodes added -- log count and descriptions
> - [ ] HALT: task_count > 50 after extensions -- "Cannot fit all requirements within 50-task limit."

---

### Step 5 -- Validate and Write Terminal Artifact

**Goal:** Final validation and artifact generation.

**Pre-step assertion:** task_nodes array is complete with skill matching done.

**Actions:**

```
validate:
  - every scope_dimension has at least one covering task node
  - no duplicate task_ids
  - task_count >= 1 and <= 50
  - all task_nodes have required fields

generate artifact_id (uuid v4)
write task_node_list.json
```

**Checkpoint:**
> - [ ] Assert: task_node_list.json is valid JSON
> - [ ] Assert: record_count matches task_nodes array length
> - [ ] PASS: Artifact written successfully
> - [ ] HALT: Validation failure -- "{exact condition}"

---

## Terminal Artifact

**File:** `task_node_list.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "task-decomposition",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 9,
  "artifact_id": "{uuid}",
  "scope_artifact_id": "{uuid}",
  "task_nodes": [
    {
      "task_id": "TN-001",
      "task_type": "ingestion",
      "description": "Extract and profile customer data from warehouse",
      "skill_ref": "data-retrieval",
      "input_requirements": ["connection_config", "scope_artifact"],
      "output_type": "raw_dataset",
      "estimated_complexity": "low",
      "requires_human_review": false,
      "tool_types_needed": ["ingestion"],
      "playbook_ref": "playbook-data-ingestion-compare"
    },
    {
      "task_id": "TN-002",
      "task_type": "population",
      "description": "Extract treatment population based on scope criteria",
      "skill_ref": "cohort-extraction",
      "input_requirements": ["raw_dataset", "scope_artifact"],
      "output_type": "cohort_dataset",
      "estimated_complexity": "medium",
      "requires_human_review": false,
      "tool_types_needed": ["ingestion"],
      "playbook_ref": null
    }
  ],
  "decomposition_metadata": {
    "template_used": "compare",
    "total_tasks": 9,
    "scope_complexity": "standard",
    "skill_coverage": "full",
    "skill_gaps": [],
    "novel_tasks": [],
    "playbook_gaps": [],
    "scope_coverage": "complete",
    "consolidations_applied": 0
  }
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | scope_artifact has no scope_dimensions | HALT: "scope_artifact has no scope_dimensions. Nothing to decompose." |
| Single record | scope_artifact has exactly 1 scope_dimension | WARN: "Single scope dimension -- template may produce minimal task list." Proceed. |
| All-null dimension | analytical_pattern is null or empty | HALT: "analytical_pattern is null. Cannot select CGF template." |
| Schema mismatch | schema_version != "1.0" | HALT: "Upstream schema_version mismatch: expected 1.0, got {value}." |
| No approved_at | approved_at field missing or null | HALT: "scope_artifact not approved. Human approval required." |
| Skill registry empty | skill_registry returns 0 skills | WARN: "Skill registry empty -- all tasks flagged as novel." Set skill_coverage = "partial". |
| Pattern not in CGF | analytical_pattern not in template map | HALT: "Unrecognized analytical_pattern: {value}. No CGF template available." |
| Task count exceeds 50 | len(task_nodes) > 50 after consolidation | HALT: "Task count {N} exceeds 50-task limit. Scope must be simplified." |

---

## Postconditions

After successful completion, this skill guarantees:

- [ ] `task_node_list.json` exists and is valid JSON
- [ ] Every task node has a unique task_id in TN-NNN format
- [ ] Every scope_dimension from scope_artifact is covered by at least one task node
- [ ] task_count >= 1 and <= 50
- [ ] Every task node has skill_ref set or requires_human_review == true
- [ ] Every task node has tool_types_needed populated
- [ ] Terminal artifact contains all 5 universal envelope fields
- [ ] scope_artifact_id traces back to the source scope_artifact

---

## Quality Bar

This skill run is "done" when ALL of the following are true:

- [ ] All Step 0 upstream assertions passed
- [ ] CGF template selected matches scope's analytical_pattern
- [ ] Every task node has task_id, task_type, description, skill_ref (or null), estimated_complexity
- [ ] All scope_dimensions are covered (scope_coverage == "complete")
- [ ] task_count <= 50
- [ ] Novel tasks (if any) have requires_human_review == true and appear in novel_tasks list
- [ ] Terminal artifact validates: schema_version, skill_name, timestamp, record_count, artifact_id present
- [ ] decomposition_metadata accurately reflects the run

---

## Scope Boundary

This skill does NOT:

- Resolve dependencies between tasks -> handled by `dependency-resolution`
- Allocate iteration budgets or resource constraints -> handled by `budget-allocation`
- Format the plan for human approval -> handled by `plan-formatting`
- Execute any analytical work (ingestion, profiling, modeling) -> handled by Analyze Phase skills
- Interact with the user or request clarification -> handled by Define Agent (scope-extraction)
- Validate or approve the scope itself -> handled by `completeness-validation` and human approval

---

## Downstream

Run after this skill completes:

1. **`dependency-resolution`** -- Consumes `task_node_list.json` to build execution order. Reads `task_nodes` array, `task_id`, `task_type`, `input_requirements`, and `output_type` to identify data flow dependencies and construct the execution DAG.
