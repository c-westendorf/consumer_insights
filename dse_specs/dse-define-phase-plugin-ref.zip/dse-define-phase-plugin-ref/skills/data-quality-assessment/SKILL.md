---
name: data-quality-assessment
description: >
  Diagnostic gate that scores data fitness across four dimensions — completeness, consistency,
  freshness, and distributional health — using profiled_schema statistics plus targeted SQL
  queries against the warehouse temp table. Produces a quality_report with a composite fitness
  score, per-column issue log, and a remediation_manifest that prescribes exactly what
  data-remediation must fix. Blocks the pipeline with HALT when blocking issues are found or
  the composite score falls below threshold. Activate immediately after schema-profiling
  completes — this is the first hard quality gate in the DAG and must pass before any
  population definition, feature engineering, or analysis can proceed.
inputs:
  - type: raw_dataset
    description: "Extraction artifact — provides data_ref (temp table), row_count, column manifest, and source provenance for coverage and volume validation"
  - type: profiled_schema
    description: "Schema profile from schema-profiling — provides null_rate, cardinality, column_role, and temporal grain for all columns; consumed directly to avoid recomputing stats already available"
  - type: scope_artifact
    description: "Approved scope — provides population definition and timeframe to validate that extracted data covers the expected population and time window"
  - type: quality_report
    description: "(Optional) Prior quality_report artifact from a previous run — enables distribution drift detection via KS-test (numeric) and chi-squared (categorical); absent on first run, which establishes the baseline"
outputs:
  - type: quality_report
    description: "Quality gate verdict (PASS/CONDITIONAL_PASS/FAIL), per-dimension scores, per-column issue log, drift metrics, remediation_manifest with severity-classified issues, and downstream permissions"
can_follow: [schema-profiling]
can_precede: [data-remediation, cohort-extraction]
supports_loop: false
exit_conditions:
  - "quality_report artifact written with verdict one of: PASS | CONDITIONAL_PASS | FAIL"
  - "remediation_manifest populated (empty list if no issues found)"
  - "composite_fitness_score between 0 and 100"
---

## Overview

Bad data corrupts analysis silently. A dataset with 35% null revenue or a 2-month staleness
lag produces outputs that pass structural tests while misleading every downstream decision.
This skill is the pipeline's first hard gate — it asks "is this data safe to use?" before
any irreversible step (cohort definition, feature construction, metric computation).

**What makes this skill different from schema-profiling:** Schema-profiling describes
structure — types, cardinality, temporal grain. This skill makes fitness judgments —
whether the data is good enough to trust for the declared analytical purpose. It consumes
the profiled_schema's structural statistics as direct inputs (avoiding redundant computation)
and supplements them with targeted SQL queries for dimensions schema-profiling doesn't cover:
cross-field consistency, population coverage relative to scope expectations, and
outlier concentration.

**The remediation_manifest is this skill's key output for the pipeline:** It doesn't just
report problems — it prescribes fixes with enough information for `data-remediation` to
execute them without additional analysis. Every issue entry includes `severity` (blocking vs
advisory), `recommended_remediation` (the strategy to apply), and `remediation_params`
(the parameters data-remediation needs to execute the strategy).

---

## When to Activate

- `profiled_schema.json` exists after `schema-profiling` completes
- A plan task node with `task_type: "data_quality_assessment"` is the next unexecuted task
- A prior `quality_report.json` exists and data has been refreshed (re-assess fitness)
- Downstream skills (`cohort-extraction`, `feature-engineering`) are about to run and no
  current quality_report exists
- User explicitly requests "run the quality gate" or "check data quality"

---

## Preconditions

What must be true before this skill begins:
- [ ] `raw_dataset.json` exists with `schema_version == "1.0"` and `row_count > 0`
- [ ] `profiled_schema.json` exists with `schema_version == "1.0"` and non-empty `columns`
- [ ] `profiled_schema.raw_dataset_artifact_id` matches `raw_dataset.artifact_id` (same lineage)
- [ ] `scope_artifact.json` exists with `approved_at` set
- [ ] The temp table named in `raw_dataset.data_ref` still exists in the warehouse session
- [ ] If `quality_report.json` (prior) is provided: its `schema_version == "1.0"`

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 1 — Domain core
# (none — scoring via warehouse SQL + profiled_schema stats)

# Tier 2 — Domain optional
snowflake-connector-python>=3.0   # used when platform == "snowflake"
google-cloud-bigquery>=3.0        # used when platform == "bigquery"

# Tier 3 — Skill-specific
scipy>=1.11                       # KS-test and chi-squared for drift detection
numpy>=1.24                       # statistical computations

# Tier 4 — Infrastructure
# Python version: >=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only for scoring; targeted SQL aggregates run in warehouse
- **Memory:** <200 MB (artifact JSON + drift statistics)
- **Upstream Artifacts:** `raw_dataset.json`, `profiled_schema.json`, `scope_artifact.json`,
  optionally `quality_report.json` (prior run)
- **Credentials:** Same platform credentials used by data-retrieval

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `gate_context` | `production` / `exploratory` | production: HALT on blocking issues or composite < 60; exploratory: WARN only, never HALT on fitness verdict (halts only on precondition violations) |
| `prior_report_available` | `has_prior` / `no_prior` | has_prior: Step 5 runs full KS-test + chi-squared drift analysis; no_prior: Step 5 skipped, current run establishes baseline |
| `data_volume` | `small` / `large` | large (≥1M rows): distributional checks use warehouse APPROX_PERCENTILE rather than exact percentiles; drift detection samples 500K rows |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify gate_context: read scope_artifact.analytical_pattern
  IF analytical_pattern in ["compare", "predict", "explain"] → "production"
  IF analytical_pattern in ["profile", "segment"] → "exploratory"
  IF analytical_pattern not set or unknown → default "production" with WARN
  log: "gate_context={value} — production gates HALT on blocking issues; exploratory WARNs only"

classify prior_report_available:
  IF quality_report.json exists in project directory → "has_prior"
  ELSE → "no_prior"

classify data_volume: read raw_dataset.row_count (already available in profiled_schema.data_volume)
  IF row_count < 1,000,000 → "small"
  IF row_count >= 1,000,000 → "large"

log: "Running data-quality-assessment | gate_context={value} | prior_report={value} | data_volume={value}"
```

**Upstream Validation:**
```
load raw_dataset.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF numeric: HALT: "Upstream validation failed: raw_dataset.json — schema_version is a number
  ({actual}), expected string '1.0'. Re-run data-retrieval."
  IF wrong string: HALT: "Upstream validation failed: raw_dataset.json — schema_version is
  '{actual}', expected '1.0'. Re-run data-retrieval."
assert row_count > 0
  IF not: HALT: "Upstream validation failed: raw_dataset.json — row_count is 0. Cannot assess
  quality of empty dataset."
assert data_ref is not null
  IF null: HALT: "Upstream validation failed: raw_dataset.json — data_ref missing. Re-run
  data-retrieval."

load profiled_schema.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: profiled_schema.json — schema_version mismatch.
  Re-run schema-profiling."
assert columns is non-empty list
  IF empty: HALT: "Upstream validation failed: profiled_schema.json — no columns profiled.
  Re-run schema-profiling."
assert raw_dataset_artifact_id == raw_dataset.artifact_id
  IF mismatch: HALT: "Upstream validation failed: profiled_schema was built from a different
  raw_dataset (profiled: {profiled_id}, current: {raw_id}). Re-run schema-profiling on the
  current raw_dataset."

load scope_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."
assert approved_at is not null
  IF null: HALT: "Upstream validation failed: scope_artifact.json — not approved. Run /scope."

IF prior quality_report provided:
  assert type(schema_version) is string AND schema_version == "1.0"
    IF not: HALT: "Upstream validation failed: prior quality_report — schema_version mismatch.
    Delete the stale report and re-run."
```

---

### Step 1 — Completeness Assessment

**Goal:** Score data completeness using profiled_schema null_rate values; supplement with
population coverage check against scope_artifact expectations.

**Key principle:** `profiled_schema` already has `null_rate` per column — consume it directly
rather than recomputing from the warehouse.

**Pre-step assertion:** profiled_schema.columns loaded with null_rate populated for all columns.

**Actions:**
```
For each column in profiled_schema.columns:
  null_rate = column.null_rate (from profiled_schema — already computed)
  
  classify completeness severity:
    IF null_rate == 0.0 → no issue
    IF null_rate > 0.0 AND ≤ 0.05 → advisory: "Low null rate — document but don't block"
    IF null_rate > 0.05 AND ≤ 0.30 → advisory (if role=="dimension|measure") or
                                      blocking (if role=="identifier|temporal")
    IF null_rate > 0.30 → blocking (regardless of role)

  For identifier and temporal columns: any null_rate > 0.0 → blocking (join keys and
  time anchors cannot have missingness without corrupting downstream joins and aggregations)

Population coverage check:
  expected_population_size = scope_artifact.population.size_estimate (if available)
  actual_row_count = raw_dataset.row_count
  IF expected_population_size is set:
    coverage_ratio = actual_row_count / expected_population_size
    IF coverage_ratio < 0.5: blocking — "Extraction captured only {coverage_ratio:.0%} of
      expected population. Verify extraction criteria."
    IF coverage_ratio < 0.8: advisory — "Extraction below 80% of expected population."

Compute completeness_score (0–100):
  base = 100
  deduct 5 per advisory issue (max deduct 30)
  deduct 20 per blocking issue (max deduct 60)
  completeness_score = max(0, base - deductions)
```

**Checkpoint:**
> - [ ] PASS: all columns scored; completeness_score computed
> - [ ] WARN: any advisory null rate > 0.05 on non-critical columns
> - [ ] Blocking issues logged to remediation_manifest

---

### Step 2 — Consistency Assessment

**Goal:** Verify referential integrity (FK columns point to valid values), cross-field logic
(no contradictory field combinations), and type conformance.

**Pre-step assertion:** profiled_schema.join_candidates available (may be empty).

**Actions:**
```
Type conformance check:
  For each column: verify normalized_type in profiled_schema matches expected_type from
  scope_artifact constraints (if constraints list is non-empty).
  IF mismatch: blocking — "Column {name} has type {actual}, scope expects {expected}."

Null covariance check (identifier columns only):
  For each identifier-role column:
    SQL: SELECT COUNT(*) FROM {data_ref} WHERE {id_col} IS NULL AND {fk_col} IS NOT NULL
  IF count > 0: blocking — "Parent key {id_col} is null where FK {fk_col} is present —
    referential integrity violation."

Constant column check:
  For each column where cardinality == 1 (from profiled_schema):
    advisory — "Column {name} has only 1 distinct value — zero variance, no analytical signal."

Duplicate identifier check (for primary key candidates):
  SQL: SELECT COUNT(*) - COUNT(DISTINCT {pk_col}) AS duplicate_count FROM {data_ref}
  IF duplicate_count > 0:
    IF duplicate_count / row_count > 0.01: blocking — "PK column {name} has {N} duplicates"
    ELSE: advisory — "PK column {name} has {N} duplicates (<1%)"

Compute consistency_score (0–100): same deduction logic as Step 1
```

**Checkpoint:**
> - [ ] PASS: consistency checks complete
> - [ ] WARN: advisory consistency violations (zero variance, minor duplicates)
> - [ ] Blocking issues logged to remediation_manifest

---

### Step 3 — Freshness Assessment

**Goal:** Score data freshness using `profiled_schema.temporal_columns.freshness_lag_days`;
verify temporal coverage against scope_artifact timeframe.

**ONLY runs with substance if temporal_presence == "has_temporal". If no_temporal: assign
freshness_score = 100 and log "No temporal columns — freshness not applicable."**

**Actions:**
```
For each temporal column in profiled_schema.temporal_columns:
  freshness_lag_days = column.freshness_lag_days (from profiled_schema — days since data max date)
  date_range = column.date_range

  Compute scope-relative freshness:
    scope_end_lag_days = DATEDIFF(today, scope_artifact.timeframe.end)
      NOTE: scope_end_lag_days > 0 for historical analyses (scope ended in the past).
            For a 2025 calendar year scope reviewed in April 2026, scope_end_lag_days ≈ 99.
    data_lag_beyond_scope = max(0, freshness_lag_days - scope_end_lag_days)
      NOTE: data_lag_beyond_scope > 0 means the data ends BEFORE scope.timeframe.end —
            the extraction didn't capture the full declared window.

  Classify freshness (scope-relative):
    IF data_lag_beyond_scope == 0 AND date_range.max >= scope_artifact.timeframe.end:
      no freshness issue — data covers the full scope window
    IF data_lag_beyond_scope > 0 AND data_lag_beyond_scope ≤ 14:
      advisory: "Data ends {data_lag_beyond_scope} days before scope end —
      {data_lag_beyond_scope} days of coverage missing."
    IF data_lag_beyond_scope > 14:
      blocking: "Data ends {data_lag_beyond_scope} days before scope end — significant
      coverage gap. Re-run data-retrieval with corrected timeframe."

  Also check live data freshness (current-period scopes only):
    IF scope_end_lag_days == 0 (scope is an ongoing/current period):
      IF freshness_lag_days > 3 AND ≤ 30: advisory — "Live data is {N} days stale."
      IF freshness_lag_days > 30: blocking — "Live data is {N} days stale — exceeds
        30-day threshold."

  Timeframe coverage check:
    IF gap_count > 0 (from profiled_schema): advisory — "{gap_count} temporal gaps detected.
      Time-series analysis may be unreliable."

Compute freshness_score (0–100): same deduction logic
```

**Checkpoint:**
> - [ ] PASS: freshness scored (or N/A for no_temporal)
> - [ ] WARN: advisory freshness lag
> - [ ] Blocking: >90 day lag logged to remediation_manifest

---

### Step 4 — Distributional Health Assessment

**Goal:** Detect outlier concentration and unexpected cardinality shifts in numeric and
categorical columns.

**Pre-step assertion:** data_ref accessible; data_volume classification available.

*Branch on data_volume:*

**IF `small` (<1M rows): exact percentile computation**
```sql
SELECT
  PERCENTILE_CONT(0.01) WITHIN GROUP (ORDER BY {col}) AS p01,
  PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY {col}) AS p99,
  COUNT(CASE WHEN {col} < PERCENTILE_CONT(0.01) WITHIN GROUP (ORDER BY {col})
              OR {col} > PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY {col}) THEN 1 END)
    * 1.0 / COUNT(*) AS extreme_rate
FROM {data_ref}
WHERE {col} IS NOT NULL;
```

**IF `large` (≥1M rows): approximate percentiles — platform-specific syntax**

```sql
-- Snowflake (source_platform == "snowflake"):
SELECT
  APPROX_PERCENTILE({col}, 0.01) AS p01,
  APPROX_PERCENTILE({col}, 0.99) AS p99,
  SUM(CASE WHEN {col} < APPROX_PERCENTILE({col}, 0.01)
            OR {col} > APPROX_PERCENTILE({col}, 0.99) THEN 1 ELSE 0 END)
    * 1.0 / COUNT(*) AS extreme_rate
FROM {data_ref}
WHERE {col} IS NOT NULL;
```

```sql
-- BigQuery (source_platform == "bigquery"):
SELECT
  APPROX_QUANTILES({col}, 100)[OFFSET(1)] AS p01,
  APPROX_QUANTILES({col}, 100)[OFFSET(99)] AS p99,
  COUNTIF({col} < APPROX_QUANTILES({col}, 100)[OFFSET(1)]
       OR {col} > APPROX_QUANTILES({col}, 100)[OFFSET(99)]) * 1.0 / COUNT(*) AS extreme_rate
FROM {data_ref}
WHERE {col} IS NOT NULL;
```

NOTE: Platform is read from `raw_dataset.source_platform`. These two functions have
different signatures: Snowflake uses `APPROX_PERCENTILE(col, quantile_fraction)`;
BigQuery uses `APPROX_QUANTILES(col, num_buckets)[OFFSET(bucket_index)]`.

**For categorical/dimension columns:**
```
For each column with column_role == "dimension":
  expected_cardinality = profiled_schema column.cardinality (established at profile time)
  NOTE: On first run there is no prior baseline — skip cardinality drift check.
        Cardinality drift detected in Step 5 if prior report available.
```

**Outlier classification:**
```
For each numeric column (column_role == "measure"):
  IF extreme_rate > 0.05: blocking — "{col} has {N:.1%} extreme values outside [p1,p99]"
  IF extreme_rate > 0.02: advisory — "{col} has {N:.1%} values in distribution tails"

Compute distributional_score (0–100): same deduction logic
```

**Checkpoint:**
> - [ ] PASS: all numeric columns profiled for outlier rates
> - [ ] WARN: advisory outlier rates (2–5%)
> - [ ] Blocking: outlier rate > 5% logged to remediation_manifest

---

### Step 5 — Distribution Drift Detection

**ONLY runs if prior_report_available == "has_prior". Skip if no_prior — current run establishes baseline.**

**Goal:** Detect if the current data distribution has shifted significantly versus the
baseline established in the prior quality_report.

**Pre-step assertion:** prior quality_report loaded in Step 0.

**Actions:**
```
For each numeric column in profiled_schema.columns (role == "measure"):
  Load prior_distribution baseline from quality_report.column_stats[column]
  Run KS-test: ks_statistic, p_value = scipy.stats.ks_2samp(current_sample, prior_sample)
  IF p_value < 0.01 AND ks_statistic > 0.1:
    advisory — "Distribution drift detected on {column}: KS={ks:.3f}, p={p:.4f}"

For each categorical column (role == "dimension"):
  Load prior value_counts from quality_report.column_stats[column]
  Run chi-squared test on frequency distributions
  IF p_value < 0.01:
    advisory — "Categorical distribution shifted on {column}: chi2 p={p:.4f}"

Multi-column drift flag:
  IF 3+ columns show statistically significant drift:
    blocking — "Multi-column drift detected ({N} columns). Suspect upstream ETL or schema
    change. Halt and investigate before proceeding."

Volume drift check:
  prior_row_count = prior quality_report.record_count (or a numeric equivalent)
  current_row_count = raw_dataset.row_count
  volume_change = (current_row_count - prior_row_count) / prior_row_count
  IF abs(volume_change) > 0.20:
    blocking — "Volume changed {volume_change:+.0%} vs prior run. Possible ETL truncation or
    duplication. Halt and verify upstream source."

NOTE: Drift checks for large datasets sample 500K rows from the warehouse temp table
to avoid full-table scans. Samples use stratified random sampling where possible.
```

**Checkpoint:**
> - [ ] PASS: drift analysis complete (or skipped with no_prior)
> - [ ] WARN: individual column drift (advisory)
> - [ ] Blocking: multi-column drift or volume anomaly logged to remediation_manifest

---

### Step 6 — Composite Scoring, Remediation Manifest, and Verdict

**Goal:** Compute composite fitness score, build the remediation manifest, issue the
pipeline verdict, and determine whether to HALT.

**Actions:**
```
Compute composite_fitness_score:
  weights: completeness=0.30, consistency=0.25, freshness=0.20, distributional=0.25
  composite_fitness_score = (completeness_score * 0.30 +
                             consistency_score * 0.25 +
                             freshness_score * 0.20 +
                             distributional_score * 0.25)

Build remediation_manifest:
  For each blocking and advisory issue collected across Steps 1–5:
    {
      "issue_id": "RM-{N:03d}",
      "column": column_name or "__dataset__" for dataset-level issues,
      "dimension": "completeness|consistency|freshness|distributional|drift",
      "severity": "blocking|advisory",
      "description": issue description,
      "recommended_remediation": one of:
        "impute_mean" | "impute_median" | "impute_mode" | "impute_model" |
        "cap_outliers" | "deduplicate" | "type_coerce" | "drop_column" | "investigate",
      "remediation_params": {strategy-specific parameters for data-remediation to execute}
    }

Determine verdict:
  blocking_count = count of items in remediation_manifest where severity == "blocking"

  IF gate_context == "production":
    IF blocking_count > 0 OR composite_fitness_score < 60:
      verdict = "FAIL"
      allowed_downstream_skills = ["data-remediation"]
      NOTE: Do NOT HALT here — proceed to Step 7 to write the artifact first.
            HALT fires at the end of Step 7, after quality_report.json is written,
            so data-remediation can read the remediation_manifest.
    IF blocking_count == 0 AND composite_fitness_score >= 60 AND composite_fitness_score < 80:
      verdict = "CONDITIONAL_PASS"
      allowed_downstream_skills = ["data-remediation", "cohort-extraction"]
    IF composite_fitness_score >= 80:
      verdict = "PASS"
      allowed_downstream_skills = ["data-remediation", "cohort-extraction", "feature-engineering"]

  IF gate_context == "exploratory":
    verdict = "CONDITIONAL_PASS" (always — exploratory gate never halts on fitness verdict)
    allowed_downstream_skills = ["cohort-extraction", "feature-engineering", "exploratory-analysis"]
    NOTE: Blocking issues are documented but do not halt exploratory analysis.

Log: "Verdict: {verdict} | composite={score:.0f} | blocking={N} | advisory={M}"
```

**Checkpoint:**
> - [ ] PASS: verdict assigned; remediation_manifest built; composite_fitness_score computed
> - [ ] HALT: FAIL verdict in production gate context
> - [ ] WARN: CONDITIONAL_PASS with advisory issues

---

### Step 7 — Write Terminal Artifact

**Goal:** quality_report artifact written with verdict, all scores, issues, and remediation manifest.

**Actions:**
```
Generate artifact_id: UUID v4
Write quality_report.json with all fields in Terminal Artifact spec
Log: "quality_report written | verdict={verdict} | score={score:.0f} | issues={N}"

AFTER artifact write:
  IF verdict == "FAIL" AND gate_context == "production":
    HALT: "Quality gate FAILED: {blocking_count} blocking issues,
    composite_fitness_score={score:.0f}. Run data-remediation — the remediation_manifest
    in quality_report.json prescribes all required fixes."
    NOTE: HALT fires after artifact write so data-remediation can read the remediation_manifest.
```

**Checkpoint:**
> - [ ] PASS: quality_report.json written; all 5 universal envelope fields present
> - [ ] HALT (verdict=FAIL, production): fires AFTER artifact write — data-remediation can read quality_report.json
> - [ ] HALT (write failure): "Could not write quality_report.json: {error}"

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "data-quality-assessment",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 84729,
  "artifact_id": "{uuid}",
  "verdict": "CONDITIONAL_PASS",
  "gate_context": "production",
  "composite_fitness_score": 74.2,
  "dimension_scores": {
    "completeness": 82.0,
    "consistency": 95.0,
    "freshness": 40.0,
    "distributional": 88.0
  },
  "blocking_issue_count": 0,
  "advisory_issue_count": 3,
  "allowed_downstream_skills": ["data-remediation", "cohort-extraction"],
  "raw_dataset_artifact_id": "{raw_dataset.artifact_id}",
  "profiled_schema_artifact_id": "{profiled_schema.artifact_id}",
  "scope_artifact_id": "{scope_artifact.artifact_id}",
  "prior_report_artifact_id": null,
  "drift_detected": false,
  "remediation_manifest": [
    {
      "issue_id": "RM-001",
      "column": "transaction_date",
      "dimension": "freshness",
      "severity": "advisory",
      "description": "transaction_date is 99 days stale — exceeds 30-day advisory threshold",
      "recommended_remediation": "investigate",
      "remediation_params": {"freshness_lag_days": 99, "threshold": 30}
    },
    {
      "issue_id": "RM-002",
      "column": "revenue",
      "dimension": "distributional",
      "severity": "advisory",
      "description": "3.2% of revenue values outside [p1, p99] bounds",
      "recommended_remediation": "cap_outliers",
      "remediation_params": {"strategy": "winsorize", "p_lower": 0.01, "p_upper": 0.99}
    }
  ],
  "column_stats": {
    "revenue": {
      "sample_values": [12.50, 45.00, 120.00],
      "p01": 1.99,
      "p99": 489.00,
      "extreme_rate": 0.032
    }
  },
  "profiling_notes": [
    "freshness_lag_days=99 on transaction_date — data may not cover scope timeframe end"
  ]
}
```

**Write to:** `quality_report.json` in the project directory.

**Field: `record_count`** = row count of the assessed dataset (same as `raw_dataset.row_count`).

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty dataset (0 rows) | `raw_dataset.row_count == 0` | HALT Step 0: "Cannot assess quality of empty dataset. Re-run data-retrieval." |
| All columns 100% null | all null_rates == 1.0 in profiled_schema | HALT Step 1: "All columns are 100% null — data extraction likely failed. Re-run data-retrieval." |
| Single column | column_count == 1 | WARN Steps 2–4: consistency and distributional checks severely limited with only 1 column; proceed with reduced scoring |
| FAIL verdict in exploratory gate | gate_context=exploratory + blocking issues | Document blocking issues in remediation_manifest; set verdict=CONDITIONAL_PASS; do NOT HALT |
| Multi-column drift (3+) | Step 5: 3+ columns show KS p<0.01 | blocking: halt pipeline with "Multi-column drift detected" — suspect ETL or schema change |
| No temporal columns | temporal_presence=no_temporal from profiled_schema | freshness_score = 100; Step 3 notes "Not applicable — no temporal columns" |
| Lineage mismatch | profiled_schema.raw_dataset_artifact_id ≠ raw_dataset.artifact_id | HALT Step 0: artifacts from different extractions — cannot assess consistently |
| Perfect scores (all dimensions ≥ 95) | composite_fitness_score ≥ 95 | WARN: "All quality dimensions near-perfect. Verify profiling ran on the correct dataset." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `quality_report.json` exists with all 5 universal envelope fields
- [ ] `verdict` is exactly one of: `PASS`, `CONDITIONAL_PASS`, `FAIL`
- [ ] `remediation_manifest` is a list (may be empty) with all required fields per entry
- [ ] `composite_fitness_score` is between 0 and 100 inclusive
- [ ] `allowed_downstream_skills` accurately reflects which next skills may run
- [ ] `column_stats` is populated for drift baseline use in the next run
- [ ] All three source artifact IDs are linked for full lineage tracing

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] All four dimension scores computed and between 0–100
- [ ] `composite_fitness_score` is a weighted average of dimension scores (not a simple average)
- [ ] Every issue in `remediation_manifest` has `issue_id`, `severity`, `recommended_remediation`, and `remediation_params`
- [ ] `verdict` is correct per the gate_context rules (production gates block; exploratory never halts)
- [ ] `allowed_downstream_skills` accurately gates access to cohort-extraction and feature-engineering
- [ ] `data-remediation` Step 0 can load `quality_report.json` and read `remediation_manifest`

---

## Scope Boundary

This skill does NOT:
- Clean, impute, or transform data → handled by `data-remediation` (this skill only diagnoses
  and prescribes; it does not treat)
- Profile column types or cardinality → handled by `schema-profiling` (consumed here, not
  recomputed)
- Define or filter the customer population → handled by `cohort-extraction`
- Assign business meaning to data quality findings → handled by `business-context-layer`
- Run exploratory analysis or hypothesis generation → handled by `exploratory-analysis`

The boundary between this skill and `data-remediation` is diagnostic vs treatment:
this skill produces the `remediation_manifest` (the prescription); `data-remediation` executes it.

---

## Downstream

Run after this skill completes:
1. **`data-remediation`** (if FAIL or remediable CONDITIONAL_PASS) — reads `quality_report.json`,
   specifically `remediation_manifest`, to apply prescribed fixes and produce `remediated_dataset`
2. **`cohort-extraction`** (if PASS or CONDITIONAL_PASS with cohort-extraction in allowed list) —
   reads `quality_report.json` to verify it may proceed, then applies scope criteria to extract cohort
3. **Re-assess after remediation:** After `data-remediation` runs, this skill should be invoked
   again on the `remediated_dataset` to confirm blocking issues are resolved before feature engineering
