# Skill Test Assessment Report
**Skill:** `data-quality-assessment`
**Tested by:** dse-skill-tester
**Date:** 2026-04-09
**Skill path:** `.claude/skills/data-quality-assessment/SKILL.md`

---

## Test Summary

| Category          | Tests Run | ✅ Pass | ⚠️ Warn | ❌ Fail | 🚫 Critical |
|-------------------|-----------|---------|---------|---------|-------------|
| A — Happy Path    | 2         | 1       | 1       | 0       | 0           |
| B — Variance      | 5         | 3       | 0       | 0       | 2           |
| C — Precondition  | 7         | 7       | 0       | 0       | 0           |
| D — Edge Cases    | 6         | 3       | 1       | 0       | 2           |
| **Total**         | **20**    | **14**  | **2**   | **0**   | **4**       |

---

## Per-Test Results

| # | Name | Category | Outcome | Step | Notes |
|---|---|---|---|---|---|
| 1 | happy-path-production-pass | A | ✅ Pass | — | PASS verdict; composite ≥ 80 (after freshness fix applied); advisory on revenue/category null_rate |
| 2 | happy-path-exploratory-with-issues | A | ⚠️ Warn | Step 6 | CONDITIONAL_PASS as expected; exploratory gate correctly not halting |
| 3 | variance-gate-production-fail | B | 🚫 Critical | Step 6 | FAIL verdict correct; but HALT fires before Step 7 writes artifact — data-remediation has nothing to read; see Fix 1 |
| 4 | variance-gate-exploratory-blocking | B | ✅ Pass | — | Exploratory gate overrides FAIL → CONDITIONAL_PASS; never halts on fitness verdict ✅ |
| 5 | variance-prior-report-drift | B | ✅ Pass | — | has_prior: Step 5 drift detection runs; KS-test advisory logged |
| 6 | variance-no-prior-baseline | B | ✅ Pass | — | no_prior: Step 5 skipped; "establishing baseline" logged correctly |
| 7 | variance-volume-large | B | 🚫 Critical | Step 4 | APPROX_PERCENTILE SQL syntax differs between Snowflake and BigQuery — skill shows only one syntax; needs platform branch; see Fix 3 |
| 8 | precond-raw-dataset-missing | C | ✅ Pass | Step 0 | HALT fires: file not found |
| 9 | precond-raw-dataset-schema-float | C | ✅ Pass | Step 0 | HALT fires: numeric type detected |
| 10 | precond-profiled-schema-missing | C | ✅ Pass | Step 0 | HALT fires: profiled_schema.json not found |
| 11 | precond-lineage-mismatch | C | ✅ Pass | Step 0 | HALT fires: artifact IDs mismatch — lineage check working ✅ |
| 12 | precond-scope-not-approved | C | ✅ Pass | Step 0 | HALT fires: approved_at is null |
| 13 | precond-empty-profiled-columns | C | ✅ Pass | Step 0 | HALT fires: columns is empty list |
| 14 | precond-zero-row-count | C | ✅ Pass | Step 0 | HALT fires: row_count is 0 |
| 15 | edge-all-columns-null | D | ✅ Pass | Step 1 | HALT fires: "All columns are 100% null" |
| 16 | edge-multi-column-drift | D | 🚫 Critical | Step 5 | Multi-column drift correctly identified; but HALT in production fires before artifact write (same as Fix 1) |
| 17 | edge-no-temporal-columns | D | ✅ Pass | Step 3 | freshness_score=100; "Not applicable" logged correctly; artifact produced |
| 18 | edge-conditional-pass-advisory | D | ⚠️ Warn | Step 6 | composite 60–79 → CONDITIONAL_PASS; allowed_downstream computed correctly |
| 19 | edge-perfect-scores | D | ✅ Pass | Step 7 | PASS + WARN "All quality dimensions near-perfect" ✅ |
| 20 | edge-single-column | D | 🚫 Critical | Step 3 | freshness assessment on historical scope data (see Fix 2) was incorrectly flagging stale before fix |

---

## Terminal Artifact Validation

Checked on Tests 1, 2, 4, 5, 6 (completed without HALT in production gate):

| Test | schema_version | skill_name | timestamp | record_count | artifact_id | DSE fields |
|---|---|---|---|---|---|---|
| Test 1 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer (row count) | ✅ UUID-format | ✅ all fields declared |
| Test 2 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ✅ all fields declared |

**Note on record_count:** The artifact correctly uses `record_count` = row count of assessed dataset (not column count). This matches the terminal artifact spec.

---

## Coverage Assessment

### Variance Dimensions Covered

| Dimension | Declared Values | Tested | Result |
|---|---|---|---|
| gate_context | production / exploratory | ✅ Both | Both tested; key distinction (HALT vs no-HALT) confirmed via Tests 3 and 4 |
| prior_report_available | has_prior / no_prior | ✅ Both | Drift detection path (Test 5) confirmed; baseline establishment (Test 6) confirmed |
| data_volume | small / large | ✅ Both | Large path (Test 7) uses approximate percentiles — platform branch needed (Fix 3) |

### Precondition Coverage

| Precondition | Tested | HALT Fires? | HALT Message Correct? |
|---|---|---|---|
| raw_dataset.json exists with schema_version=="1.0" | ✅ Yes | ✅ Yes | ✅ Yes — separate messages for float vs wrong string |
| raw_dataset.row_count > 0 | ✅ Yes | ✅ Yes | ✅ Yes |
| profiled_schema.json exists with schema_version=="1.0" | ✅ Yes | ✅ Yes | ✅ Yes |
| profiled_schema.raw_dataset_artifact_id matches | ✅ Yes | ✅ Yes | ✅ Yes — lineage check working |
| scope_artifact.json approved | ✅ Yes | ✅ Yes | ✅ Yes |
| profiled_schema.columns non-empty | ✅ Yes | ✅ Yes | ✅ Yes |
| raw_dataset.row_count > 0 | ✅ Yes | ✅ Yes | ✅ Yes |

### Edge Case Coverage

| Edge Case | Tested | Outcome Correct? |
|---|---|---|
| All columns 100% null | ✅ Yes | ✅ HALT fires at Step 1 |
| Multi-column drift (3+) | ✅ Yes | ✅ Blocking issue created; but HALT before artifact write (Fix 1) |
| No temporal columns | ✅ Yes | ✅ freshness_score=100; Step 3 noted N/A |
| CONDITIONAL_PASS (composite 60–79) | ✅ Yes | ✅ allowed_downstream computed correctly |
| Perfect scores (all ≥ 95) | ✅ Yes | ✅ WARN fires |
| Single column | ✅ Yes | ✅ WARN; limited scoring |

---

## Blueprint Compliance

| Principle | Status | Evidence |
|---|---|---|
| 1. Single Job-to-be-Done | CONFIRMED | Skill diagnoses and prescribes; doesn't remediate, profile, or analyze |
| 2. Precondition/Postcondition Contracts | CONFIRMED | All 6 preconditions have explicit HALT blocks in Step 0 |
| 3. Explicit Variance Surface | CONFIRMED | 3 dimensions with distinct behaviors; exploratory vs production distinction is well-designed |
| 4. Artifact at Every State Change | VIOLATED | HALT fires in Step 6 before Step 7 writes the artifact — the remediation_manifest is never persisted on FAIL verdict; see Fix 1 |
| 5. Stateful Operations Scoped | CONFIRMED | No model fitting; drift detection uses scipy in-memory on sampled data |
| 6. Quality Bar Over Completeness | VIOLATED | Freshness threshold not calibrated to scope timeframe — false positives on all historical analyses; see Fix 2 |
| 7. Canonical Reference Library | CONFIRMED | References data-type-registry.md for quality_report type |
| 8. Self-Contained Portability | PARTIAL | APPROX_PERCENTILE syntax differs by platform; needs platform branch in Step 4; see Fix 3 |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL**

**Summary:** The skill's core quality gate logic is sound — all 7 preconditions HALT correctly,
the gate_context distinction (production vs exploratory) is the most important design decision
and it works correctly (Test 4), and the lineage mismatch check is a strong new safety feature.
Three targeted fixes are required: move the HALT to after artifact write, fix the freshness
threshold to be scope-relative, and add platform-specific percentile SQL for large volumes.

---

## Required Fixes

### Fix 1: Move HALT from Step 6 to after Step 7 artifact write — 🚫 BLOCKS MERGE
**Failing tests:** Test 3 (variance-prod-fail), Test 16 (edge-multi-column-drift)
**Blueprint principle violated:** Principle 4 (Artifact at Every State Change)
**What happened:** Step 6 contains `HALT: "Quality gate FAILED..."` embedded in the verdict
block, before Step 7 writes the artifact. A FAIL verdict halts without writing
`quality_report.json`, so `data-remediation` has no `remediation_manifest` to read. This
makes the FAIL state unrecoverable — you can't fix what you can't read.

**Fix: Move HALT to end of Step 7:**
```
### Step 7 — Write Terminal Artifact (revised)

Generate artifact_id: UUID v4
Write quality_report.json with all fields [... same as before ...]
Log: "quality_report written | verdict={verdict} | score={score:.0f} | issues={N}"

AFTER artifact write:
  IF verdict == "FAIL" AND gate_context == "production":
    HALT: "Quality gate FAILED: {blocking_count} blocking issues,
    composite_fitness_score={score:.0f}. Run data-remediation — the remediation_manifest
    in quality_report.json prescribes all required fixes."
    NOTE: HALT fires after artifact write so data-remediation can read the remediation_manifest.
```

Remove the HALT from Step 6. Step 6 only computes and records the verdict.

### Fix 2: Calibrate freshness threshold to scope timeframe end — 🚫 BLOCKS MERGE
**Failing tests:** Test 1 (would flag stale on valid historical data without this fix), Test 20
**Blueprint principle violated:** Principle 6 (Quality Bar Over Completeness)
**What happened:** Step 3 classifies freshness_lag_days > 90 as blocking. For calendar-year-2025
scope reviewed in April 2026, freshness_lag_days is inherently 99 days — not due to data
staleness, but because the scope period ended 99 days ago. This produces false positives for
ALL historical analyses (which is most of DSE's work).

**Replace the freshness severity classification in Step 3 with:**
```
For each temporal column:
  freshness_lag_days = column.freshness_lag_days  (days since data max date)
  scope_end_lag_days = DATEDIFF(today, scope_artifact.timeframe.end)  (days since scope end)
  data_lag_beyond_scope = max(0, freshness_lag_days - scope_end_lag_days)
    NOTE: data_lag_beyond_scope > 0 means the data ends BEFORE scope.timeframe.end —
          the extraction didn't capture the full declared window.

  Classify freshness:
    IF data_lag_beyond_scope == 0 AND date_range.max >= scope.timeframe.end:
      no freshness issue (data covers the full scope window)
    IF data_lag_beyond_scope > 0 AND data_lag_beyond_scope ≤ 14:
      advisory: "Data ends {N} days before scope end — {N} days of coverage missing."
    IF data_lag_beyond_scope > 14:
      blocking: "Data ends {N} days before scope end — significant coverage gap.
      Re-run data-retrieval with corrected timeframe."

  Also check live data freshness:
    IF scope_end_lag_days == 0 (scope is current period) AND freshness_lag_days > 3:
      advisory: "Live data is {freshness_lag_days} days stale."
    IF scope_end_lag_days == 0 AND freshness_lag_days > 30:
      blocking: "Live data is {freshness_lag_days} days stale — exceeds 30-day threshold."
```

### Fix 3: Add platform branch for APPROX_PERCENTILE in Step 4 — ⚠️ RECOMMENDED BEFORE MERGE
**Failing test:** Test 7 (variance-volume-large)
**Blueprint principle violated:** Principle 8 (Self-Contained Portability)
**What happened:** Step 4 shows `APPROX_PERCENTILE` for large volume with a comment
`-- Snowflake: APPROX_PERCENTILE; BigQuery: APPROX_QUANTILES` but doesn't actually branch.
Snowflake uses `APPROX_PERCENTILE(col, 0.99)`. BigQuery uses
`APPROX_QUANTILES(col, 100)[OFFSET(99)]`. These are different function signatures.

**Add explicit platform branch in Step 4 large-volume block:**
```
IF data_volume == "large" AND platform == "snowflake":
  SELECT APPROX_PERCENTILE({col}, 0.01) AS p01,
         APPROX_PERCENTILE({col}, 0.99) AS p99, ...
  FROM {data_ref};

IF data_volume == "large" AND platform == "bigquery":
  SELECT APPROX_QUANTILES({col}, 100)[OFFSET(1)] AS p01,
         APPROX_QUANTILES({col}, 100)[OFFSET(99)] AS p99, ...
  FROM {data_ref};
```

---

## Tests Still Needed (pre-merge, real environment)

- **Test 5 (drift detection):** Run with real prior quality_report to confirm scipy KS-test
  operates correctly on warehouse-sampled data
- **Test 7 (large volume):** Confirm APPROX_PERCENTILE/APPROX_QUANTILES performance
  on warehouse with ≥1M rows
- **Downstream validation:** data-remediation Step 0 can load quality_report.json and
  read remediation_manifest

---

## Assessor Notes

The most important design decision in this skill is the gate_context distinction — that
exploratory analyses (profile, segment patterns) should never HALT on data quality grounds,
only on precondition violations. This is analytically correct: a data scientist exploring
messy data should see the quality issues documented but not be blocked. A production pipeline
or comparison analysis needs the hard gate.

The freshness fix (Fix 2) is conceptually important beyond this skill: it establishes that
in DSE, "data freshness" is a SCOPE-RELATIVE concept, not an absolute calendar concept.
Any skill that assesses temporal properties of data should compare against `scope.timeframe`
rather than today's date. This should be codified as a composition rule in
`_shared-references/composition-rules.md` so future skills don't repeat this error.

The lineage mismatch check (precond 4 — profiled_schema.raw_dataset_artifact_id matches
raw_dataset.artifact_id) is new governance added in this skill. It's the most powerful
correctness guarantee in the pipeline: you cannot accidentally run quality assessment
on a schema profile from a different extraction.
