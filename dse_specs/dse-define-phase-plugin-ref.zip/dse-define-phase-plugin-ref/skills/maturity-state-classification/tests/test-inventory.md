# Test Inventory: maturity-state-classification

Generated: 2026-04-10
Skill version: SKILL.md (378 lines)

---

## Category A — Happy Path (3 tests)

| ID | Test Name | Variance Combo | Description | Expected Outcome |
|---|---|---|---|---|
| A1 | Full RFM, CGF defaults, trajectory available | cgf_default / true / all_three | Standard run with all 3 RFM dimensions, default thresholds, temporal data present | maturity_classification.json with 8 states, trajectory counts > 0, thresholds_applied = CGF defaults |
| A2 | Full RFM, CGF defaults, no trajectory | cgf_default / false / all_three | Standard run, no temporal comparison data | maturity_classification.json with 8 states, trajectory_annotation all zeros, WARN logged |
| A3 | Full RFM, scope custom, trajectory available | scope_custom / true / all_three | Custom threshold overrides from scope_artifact.constraints | maturity_classification.json with custom thresholds in thresholds_applied |

---

## Category B — Variance Coverage (8 tests)

Each variance dimension requires at least 2 values tested. 3 dimensions x 2 values = 6 minimum combinations.

| ID | Test Name | Dimension Tested | Value | Description | Expected Outcome |
|---|---|---|---|---|---|
| B1 | threshold_source = cgf_default | threshold_source | cgf_default | No scope overrides present | Thresholds match CGF defaults: recency at_risk=60, lapsed=365 |
| B2 | threshold_source = scope_custom (complete) | threshold_source | scope_custom | scope_artifact.constraints has full threshold overrides | Thresholds match custom values exactly |
| B3 | threshold_source = scope_custom (incomplete) | threshold_source | scope_custom | scope_artifact.constraints has partial overrides | WARN: incomplete thresholds; merged with CGF defaults |
| B4 | trajectory_available = true | trajectory_available | true | Feature set has period-over-period columns | trajectory_annotation has non-zero improving/stable/declining counts |
| B5 | trajectory_available = false | trajectory_available | false | Feature set is single snapshot, no temporal columns | trajectory_annotation = {improving: 0, stable: 0, declining: 0}; WARN logged |
| B6 | rfm_completeness = all_three | rfm_completeness | all_three | R, F, and M columns all present in feature_set | Full CASE classification with all 8 states possible |
| B7 | rfm_completeness = partial (R+F only) | rfm_completeness | partial | Only recency and frequency columns; no monetary | WARN: partial RFM; simplified classification SQL; artifact valid |
| B8 | rfm_completeness = partial (R only) | rfm_completeness | partial | Only recency column available | WARN: partial RFM; classification uses recency only; artifact valid |

---

## Category C — Precondition Violations (6 tests)

Each test PASSES only if HALT fires with the expected message. Silent continuation = FAIL.

| ID | Test Name | Violated Precondition | Input Condition | Expected HALT Message |
|---|---|---|---|---|
| C1 | Missing cohort.json | cohort.json exists | cohort.json does not exist | HALT (implicit — file load fails) |
| C2 | cohort schema mismatch | schema_version == "1.0" | cohort.json has schema_version "0.9" | "Upstream validation failed: cohort.json -- schema_version mismatch." |
| C3 | Empty cohort | population_size > 0 | cohort.json has population_size = 0 | "Upstream validation failed: cohort.json -- population_size=0." |
| C4 | feature_set schema mismatch | feature_set schema_version == "1.0" | feature_set.json has schema_version "2.0" | "Upstream validation failed: feature_set.json -- schema_version mismatch." |
| C5 | feature_set missing data_ref | data_ref is not null | feature_set.json has data_ref = null | "Upstream validation failed: feature_set.json -- data_ref missing." |
| C6 | No RFM dimensions at all | At least one RFM dimension exists | feature_set has no recency/frequency/monetary columns | "No RFM dimensions found in feature_set. Cannot classify maturity states." |

---

## Category D — Edge Cases (8 tests)

| ID | Test Name | Edge Case | Input Condition | Expected Behavior |
|---|---|---|---|---|
| D1 | Empty source (population = 0) | Empty source | cohort.population_size == 0 | HALT Step 0: "Cannot classify maturity on empty cohort." |
| D2 | Single customer | Single record | cohort with 1 customer | WARN: "Single customer -- state distribution is trivial." Artifact produced. |
| D3 | All-null RFM columns | All-null RFM | All R, F, M columns are 100% NULL | HALT: "All RFM dimension columns are NULL -- cannot classify." |
| D4 | Schema mismatch (cohort) | Schema mismatch | cohort.json schema_version != "1.0" | HALT Step 0 with artifact name |
| D5 | Schema mismatch (feature_set) | Schema mismatch | feature_set.json schema_version != "1.0" | HALT Step 0 with artifact name |
| D6 | All customers one state | Mono-state distribution | All customers classify as "lapsed" | WARN: "All customers classified as 'lapsed' -- verify thresholds." Artifact produced. |
| D7 | Custom thresholds invalid | Invalid custom thresholds | scope_custom thresholds have negative or zero values | HALT: "Invalid custom thresholds -- values must be positive." |
| D8 | No prior lapse data | Reactivation detection impossible | No prior-period lapse data available | WARN: "Cannot detect reactivated state -- no prior lapse data. Reactivated count will be 0." |

---

## Coverage Matrix

| Variance Dimension | Values Tested | Min Required | Status |
|---|---|---|---|
| threshold_source | cgf_default, scope_custom (complete), scope_custom (incomplete) | 2 | COVERED (3 values) |
| trajectory_available | true, false | 2 | COVERED (2 values) |
| rfm_completeness | all_three, partial (R+F), partial (R only) | 2 | COVERED (3 values) |

## Precondition Coverage

| Precondition | Test IDs | Covered |
|---|---|---|
| cohort.json exists with schema_version 1.0 | C1, C2, D4 | YES |
| cohort.json population_size > 0 | C3, D1 | YES |
| feature_set.json exists with schema_version 1.0 | C4, D5 | YES |
| feature_set.json data_ref not null | C5 | YES |
| At least one RFM dimension | C6 | YES |
| data_ref accessible | (implied by Step 2 HALT) | PARTIAL |

## Edge Case Coverage

| Edge Case from Spec | Test ID | Covered |
|---|---|---|
| Empty source (record_count == 0) | D1 | YES |
| Single record | D2 | YES |
| All-null RFM columns | D3 | YES |
| Schema mismatch | D4, D5 | YES |
| No RFM columns found | C6 | YES |
| All customers in one state | D6 | YES |
| Custom thresholds invalid | D7 | YES |
| Reactivation detection impossible | D8 | YES |

**Total tests: 25** (A: 3, B: 8, C: 6, D: 8)
