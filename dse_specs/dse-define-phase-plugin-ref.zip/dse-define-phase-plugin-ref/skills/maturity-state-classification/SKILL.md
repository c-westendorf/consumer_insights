---
name: maturity-state-classification
description: >
  Classifies each customer in a cohort into lifecycle maturity states (acquisition, new,
  low/medium/high engaged, reactivated, at-risk, lapsed) using RFM-based thresholds from
  the CGF taxonomy, producing maturity_classification.json with state distributions and
  trajectory annotations. Activate after feature-engineering when analysis requires lifecycle
  segmentation; takes cohort + feature_set.
inputs:
  - type: cohort
    description: "Full filtered population from cohort-extraction; provides population context, customer_id_ref, and observation_window"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref and features_applied provide RFM-relevant columns (recency, frequency, monetary)"
outputs:
  - type: maturity_classification
    description: "Per-customer lifecycle state assignment with state distribution summary, trajectory annotations, and applied thresholds"
can_follow: [feature-engineering]
can_precede: [retention-curve-analysis, engagement-decay-analysis, exploratory-analysis, finding-assembly]
supports_loop: false
exit_conditions:
  - "maturity_classification.json written with all customers classified and state distribution computed"
  - "classification_ref points to accessible temp table with per-customer state assignments"
---

## Overview

Feature-engineering builds *what signals exist* about customers. Maturity-state-classification
answers *where each customer is in their lifecycle journey*. Using Recency, Frequency, and
Monetary (RFM) dimensions with CGF taxonomy thresholds, this skill assigns each customer to
one of eight lifecycle states and annotates directional trajectory (improving, stable, declining).

The classification powers downstream retention-curve-analysis (which states are churning fastest),
engagement-decay-analysis (which states are declining), and finding-assembly (lifecycle context
for findings). Without this classification, downstream skills lack the population segmentation
needed for lifecycle-specific analysis.

**What this skill produces:** `maturity_classification.json` with state distribution counts,
trajectory annotations, applied thresholds, and a `classification_ref` pointing to a warehouse
temp table with per-customer state assignments.

---

## When to Activate

- A plan task node with `task_type: "maturity_state_classification"` is the next unexecuted task
- Scope involves lifecycle segmentation, churn analysis, or retention analysis
- `feature_set.json` exists with RFM-relevant columns (recency, frequency, monetary indicators)
- Downstream skill requires `maturity_classification` as input (retention-curve-analysis, engagement-decay-analysis)
- User explicitly requests "classify lifecycle states", "maturity segmentation", or "RFM classification"

---

## Preconditions

What must be true before this skill begins:

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] At least one RFM dimension column exists in feature_set (recency OR frequency OR monetary)
- [ ] `feature_set.data_ref` is accessible in the warehouse

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: (none — classification logic is pure SQL CASE expressions)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; classification is warehouse SQL CASE expressions
- **Memory:** <100 MB (artifact processing only)
- **Upstream Artifacts:** `cohort.json` (population context), `feature_set.json` (data_ref, features_applied with RFM columns)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `threshold_source` | `cgf_default` / `scope_custom` | `cgf_default`: use standard CGF RFM thresholds; `scope_custom`: override thresholds from scope_artifact.constraints if present |
| `trajectory_available` | `true` / `false` | `true`: temporal data enables computing improving/stable/declining trajectory per customer; `false`: snapshot classification only, trajectory_annotation all zeros |
| `rfm_completeness` | `all_three` / `partial` | `all_three`: R+F+M dimensions all available for full classification; `partial`: one or more RFM dimensions missing — use fallback classification with available dimensions only |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify threshold_source:
  IF scope_artifact.constraints contains threshold overrides → "scope_custom"
  ELSE → "cgf_default"
  log: "threshold_source={value}"

classify trajectory_available:
  IF feature_set contains ≥2 temporal snapshots or period-over-period columns → "true"
  ELSE → "false"
  log: "trajectory_available={value}"

classify rfm_completeness:
  recency_col = find column matching recency pattern (days_since_*, last_*_date) in feature_set
  frequency_col = find column matching frequency pattern (*_count*, *_frequency*) in feature_set
  monetary_col = find column matching monetary pattern (*_spend*, *_value*, *_revenue*) in feature_set
  IF all three found → "all_three"
  ELSE → "partial"
  log: "rfm_completeness={value} | R={recency_col} | F={frequency_col} | M={monetary_col}"

log: "Running maturity-state-classification | thresholds={value} | trajectory={value} | rfm={value}"
```

**Upstream Validation:**
```
load cohort.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json — schema_version mismatch."
assert population_size > 0
  IF not: HALT: "Cannot classify maturity on empty cohort (population_size=0)."

load feature_set.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json — schema_version mismatch."
assert data_ref is not null
  IF not: HALT: "Upstream validation failed: feature_set.json — data_ref missing."

IF rfm_completeness == "partial" AND no RFM dimensions found:
  HALT: "No RFM dimensions found in feature_set. Cannot classify maturity states.
  Verify feature-engineering produced recency, frequency, or monetary columns."
```

---

### Step 1 — Define Classification Thresholds

**Goal:** Establish the RFM threshold values for each lifecycle state.

**Pre-step assertion:** At least one RFM dimension column identified.

**Actions:**
```
IF threshold_source == "cgf_default":
  thresholds = {
    recency_days: {at_risk: 60, lapsed: 365},
    frequency_min: {low_engaged: 1, medium_engaged: 3, high_engaged: 6},
    monetary_min: {low_engaged: 10.0}
  }

ELIF threshold_source == "scope_custom":
  thresholds = read from scope_artifact.constraints
  -- Validate custom threshold values are positive
  assert all threshold values > 0
    IF not: HALT: "Invalid custom thresholds — values must be positive."
  -- Validate custom thresholds have required keys
  assert at_risk and lapsed recency thresholds present
    IF not: WARN: "Custom thresholds incomplete — supplementing with CGF defaults"
    merge CGF defaults for missing keys

Log: "Thresholds defined | source={threshold_source} | at_risk_days={thresholds.recency_days.at_risk}"
```

**Checkpoint:**
> - [ ] PASS: thresholds defined for all states
> - [ ] WARN: custom thresholds incomplete — merged with defaults

---

### Step 2 — Execute Classification SQL

**Goal:** Assign each customer to a lifecycle state via SQL CASE logic.

**Pre-step assertion:** thresholds defined; data_ref accessible.

**Actions:**
```
classification_ref = "MATURITY_{feature_set.data_ref}"

IF rfm_completeness == "all_three":
  Execute:
    CREATE TEMP TABLE {classification_ref} AS
    SELECT *,
      CASE
        WHEN {recency_col} <= 30 AND {frequency_col} == 1 THEN 'new_customer'
        WHEN {recency_col} <= 30 AND {frequency_col} >= {thresholds.frequency_min.high_engaged} THEN 'high_engaged'
        WHEN {recency_col} <= 60 AND {frequency_col} >= {thresholds.frequency_min.medium_engaged} THEN 'medium_engaged'
        WHEN {recency_col} <= 60 AND {frequency_col} >= {thresholds.frequency_min.low_engaged} THEN 'low_engaged'
        WHEN {recency_col} > {thresholds.recency_days.lapsed} THEN 'lapsed'
        WHEN {recency_col} > {thresholds.recency_days.at_risk} THEN 'at_risk'
        WHEN {recency_col} <= {thresholds.recency_days.at_risk}
             AND EXISTS prior_lapsed_period THEN 'reactivated'
        ELSE 'acquisition'
      END AS maturity_state
    FROM {feature_set.data_ref}

ELIF rfm_completeness == "partial":
  -- Use available dimensions only; WARN about reduced precision
  WARN: "Partial RFM — classification uses {available_dimensions} only. States may be less precise."
  -- Build CASE with available columns only
  Execute simplified classification SQL

-- Compute state distribution
Execute:
  SELECT maturity_state, COUNT(*) AS customer_count
  FROM {classification_ref}
  GROUP BY maturity_state

state_distribution = {row.maturity_state: row.customer_count for row in result}

Log: "Classification complete | states={len(state_distribution)} | total={sum(counts)}"
```

**Checkpoint:**
> - [ ] PASS: classification_ref table created; state_distribution computed
> - [ ] HALT: SQL error (temp table expired) → "Feature table not found — re-run feature-engineering."
> - [ ] WARN: partial RFM — reduced classification precision

---

### Step 3 — Compute Trajectory Annotations

**Goal:** For each customer, determine if they are improving, stable, or declining.

**Pre-step assertion:** classification_ref table exists.

**Branch on `trajectory_available`:**

**IF `true`:**
```
-- Compare current state to prior-period state (if temporal columns available)
-- Use period-over-period recency/frequency changes to classify trajectory
Execute:
  SELECT
    CASE
      WHEN {frequency_delta} > 0 OR {recency_delta} < 0 THEN 'improving'
      WHEN {frequency_delta} < 0 OR {recency_delta} > 0 THEN 'declining'
      ELSE 'stable'
    END AS trajectory,
    COUNT(*) AS customer_count
  FROM {classification_ref}
  GROUP BY trajectory

trajectory_annotation = {row.trajectory: row.customer_count for row in result}
```

**IF `false`:**
```
trajectory_annotation = {improving: 0, stable: 0, declining: 0}
WARN: "Trajectory unavailable — no temporal comparison data. Snapshot classification only."
```

**Checkpoint:**
> - [ ] PASS: trajectory_annotation populated
> - [ ] WARN: trajectory unavailable — snapshot only

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist maturity_classification.json.

**Actions:**
```
Generate artifact_id: UUID v4
customer_count = sum(state_distribution.values())

-- Ensure all 8 states present in distribution (0 for missing states)
FOR each state in [acquisition, new_customer, low_engaged, medium_engaged, high_engaged, reactivated, at_risk, lapsed]:
  IF state not in state_distribution: state_distribution[state] = 0

Write maturity_classification.json

Log: "maturity_classification.json written | customer_count={customer_count} | states={len(state_distribution)}"
```

**Checkpoint:**
> - [ ] PASS: maturity_classification.json written; all 5 universal envelope fields present

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "maturity-state-classification",
  "timestamp": "2026-04-10T15:00:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "classification_method": "cgf_rfm_threshold",
  "lifecycle_stages_used": ["new_customer", "low_engaged", "medium_engaged", "high_engaged", "at_risk", "lapsed"],
  "customer_count": 6148,
  "state_distribution": {
    "acquisition": 312,
    "new_customer": 891,
    "low_engaged": 1823,
    "medium_engaged": 1456,
    "high_engaged": 734,
    "reactivated": 289,
    "at_risk": 412,
    "lapsed": 231
  },
  "trajectory_annotation": {
    "improving": 1823,
    "stable": 2891,
    "declining": 1434
  },
  "thresholds_applied": {
    "recency_days": {"at_risk": 60, "lapsed": 365},
    "frequency_min": {"low_engaged": 1, "medium_engaged": 3, "high_engaged": 6},
    "monetary_min": {"low_engaged": 10.0}
  },
  "classification_ref": "MATURITY_FEATURES_SAMPLE_COHORT_REMEDIATED_DSE_EXTRACTION_rd001"
}
```

**Write to:** `maturity_classification.json` in the project directory.

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source (record_count == 0) | cohort.population_size == 0 | HALT Step 0: "Cannot classify maturity on empty cohort (population_size=0)." |
| Single record | customer_count == 1 | WARN: "Single customer — state distribution is trivial." |
| All-null RFM columns | all RFM columns 100% NULL | HALT: "All RFM dimension columns are NULL — cannot classify." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact artifact name |
| No RFM columns found | rfm_completeness check finds zero dimensions | HALT Step 0: "No RFM dimensions in feature_set." |
| All customers in one state | state_distribution has only 1 non-zero state | WARN: "All customers classified as '{state}' — verify thresholds are appropriate for this population." |
| Custom thresholds invalid | scope_custom thresholds have negative or zero values | HALT: "Invalid custom thresholds — values must be positive." |
| Reactivation detection impossible | no prior-period lapse data available | WARN: "Cannot detect reactivated state — no prior lapse data. Reactivated count will be 0." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `maturity_classification.json` exists with all 5 universal envelope fields
- [ ] `state_distribution` contains all 8 lifecycle states (values may be 0)
- [ ] `customer_count` equals sum of all state_distribution values
- [ ] `classification_ref` points to an accessible warehouse temp table with per-customer assignments
- [ ] `thresholds_applied` documents the exact thresholds used

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `maturity_classification.json` written and validates against terminal artifact spec
- [ ] All 8 lifecycle states present in `state_distribution` (with counts ≥ 0)
- [ ] `customer_count` matches cohort.population_size (or sample_set.sample_size)
- [ ] `classification_ref` temp table is queryable
- [ ] Downstream `retention-curve-analysis` Step 0 can load and validate the artifact
- [ ] `thresholds_applied` matches the source (CGF defaults or scope overrides)

---

## Scope Boundary

This skill does NOT:
- Analyze retention curves over time → handled by `retention-curve-analysis`
- Detect engagement decay patterns → handled by `engagement-decay-analysis`
- Compute aggregate metrics → handled by `metric-computation`
- Engineer RFM feature columns → handled by `feature-engineering`
- Identify behavioral segments (cluster-based) → handled by `cohort-behavior-analysis`

---

## Downstream

Run after this skill completes:
1. **`retention-curve-analysis`** — reads `maturity_classification` to build retention curves per lifecycle state; uses `classification_ref` to join state assignments to transaction data
2. **`engagement-decay-analysis`** — reads `maturity_classification` to identify which lifecycle states are experiencing engagement decline; uses `trajectory_annotation` as starting signal
3. **`exploratory-analysis`** — may use `maturity_classification` as a segmentation dimension for exploring feature distributions across lifecycle states
4. **`finding-assembly`** — includes lifecycle state distribution as context for assembled findings
