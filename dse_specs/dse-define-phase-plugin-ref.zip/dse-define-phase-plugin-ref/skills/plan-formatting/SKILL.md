---
name: plan-formatting
description: >
  Renders the budgeted task plan into plan_artifact.json with three views -- stakeholder
  (numbered steps in plain language with rationale), agent (task nodes with dependencies,
  playbook references, tool types, and budgets), and trace (initially empty, populated
  during Phase 2). Requires user approval before writing the immutable artifact. Activate
  after budget-allocation. Takes budgeted_task_plan and scope_artifact; produces
  plan_artifact consumed by Analyze Phase data-retrieval.
inputs:
  - type: budgeted_task_plan
    description: "Execution plan with budgets, exit conditions, and priority per task"
  - type: scope_artifact
    description: "Approved scope definition for back-reference and completeness validation"
outputs:
  - type: plan_artifact
    description: "Final plan with stakeholder view, agent view, trace view, and metadata; immutable after approval"
can_follow: [budget-allocation]
can_precede: []
supports_loop: false
exit_conditions:
  - "plan_artifact.json written with stakeholder_view, agent_view, trace_view, and metadata"
  - "user explicitly approved the plan"
  - "every scope requirement is addressed by at least one task"
---

## Overview

This is the terminal skill of the Plan Agent pipeline. It takes the fully budgeted
task plan and formats it into the canonical plan_artifact.json that serves as the
execution guide for Phase 2 (Analyze). The artifact has three views: a stakeholder
view for non-technical readers (numbered steps with plain-language descriptions and
rationale), an agent view for the data scientist or execution agent (task nodes with
dependencies, playbook references, tool types, and iteration budgets), and a trace
view (initially empty, populated during Phase 2 execution). The plan must pass
completeness validation against the scope_artifact before presentation.
The plan_artifact is immutable after user approval. If the user requests revisions,
control returns to task-decomposition with feedback.

---

## When to Activate

- budgeted_task_plan.json exists in the working directory with a valid artifact_id
- scope_artifact.json exists in the working directory with a valid artifact_id
- Plan Agent pipeline has completed budget-allocation and no plan_artifact.json exists
- budgeted_task_plan.json has been regenerated since the last plan_artifact.json timestamp
- A prior plan_artifact.json was rejected and budgeted_task_plan.json is unchanged
- The Plan Agent receives a `format-plan` or `finalize-plan` command referencing valid inputs

---

## Preconditions

What must be true before this skill begins:

- [ ] `budgeted_task_plan.json` exists and `schema_version == "1.0"`
- [ ] `budgeted_task_plan.json` contains `budgeted_tasks` array with >= 1 entry
- [ ] Every budgeted task has `task_id`, `task_type`, `budget`, and `priority`
- [ ] `budgeted_task_plan.json` contains a valid `artifact_id`
- [ ] `scope_artifact.json` exists and contains `requirements` or `scope_elements`
- [ ] `scope_artifact.json` contains a valid `artifact_id`

Each precondition has a corresponding HALT condition in Step 0.

---

## Prerequisites

### Library Dependencies

```
# Tier 1 -- Core (required)
python>=3.10

# Tier 2 -- Skill-specific
json (stdlib)
uuid (stdlib)
datetime (stdlib)
```

No external library dependencies. CPU-only, minimal memory.

### Infrastructure Requirements

- **Compute:** CPU-only
- **Memory:** < 128 MB (formatting and validation only)
- **Disk:** < 1 MB scratch (JSON artifacts only)
- **OS packages:** None
- **Environment:** Any Python 3.10+ runtime

### Upstream Artifacts

- `budgeted_task_plan.json`: produced by `budget-allocation` -- required fields: `schema_version`, `artifact_id`, `budgeted_tasks`, `budget_strategy`, `budget_metadata`
- `scope_artifact.json`: produced by `scope-formatting` -- required fields: `schema_version`, `artifact_id`, scope requirements or elements

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `plan_complexity` | `simple` (<=5 stakeholder steps) / `complex` (>5 steps) | `simple`: linear numbered steps (1, 2, 3...); `complex`: grouped steps with sub-items for parallel branches (e.g., "3a/3b") |
| `approval_status` | `pending` / `approved` / `revision_requested` | `pending`: present all three views for review; `approved`: set approved_at, write artifact; `revision_requested`: return to task-decomposition with feedback |
| `has_gaps` | `true` / `false` | `true`: WARN in stakeholder view about capabilities not in registry; metadata.skill_gaps, tool_gaps, and playbook_gaps populated; `false`: clean plan, no warnings |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:** Classify variance dimensions from inputs.

```
load budgeted_task_plan.json
load scope_artifact.json

# Count stakeholder-visible steps (collapse parallel branches)
stage_count = count unique stages from budgeted_tasks
classify plan_complexity:
  IF stage_count <= 5 -> "simple"
  ELSE -> "complex"

# Check for skill, tool, and playbook gaps
skill_gaps = [ref for ref in all skill_refs if ref not in known_skills and ref is not null]
tool_gaps = [tt for tt in flatten(t.tool_types_needed) if tt not in tool_registry]
playbook_gaps = [t.task_id for t in budgeted_tasks if t.playbook_ref is null]
classify has_gaps:
  IF len(skill_gaps) > 0 or len(tool_gaps) > 0 -> "true"
  ELSE -> "false"

# Initial approval status
approval_status = "pending"

log: "Running plan-formatting | plan_complexity={value} | has_gaps={value} | task_count={N}"
```

**Upstream Validation:**

```
assert budgeted_task_plan.json file exists
  HALT: "budgeted_task_plan.json not found. Run budget-allocation first."
assert scope_artifact.json file exists
  HALT: "scope_artifact.json not found. Cannot validate completeness."

assert budgeted_task_plan.schema_version == "1.0"
  HALT: "Schema version mismatch on budgeted_task_plan: expected 1.0, got {value}."
assert budgeted_task_plan.budgeted_tasks is array with length >= 1
  HALT: "budgeted_tasks is empty. Nothing to format."
assert budgeted_task_plan.artifact_id is present
  HALT: "budgeted_task_plan missing artifact_id. Cannot establish provenance chain."

FOR each task in budgeted_tasks:
  assert task.task_id is present
    HALT: "Task missing task_id."
  assert task.task_type is present
    HALT: "Task {task_id} missing task_type."
  assert task.budget is present with max_iterations >= 1
    HALT: "Task {task_id} missing or invalid budget."
  assert task.priority in {"critical", "standard", "optional"}
    HALT: "Task {task_id} has invalid priority: {value}."

assert scope_artifact.schema_version == "1.0"
  HALT: "Schema version mismatch on scope_artifact: expected 1.0, got {value}."
assert scope_artifact.artifact_id is present
  HALT: "scope_artifact missing artifact_id."
```

**Checkpoint:**
> - [ ] PASS: All upstream assertions pass, variance dimensions classified
> - [ ] HALT: Any assertion failure -- stop with exact message

---

### Step 1 -- Generate Stakeholder View

**Goal:** Produce numbered steps in plain language with rationale for non-technical readers.

**Pre-step assertion:** All tasks validated. plan_complexity classified.

**Actions:**

```
steps = []
step_counter = 0
FOR each stage in execution_order (sorted by stage number):
  tasks_in_stage = [t for t in budgeted_tasks if t.task_id in stage.tasks]
  IF plan_complexity == "simple" OR len(tasks_in_stage) == 1:
    step_counter += 1
    FOR each task: steps.append({step: step_counter, description: plain_language(task), rationale: rationale(task)})
  ELSE:  # complex: parallel branches as sub-items (3a, 3b)
    step_counter += 1; sub_label = "a"
    FOR each task: steps.append({step: "{step_counter}{sub_label}", description: ..., rationale: ...}); sub_label++

summary = generate_plan_summary(scope_artifact, steps)
IF has_gaps: summary += " Note: some tasks reference skills or tools not in the current registry."
stakeholder_view = {summary, steps}
```

**Checkpoint:**
> - [ ] Assert: steps array is non-empty
> - [ ] Assert: every step has description and rationale
> - [ ] PASS: Stakeholder view generated
> - [ ] WARN: skill/tool gaps present -- warning appended to summary

---

### Step 2 -- Generate Agent View

**Goal:** Structured task list with dependencies, fan-out/join, skill refs, playbook refs, tool types, and budgets.

**Pre-step assertion:** Stakeholder view generated. budgeted_tasks available.

**Actions:**

```
task_nodes = []
FOR each task in budgeted_tasks:
  task_nodes.append({
    task_id: task.task_id,
    task_type: task.task_type,
    description: task.description,
    skill_ref: task.skill_ref,
    playbook_ref: task.playbook_ref or null,
    tool_types_needed: task.tool_types_needed or [],
    depends_on: resolve from source dependencies,
    fan_out_group: resolve from source fan_out_points,
    join_point: resolve from source fan_out_points,
    priority: task.priority,
    budget: task.budget
  })

# Carry forward execution_order and dependencies from ordered_task_plan
execution_order = source execution_order stages
dependencies = source dependency edges
fan_out_points = source fan_out_points

agent_view = {task_nodes, execution_order, dependencies, fan_out_points}
```

**Checkpoint:**
> - [ ] Assert: task_nodes count matches budgeted_tasks count
> - [ ] Assert: every task_node has depends_on (may be empty array)
> - [ ] PASS: Agent view generated

---

### Step 3 -- Generate Metadata

**Goal:** Compute plan-level statistics and identify gaps.

**Pre-step assertion:** Stakeholder and agent views generated.

**Actions:**

```
plan_metadata = {
  total_tasks: len(budgeted_tasks),
  total_budget: sum(t.budget.max_iterations for t in budgeted_tasks),
  critical_path_length: from source dag_metadata,
  fan_out_count: len(fan_out_points),
  estimated_complexity: classify_complexity(total_tasks, critical_path_length, fan_out_count),
  skill_gaps: skill_gaps,  # from Step 0
  tool_gaps: [tt for tt in all_tool_types_needed if tt not in tool_registry],
  playbook_gaps: [t.task_id for t in budgeted_tasks if t.playbook_ref is null],
  scope_warnings: [],      # populated in Step 4
  novel_tasks: [t.task_id for t in budgeted_tasks if t.skill_ref is null or unknown],
  requires_human_review: len(skill_gaps) > 0 or len(tool_gaps) > 0 or len(novel_tasks) > 0
}

# Complexity: low (<=5 tasks, no fan-out), medium (<=10, <=1 fan-out), else high
```

**Checkpoint:**
> - [ ] Assert: plan_metadata has all required fields
> - [ ] PASS: Metadata generated

---

### Step 4 -- Validate Completeness

**Goal:** Every scope requirement is addressed by at least one task. No orphans. Path from ingestion to synthesis.

**Pre-step assertion:** Stakeholder view, agent view, and metadata generated.

**Actions:**

```
# Check 1: Scope coverage
scope_requirements = extract requirements from scope_artifact
FOR each requirement in scope_requirements:
  matching_tasks = [t for t in budgeted_tasks
                    if t addresses requirement]
  IF len(matching_tasks) == 0:
    plan_metadata.scope_warnings.append(
      "Scope requirement '{requirement}' not addressed by any task."
    )
    WARN: "Uncovered scope requirement: {requirement}"

# Check 2: Ingestion-to-synthesis path exists
has_ingestion = any(t.task_type == "ingestion" for t in budgeted_tasks)
has_synthesis = any(t.task_type == "synthesis" for t in budgeted_tasks)
IF not has_ingestion:
  WARN: "No ingestion task in plan. Data entry point unclear."
IF not has_synthesis:
  WARN: "No synthesis task in plan. Final deliverable unclear."

# Check 3: No orphan tasks (every task in execution_order)
all_ordered = flatten(stage.tasks for stage in execution_order)
all_budgeted = [t.task_id for t in budgeted_tasks]
orphans = set(all_budgeted) - set(all_ordered)
IF len(orphans) > 0:
  WARN: "Orphan tasks not in execution_order: {orphans}"

# Check 4: Stakeholder view is linearizable
assert len(stakeholder_view.steps) >= 1
  HALT: "Stakeholder view has no steps. Cannot present empty plan."
```

**Checkpoint:**
> - [ ] Assert: scope_warnings is empty or all warnings logged
> - [ ] Assert: ingestion and synthesis tasks present
> - [ ] PASS: Completeness validation passed
> - [ ] WARN: Uncovered scope requirements or missing ingestion/synthesis

---

### Step 5 -- Present for Approval

**Goal:** Show all three views and metadata to user. Wait for explicit approval.

**Pre-step assertion:** Completeness validation passed (or passed with warnings).

**Actions:**

```
# Present stakeholder view (summary + numbered steps)
# Present agent view summary (task count, stages, critical path, complexity)
# Display scope_warnings and skill_gaps if non-empty
# If requires_human_review, display advisory

prompt user: "Approve this plan? (approve / revise / reject)"
IF user_response == "approve":   approval_status = "approved"
ELIF user_response == "revise":  approval_status = "revision_requested"; capture feedback
ELSE:                            HALT: "Plan rejected by user."
```

**Checkpoint:**
> - [ ] PASS (approved): User approved -- proceed to Step 6
> - [ ] WARN (revision_requested): Return to task-decomposition with feedback
> - [ ] HALT (rejected): User rejected plan -- pipeline stops

---

### Step 6 -- Write Terminal Artifact

**Goal:** On approval, write the immutable plan_artifact.json. On revision, route feedback upstream.

**Pre-step assertion:** approval_status is "approved" or "revision_requested".

**Actions:**

```
IF approval_status == "approved":
  generate artifact_id (uuid v4)
  approved_at = current ISO-8601 UTC

  plan_artifact = {
    schema_version: "1.0",
    skill_name: "plan-formatting",
    timestamp: current ISO-8601 UTC,
    record_count: len(budgeted_tasks),
    artifact_id: new_uuid,
    scope_artifact_id: scope_artifact.artifact_id,
    approved_at: approved_at,
    approved_by: "user",
    stakeholder_view: stakeholder_view,
    agent_view: agent_view,
    trace_view: {events: []},
    plan_metadata: plan_metadata
  }

  write plan_artifact.json

ELIF approval_status == "revision_requested":
  log: "Revision requested. Feedback: {revision_feedback}"
  route feedback to task-decomposition for re-planning
  HALT: "Plan returned for revision. Re-run pipeline from task-decomposition."
```

**Checkpoint:**
> - [ ] Assert: plan_artifact.json is valid JSON (if approved)
> - [ ] Assert: all 5 universal envelope fields present
> - [ ] Assert: approved_at and approved_by set
> - [ ] PASS: Artifact written successfully
> - [ ] HALT: Write failure or revision routing -- "{exact message}"

---

## Terminal Artifact

**File:** `plan_artifact.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "plan-formatting",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 9,
  "artifact_id": "{uuid}",
  "scope_artifact_id": "{uuid}",
  "approved_at": "{ISO-8601 UTC}",
  "approved_by": "user",
  "stakeholder_view": {
    "summary": "We will compare the retention behavior of reactivated customers...",
    "steps": [
      {"step": 1, "description": "Connect to data warehouse and profile tables", "rationale": "Confirm data availability and quality before analysis"}
    ]
  },
  "agent_view": {
    "task_nodes": [
      {"task_id": "TN-001", "task_type": "ingestion", "description": "Data extraction and schema profiling", "skill_ref": "data-retrieval", "playbook_ref": null, "tool_types_needed": ["ingestion"], "depends_on": [], "fan_out_group": null, "join_point": null, "priority": "critical", "budget": {"max_iterations": 1, "exit_condition": "data_loaded"}}
    ],
    "execution_order": [{"stage": 1, "tasks": ["TN-001"], "parallel": false}],
    "dependencies": [{"from": "TN-001", "to": "TN-002", "data_type": "raw_dataset"}],
    "fan_out_points": []
  },
  "trace_view": {
    "events": []
  },
  "plan_metadata": {"total_tasks": 9, "total_budget": 22, "critical_path_length": 7, "fan_out_count": 1, "estimated_complexity": "medium", "skill_gaps": [], "tool_gaps": [], "playbook_gaps": [], "scope_warnings": [], "novel_tasks": [], "requires_human_review": false}
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | budgeted_tasks array is empty | HALT: "budgeted_tasks is empty. Nothing to format." |
| Single record | budgeted_tasks has exactly 1 task | WARN: "Single-task plan." Generate 1-step stakeholder view, 1-node agent view. |
| All-null dimension | task_type is null for all tasks | HALT: "No tasks have task_type. Cannot generate stakeholder descriptions." |
| Schema mismatch | schema_version != "1.0" on either input | HALT: "Schema version mismatch: expected 1.0, got {value} on {artifact_name}." |
| Missing scope_artifact | scope_artifact.json does not exist | HALT: "scope_artifact.json not found. Cannot validate completeness." |
| All tasks optional | every task has priority "optional" | WARN: "All tasks are optional. Plan has no critical path. Present for review with warning." |
| Scope requirement uncovered | requirement not addressed by any task | WARN: "Scope requirement '{req}' not covered. Added to scope_warnings." Present to user during approval. |
| Revision loop | user requests revision 3+ times | WARN: "Multiple revision cycles detected. Consider re-scoping with scope-extraction." Present revision history to user. |

---

## Postconditions

After successful completion, this skill guarantees:

- [ ] `plan_artifact.json` exists and is valid JSON (only if user approved)
- [ ] `stakeholder_view` contains summary and steps with description and rationale
- [ ] `agent_view` contains task_nodes (with playbook_ref and tool_types_needed), execution_order, dependencies, and fan_out_points
- [ ] `trace_view` exists with empty events array (populated during Phase 2)
- [ ] Every scope requirement is addressed by at least one task (or warnings logged)
- [ ] `approved_at` and `approved_by` are set
- [ ] Terminal artifact contains all 5 universal envelope fields
- [ ] `scope_artifact_id` traces back to the source scope_artifact

---

## Quality Bar

This skill run is "done" when ALL of the following are true:

- [ ] All Step 0 upstream assertions passed
- [ ] Stakeholder view has plain-language steps with rationale for every stage
- [ ] Agent view has complete task_nodes with depends_on, skill_ref, playbook_ref, tool_types_needed, and budget
- [ ] Trace view exists with empty events array
- [ ] Completeness validation passed (scope coverage, ingestion-to-synthesis path, no orphans)
- [ ] User explicitly approved the plan
- [ ] plan_metadata accurately reflects task counts, complexity, and gaps
- [ ] Terminal artifact validates: schema_version, skill_name, timestamp, record_count, artifact_id present
- [ ] plan_artifact.json is consumable by Analyze Phase data-retrieval (agent_view.task_nodes present)

---

## Scope Boundary

This skill does NOT:

- Decompose scope into task nodes -> handled by `task-decomposition`
- Resolve task dependencies or execution order -> handled by `dependency-resolution`
- Allocate iteration budgets or exit conditions -> handled by `budget-allocation`
- Execute any tasks in the plan -> handled by Analyze Phase skills (data-retrieval first)
- Define or approve scope -> handled by `scope-formatting`
- Modify budgets or priorities after formatting -> immutable from budget-allocation

---

## Downstream

1. **`data-retrieval`** -- Consumes `plan_artifact.json`. Reads `agent_view.task_nodes` for task sequencing and `agent_view.dependencies` for data flow routing.
