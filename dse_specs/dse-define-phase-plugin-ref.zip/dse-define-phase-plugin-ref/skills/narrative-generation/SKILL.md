---
name: narrative-generation
description: >
  Transforms a ranked finding_set into a stakeholder-ready narrative with executive summary,
  structured sections with evidence references, recommendations, and visualization specifications.
  Activate after finding-assembly produces finding_set.json. Takes finding_set, scope_artifact,
  and context_map; produces narrative. HALTs if scope_coverage_assessment is "insufficient".
  Supports up to 2 revision iterations for stakeholder feedback.
inputs:
  - type: finding_set
    description: "Ranked findings with evidence sources and scope coverage assessment"
  - type: scope_artifact
    description: "Approved scope for framing the narrative"
  - type: context_map
    description: "Business context definitions and data lineage from business-context-layer"
    optional: true
outputs:
  - type: narrative
    description: "Executive summary, structured sections, recommendations, and visualization specs"
can_follow: [finding-assembly]
can_precede: [notify-schedule]
supports_loop: true
exit_conditions:
  - "narrative.json written with executive_summary, sections, and recommendations"
  - "all findings referenced in at least one section"
  - "stakeholder approves or max 2 revision iterations reached"
---

## Overview

This is the delivery preparation skill. It takes the synthesized findings and transforms them
into a narrative that a business stakeholder can act on. The narrative is structured -- not
free-form prose -- with an executive summary, evidence-linked sections, recommendations with
confidence levels, and visualization specifications.

Each section explicitly references which findings support its claims. The skill respects the
scope_coverage_assessment: "insufficient" triggers a HALT, "partial" adds caution flags. When
context_map is available, the narrative is enriched with business definitions and data lineage.

**Revision loop:** The skill supports up to 2 revision iterations for stakeholder feedback. After
presenting the initial narrative, if the stakeholder requests changes, the skill adjusts and
re-generates. After 2 iterations, the narrative is finalized regardless.

**What this skill produces:** `narrative.json` with executive summary, structured sections,
recommendations, visualization specs, and caution flags.

---

## When to Activate

- `finding_set.json` exists with `scope_coverage_assessment` of "complete" or "partial"
- User explicitly requests "generate narrative", "create report", "summarize for stakeholders", or "prepare deliverable"
- Downstream delivery or notification is planned
- All analytical work is complete and findings have been assembled

---

## Preconditions

- [ ] `finding_set.json` exists with `schema_version == "1.0"` and `scope_coverage_assessment != "insufficient"`
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"` for narrative framing
- [ ] `finding_set.findings` array has >=1 finding
- [ ] If `context_map.json` is referenced, it has `schema_version == "1.0"`

---

## Prerequisites

### Library Dependencies
```
# Tier 1: (none)
# Tier 3: (none — narrative is structured JSON, not rendered document)
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `narrative_style` | `executive` / `technical` / `operational` | `executive`: high-level summary, business outcomes, ROI focus; `technical`: detailed methodology, statistical evidence, caveats; `operational`: action-oriented, implementation steps, timelines |
| `scope_coverage` | `complete` / `partial` | `complete`: full narrative with confidence; `partial`: narrative includes caution_flags noting which scope areas lack evidence |
| `context_availability` | `available` / `unavailable` | `available`: enrich narrative with business definitions and lineage from context_map; `unavailable`: proceed without context enrichment, add caution_flag |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:**
```
classify narrative_style:
  IF scope_artifact.audience contains "executive" OR "VP" OR "C-suite" → "executive"
  ELIF scope_artifact.audience contains "analyst" OR "data science" → "technical"
  ELIF scope_artifact.audience contains "operations" OR "manager" → "operational"
  ELSE → "executive"  -- default

classify scope_coverage:
  read from finding_set.scope_coverage_assessment

classify context_availability:
  IF context_map.json exists → "available"
  ELSE → "unavailable"

log: "Running narrative-generation | style={value} | scope_coverage={value} | context={value}"
```

**Upstream Validation:**
```
load finding_set.json; assert schema_version == "1.0"
  IF finding_set.scope_coverage_assessment == "insufficient":
    HALT: "Scope coverage is insufficient. Cannot generate narrative. Return to analytical skills to address gaps: {finding_set.scope_gaps}"

  IF len(finding_set.findings) == 0:
    HALT: "No findings in finding_set. Nothing to narrate."

load scope_artifact.json; assert schema_version == "1.0"
  IF not found: WARN: "scope_artifact.json not found; narrative framing will be generic."

IF context_availability == "available":
  load context_map.json; assert schema_version == "1.0"
```

---

### Step 1 -- Validate Scope Coverage

**Goal:** Confirm finding_set has adequate coverage before investing in narrative generation.

**Actions:**
```
IF scope_coverage == "partial":
  caution_flags = []
  FOR each gap in finding_set.scope_gaps:
    caution_flags.append("Scope gap: {gap} — no analytical evidence available for this area")
  WARN: "Partial scope coverage. Proceeding with {len(caution_flags)} caution flags."
ELSE:
  caution_flags = []
  PASS: "Full scope coverage confirmed."
```

---

### Step 2 -- Generate Executive Summary

**Goal:** 3-5 sentences covering the question asked, key finding, and recommended action.

**Actions:**
```
IF scope_artifact is null or scope_artifact.research_question is null:
  research_question = finding_set.scope_reference or "the analysis"
ELSE:
  research_question = scope_artifact.research_question OR scope_artifact.objective

question = research_question
top_finding = finding_set.findings[0]  -- highest ranked
top_recommendation = derive_action(top_finding)

IF narrative_style == "executive":
  summary = compose_executive_summary(question, top_finding, top_recommendation)
  -- Focus: business outcome, magnitude, recommended action
  -- Length: 3-5 sentences
  -- Avoid: p-values, technical methodology, caveats (save for sections)

ELIF narrative_style == "technical":
  summary = compose_technical_summary(question, top_finding, methodology_overview)
  -- Focus: analytical approach, key statistical result, confidence level
  -- Length: 3-5 sentences

ELIF narrative_style == "operational":
  summary = compose_operational_summary(question, top_finding, action_steps)
  -- Focus: what to do, when, expected impact
  -- Length: 3-5 sentences

-- Single-finding note
IF len(finding_set.findings) == 1:
  summary += " Note: This narrative is based on a single analytical finding. Additional analysis may strengthen or qualify these conclusions."

PASS: "Executive summary generated ({len(summary)} chars)."
```

---

### Step 3 -- Generate Sections

**Goal:** One section per major finding cluster; each section has title, body, evidence_refs, and visualization_specs.

**Actions:**
```
-- Cluster findings by topic/metric
clusters = cluster_findings_by_topic(finding_set.findings)

sections = []
section_counter = 0
referenced_findings = set()

FOR each cluster in clusters:
  section_counter += 1
  section = {
    section_id: "S-{section_counter:03d}",
    title: derive_section_title(cluster),
    body: "",
    evidence_refs: [],
    visualization_specs: []
  }

  -- Build body based on narrative_style
  IF narrative_style == "executive":
    section.body = compose_business_body(cluster)
    -- Emphasize: magnitude, business impact, comparison to benchmarks
  ELIF narrative_style == "technical":
    section.body = compose_technical_body(cluster)
    -- Emphasize: methodology, statistical details, effect sizes, CIs
  ELIF narrative_style == "operational":
    section.body = compose_operational_body(cluster)
    -- Emphasize: implications, action items, implementation considerations

  -- Attach evidence references
  FOR each finding in cluster:
    section.evidence_refs.append(finding.finding_id)
    referenced_findings.add(finding.finding_id)

  -- Generate visualization specifications
  section.visualization_specs = derive_visualizations(cluster, narrative_style)
  -- Common types: bar (comparisons), line (trends), scatter (correlations), table (summaries)

  sections.append(section)

-- Verify all findings referenced
unreferenced = set(f.finding_id for f in findings) - referenced_findings
IF len(unreferenced) > 0:
  WARN: "Findings not referenced in any section: {unreferenced}. Adding catch-all section."
  sections.append(create_additional_findings_section(unreferenced))
```

---

### Step 4 -- Generate Recommendations

**Goal:** Actionable recommendations with supporting finding ref and confidence level.

**Actions:**
```
recommendations = []

FOR each finding in finding_set.findings WHERE finding.evidence_strength in ["strong", "moderate"]:
  recommendation = {
    recommendation: derive_action(finding, scope_artifact),
    supporting_finding: finding.finding_id,
    confidence: map_strength_to_confidence(finding.evidence_strength, finding.causal_confidence)
  }
  recommendations.append(recommendation)

-- Confidence mapping:
--   evidence_strength=="strong" AND causal_confidence in ["quasi-experimental","causal"] → "high"
--   evidence_strength=="strong" AND causal_confidence=="adjusted" → "medium"
--   evidence_strength=="moderate" → "medium"
--   evidence_strength=="weak" → "low" (but weak findings excluded from recommendations)

-- Add contradiction-aware recommendations
IF finding_set.contradictions_found is not empty:
  recommendations.append({
    recommendation: "Investigate contradictory findings before acting: {contradiction_summary}",
    supporting_finding: contradictions_found[0].finding_a,
    confidence: "low"
  })

IF len(recommendations) == 0:
  WARN: "No recommendations generated — all findings are weak evidence."
  recommendations.append({
    recommendation: "Conduct additional analysis to strengthen evidence before taking action",
    supporting_finding: findings[0].finding_id,
    confidence: "low"
  })

PASS: "Generated {len(recommendations)} recommendations."
```

---

### Step 5 -- Enrich with Context

**Goal:** If context_map available, add business definitions and lineage; otherwise add caution_flag.

**Actions:**
```
IF context_availability == "available":
  -- Enrich sections with business definitions
  FOR each section in sections:
    terms_used = extract_business_terms(section.body)
    FOR each term in terms_used:
      IF term in context_map.definitions:
        section.body = annotate_definition(section.body, term, context_map.definitions[term])

  -- Add data lineage context
  stakeholder_context = context_map.stakeholder_context OR scope_artifact.audience
  PASS: "Context enrichment complete."

ELIF context_availability == "unavailable":
  caution_flags.append("Business context definitions not available — metric definitions may require stakeholder verification")
  stakeholder_context = scope_artifact.audience OR "Not specified"
  WARN: "Context map unavailable. Caution flag added."
```

---

### Step 6 -- Present for Review

**Goal:** Show narrative to stakeholder; if revision requested and iteration < 2, loop back.

**Actions:**
```
iteration = current_iteration OR 1

-- Present narrative summary to stakeholder
present(executive_summary, sections, recommendations, caution_flags)

IF stakeholder requests revision AND iteration < 2:
  revision_notes = capture_stakeholder_feedback()
  adjust_narrative(revision_notes)
  iteration += 1
  GOTO Step 2  -- re-generate with adjustments

ELIF iteration >= 2:
  WARN: "Maximum revision iterations (2) reached. Finalizing narrative."

ELSE:
  PASS: "Narrative approved by stakeholder."
```

---

### Step 7 -- Write Terminal Artifact

```
Generate artifact_id  -- NEW UUID

Write narrative.json:
  executive_summary = executive_summary
  sections = sections
  recommendations = recommendations
  stakeholder_context = stakeholder_context
  caution_flags = caution_flags

Log: "narrative.json written | sections={len(sections)} | recommendations={len(recommendations)} | caution_flags={len(caution_flags)}"
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "narrative-generation",
  "timestamp": "2026-04-10T18:00:00Z",
  "record_count": 5,
  "artifact_id": "{uuid}",
  "executive_summary": "Reactivated customers show meaningfully lower retention than continuously active customers, with a 5.5pp gap in 90-day repeat purchase rate. The difference is statistically significant (p<0.01) with a medium effect size. This suggests the Q3 reactivation campaign budget should be maintained but paired with retention interventions.",
  "sections": [
    {
      "section_id": "S-001",
      "title": "Retention Gap Between Reactivated and Active Customers",
      "body": "...",
      "evidence_refs": ["F-001", "F-002"],
      "visualization_specs": [
        {"chart_type": "bar", "x": "population", "y": "repeat_purchase_rate", "title": "90-Day Repeat Purchase Rate by Cohort"}
      ]
    }
  ],
  "recommendations": [
    {"recommendation": "Maintain Q3 reactivation budget but add 30-day post-reactivation touchpoint", "supporting_finding": "F-001", "confidence": "high"}
  ],
  "stakeholder_context": "VP of Customer Growth — Q3 budget decision",
  "caution_flags": []
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | finding_set.findings is empty | HALT Step 0: "No findings to narrate." |
| Single record | finding_set has exactly 1 finding | PASS: Generate single-section narrative. Note limited evidence base. |
| All-null dimension | All findings have null evidence_strength | WARN Step 3: "Cannot rank findings — treat all as moderate." |
| Schema mismatch | schema_version != "1.0" on finding_set or scope_artifact | HALT Step 0: "Schema mismatch on {artifact}." |
| Insufficient scope coverage | scope_coverage_assessment == "insufficient" | HALT Step 0: "Cannot generate narrative with insufficient scope coverage." |
| All findings weak | Every finding has evidence_strength == "weak" | WARN Step 4: "All findings weak. Narrative will emphasize need for additional analysis." |
| Contradictions dominate | More than 50% of findings are contradictory | WARN Step 3: "Majority of findings contradict. Narrative will prominently feature uncertainty." |
| Context map missing | context_map.json not found | WARN Step 5: "Proceeding without business context enrichment. Add caution flag." |

---

## Postconditions

- [ ] `narrative.json` exists with all 5 universal envelope fields
- [ ] `executive_summary` is 3-5 sentences and covers question, finding, and action
- [ ] Every finding from `finding_set` is referenced in at least one section's `evidence_refs`
- [ ] `recommendations` have `supporting_finding` refs and `confidence` levels
- [ ] `caution_flags` reflect scope gaps and context availability

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] Executive summary is appropriate for the narrative_style
- [ ] All findings are referenced -- none silently dropped
- [ ] Recommendations trace back to specific findings
- [ ] Contradictions from finding_set are reflected in the narrative (not suppressed)
- [ ] Scope gaps produce caution_flags in the output
- [ ] Visualization specs are actionable (chart_type, axes, title specified)

---

## Scope Boundary

This skill does NOT:
- Assemble findings --> handled by `finding-assembly`
- Compute ROI --> handled by `roi-computation`
- Deliver or schedule notification --> handled by `notify-schedule`
- Run any analytical work --> handled by Group 4/5 skills
- Render visualizations --> produces specs only; rendering is downstream

---

## Downstream

1. **`notify-schedule`** -- reads `narrative` to deliver the final report to stakeholders via configured channels
