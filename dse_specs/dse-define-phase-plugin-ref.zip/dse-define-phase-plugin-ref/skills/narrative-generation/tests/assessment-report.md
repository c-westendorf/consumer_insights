# Assessment Report: narrative-generation (Skill 11)

**Assessed:** 2026-04-10
**Skill Version:** schema_version 1.0
**Assessor:** DSE Skill Tester

---

## Test Inventory

| Category | Count | Description |
|---|---|---|
| A (Happy Path) | 2 | Valid inputs producing expected narrative |
| B (Variance) | 7 | One per variance dimension value |
| C (Precondition Violations) | 4 | One per precondition |
| D (Edge Cases) | 8 | One per edge case row |
| **Total** | **21** | |

---

## Category A -- Happy Path

### A-1: Executive narrative, complete scope, with context_map

**Input:** finding_set.json (schema_version=1.0, scope_coverage_assessment="complete", findings=[F-001 strong, F-002 moderate, F-003 moderate], contradictions_found=[]), scope_artifact.json (schema_version=1.0, audience="VP of Customer Growth", research_question="What is the ROI of reactivation campaigns?"), context_map.json (schema_version=1.0, definitions={...}).

**Walkthrough:**
- Step 0: narrative_style="executive" (audience contains "VP"). scope_coverage="complete". context_availability="available". finding_set loads, scope_coverage_assessment != "insufficient", findings.length=3 >= 1. scope_artifact loads. context_map loads.
- Step 1: scope_coverage="complete", caution_flags=[]. PASS.
- Step 2: Executive summary composed: 3-5 sentences, question + top finding + recommended action. No p-values or technical details.
- Step 3: Findings clustered by topic. Sections generated with section_id, title, body (business-focused), evidence_refs, visualization_specs. All 3 findings referenced. No unreferenced findings.
- Step 4: Recommendations generated for strong/moderate findings. F-001 strong + quasi-experimental -> confidence "high". F-002, F-003 moderate -> confidence "medium". No contradictions.
- Step 5: Context enrichment applied. Business terms annotated with definitions.
- Step 6: Present for review. Iteration 1.
- Step 7: narrative.json written with all 5 envelope fields.

**Envelope fields:** schema_version, skill_name, timestamp, record_count, artifact_id -- all present.

**Result:** ✅ PASS

---

### A-2: Technical narrative, partial scope, no context_map

**Input:** finding_set.json (schema_version=1.0, scope_coverage_assessment="partial", scope_gaps=["churn prediction"], findings=[F-001 moderate], contradictions_found=[]), scope_artifact.json (schema_version=1.0, audience="data science team"), no context_map.json.

**Walkthrough:**
- Step 0: narrative_style="technical" (audience contains "data science"). scope_coverage="partial". context_availability="unavailable". All validations pass.
- Step 1: Partial coverage. caution_flags=["Scope gap: churn prediction -- no analytical evidence available for this area"].
- Step 2: Technical summary composed with methodology focus.
- Step 3: Sections with statistical details, CIs, effect sizes.
- Step 4: Recommendations for moderate finding -> confidence "medium".
- Step 5: Context unavailable. caution_flags gets additional flag: "Business context definitions not available..."
- Step 7: narrative.json written with caution_flags populated.

**Result:** ✅ PASS

---

## Category B -- Variance Dimensions

### B-1: narrative_style = "executive"

**Input:** scope_artifact.audience="C-suite executive".

**Walkthrough:** Step 0 matches "C-suite" -> "executive". Step 2: compose_executive_summary (business outcome, magnitude, recommended action). Step 3: compose_business_body. No p-values in summary.

**Result:** ✅ PASS

---

### B-2: narrative_style = "technical"

**Input:** scope_artifact.audience="senior analyst team".

**Walkthrough:** Step 0 matches "analyst" -> "technical". Step 2: compose_technical_summary (analytical approach, key statistical result). Step 3: compose_technical_body (methodology, effect sizes, CIs).

**Result:** ✅ PASS

---

### B-3: narrative_style = "operational"

**Input:** scope_artifact.audience="operations manager".

**Walkthrough:** Step 0 matches "operations" OR "manager" -> "operational". Step 2: compose_operational_summary (what to do, when, expected impact). Step 3: compose_operational_body (action items, implementation).

**Result:** ✅ PASS

---

### B-4: scope_coverage = "complete"

**Input:** finding_set.scope_coverage_assessment="complete".

**Walkthrough:** Step 1: caution_flags=[]. PASS: "Full scope coverage confirmed."

**Result:** ✅ PASS

---

### B-5: scope_coverage = "partial"

**Input:** finding_set.scope_coverage_assessment="partial", scope_gaps=["retention prediction", "churn modeling"].

**Walkthrough:** Step 1: caution_flags populated with 2 gaps. WARN logged. Narrative proceeds with caution flags.

**Result:** ✅ PASS

---

### B-6: context_availability = "available"

**Input:** context_map.json exists with definitions.

**Walkthrough:** Step 5: Business terms extracted and annotated. Data lineage added. PASS.

**Result:** ✅ PASS

---

### B-7: context_availability = "unavailable"

**Input:** No context_map.json.

**Walkthrough:** Step 5: caution_flag added about missing business context definitions. WARN logged.

**Result:** ✅ PASS

---

## Category C -- Precondition Violations

### C-1: finding_set.json missing or scope_coverage_assessment == "insufficient"

**Precondition violated:** "finding_set.json exists with schema_version == '1.0' and scope_coverage_assessment != 'insufficient'"

**Input:** finding_set.json with scope_coverage_assessment="insufficient".

**Walkthrough:** Step 0: loads finding_set.json, checks scope_coverage_assessment. HALT: "Scope coverage is insufficient. Cannot generate narrative. Return to analytical skills to address gaps: {scope_gaps}."

**Result:** ✅ PASS -- Step 0 correctly HALTs.

---

### C-2: scope_artifact.json missing

**Precondition violated:** "scope_artifact.json exists with schema_version == '1.0'"

**Input:** finding_set.json exists, no scope_artifact.json.

**Walkthrough:** Step 0: scope_artifact not found. WARN: "scope_artifact.json not found; narrative framing will be generic."

**Analysis:** Precondition says scope_artifact is required, but Step 0 only WARNs. The skill proceeds with generic framing. Step 0 classification defaults narrative_style to "executive" (ELSE branch). Step 2 uses scope_artifact.research_question -- if null, this could fail silently.

**Result:** ⚠️ WARN -- Precondition says "required" but workflow WARNs and proceeds. Step 2 references scope_artifact.research_question without null-safety after the WARN path.

---

### C-3: finding_set.findings array is empty

**Precondition violated:** "finding_set.findings array has >= 1 finding"

**Input:** finding_set.json with findings=[].

**Walkthrough:** Step 0: len(finding_set.findings)==0. HALT: "No findings in finding_set. Nothing to narrate."

**Result:** ✅ PASS -- Step 0 correctly HALTs.

---

### C-4: context_map.json has wrong schema_version

**Precondition violated:** "If context_map.json is referenced, it has schema_version == '1.0'"

**Input:** context_map.json with schema_version="2.0".

**Walkthrough:** Step 0: context_availability="available", loads context_map.json, asserts schema_version=="1.0". Assertion fails.

**Analysis:** Step 0 pseudocode has the assert. However, unlike finding_set and scope_artifact, there is no explicit HALT message for context_map schema mismatch. The edge case table does not specifically cover context_map schema mismatch either (only finding_set and scope_artifact).

**Result:** ⚠️ WARN -- The assert exists in Step 0 but no explicit HALT message or edge case entry for context_map schema mismatch. Behavior on assertion failure is implicit.

---

## Category D -- Edge Cases

### D-1: Empty input (findings empty)

**Edge case:** "finding_set.findings is empty"

**Walkthrough:** Step 0: HALT: "No findings to narrate."

**Result:** ✅ PASS

---

### D-2: Single record (1 finding)

**Edge case:** "finding_set has exactly 1 finding"

**Walkthrough:** Step 2: top_finding is the only finding. Step 3: One cluster, one section. Step 4: recommendation generated if evidence_strength is strong/moderate.

**Analysis:** Edge case says "PASS: Generate single-section narrative. Note limited evidence base." Step 3 does not explicitly add a note about limited evidence base for single-finding narratives.

**Result:** ⚠️ WARN -- "Note limited evidence base" documented in edge case but no Step 3 logic adds such a note.

---

### D-3: All-null dimension (all findings have null evidence_strength)

**Edge case:** "All findings have null evidence_strength"

**Walkthrough:** Step 3: clustering and section generation. Edge case says WARN Step 3: "Cannot rank findings -- treat all as moderate."

**Analysis:** Step 3 pseudocode in narrative-generation does not perform ranking (that's finding-assembly's job). Narrative-generation receives pre-ranked findings. However, if evidence_strength is null on all findings, Step 4 recommendation filtering (`WHERE finding.evidence_strength in ["strong", "moderate"]`) would exclude all findings, triggering the "No recommendations generated" fallback. This is handled.

**Result:** ✅ PASS -- The edge case WARN is slightly misplaced (ranking is finding-assembly's concern), but Step 4 fallback handles the consequence correctly.

---

### D-4: Schema mismatch

**Edge case:** "schema_version != '1.0' on finding_set or scope_artifact"

**Walkthrough:** Step 0: assert fails on load. HALT: "Schema mismatch on {artifact}."

**Result:** ✅ PASS

---

### D-5: Insufficient scope coverage

**Edge case:** "scope_coverage_assessment == 'insufficient'"

**Walkthrough:** Step 0: HALT: "Cannot generate narrative with insufficient scope coverage."

**Result:** ✅ PASS

---

### D-6: All findings weak

**Edge case:** "Every finding has evidence_strength == 'weak'"

**Walkthrough:** Step 4: recommendation filter excludes all findings (only strong/moderate). Fallback triggers: WARN: "All findings weak. Narrative will emphasize need for additional analysis." Fallback recommendation added with confidence="low".

**Result:** ✅ PASS

---

### D-7: Contradictions dominate (>50% contradictory)

**Edge case:** "More than 50% of findings are contradictory"

**Walkthrough:** Edge case says WARN Step 3: "Majority of findings contradict. Narrative will prominently feature uncertainty."

**Analysis:** Step 3 pseudocode does not check contradiction ratio. Step 4 adds a contradiction-aware recommendation if contradictions_found is not empty, but there's no special handling for >50% contradictions. The WARN is documented but the "prominently feature uncertainty" behavior is not implemented.

**Result:** ⚠️ WARN -- Edge case documents special handling for dominant contradictions, but Steps 3-4 have no threshold check or differentiated behavior for >50%.

---

### D-8: Context map missing

**Edge case:** "context_map.json not found"

**Walkthrough:** Step 5: context_availability="unavailable". caution_flag added. WARN logged. Proceeds without enrichment.

**Result:** ✅ PASS

---

## Postcondition Verification

| Postcondition | Status | Notes |
|---|---|---|
| narrative.json exists with all 5 universal envelope fields | ✅ PASS | schema_version, skill_name, timestamp, record_count, artifact_id all present |
| executive_summary is 3-5 sentences covering question, finding, action | ✅ PASS | Step 2 explicitly specifies 3-5 sentences and the three components |
| Every finding referenced in at least one section's evidence_refs | ✅ PASS | Step 3 catch-all section handles unreferenced findings |
| Recommendations have supporting_finding refs and confidence levels | ✅ PASS | Step 4 explicitly sets both fields |
| caution_flags reflect scope gaps and context availability | ✅ PASS | Steps 1 and 5 populate caution_flags correctly |

---

## Quality Bar Verification

| Quality Item | Status | Notes |
|---|---|---|
| Validates against terminal artifact spec | ✅ PASS | All required fields present |
| Executive summary appropriate for narrative_style | ✅ PASS | Three distinct compose functions per style |
| All findings referenced -- none silently dropped | ✅ PASS | Step 3 catch-all section ensures completeness |
| Recommendations trace to specific findings | ✅ PASS | supporting_finding field always populated |
| Contradictions reflected in narrative | ✅ PASS | Step 4 adds contradiction-aware recommendation |
| Scope gaps produce caution_flags | ✅ PASS | Step 1 generates caution_flags from scope_gaps |
| Visualization specs are actionable | ✅ PASS | Terminal artifact example shows chart_type, x, y, title |

---

## Summary

| Category | Total | Pass | Warn | Fail | Critical |
|---|---|---|---|---|---|
| A (Happy Path) | 2 | 2 | 0 | 0 | 0 |
| B (Variance) | 7 | 7 | 0 | 0 | 0 |
| C (Precondition) | 4 | 2 | 2 | 0 | 0 |
| D (Edge Cases) | 8 | 6 | 2 | 0 | 0 |
| **Total** | **21** | **17** | **4** | **0** | **0** |

---

## Critical Issues

None.

---

## Warnings

1. **C-2:** scope_artifact.json precondition says "required" but workflow WARNs and proceeds. Step 2 references scope_artifact.research_question without null-safety after the WARN path, risking a silent failure when composing the executive summary.
2. **C-4:** context_map schema mismatch triggers an assert but has no explicit HALT message or edge case coverage. Behavior on failure is implicit.
3. **D-2:** Single-finding edge case says "Note limited evidence base" but no step adds such a note to the narrative output.
4. **D-7:** Dominant contradictions (>50%) edge case documents special behavior ("prominently feature uncertainty") but no step implements a threshold check or differentiated handling.
