# Assessment Report — stickiness-interval-analysis

Generated: 2026-04-10
Assessor: DSE Skill Tester (conceptual walkthrough)
Skill: `.claude/skills/stickiness-interval-analysis/SKILL.md`
Blueprint: `skill-blueprint/BLUEPRINT.md`

---

## Test Summary

| Category | Tests | Pass | Fail | Blocked |
|---|---|---|---|---|
| A — Happy Path | 4 | 4 | 0 | 0 |
| B — Variance Coverage | 9 | 7 | 2 | 0 |
| C — Precondition Violations | 10 | 8 | 2 | 0 |
| D — Edge Cases | 7 | 5 | 2 | 0 |
| **Total** | **30** | **24** | **6** | **0** |

---

## Per-Test Results

### Category A — Happy Path

| ID | Verdict | Notes |
|---|---|---|
| A-1 | PASS | Spec covers full workflow for transaction/daily/medium. Terminal artifact example matches. |
| A-2 | PASS | Login event type documented in variance surface. Weekly granularity path described in context classification. |
| A-3 | PASS | Interaction fallback and long window documented. |
| A-4 | PASS | `can_follow` declares retention-curve-analysis; `can_precede` declares finding-assembly and roi-computation. Upstream validation in Step 0 covers all four inputs. |

### Category B — Variance Coverage

| ID | Verdict | Notes |
|---|---|---|
| B-1 | PASS | Transaction path is the primary example in the SQL template. |
| B-2 | PASS | Login documented as variance value with distinct table. |
| B-3 | PASS | Interaction documented as fallback. |
| B-4 | PASS | Daily granularity uses precise DATEDIFF. |
| B-5 | FAIL | Weekly granularity is declared but the workflow SQL and Steps 1-3 show no distinct code path for weekly bucketing. The context classification sets the value but no step branches on `interval_granularity`. Behavior difference is stated ("smoothed to weekly buckets") but never implemented in the workflow. |
| B-6 | PASS | Short window (< 60d) maps correctly in context classification. |
| B-7 | PASS | Medium window (60-179d) mapped. |
| B-8 | FAIL | Long window (180d+) is declared but the workflow steps do not show how `trajectory_window` actually changes behavior in Steps 2-3. The trend detection logic is identical regardless of window length. No branching on this dimension in the workflow. |
| B-9 | FAIL (consequent) | Depends on B-5 and B-8; since those dimensions lack implementation branches, worst-case combo cannot be validated. Marked consequent to B-5/B-8. |

### Category C — Precondition Violations (PASS = HALT fires)

| ID | Verdict | Notes |
|---|---|---|
| C-1 | PASS | Step 0 upstream validation: `load cohort.json` will fail if missing. |
| C-2 | PASS | Step 0: `assert schema_version == "1.0"` covers this. |
| C-3 | PASS | Edge case table: `cohort.population_size == 0` triggers HALT Step 0. |
| C-4 | PASS | Step 0: `load feature_set.json` will fail if missing. |
| C-5 | PASS | Precondition: `assert data_ref not null`. |
| C-6 | PASS | Step 0: `load metric_result.json` will fail if missing. |
| C-7 | PASS | Step 0: `assert schema_version == "1.0"`. |
| C-8 | PASS | Step 0: `load retention_curve.json` will fail if missing. |
| C-9 | PASS | Step 0: `assert schema_version == "1.0"`. |
| C-10 | FAIL | Edge case table says HALT for all-null event dates, but no corresponding check exists in the Step 0 or Step 1 workflow pseudocode. The HALT is declared in the edge case table but not wired into the workflow as an explicit assertion. This means the HALT may not actually fire. |

### Category D — Edge Cases

| ID | Verdict | Notes |
|---|---|---|
| D-1 | PASS | Step 2 classifies `event_count <= 1` as "dormant". Edge case table documents the WARN. |
| D-2 | PASS | Edge case table: all customers dormant produces WARN. |
| D-3 | PASS | Edge case table: extreme intervals produce WARN. |
| D-4 | PASS | Step 1 checkpoint: WARN for single-event customers. Multi-event customers get intervals. |
| D-5 | PASS | Step 1 checkpoint: `intervals computed for >= 80% of cohort` — sub-80% would not pass checkpoint. |
| D-6 | FAIL | Not an explicit edge case in the table, but the trajectory classification logic has a gap: if all customers are `regular_weekly` with `cv < 0.3`, they map to "stable" in trajectory. However, the logic in Step 3 also checks `stickiness_score > 0.7 AND trend improving` for "deepening_engagement" — a regular customer with high stickiness and improving trend could be classified as either "stable" or "deepening_engagement". The precedence is ambiguous (IF/ELIF ordering matters but is not explicit about overlapping conditions). |
| D-7 | FAIL | Boundary values at thresholds (cv=0.3, stickiness=0.7, stickiness=0.2, cv=0.5) are not addressed. The spec uses strict inequalities (`<` not `<=`) for some thresholds but the boundary behavior is not documented. For example: `cv < 0.3` means cv=0.3 exactly is NOT regular_weekly but falls through to trend check. This is a specification gap. |

---

## Terminal Artifact Validation (5 Envelope Fields)

| # | Field | Present | Valid | Notes |
|---|---|---|---|---|
| 1 | `schema_version` | YES | YES | Value `"1.0"` in example. |
| 2 | `skill_name` | YES | YES | Value `"stickiness-interval-analysis"` matches frontmatter `name`. |
| 3 | `timestamp` | YES | YES | ISO-8601 UTC format in example. |
| 4 | `record_count` | YES | YES | Value `6148` in example. |
| 5 | `artifact_id` | YES | YES | Declared as `"{uuid}"` placeholder. |

**Envelope verdict: PASS** — All 5 universal envelope fields present and correctly formatted.

**Additional artifact fields validated:**

| Field | Present | Consistent |
|---|---|---|
| `analysis_level` | YES | Informational; value `"individual_customer"`. |
| `customer_count` | YES | Matches `record_count` in example (6148). Postcondition requires sum of pattern counts = customer_count. |
| `stickiness_scores` | YES | Contains mean, median, p25, p75, distribution_ref. |
| `interval_patterns` | YES | Array of 5 pattern objects with pattern_label, customer_count, mean_inter_event_days, cv_inter_event. |
| `trajectory_classifications` | YES | Object with 4 trajectory buckets. |

**Arithmetic check on example artifact:**
- Pattern counts: 2134 + 1856 + 891 + 734 + 533 = 6148 = customer_count. PASS.
- Trajectory counts: 1523 + 2134 + 1456 + 1035 = 6148 = customer_count. PASS.

---

## Coverage Assessment

### Variance Dimensions

| Dimension | Declared Values | Tested Values | Distinct Workflow Branch Exists | Verdict |
|---|---|---|---|---|
| `event_type` | 3 (transaction, login, interaction) | 3 | YES (different tables/columns) | PASS |
| `interval_granularity` | 2 (daily, weekly) | 2 | NO — no branch in Steps 1-3 | FAIL |
| `trajectory_window` | 3 (short, medium, long) | 3 | NO — no branch in Steps 2-3 | FAIL |

### Edge Case Coverage

| Declared Edge Cases | 6 |
|---|---|
| Tested (Cat C + Cat D) | 10 (C) + 7 (D) = 17 scenarios |
| All declared edge cases covered | YES |
| Additional edge cases identified | 2 (D-6: all-regular cohort overlap, D-7: boundary thresholds) |

### Precondition Coverage

| Declared Preconditions | 5 |
|---|---|
| HALT-wired in Step 0 | 4 of 5 (event-level data accessibility not explicitly validated in Step 0) |
| Category C tests | 10 |

---

## Blueprint Compliance (8 Principles)

| # | Principle | Verdict | Evidence |
|---|---|---|---|
| 1 | Single Job-to-be-Done | PASS | Name is `stickiness-interval-analysis` (verb-noun). Scope Boundary lists 4 refused jobs with responsible skills. |
| 2 | Precondition / Postcondition Contracts | PARTIAL | Preconditions are testable assertions with HALT in Step 0. However, precondition 5 ("Event-level data accessible") is not a testable assertion with an explicit HALT — it is vague compared to the others. Postconditions are present but only 3 items (blueprint recommends ensuring terminal artifact assertion is explicit). |
| 3 | Explicit Variance Surface | FAIL | 3 dimensions declared, but only `event_type` has distinct workflow branches. `interval_granularity` and `trajectory_window` are classified in Step 0 but never branched on in subsequent steps. This violates: "shows how behavior differs per dimension value." |
| 4 | Artifact at Every State Change | PASS | Terminal artifact captures stickiness scores, interval patterns, and trajectory classifications. Step 4 writes the artifact. |
| 5 | Stateful Operations Are Scoped | N/A | This skill does not fit/train/calibrate. It computes statistics. No leakage risk. |
| 6 | Quality Bar Over Completeness | PARTIAL | Edge case table declares 6 HALT/WARN conditions. However, the all-null event dates HALT is not wired into the workflow steps. One edge case HALT exists only in the table, not in procedural code. |
| 7 | Canonical Reference Library | N/A | No `references/` directory exists. No shared references are called. No pattern is duplicated from another skill. Not a violation — the skill simply has no extractable references yet. |
| 8 | Self-Contained Portability | FAIL | `scripts/` directory is empty — `generate_interval_result_artifact.py` does not exist. Blueprint checklist item 4 requires this script. The skill cannot produce its artifact via CLI when installed standalone. |

---

## 17-Item Checklist (Section 7)

### Definition and Structure (5)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 1 | Frontmatter: name + description only, description states transformation/trigger/input/output in <=3 sentences | PASS | Frontmatter is well-formed; description covers all four elements. |
| 2 | All required sections present in order | PASS | All 12 sections present: Overview, When to Activate, Preconditions, Prerequisites, Variance Surface, Workflow, Terminal Artifact, Edge Cases, Postconditions, Quality Bar, Scope Boundary, Downstream. Correct order. |
| 3 | SKILL.md <= 500 lines; overflow to references/ | PASS | File is 253 lines. Well under 500. |
| 4 | `scripts/generate_{name}_artifact.py` exists with standalone CLI | FAIL | `scripts/` directory is empty. No artifact generation script. |
| 5 | `requirements.txt` with 4-tier format; infrastructure in Prerequisites | PARTIAL | Prerequisites section lists library dependencies in tier format but there is no `requirements.txt` file. Infrastructure requirements (compute, memory, disk, OS, environment) are missing from Prerequisites. |

### Contracts and Correctness (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 6 | Preconditions testable with explicit HALT in Step 0 | PARTIAL | 4 of 5 preconditions have explicit HALT. Precondition 5 ("Event-level data accessible") lacks a concrete assertion and HALT. |
| 7 | Terminal artifact has all 5 envelope fields + domain fields | PASS | All 5 present. Domain fields (customer_count, stickiness_scores, interval_patterns, trajectory_classifications) present. |
| 8 | Stateful ops bounded to declared subset | N/A | No stateful operations. |
| 9 | Degraded upstream produces explicit HALT | PASS | Step 0 asserts schema_version and required fields for all 4 upstreams. |

### Variance and Testing (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 10 | Variance Surface complete; every dimension has >=2 values with distinct behavior | FAIL | 2 of 3 dimensions lack distinct workflow branches (see B-5, B-8). |
| 11 | Skill run with >=3 values of each dimension; all produce valid artifacts | BLOCKED | Cannot verify without implementation; conceptually blocked by item 10. |
| 12 | Terminal artifact passes downstream validation | PASS (conceptual) | Artifact structure is consumable by finding-assembly and roi-computation per declared downstream. |
| 13 | Domain pipeline regression test passes | BLOCKED | No regression test infrastructure exists. |

### Documentation and Integration (4)

| # | Item | Verdict | Notes |
|---|---|---|---|
| 14 | Domain README pipeline diagram updated | BLOCKED | No domain README exists to update. |
| 15 | Domain README artifact chain updated | BLOCKED | Same as above. |
| 16 | Domain README variance coverage table updated | BLOCKED | Same as above. |
| 17 | New shared patterns promoted to _shared-references/ | N/A | No new shared patterns identified. |

### Checklist Score: 7 PASS / 3 FAIL / 2 PARTIAL / 2 N/A / 4 BLOCKED = 17 items

---

## Pre-Merge Readiness Verdict

**NOT READY FOR MERGE**

The skill demonstrates strong structural design (all sections present, correct order, well-formed frontmatter, complete terminal artifact envelope) but has 4 blocking issues that must be resolved before merge.

---

## Required Fixes (Blocking)

| # | Priority | Issue | Location | Fix |
|---|---|---|---|---|
| RF-1 | P0 | `interval_granularity` dimension declared but no workflow branch | Steps 1-3 | Add explicit branching: daily path uses raw DATEDIFF; weekly path buckets intervals to 7-day periods before computing CV. Show distinct SQL or pseudocode for each. |
| RF-2 | P0 | `trajectory_window` dimension declared but no workflow branch | Steps 2-3 | Add explicit branching: short window uses recent-N-events trend; medium uses full-period linear regression; long uses segmented trend detection. Show how window length changes the trend computation. |
| RF-3 | P0 | `scripts/generate_interval_result_artifact.py` missing | `scripts/` | Create standalone CLI script that accepts computed stickiness data and writes `interval_result.json`. Must support `--help` and have no cross-skill imports. |
| RF-4 | P1 | All-null event dates HALT not wired into workflow | Step 1 | Add explicit check after SQL execution: `IF all event_date values are NULL: HALT "No event dates available."` as a pre-step assertion or checkpoint in Step 1. |

---

## Required Fixes (Non-Blocking)

| # | Priority | Issue | Location | Fix |
|---|---|---|---|---|
| RF-5 | P2 | Precondition 5 ("Event-level data accessible") is vague | Preconditions + Step 0 | Rewrite as testable assertion: e.g., `event_table exists AND row_count > 0 for cohort members`. Add HALT in Step 0. |
| RF-6 | P2 | Boundary threshold behavior undocumented | Steps 2-3 | Document whether thresholds use `<` or `<=` consistently. Specify: cv=0.3 exactly maps to which pattern? stickiness=0.7 exactly maps to which trajectory? |
| RF-7 | P2 | Trajectory classification overlap between "deepening_engagement" and "stable" | Step 3 | Clarify: a customer with pattern="regular_weekly" AND stickiness_score > 0.7 AND improving trend — which trajectory wins? The IF/ELIF ordering implies deepening wins, but document this explicitly. |
| RF-8 | P2 | Prerequisites section missing infrastructure requirements | Prerequisites | Add Compute, Memory, Disk, OS packages, Environment subsection per blueprint template. |
| RF-9 | P3 | No `requirements.txt` file | Skill root | Create `requirements.txt` with 4-tier format matching the inline Prerequisites section. |

---

## Tests Still Needed

| # | Test | Rationale | Blocked By |
|---|---|---|---|
| TN-1 | B-5 re-test after RF-1 | Weekly granularity branch must be verified once implemented | RF-1 |
| TN-2 | B-8 re-test after RF-2 | Long trajectory window branch must be verified once implemented | RF-2 |
| TN-3 | B-9 re-test after RF-1 + RF-2 | Worst-case variance combo depends on both fixes | RF-1, RF-2 |
| TN-4 | C-10 re-test after RF-4 | All-null event dates HALT must fire from workflow, not just edge case table | RF-4 |
| TN-5 | Integration test with generate script | Verify `scripts/generate_interval_result_artifact.py` produces valid artifact via CLI | RF-3 |
| TN-6 | Downstream acceptance test | Run finding-assembly and roi-computation validation against produced artifact | RF-3 |
| TN-7 | Pipeline regression test | Insert skill at declared position; verify full chain produces valid output | Infrastructure |

---

## Summary

The stickiness-interval-analysis skill has a solid conceptual design: clear single job, well-defined terminal artifact with correct envelope, proper upstream validation, and meaningful edge case coverage. The primary structural gap is that 2 of 3 declared variance dimensions are "classify-only" -- they are identified in Step 0 but never cause the workflow to branch. This means the skill effectively handles only one behavioral path regardless of granularity or window settings. The missing artifact generation script is the other blocking gap. Four required fixes (RF-1 through RF-4) must be resolved before this skill meets the blueprint's merge bar.
