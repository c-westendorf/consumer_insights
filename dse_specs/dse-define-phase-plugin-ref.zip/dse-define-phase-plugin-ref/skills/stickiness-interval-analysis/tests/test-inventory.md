# Test Inventory — stickiness-interval-analysis

Generated: 2026-04-10
Skill version: SKILL.md @ current HEAD

---

## Category A — Happy Path

| ID | Test Name | Description | Expected Outcome |
|---|---|---|---|
| A-1 | Standard transaction cohort | Cohort of 6000+ customers with transaction events, daily granularity, medium trajectory window (90d). All upstreams valid. | `interval_result.json` produced with all 5 envelope fields; pattern counts and trajectory counts each sum to `customer_count`. |
| A-2 | Login event type, weekly granularity | Cohort with login events, weekly granularity, short trajectory window (30d). | Valid artifact; intervals smoothed to weekly buckets; trajectory classifications reflect short window. |
| A-3 | Interaction events, long window | Interaction events, daily granularity, long trajectory window (180d+). | Valid artifact; trend detection uses longer window; all patterns populated. |
| A-4 | Full pipeline chain | Run after retention-curve-analysis with real upstream artifacts (cohort, feature_set, metric_result, retention_curve). Verify downstream readiness for finding-assembly and roi-computation. | Artifact validates; downstream skills can consume `interval_result.json`. |

---

## Category B — Variance Coverage

Each variance dimension requires at least 2 distinct values tested.

### B.event_type (3 values required)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B-1 | event_type = transaction | `transaction` | Queries transaction table; intervals based on purchase events. |
| B-2 | event_type = login | `login` | Queries login table; intervals based on authentication events. |
| B-3 | event_type = interaction | `interaction` | Queries interaction/engagement table; intervals based on general interactions. |

### B.interval_granularity (2 values required)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B-4 | granularity = daily | `daily` | Precise inter-event day calculations; no bucketing. |
| B-5 | granularity = weekly | `weekly` | Intervals smoothed to weekly buckets. |

### B.trajectory_window (3 values required)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B-6 | window = short (30d) | `short` | Observation window < 60d; faster trajectory detection. |
| B-7 | window = medium (90d) | `medium` | Observation window 60-179d; standard trajectory classification. |
| B-8 | window = long (180d+) | `long` | Observation window 180d+; detects slower trajectory changes. |

### B.cross — Worst-case combination

| ID | Test Name | Combination | Expected Outcome |
|---|---|---|---|
| B-9 | interaction + weekly + short | All three dimensions at least-data-rich values | Valid artifact produced or documented WARN; no silent failure. |

---

## Category C — Precondition Violations (HALT expected)

A Category C test PASSES only if the skill fires HALT and does NOT produce a terminal artifact.

| ID | Test Name | Violation | Expected HALT Message |
|---|---|---|---|
| C-1 | Missing cohort.json | `cohort.json` does not exist | HALT at Step 0: upstream validation failure. |
| C-2 | cohort.json schema mismatch | `schema_version != "1.0"` | HALT at Step 0: schema mismatch. |
| C-3 | cohort.json empty population | `population_size == 0` | HALT at Step 0: "Empty source" (edge case table). |
| C-4 | Missing feature_set.json | `feature_set.json` does not exist | HALT at Step 0: upstream validation failure. |
| C-5 | feature_set.json null data_ref | `data_ref` is null | HALT at Step 0: upstream validation failure. |
| C-6 | Missing metric_result.json | `metric_result.json` does not exist | HALT at Step 0: upstream validation failure. |
| C-7 | metric_result.json schema mismatch | `schema_version != "1.0"` | HALT at Step 0: schema mismatch. |
| C-8 | Missing retention_curve.json | `retention_curve.json` does not exist | HALT at Step 0: upstream validation failure. |
| C-9 | retention_curve.json schema mismatch | `schema_version != "1.0"` | HALT at Step 0: schema mismatch. |
| C-10 | All-null event dates | Event dates entirely NULL | HALT: "No event dates available." |

---

## Category D — Edge Cases

| ID | Test Name | Condition | Expected Action |
|---|---|---|---|
| D-1 | All single-event customers | Every customer has `event_count == 1` | WARN: "All customers have single event — interval analysis trivial." All classified as dormant. |
| D-2 | All customers dormant | Every customer has pattern "dormant" | WARN: "Entire cohort is dormant — verify event data coverage." |
| D-3 | Extreme intervals (>365d) | `mean_interval > 365` for some/all customers | WARN: "Very long intervals — verify this is the intended event type." |
| D-4 | Mixed single/multi-event | 50% single-event, 50% multi-event | Intervals computed for multi-event customers; singles classified as dormant; checkpoint passes if >= 80% coverage met. |
| D-5 | Sub-80% interval coverage | >20% of cohort has single events | WARN at Step 1 checkpoint: intervals computed for < 80% of cohort. |
| D-6 | All customers regular | Every customer has cv < 0.3 | All classified as regular_weekly/stable; valid artifact; no crash. |
| D-7 | Boundary stickiness scores | Customers at exact thresholds (cv=0.3, stickiness=0.7, stickiness=0.2, cv=0.5) | Classification handles boundary values consistently. |

---

## Test Count Summary

| Category | Count | Purpose |
|---|---|---|
| A — Happy Path | 4 | Confirm correct output under normal conditions |
| B — Variance Coverage | 9 | Ensure all dimension values produce distinct, valid behavior |
| C — Precondition Violations | 10 | Confirm HALT fires and no artifact produced |
| D — Edge Cases | 7 | Confirm graceful degradation under boundary conditions |
| **Total** | **30** | |
