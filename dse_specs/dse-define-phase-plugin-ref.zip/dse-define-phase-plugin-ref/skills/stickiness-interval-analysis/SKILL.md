---
name: stickiness-interval-analysis
description: >
  Analyzes inter-event intervals and engagement regularity patterns at the individual customer
  level, computing stickiness scores and classifying trajectory patterns (deepening, stable,
  decelerating, at-risk), producing interval_result.json. Activate after retention-curve-analysis
  when scope requires understanding engagement rhythm; takes cohort + feature_set + metric_result
  + retention_curve.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; provides customer_id_ref and observation_window"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref for event-level queries"
  - type: metric_result
    description: "Aggregate metrics from metric-computation; contextualizes interval analysis"
  - type: retention_curve
    description: "Retention rates from retention-curve-analysis; inflection periods inform where to focus interval analysis"
outputs:
  - type: interval_result
    description: "Per-customer stickiness scores, interval pattern classifications, and trajectory groupings"
can_follow: [feature-engineering, retention-curve-analysis]
can_precede: [finding-assembly, roi-computation]
supports_loop: true
exit_conditions:
  - "interval_result.json written with stickiness scores and interval patterns for all segments"
  - "patterns validated for all segments or budget exhausted (max 3 iterations)"
---

## Overview

Retention-curve-analysis shows *how many customers remain active* over time. Stickiness-interval-analysis shows *how regularly they engage* — the rhythm of interaction. A customer who visits weekly is fundamentally different from one who visits monthly, even if both "retain" across the same period.

This skill computes inter-event intervals at the individual customer level, derives stickiness scores (regularity metrics), classifies customers into interval patterns (regular, irregular, accelerating, decelerating, dormant), and groups them into trajectory classifications for downstream use.

**What this skill produces:** `interval_result.json` with stickiness score distributions, interval pattern classifications with counts, and trajectory classifications.

---

## When to Activate

- A plan task node with `task_type: "stickiness_interval_analysis"` is the next unexecuted task
- Scope involves engagement frequency, visit regularity, or stickiness metrics
- `retention_curve.json` exists and shows retention variation worth investigating at the interval level
- User explicitly requests "stickiness analysis", "engagement intervals", or "visit regularity"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `metric_result.json` exists with `schema_version == "1.0"`
- [ ] `retention_curve.json` exists with `schema_version == "1.0"`
- [ ] Event table exists and contains rows for cohort members (`SELECT COUNT(*) FROM {event_table} WHERE customer_id IN (cohort) > 0`)

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: scipy>=1.10 (coefficient of variation); numpy>=1.24 (interval statistics); pandas>=2.0 (time series)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
```
Compute: Standard (no GPU required); single-threaded sufficient for cohorts < 100K
Memory: 2 GB minimum; scales linearly with cohort size (~20 bytes per customer interval record)
Disk: < 50 MB for interval_result.json output
OS packages: None beyond Python standard library
Environment: Snowflake warehouse access with read permissions on event tables
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `event_type` | `transaction` / `login` / `interaction` | Determines which events define intervals; different tables/columns |
| `interval_granularity` | `daily` / `weekly` | `daily`: precise inter-event days; `weekly`: smoothed to weekly buckets |
| `trajectory_window` | `short` (30d) / `medium` (90d) / `long` (180d+) | Window for trend classification; longer windows detect slower trajectory changes |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify event_type: IF transaction data available → "transaction"; ELIF login data → "login"; ELSE → "interaction"
classify interval_granularity: IF scope_artifact.timeframe.granularity == "daily" → "daily"; ELSE → "weekly"
classify trajectory_window: IF observation window < 60d → "short"; ELIF < 180d → "medium"; ELSE → "long"
log: "Running stickiness-interval-analysis | event={value} | granularity={value} | window={value}"
```

**Upstream Validation:**
```
-- Cohort
load cohort.json
  IF file missing: HALT "cohort.json not found — run cohort-extraction first."
  assert schema_version == "1.0"; IF fail: HALT "cohort.json schema_version mismatch."
  assert population_size > 0; IF fail: HALT "Empty cohort — population_size is 0."

-- Feature Set
load feature_set.json
  IF file missing: HALT "feature_set.json not found — run feature-engineering first."
  assert schema_version == "1.0"; IF fail: HALT "feature_set.json schema_version mismatch."
  assert data_ref not null; IF fail: HALT "feature_set.json data_ref is null."

-- Metric Result
load metric_result.json
  IF file missing: HALT "metric_result.json not found — run metric-computation first."
  assert schema_version == "1.0"; IF fail: HALT "metric_result.json schema_version mismatch."

-- Retention Curve
load retention_curve.json
  IF file missing: HALT "retention_curve.json not found — run retention-curve-analysis first."
  assert schema_version == "1.0"; IF fail: HALT "retention_curve.json schema_version mismatch."

-- Event-Level Data Accessibility
query: SELECT COUNT(*) AS n FROM {event_table} WHERE customer_id IN (SELECT customer_id FROM {cohort.customer_id_ref})
  IF n == 0: HALT "No event-level data found for cohort members in {event_table}."
```

---

### Step 1 — Compute Inter-Event Intervals

**Goal:** For each customer, calculate the time between consecutive events.

**Actions:**
```
-- All-null event dates guard (RF-4)
pre_check = SELECT COUNT(*) AS n FROM {event_table}
            WHERE customer_id IN (SELECT customer_id FROM {cohort.customer_id_ref})
              AND event_date IS NOT NULL
IF n == 0: HALT "No event dates available — all event_date values are NULL."

-- Branch on interval_granularity
IF interval_granularity == "daily":
  -- Daily: use raw inter-event days (precise)
  Execute SQL:
    WITH ordered_events AS (
      SELECT customer_id, event_date,
             LAG(event_date) OVER (PARTITION BY customer_id ORDER BY event_date) AS prev_event_date
      FROM {event_table}
      WHERE customer_id IN (SELECT customer_id FROM {cohort.customer_id_ref})
        AND event_date IS NOT NULL
    )
    SELECT customer_id,
           AVG(DATEDIFF('day', prev_event_date, event_date)) AS mean_interval,
           STDDEV(DATEDIFF('day', prev_event_date, event_date)) AS std_interval,
           COUNT(*) AS event_count
    FROM ordered_events
    WHERE prev_event_date IS NOT NULL
    GROUP BY customer_id

ELIF interval_granularity == "weekly":
  -- Weekly: bucket events into ISO-week periods, then compute inter-bucket intervals
  Execute SQL:
    WITH weekly_events AS (
      SELECT customer_id,
             DATE_TRUNC('week', event_date) AS event_week
      FROM {event_table}
      WHERE customer_id IN (SELECT customer_id FROM {cohort.customer_id_ref})
        AND event_date IS NOT NULL
      GROUP BY customer_id, DATE_TRUNC('week', event_date)  -- deduplicate within week
    ),
    ordered_weeks AS (
      SELECT customer_id, event_week,
             LAG(event_week) OVER (PARTITION BY customer_id ORDER BY event_week) AS prev_event_week
      FROM weekly_events
    )
    SELECT customer_id,
           AVG(DATEDIFF('week', prev_event_week, event_week)) AS mean_interval,  -- in weeks
           STDDEV(DATEDIFF('week', prev_event_week, event_week)) AS std_interval,
           COUNT(*) AS event_count
    FROM ordered_weeks
    WHERE prev_event_week IS NOT NULL
    GROUP BY customer_id

-- Compute coefficient of variation (CV) per customer
FOR each customer: cv = std_interval / NULLIF(mean_interval, 0)
-- Stickiness score: inverse of CV (higher = more regular)
stickiness_score = 1 / (1 + cv)  -- normalized to [0, 1]
```

**Checkpoint:**
> - [ ] PASS: intervals computed for >=80% of cohort
> - [ ] WARN: customers with single event cannot have intervals computed

---

### Step 2 — Classify Interval Patterns

**Goal:** Assign each customer to an interval pattern category.

**Threshold Definitions (boundary behavior):**
```
Thresholds use strict inequality unless noted. Exact boundary values fall through to the next condition:
  - cv < 0.3    → regular   (cv == 0.3 exactly is NOT regular; falls through to trend check)
  - cv >= 0.3   → checked for trend-based patterns
  - event_count <= 1 → dormant (includes event_count == 1)
```

**Actions:**
```
interval_patterns = []
FOR each customer:
  -- Precedence: evaluated top-to-bottom; first match wins
  IF event_count <= 1: pattern = "dormant"
  ELIF cv < 0.3: pattern = "regular_weekly" (or "regular_biweekly"/"regular_monthly" based on mean_interval)

  -- Trend detection: branches on trajectory_window
  ELIF trajectory_window == "short":
    -- Short (30d): compare most-recent 3 intervals vs first 3 intervals
    compute trend = slope of recent-N-events (N = min(6, event_count))
    IF trend < 0 (intervals shrinking): pattern = "accelerating"
    ELIF trend > 0 (intervals growing): pattern = "decelerating"
    ELSE: pattern = "irregular"

  ELIF trajectory_window == "medium":
    -- Medium (90d): linear regression over all intervals in window
    compute trend = OLS slope of interval_days ~ event_sequence_number
    IF slope < -0.5 days/event (statistically significant): pattern = "accelerating"
    ELIF slope > 0.5 days/event (statistically significant): pattern = "decelerating"
    ELSE: pattern = "irregular"

  ELIF trajectory_window == "long":
    -- Long (180d+): segmented trend detection (split window into thirds)
    compute trend_early  = mean interval in first third of window
    compute trend_middle = mean interval in middle third
    compute trend_late   = mean interval in final third
    IF trend_late < trend_early AND trend_late < trend_middle: pattern = "accelerating"
    ELIF trend_late > trend_early AND trend_late > trend_middle: pattern = "decelerating"
    ELSE: pattern = "irregular"

-- Aggregate pattern counts
pattern_summary = GROUP BY pattern → {pattern_label, customer_count, mean_inter_event_days, cv_inter_event}
```

---

### Step 3 — Compute Trajectory Classifications

**Goal:** Group customers into engagement trajectory buckets.

**Precedence rule:** Conditions are evaluated top-to-bottom. The first matching condition wins. A customer with `pattern="regular_weekly"` AND `stickiness_score > 0.7` AND improving trend will be classified as `"deepening_engagement"` (not `"stable"`) because the deepening check comes first.

**Threshold Definitions (boundary behavior):**
```
  - stickiness_score > 0.7  → eligible for deepening (score == 0.7 exactly is NOT deepening)
  - stickiness_score < 0.2  → eligible for at_risk   (score == 0.2 exactly is NOT at_risk)
  - cv < 0.5                → eligible for stable     (cv == 0.5 exactly is NOT stable)
```

**Actions:**
```
trajectory_classifications = {deepening_engagement: 0, stable: 0, decelerating: 0, at_risk: 0}
FOR each customer:
  -- Evaluated in strict order; first match wins
  -- 1. Deepening: accelerating pattern OR high stickiness with improving trend
  IF pattern == "accelerating" OR (stickiness_score > 0.7 AND trend improving): "deepening_engagement"

  -- 2. At-risk: dormant pattern OR very low stickiness (checked before stable to prevent
  --    a dormant customer with cv < 0.5 from being misclassified as stable)
  ELIF pattern == "dormant" OR stickiness_score < 0.2: "at_risk"

  -- 3. Decelerating: explicitly decelerating pattern
  ELIF pattern == "decelerating": "decelerating"

  -- 4. Stable: regular pattern or moderate regularity (catch-all for remaining customers)
  ELIF pattern IN ("regular_weekly", "regular_biweekly", "regular_monthly") OR cv < 0.5: "stable"

  -- 5. Fallback: any customer not matching above (e.g., irregular with moderate stickiness)
  ELSE: "decelerating"
```

---

### Step 4 — Write Terminal Artifact

```
Generate artifact_id; compute aggregate stickiness score statistics
Write interval_result.json
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "stickiness-interval-analysis",
  "timestamp": "2026-04-10T16:30:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "analysis_level": "individual_customer",
  "customer_count": 6148,
  "stickiness_scores": {
    "mean": 0.62, "median": 0.67, "p25": 0.41, "p75": 0.81,
    "distribution_ref": "path/to/scores"
  },
  "interval_patterns": [
    {"pattern_label": "regular_weekly", "customer_count": 2134, "mean_inter_event_days": 7.2, "cv_inter_event": 0.21},
    {"pattern_label": "irregular", "customer_count": 1856, "mean_inter_event_days": 14.5, "cv_inter_event": 0.72},
    {"pattern_label": "accelerating", "customer_count": 891, "mean_inter_event_days": 10.1, "cv_inter_event": 0.45},
    {"pattern_label": "decelerating", "customer_count": 734, "mean_inter_event_days": 18.3, "cv_inter_event": 0.58},
    {"pattern_label": "dormant", "customer_count": 533, "mean_inter_event_days": null, "cv_inter_event": null}
  ],
  "trajectory_classifications": {
    "deepening_engagement": 1523, "stable": 2134, "decelerating": 1456, "at_risk": 1035
  }
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | cohort.population_size == 0 | HALT Step 0 |
| Single event per customer | all customers have event_count == 1 | WARN: "All customers have single event — interval analysis trivial." |
| All-null event dates | event dates entirely NULL | HALT: "No event dates available." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 |
| All customers dormant | every customer has pattern "dormant" | WARN: "Entire cohort is dormant — verify event data coverage." |
| Extreme intervals (>365 days) | mean_interval > 365 | WARN: "Very long intervals — verify this is the intended event type." |

---

## Postconditions

- [ ] `interval_result.json` exists with all 5 universal envelope fields
- [ ] `customer_count` matches sum of all pattern counts
- [ ] `stickiness_scores` statistics are consistent with distribution

---

## Quality Bar

- [ ] `interval_result.json` validates against terminal artifact spec
- [ ] Pattern counts sum to `customer_count`
- [ ] Trajectory classifications sum to `customer_count`
- [ ] Downstream `finding-assembly` and `roi-computation` can validate the artifact

---

## Scope Boundary

This skill does NOT:
- Compute retention curves → handled by `retention-curve-analysis`
- Classify lifecycle maturity states → handled by `maturity-state-classification`
- Compute aggregate metrics → handled by `metric-computation`
- Monetize stickiness impact → handled by `roi-computation`

---

## Downstream

1. **`finding-assembly`** — includes stickiness patterns and trajectory distributions as findings
2. **`roi-computation`** — reads `interval_result` to estimate revenue impact of engagement regularity changes
