---
name: scope-formatting
description: >
  Renders a validated, complete scope into scope_artifact.json for user approval and Plan
  Agent consumption. Generates a 3-5 sentence human-readable summary alongside the structured
  JSON. Activate when completeness-validation reports is_complete=true. Takes complete
  partial_scope and intent_classification; produces scope_artifact that is immutable after
  user approval.
inputs:
  - type: partial_scope
    description: "Complete partial scope with all required fields non-null"
  - type: intent_classification
    description: "Classified lifecycle stage and analytical pattern"
  - type: session_metadata
    description: "Session ID, attempt count, and disambiguation history"
    optional: true
outputs:
  - type: scope_artifact
    description: "Approved, immutable scope definition consumed by Plan Agent and Analyze Phase"
can_follow: [completeness-validation]
can_precede: []
supports_loop: false
exit_conditions:
  - "scope_artifact.json written with all required fields, human-readable summary, and approved_at timestamp"
  - "user explicitly approved the scope (not ambiguous acknowledgment)"
---

# scope-formatting

## Overview

This is the terminal skill of the Scope Agent pipeline. It takes a complete `partial_scope`
and formats it into the canonical `scope_artifact.json` that serves as the sole interface
between the Scope Agent and the Plan Agent. The scope_artifact is consumed by 5+ Analyze
Phase skills (`data-retrieval`, `cohort-extraction`, `metric-computation`,
`business-context-layer`, `narrative-generation`). The artifact is immutable after user
approval -- hooks enforce this constraint. Any post-approval change requires a new scope
session.

The skill generates a human-readable summary (3-5 sentences) that restates the analysis
scope in plain language, allowing the user to verify intent before the artifact is locked.

---

## When to Activate

Invoke this skill when:

- `completeness-validation` has produced a `completeness_assessment` with `is_complete=true`.
- All pattern-specific required fields in `partial_scope` are non-null.
- The pipeline is ready to present the scope for user approval.

Do NOT invoke when:

- `completeness-validation` reported `is_complete=false` (disambiguation still needed).
- No `partial_scope` or `intent_classification` exists.
- A `scope_artifact` already exists for this session and has been approved (immutability).

---

## Preconditions

| # | Condition | On Fail |
|---|-----------|---------|
| P1 | `partial_scope` artifact exists with `artifact_id` | HALT -- "No partial_scope found. Run scope-extraction first." |
| P2 | `intent_classification` artifact exists with `analytical_pattern` and `lifecycle_stage` | HALT -- "No intent_classification found. Run intent-classification first." |
| P3 | `completeness_assessment` exists with `is_complete=true` | HALT -- "Scope is not complete. Run completeness-validation first." |
| P4 | All pattern-specific required fields in `partial_scope` are non-null | HALT -- "Required field '{field}' is null despite completeness_assessment.is_complete=true. Data integrity error." |
| P5 | No approved `scope_artifact` already exists for this session | HALT -- "An approved scope_artifact already exists (artifact_id={id}). Scope is immutable after approval." |

---

## Prerequisites

| Prerequisite | Required | Notes |
|---|---|---|
| `partial_scope` artifact | Yes | Complete scope from `scope-extraction`, validated by `completeness-validation`. |
| `intent_classification` artifact | Yes | From `intent-classification`. Must include `analytical_pattern`, `lifecycle_stage`, `confidence`. |
| `completeness_assessment` artifact | Yes | From `completeness-validation`. Must have `is_complete=true`. |
| `session_metadata` | No | Session ID, attempt count, and disambiguation history for provenance tracking. |

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `analytical_pattern` | `profile` / `compare` / `predict` / `explain` / `segment` | Affects human-readable summary template: `profile` emphasizes population description; `compare` highlights the reference; `predict` states the horizon; `explain` names the outcome variable; `segment` describes the segmentation basis. |
| `approval_status` | `pending` / `approved` / `revision_requested` | `pending`: present summary and structured fields for user review. `approved`: set `approved_at` and `approved_by`, write final artifact, lock immutability. `revision_requested`: return to `scope-extraction` loop with user's feedback attached. |
| `business_context` | `present` / `absent` | `present`: summary includes decision framing ("to inform {decision}"). `absent`: summary omits decision framing, adds advisory warning that context is missing. |

---

## Workflow

### Step 0: Context Classification + Upstream Validation

Load and validate all upstream artifacts before assembly.

```
LOAD partial_scope from upstream scope-extraction artifact
LOAD intent_classification from upstream intent-classification artifact
LOAD completeness_assessment from upstream completeness-validation artifact
LOAD session_metadata (optional)

VALIDATE partial_scope.artifact_id exists           → on fail: HALT "Missing partial_scope"
VALIDATE intent_classification.artifact_id exists   → on fail: HALT "Missing intent_classification"
VALIDATE completeness_assessment.is_complete == true → on fail: HALT "Scope not complete"
VALIDATE intent_classification.analytical_pattern
    IN [profile, compare, predict, explain, segment]
    → on fail: HALT "Unknown analytical_pattern"

SET pattern = intent_classification.analytical_pattern
SET required_fields = REQUIRED_FIELDS_MATRIX[pattern]

FOR each key in [population, metric, timeframe, comparison, business_context, constraints]:
    IF key not in partial_scope:
        HALT: "partial_scope schema mismatch: missing key '{key}'."

FOR field IN required_fields:
    VALIDATE partial_scope[field] is not null
    → on fail: HALT "Required field '{field}' is null. Data integrity error."

CHECK no approved scope_artifact exists for session
    → on fail: HALT "Immutable scope_artifact already exists."
```

> **CHECKPOINT -- Step 0**
> - [ ] All three upstream artifacts loaded with valid `artifact_id` -- PASS / HALT
> - [ ] `is_complete=true` confirmed -- PASS / HALT
> - [ ] All pattern-specific required fields non-null -- PASS / HALT
> - [ ] No prior approved artifact for this session -- PASS / HALT

---

### Step 1: Assemble Scope Structure

Combine `intent_classification` and `partial_scope` into the `scope_artifact` schema
defined in `data-type-registry.md`.

```
SET scope_artifact = {
    schema_version: "1.0",
    skill_name: "scope-formatting",
    timestamp: NOW_UTC_ISO8601,
    record_count: 1,
    artifact_id: NEW_UUID,
    approved_at: null,          # set on approval
    approved_by: null,          # set on approval
    lifecycle_stage: intent_classification.lifecycle_stage,
    analytical_pattern: pattern,
    confidence: intent_classification.confidence,
    population: partial_scope.population,
    metric: partial_scope.metric,
    timeframe: partial_scope.timeframe,
    comparison: partial_scope.comparison OR null,
    prediction_horizon: partial_scope.prediction_horizon OR null,
    outcome_variable: partial_scope.outcome_variable OR null,
    segmentation_basis: partial_scope.segmentation_basis OR null,
    business_context: partial_scope.business_context OR null,
    constraints: partial_scope.constraints OR [],
    human_readable_summary: null,   # generated in Step 2
    metadata: {
        session_id: session_metadata.session_id OR NEW_UUID,
        disambiguation_turns: session_metadata.attempt_count OR 0,
        classification_confidence: intent_classification.confidence
    }
}
```

Include pattern-specific fields from partial_scope. Set to null if not applicable to current pattern.

Field formatting rules:
- `population.criteria`: each criterion must have `field`, `operator`, `value`.
- `metric.aggregation`: must be one of `proportion`, `mean`, `count`, `sum`, `rate`.
- `timeframe.start` and `timeframe.end`: ISO-8601 date format (`YYYY-MM-DD`).
- `timeframe.granularity`: must be one of `daily`, `weekly`, `monthly`.
- `constraints`: array of strings; empty array if none.

> **CHECKPOINT -- Step 1**
> - [ ] All 5 envelope fields present -- PASS
> - [ ] `lifecycle_stage` and `analytical_pattern` are valid enum values -- PASS
> - [ ] `population`, `metric`, `timeframe` are structured objects (not bare strings) -- PASS
> - [ ] On assembly error: HALT "Failed to assemble scope_artifact structure."

---

### Step 2: Generate Human-Readable Summary

Write a 3-5 sentence summary that restates the analysis scope in plain language. The
summary must be specific enough that a stakeholder can approve or reject it without
reading the JSON.

**Template by pattern:**

| Pattern | Template |
|---------|----------|
| `profile` | "We will analyze {population} by measuring {metric} over {timeframe}. {business_context_sentence}" |
| `compare` | "We will analyze {population} by measuring {metric} over {timeframe}, comparing against {comparison}. {business_context_sentence}" |
| `predict` | "We will analyze {population} by measuring {metric} over {timeframe}, forecasting {prediction_horizon} ahead. {business_context_sentence}" |
| `explain` | "We will analyze {population} by measuring {metric} over {timeframe}, identifying factors that drive {outcome_variable}. {business_context_sentence}" |
| `segment` | "We will analyze {population} over {timeframe}, segmenting by {segmentation_basis}. {business_context_sentence}" |

```
SET summary = render_summary_template(pattern, scope_artifact)

IF business_context is not null:
    APPEND "This analysis will inform {business_context}."
ELSE:
    APPEND "No specific business decision was stated for this analysis."

IF constraints is not empty:
    APPEND "Constraints: {constraints_as_sentence}."

SET scope_artifact.human_readable_summary = summary
```

Summary validation rules:
- Must be 3-5 sentences. Fewer than 3: too vague. More than 5: too detailed.
- Must mention the population, metric (or segmentation basis), and timeframe explicitly.
- Must not include JSON field names or technical identifiers.
- Must not speculate beyond what the user stated.

> **CHECKPOINT -- Step 2**
> - [ ] Summary is 3-5 sentences -- PASS / WARN if outside range
> - [ ] Summary references population, metric/basis, and timeframe -- PASS
> - [ ] Summary contains no JSON field names -- PASS
> - [ ] On template rendering failure: HALT "Failed to generate summary."

---

### Step 3: Present for Approval

Display the human-readable summary AND the structured fields to the user. Wait for
explicit approval.

```
PRESENT to user:
    "## Scope Summary"
    "{human_readable_summary}"
    ""
    "## Structured Scope"
    "- Population: {population.description}"
    "- Metric: {metric.name} ({metric.aggregation})"
    "- Timeframe: {timeframe.start} to {timeframe.end} ({timeframe.granularity})"
    "- Comparison: {comparison.reference OR 'None'}"
    "- Business Context: {business_context OR 'Not specified'}"
    "- Constraints: {constraints OR 'None'}"
    ""
    "Do you approve this scope? (yes / no / revise)"

WAIT for user response

CLASSIFY response:
    "yes", "approved", "looks good", "correct", "lgtm" → approval_status = "approved"
    "no", "wrong", "start over"                        → approval_status = "revision_requested"
    "revise", "change", "update", "actually"            → approval_status = "revision_requested"
    ambiguous or unclear                                → RE-ASK "Please confirm: do you
                                                           approve this scope as stated?
                                                           (yes / no / revise)"
```

Approval classification rules:
- Only explicit affirmation counts as approval. "Sure" or "okay" alone are ambiguous.
- If the user provides a revision in their response (e.g., "change the timeframe to Q2"),
  classify as `revision_requested` and attach the feedback.
- Never auto-approve. The user must respond.

> **CHECKPOINT -- Step 3**
> - [ ] User response received and classified -- PASS
> - [ ] If ambiguous: re-asked for explicit confirmation -- PASS
> - [ ] On timeout (no response): WARN "Awaiting user approval. Scope not yet finalized."

---

### Step 4: Write Artifact

On approval, finalize and write the immutable artifact. On revision, route back to the
disambiguation loop.

```
IF revision_count >= 3:
    WARN: "Multiple revision cycles ({revision_count}). Consider restarting the scope session."

IF approval_status == "approved":
    SET scope_artifact.approved_at = NOW_UTC_ISO8601
    SET scope_artifact.approved_by = "user"
    WRITE scope_artifact.json
    LOG "Scope approved and written. artifact_id={artifact_id}"

ELIF approval_status == "revision_requested":
    ATTACH user_feedback to session_metadata
    LOG "Revision requested. Returning to scope-extraction with feedback."
    ROUTE to scope-extraction with:
        - original raw_question
        - user_feedback as additional context
        - incremented attempt_count
    EXIT without writing artifact
```

> **CHECKPOINT -- Step 4**
> - [ ] If approved: `approved_at` and `approved_by` are set -- PASS
> - [ ] If approved: `scope_artifact.json` written successfully -- PASS
> - [ ] If revision: feedback attached and routed to scope-extraction -- PASS
> - [ ] On write failure: HALT "Failed to write scope_artifact.json."

---

## Terminal Artifact

**File:** `scope_artifact.json` (conforms to `data-type-registry.md`)

```json
{
  "schema_version": "1.0",
  "skill_name": "scope-formatting",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 1,
  "artifact_id": "{uuid}",
  "approved_at": "{ISO-8601 UTC}",
  "approved_by": "user",
  "lifecycle_stage": "reactivated",
  "analytical_pattern": "compare",
  "confidence": 0.87,
  "population": {
    "description": "Reactivated low-engaged customers who returned in Q1 2025",
    "criteria": [
      {"field": "lifecycle_stage", "operator": "==", "value": "reactivated_low_engaged"}
    ]
  },
  "metric": {
    "name": "90-day repeat purchase rate",
    "definition": "% of customers with 2+ purchases within 90 days of reactivation",
    "aggregation": "proportion"
  },
  "timeframe": {
    "start": "2025-01-01",
    "end": "2025-06-30",
    "granularity": "monthly",
    "reference": "12 months for behavioral features"
  },
  "comparison": {
    "type": "vs_population",
    "reference": "Continuously active medium-engaged customers in same period"
  },
  "prediction_horizon": null,
  "outcome_variable": null,
  "segmentation_basis": null,
  "business_context": {
    "question": "How do reactivated low-engaged customers compare to continuously active medium-engaged customers?",
    "decision": "Whether to increase reactivation campaign budget for Q3",
    "stakeholder": "VP Marketing"
  },
  "constraints": ["Exclude customers reactivated via deep discount (>50% off)"],
  "human_readable_summary": "We will analyze reactivated low-engaged customers who returned in Q1 2025 by measuring their 90-day repeat purchase rate over January-June 2025, comparing against continuously active medium-engaged customers in the same period. This analysis will inform the Q3 reactivation campaign budget decision. Customers reactivated via deep discount (>50% off) will be excluded.",
  "metadata": {
    "session_id": "{uuid}",
    "disambiguation_turns": 4,
    "classification_confidence": 0.87
  }
}
```

---

## Edge Cases

| # | Edge Case | Detection | Action |
|---|-----------|-----------|--------|
| E1 | **Empty input** -- `partial_scope` has all null fields | All six fields are null | HALT -- "Cannot format an empty scope. This should have been caught by completeness-validation." |
| E2 | **Single record** -- only one field populated | Only 1 of 6 fields non-null despite `is_complete=true` | HALT -- "Data integrity error: completeness_assessment reported complete but only 1 field populated." |
| E3 | **All-null dimension** -- a pattern-required field is null | Required field is null despite `is_complete=true` | HALT -- "Data integrity error: {field} is null but was reported as complete." |
| E4 | **Schema mismatch** -- `partial_scope` missing expected keys | `partial_scope` does not contain canonical field keys | HALT -- "partial_scope schema mismatch: missing key '{key}'." |
| E5 | **Duplicate approval** -- user approves a scope that already has `approved_at` set | `scope_artifact.approved_at` is already non-null | HALT -- "Scope already approved at {approved_at}. Cannot re-approve. Start a new session to modify." |
| E6 | **Summary generation failure** -- template rendering produces empty or malformed text | Summary is empty, < 3 sentences, or contains JSON field names | WARN -- fall back to basic concatenation: "{population} + {metric} + {timeframe}". Flag for manual review. |
| E7 | **Revision loop depth** -- user requests revision > 3 times from this skill | Revision count from scope-formatting >= 3 | WARN -- "Multiple revisions requested. Consider restarting the scope session." Still allow revision. |
| E8 | **Ambiguous approval response** -- user response cannot be classified | Response does not match any approval/rejection/revision pattern | Re-ask with explicit options: "Please respond with 'yes' to approve, 'no' to reject, or describe what you'd like to change." |

---

## Postconditions

| # | Condition | Enforcement |
|---|-----------|-------------|
| Q1 | If approved: `scope_artifact.json` exists with valid `artifact_id` | File-existence check after write. |
| Q2 | If approved: `approved_at` is a valid ISO-8601 timestamp | Timestamp format validation. |
| Q3 | If approved: `approved_by` is "user" | String equality check. |
| Q4 | If approved: `human_readable_summary` is 3-5 sentences | Sentence-count check. |
| Q5 | If approved: artifact conforms to `data-type-registry.md` `scope_artifact` schema | Schema validation against registry. |
| Q6 | If revision_requested: no artifact written, feedback routed to scope-extraction | File-absence check + routing confirmation. |
| Q7 | Artifact is immutable after approval -- no subsequent writes permitted | Hook enforcement on file modification. |

---

## Quality Bar

Every scope-formatting run must meet this standard:

- The `scope_artifact.json` conforms exactly to the schema in `data-type-registry.md`.
- All 5 universal envelope fields are present and correctly typed.
- `human_readable_summary` is 3-5 sentences, mentions population, metric/basis, and timeframe.
- The summary contains no JSON field names, UUIDs, or technical identifiers.
- User approval is explicit -- not inferred from ambiguous responses.
- `approved_at` is set only after explicit user approval, never pre-populated.
- If the user requests revision, feedback is attached and the loop routes correctly.
- The artifact, once approved, is never modified (immutability enforced by hooks).

---

## Scope Boundary

This skill formats and presents the scope. It does NOT:

- Classify the question intent -- that is `intent-classification`.
- Extract structured fields from the question -- that is `scope-extraction`.
- Validate completeness of the scope -- that is `completeness-validation`.
- Decompose the scope into tasks -- that is `task-decomposition`.
- Generate a project plan -- that is `plan-formatting`.
- Execute any analysis -- that is the Analyze Phase.
- Modify the `partial_scope` -- it reads and formats, never mutates upstream data.

---

## Downstream

| If outcome is... | Next skill | Rationale |
|---|---|---|
| `approved` | `task-decomposition` (Plan Agent) | Approved scope_artifact is the sole input to the Plan Agent pipeline. |
| `revision_requested` | `scope-extraction` (with feedback) | User feedback is attached as additional context for re-extraction. Completeness-validation will re-evaluate. |
| Approval pending (no response) | None -- wait | Cannot proceed without explicit user approval. |
