---
name: latent-factor-modeling
description: >
  Discovers latent behavioral dimensions underlying customer feature sets using factor analysis
  or PCA, with factorability tests and model fit validation, producing factor_model.json with
  labeled factors, loadings, and variance explained. Activate when scope_artifact.analytical_pattern
  is 'segment' or analysis requires dimensionality reduction; takes cohort + feature_set.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; provides population context"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref and features_applied provide the feature matrix for factor analysis"
outputs:
  - type: factor_model
    description: "Latent factors with loadings, variance explained, fit indices, and cluster assignments"
can_follow: [feature-engineering]
can_precede: [finding-assembly, value-decomposition-analysis]
supports_loop: true
exit_conditions:
  - "factor_model.json written with fit indices acceptable or budget exhausted (max 3 iterations)"
---

## Overview

Feature-engineering produces many observed variables. Latent-factor-modeling discovers the smaller set of *underlying dimensions* that explain the covariance structure — revealing that 20 behavioral features might reduce to 3-4 interpretable factors like "purchase intensity", "channel diversity", and "recency sensitivity."

The skill selects between factor analysis (for latent construct discovery) and PCA (for variance-maximizing reduction), validates factorability (KMO, Bartlett's), determines optimal factor count, applies rotation, and produces labeled factors with interpretive notes.

**What this skill produces:** `factor_model.json` with method selection rationale, factorability tests, fit indices, labeled factors with top loadings, and cluster assignment references.

---

## When to Activate

- `scope_artifact.analytical_pattern == "segment"` implies dimensionality reduction
- Feature set has ≥10 numeric features suitable for factor analysis
- User requests "factor analysis", "PCA", "dimensionality reduction", or "latent factors"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and `population_size > 0`
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and `feature_count >= 5`
- [ ] ≥5 numeric features available in feature_set (factor analysis requires sufficient dimensionality)

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: factor-analyzer>=0.4 (FA, KMO, Bartlett's); sklearn>=1.2 (PCA); scipy>=1.10; numpy>=1.24; pandas>=2.0
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `method` | `factor_analysis` / `pca` | FA: latent constructs with unique variance; PCA: total variance maximization without latent model |
| `factor_selection` | `scree_plot` / `parallel_analysis` / `bic` | Different criteria for determining optimal factor count |
| `rotation` | `varimax` / `promax` / `none` | `varimax`: orthogonal simple structure; `promax`: oblique (correlated factors); `none`: unrotated |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

```
-- Classify variance dimensions from scope/user intent
method       = classify("factor_analysis" | "pca")
factor_selection = classify("parallel_analysis" | "scree_plot" | "bic")
rotation     = classify("varimax" | "promax" | "none")

-- Validate upstream: cohort.json
load cohort.json
  IF not found: HALT: "Upstream validation failed: cohort.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json -- schema_version mismatch."
assert population_size > 0
  IF not: HALT: "Upstream validation failed: cohort.json -- population_size is 0 (empty source)."

-- Validate upstream: feature_set.json
load feature_set.json
  IF not found: HALT: "Upstream validation failed: feature_set.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json -- schema_version mismatch."
assert feature_count >= 5
  IF not: HALT: "Upstream validation failed: feature_set.json -- feature_count < 5. Insufficient features for factor analysis (minimum 5)."
assert numeric_feature_count >= 5
  IF not: HALT: "Upstream validation failed: feature_set.json -- fewer than 5 numeric features available for factor analysis."
```

### Step 1 — Factorability Assessment

```
-- Load feature matrix (sample if >50k rows)
feature_matrix = sample(feature_set.data_ref, max=50000)
-- Remove non-numeric and zero-variance columns

-- KMO test (Kaiser-Meyer-Olkin)
kmo_model, kmo_score = calculate_kmo(feature_matrix)
IF kmo_score < 0.5:
  HALT: "KMO score {kmo_score} < 0.5 — data is not suitable for factor analysis.
  Consider alternative analytical approaches."
ELIF kmo_score < 0.6:
  WARN: "KMO score {kmo_score} is marginal — proceed with caution."

-- Bartlett's test of sphericity
chi2, p_value = bartletts_test(feature_matrix)
IF p_value > 0.05:
  WARN: "Bartlett's test not significant (p={p_value}) — correlation matrix may not differ from identity."
```

### Step 2 — Determine Factor Count

```
IF factor_selection == "parallel_analysis":
  n_factors = parallel_analysis(feature_matrix)  -- compare eigenvalues to random data
ELIF factor_selection == "scree_plot":
  eigenvalues = compute_eigenvalues(feature_matrix)
  n_factors = find_elbow(eigenvalues)
ELIF factor_selection == "bic":
  n_factors = argmin(BIC for k=1..max_k)

IF n_factors < 2:
  WARN: "Only 1 factor identified — data may be unidimensional."
IF n_factors > feature_count / 3:
  WARN: "Many factors relative to features — consider reducing feature set."
```

### Step 3 — Fit Model and Rotate

```
IF method == "factor_analysis":
  fa = FactorAnalyzer(n_factors=n_factors, rotation=rotation)
  fa.fit(feature_matrix)
  loadings = fa.loadings_
  variance_explained = fa.get_factor_variance()
  -- Compute fit indices
  cfi, rmsea, srmr = compute_fit_indices(fa, feature_matrix)

  -- Fit index enforcement checkpoint (Quality Bar)
  IF cfi < 0.90 OR rmsea > 0.08:
    WARN: "Model fit below quality bar (CFI={cfi}, RMSEA={rmsea}). Consider adjusting factor count or rotation."
    IF supports_loop AND iteration < max_iterations:
      flag_for_refit = true  -- loop logic in Step 4 will retry
    ELSE:
      WARN: "Proceeding with substandard fit -- no iterations remaining."
  IF srmr > 0.10:
    WARN: "SRMR={srmr} exceeds 0.10 -- residual correlations are large."

ELIF method == "pca":
  pca = PCA(n_components=n_factors)
  pca.fit(feature_matrix)
  loadings = pca.components_.T
  variance_explained = pca.explained_variance_ratio_

-- Label factors by top-loading features
factors = []
FOR each factor_idx in range(n_factors):
  top_features = sorted by |loading|, take top 3-5
  label = LLM_generate_label(top_features, scope_context)
  factors.append({factor_id, label, top_loading_features, variance_explained_pct, interpretive_notes})
```

### Step 4 — Loop Evaluation and Terminal Artifact

```
max_iterations = 3
iteration = 1
previous_loadings = null

LOOP:
  -- Steps 1-3 execute above; results available as loadings, fit indices, factors

  -- Check loading stability (iteration >= 2)
  IF previous_loadings IS NOT null:
    loading_delta = max(|loadings - previous_loadings|)
    IF loading_delta < 0.05:
      stable = true  -- converged
    ELSE:
      stable = false
      WARN: "Loading instability detected (max delta={loading_delta}). Adjusting model."
  ELSE:
    stable = false  -- first iteration, no comparison yet

  -- Decide: write artifact or iterate
  IF stable OR NOT flag_for_refit:
    BREAK  -- proceed to write artifact
  ELIF iteration >= max_iterations:
    WARN: "Budget exhausted ({max_iterations} iterations). Writing best available model."
    BREAK
  ELSE:
    -- Prepare next iteration: adjust factor count or rotation
    previous_loadings = loadings
    iteration = iteration + 1
    IF rmsea > 0.08: n_factors = n_factors - 1  -- reduce complexity
    IF cfi < 0.90 AND rotation == "varimax": rotation = "promax"  -- try oblique
    CONTINUE to Step 3  -- refit with adjusted parameters
END LOOP

-- Write factor_model.json
write factor_model.json with:
  schema_version, skill_name, timestamp, record_count, artifact_id,
  method, method_selection_rationale, n_factors, factor_selection_method,
  rotation, factorability_tests, model_fit, factors, cluster_assignments_ref,
  iterations_completed = iteration
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "latent-factor-modeling",
  "timestamp": "2026-04-10T17:15:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "method": "factor_analysis",
  "method_selection_rationale": "Latent construct discovery preferred; KMO=0.78 indicates adequate factorability",
  "n_factors": 3,
  "factor_selection_method": "parallel_analysis",
  "rotation": "varimax",
  "factorability_tests": {"kmo_score": 0.78, "bartletts_p_value": 0.001},
  "model_fit": {"cfi": 0.96, "rmsea": 0.05, "srmr": 0.04},
  "factors": [
    {
      "factor_id": "F-001",
      "label": "Purchase Intensity",
      "top_loading_features": [
        {"feature": "purchase_rate_per_30d", "loading": 0.82},
        {"feature": "annual_spend_log1p", "loading": 0.74},
        {"feature": "transaction_count_12m", "loading": 0.71}
      ],
      "variance_explained_pct": 0.32,
      "interpretive_notes": "Captures overall purchasing volume and frequency"
    }
  ],
  "cluster_assignments_ref": "path/to/factor_scores",
  "iterations_completed": 1
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | population_size == 0 | HALT Step 0 |
| Too few features | feature_count < 5 | HALT: "Insufficient features for factor analysis (minimum 5)." |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| KMO too low | kmo_score < 0.5 | HALT: "Data not suitable for factor analysis." |
| Singular correlation matrix | det(corr) ≈ 0 | WARN: remove collinear features and retry |
| All variance in one factor | first factor explains >80% | WARN: "Data is essentially unidimensional." |
| Factor structure unstable | loadings change significantly across iterations | loop continues; budget may exhaust |

---

## Postconditions

- [ ] `factor_model.json` exists with all 5 universal envelope fields
- [ ] `factors` array has `n_factors` entries, each with label and top loadings
- [ ] `factorability_tests` documented
- [ ] `model_fit` present for FA method with CFI, RMSEA, SRMR values
- [ ] `iterations_completed` field present and <= max_iterations (3)

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] KMO ≥ 0.5 (or documented exception)
- [ ] Model fit indices acceptable (CFI ≥ 0.90, RMSEA ≤ 0.08 for FA)
- [ ] Downstream skills can validate the artifact

---

## Scope Boundary

This skill does NOT:
- Engineer features → handled by `feature-engineering`
- Identify behavioral segments → handled by `cohort-behavior-analysis`
- Compute metrics → handled by `metric-computation`
- Decompose value → handled by `value-decomposition-analysis`

---

## Downstream

1. **`finding-assembly`** — includes factor structure as a finding
2. **`value-decomposition-analysis`** — may use factor scores as decomposition dimensions
