# Test Inventory: latent-factor-modeling

Skill: `latent-factor-modeling`
Spec: `.claude/skills/latent-factor-modeling/SKILL.md`
Generated: 2026-04-10

---

## Category A -- Happy Path

| ID | Name | Variance Combo | Expected Outcome |
|---|---|---|---|
| A-01 | FA + parallel_analysis + varimax | method=factor_analysis, factor_selection=parallel_analysis, rotation=varimax | factor_model.json with CFI/RMSEA/SRMR fit indices, labeled factors, orthogonal loadings |
| A-02 | PCA + scree_plot + none | method=pca, factor_selection=scree_plot, rotation=none | factor_model.json with explained_variance_ratio, unrotated loadings, no fit indices |
| A-03 | FA + bic + promax | method=factor_analysis, factor_selection=bic, rotation=promax | factor_model.json with oblique rotation, correlated factors, fit indices |

---

## Category B -- Variance Coverage

Each variance dimension must have at least 2 distinct values tested.

### Dimension: method (2 values)

| ID | Value | Behavioral Difference Tested | Expected Outcome |
|---|---|---|---|
| B-01 | factor_analysis | Latent construct model fitted; unique variance modeled; CFI/RMSEA/SRMR computed | fit indices present in model_fit; FactorAnalyzer used |
| B-02 | pca | Total variance maximized; no latent model; components_.T used for loadings | No model_fit block (or empty); PCA object used; explained_variance_ratio_ captured |

### Dimension: factor_selection (3 values)

| ID | Value | Behavioral Difference Tested | Expected Outcome |
|---|---|---|---|
| B-03 | parallel_analysis | Eigenvalues compared against random data; data-driven factor count | n_factors determined by random-comparison threshold |
| B-04 | scree_plot | Eigenvalue elbow detection | n_factors determined by find_elbow() |
| B-05 | bic | BIC minimization across k=1..max_k | n_factors = argmin(BIC) |

### Dimension: rotation (3 values)

| ID | Value | Behavioral Difference Tested | Expected Outcome |
|---|---|---|---|
| B-06 | varimax | Orthogonal simple structure; uncorrelated factors | Loadings show simple structure; factors are orthogonal |
| B-07 | promax | Oblique rotation; allows correlated factors | Factor correlations permitted; loadings may be higher |
| B-08 | none | No rotation applied | Raw loadings preserved; no post-rotation transformation |

---

## Category C -- Precondition Violations (must HALT)

| ID | Violated Precondition | Input Setup | Expected Outcome |
|---|---|---|---|
| C-01 | cohort.json missing | No cohort.json file | HALT at Step 0 |
| C-02 | cohort.json schema_version != "1.0" | cohort.json with schema_version="2.0" | HALT at Step 0: schema mismatch |
| C-03 | cohort.json population_size == 0 | cohort.json with population_size=0 | HALT at Step 0: empty source |
| C-04 | feature_set.json missing | No feature_set.json file | HALT at Step 0 |
| C-05 | feature_set.json schema_version != "1.0" | feature_set.json with schema_version="0.5" | HALT at Step 0: schema mismatch |
| C-06 | feature_count < 5 | feature_set.json with feature_count=3 | HALT: "Insufficient features for factor analysis (minimum 5)." |

---

## Category D -- Edge Cases

| ID | Edge Case | Input Setup | Expected Outcome |
|---|---|---|---|
| D-01 | Empty source (population_size == 0) | cohort with 0 rows | HALT Step 0 |
| D-02 | Too few features (feature_count < 5) | feature_set with 4 features | HALT: "Insufficient features for factor analysis (minimum 5)." |
| D-03 | Schema mismatch | schema_version="2.0" | HALT Step 0 |
| D-04 | KMO too low (< 0.5) | Feature matrix with near-zero inter-correlations | HALT: "Data not suitable for factor analysis." |
| D-05 | KMO marginal (0.5 <= kmo < 0.6) | Feature matrix with weak correlations | WARN: proceed with caution logged |
| D-06 | Bartlett's test not significant (p > 0.05) | Near-identity correlation matrix | WARN: logged, processing continues |
| D-07 | Singular correlation matrix (det ~ 0) | Highly collinear features | WARN: remove collinear features and retry |
| D-08 | All variance in one factor (>80%) | One dominant principal component | WARN: "Data is essentially unidimensional." |
| D-09 | Only 1 factor identified | Unidimensional data | WARN: "Only 1 factor identified -- data may be unidimensional." |
| D-10 | Many factors relative to features | n_factors > feature_count / 3 | WARN: "Many factors relative to features -- consider reducing feature set." |
| D-11 | Factor structure unstable across iterations | Loadings shift significantly between loop iterations | Loop continues; budget may exhaust (max 3 iterations) |
| D-12 | Large dataset (>50k rows) | 100k row feature matrix | Sampling to max=50000 applied before factorability assessment |

---

## Coverage Matrix

| Variance Dimension | Values in Spec | Tests Covering | Minimum Met (>=2)? |
|---|---|---|---|
| method | factor_analysis, pca | A-01, A-03, B-01 / A-02, B-02 | YES |
| factor_selection | parallel_analysis, scree_plot, bic | A-01, B-03 / A-02, B-04 / A-03, B-05 | YES |
| rotation | varimax, promax, none | A-01, B-06 / A-03, B-07 / A-02, B-08 | YES |
