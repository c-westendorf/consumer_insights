# Test Inventory: leading-indicator-development

**Skill:** leading-indicator-development
**Date:** 2026-04-10
**Spec version:** SKILL.md as of 2026-04-10

---

## Category A -- Happy Path

| ID | Test Name | Variance Combo | Expected Outcome |
|---|---|---|---|
| A-01 | Binary outcome, logistic AUC, holdout validation | outcome_type=binary, predictive_method=logistic_auc, validation_strategy=holdout | signal_result.json with ranked indicators, holdout scores, confidence labels |
| A-02 | Time-to-event outcome, survival concordance, holdout | outcome_type=time_to_event, predictive_method=survival_concordance, validation_strategy=holdout | signal_result.json with concordance-based indicators |
| A-03 | Continuous outcome, mutual information, cross-validation | outcome_type=continuous, predictive_method=mutual_information, validation_strategy=cross_validation | signal_result.json with MI-scored indicators, CV mean scores |
| A-04 | Binary outcome, mutual information wins over AUC | outcome_type=binary, predictive_method=mutual_information, validation_strategy=holdout | Indicators where MI > AUC get method=mutual_information |
| A-05 | Binary outcome, logistic AUC, cross-validation | outcome_type=binary, predictive_method=logistic_auc, validation_strategy=cross_validation | 5-fold CV scores, confidence from CV std |

---

## Category B -- Variance Coverage

Each variance dimension must be exercised with >=2 distinct values.

### Dimension: outcome_type (3 values)

| ID | Value | Tested In | Notes |
|---|---|---|---|
| B-01 | binary | A-01, A-04, A-05 | Logistic AUC + MI both computed, max chosen |
| B-02 | time_to_event | A-02 | Concordance index only |
| B-03 | continuous | A-03 | MI regression only |

### Dimension: predictive_method (3 values)

| ID | Value | Tested In | Notes |
|---|---|---|---|
| B-04 | logistic_auc | A-01 | Applied when outcome is binary and AUC > MI |
| B-05 | mutual_information | A-03, A-04 | Applied for continuous; also binary when MI > AUC |
| B-06 | survival_concordance | A-02 | Applied only for time_to_event |

### Dimension: validation_strategy (2 values)

| ID | Value | Tested In | Notes |
|---|---|---|---|
| B-07 | holdout | A-01, A-02, A-04 | Single 70/30 split |
| B-08 | cross_validation | A-03, A-05 | 5-fold, confidence from CV std |

### Cross-dimension combinations not yet covered

| ID | Combo | Notes |
|---|---|---|
| B-09 | outcome_type=time_to_event + validation_strategy=cross_validation | Not in A-tests; should verify concordance with CV |
| B-10 | outcome_type=continuous + validation_strategy=holdout | Not in A-tests; MI with holdout split |

---

## Category C -- Precondition Violations (expect HALT)

| ID | Test Name | Violation | Expected Behavior |
|---|---|---|---|
| C-01 | Missing feature_set.json | feature_set.json does not exist | HALT at Step 0 |
| C-02 | Missing metric_result.json | metric_result.json does not exist | HALT at Step 0 |
| C-03 | Missing cohort.json | cohort.json does not exist | HALT at Step 0 |
| C-04 | feature_set schema_version != 1.0 | feature_set.json has schema_version="2.0" | HALT at Step 0 (schema mismatch) |
| C-05 | metric_result schema_version != 1.0 | metric_result.json has schema_version="0.9" | HALT at Step 0 |
| C-06 | cohort schema_version != 1.0 | cohort.json has schema_version="0.5" | HALT at Step 0 |
| C-07 | feature_count < 3 | feature_set.json has feature_count=2 | HALT: "Insufficient features for indicator development." |
| C-08 | No identifiable outcome variable | metric_result.json lacks outcome variable | HALT at Step 0 |
| C-09 | No temporal observation window | cohort.json lacks temporal window | HALT at Step 0 |

---

## Category D -- Edge Cases

| ID | Test Name | Condition | Expected Behavior |
|---|---|---|---|
| D-01 | Empty source population | population_size == 0 | HALT at Step 0 |
| D-02 | Too few features (exactly 2) | feature_count == 2 | HALT: "Insufficient features for indicator development." |
| D-03 | Schema mismatch on any input | schema_version != "1.0" | HALT at Step 0 |
| D-04 | All features non-predictive | All holdout scores < 0.5 | WARN: "No features exceed predictive threshold." Loop may retry. indicators_meeting_threshold = 0 |
| D-05 | Severe class imbalance | Outcome prevalence < 5% | WARN about inflated AUC, suggest precision-recall |
| D-06 | Overfitting detected | train-holdout gap > 0.15 | WARN, confidence downgraded to "low" |
| D-07 | Exactly 3 features (minimum viable) | feature_count == 3 | Proceeds; all 3 scored and ranked |
| D-08 | Large feature set (100+ features) | feature_count = 150 | Proceeds; all scored, no performance degradation specified |
| D-09 | Loop iteration budget exhausted | 3 iterations with < 3 valid indicators | Exit with documented count, budget exhausted |
| D-10 | Single valid indicator after holdout | Only 1 indicator with holdout >= 0.5 | WARN or loop; indicators_meeting_threshold = 1 |

---

## Coverage Matrix

| Spec Element | Tests Covering It |
|---|---|
| Preconditions | C-01 through C-09 |
| Variance: outcome_type | B-01, B-02, B-03 |
| Variance: predictive_method | B-04, B-05, B-06 |
| Variance: validation_strategy | B-07, B-08 |
| Edge case: Empty source | D-01 |
| Edge case: Too few features | D-02, C-07 |
| Edge case: Schema mismatch | D-03, C-04, C-05, C-06 |
| Edge case: All non-predictive | D-04 |
| Edge case: Class imbalance | D-05 |
| Edge case: Overfitting | D-06 |
| Terminal artifact envelope | A-01 through A-05 |
| Postconditions | A-01 through A-05 |
| Quality bar | A-01 through A-05, D-04, D-09 |
| Loop/exit conditions | D-04, D-09, D-10 |
