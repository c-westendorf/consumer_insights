---
name: leading-indicator-development
description: >
  Identifies features that predict a future outcome within a specified horizon using mutual
  information, logistic AUC, and survival concordance, producing signal_result.json with ranked
  leading indicators and validation holdout scores. Activate when scope requires early warning
  signals or predictive features; takes feature_set + metric_result + cohort.
inputs:
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; provides the candidate indicator features"
  - type: metric_result
    description: "Computed metrics from metric-computation; provides the outcome variable to predict"
  - type: cohort
    description: "Population from cohort-extraction; provides temporal context for lead time computation"
outputs:
  - type: signal_result
    description: "Ranked leading indicators with predictive scores, lead times, confidence levels, and holdout validation"
can_follow: [feature-engineering, metric-computation, engagement-decay-analysis]
can_precede: [finding-assembly, hypothesis-validation]
supports_loop: true
exit_conditions:
  - "≥3 validated indicators or budget exhausted (max 3 iterations)"
  - "signal_result.json written with all indicators ranked"
---

## Overview

Engagement-decay-analysis identifies *pre-decay behaviors*. Leading-indicator-development
formalizes those and other candidate features into *validated predictive indicators* — features
that reliably predict a future outcome (churn, upgrade, reactivation) within a specified time
horizon, validated on a holdout set.

This skill uses multiple predictive methods (mutual information for non-linear associations,
logistic AUC for binary outcomes, survival concordance for time-to-event) to rank features by
their predictive power, then validates on held-out data to guard against overfitting.

**What this skill produces:** `signal_result.json` with ranked indicators, each having predictive
score, lead time, confidence, holdout validation score, and causal annotation.

---

## When to Activate

- Scope requires early warning signals, predictive features, or leading indicators
- `engagement-decay-analysis` has identified pre-decay behaviors worth formalizing
- User requests "leading indicators", "predictive features", or "early warning signals"

---

## Preconditions

- [ ] `feature_set.json` exists with `schema_version == "1.0"` and `feature_count >= 3`
- [ ] `metric_result.json` exists with `schema_version == "1.0"` with identifiable outcome variable
- [ ] `cohort.json` exists with `schema_version == "1.0"` with temporal observation window

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: sklearn>=1.2 (LogisticRegression, mutual_info); lifelines>=0.27 (concordance_index); scipy>=1.10; numpy>=1.24; pandas>=2.0
# Tier 4: Python>=3.10
```

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `predictive_method` | `mutual_information` / `logistic_auc` / `survival_concordance` | MI: non-parametric association; AUC: binary outcome discrimination; concordance: time-to-event prediction |
| `outcome_type` | `binary` / `continuous` / `time_to_event` | Determines which methods are applicable |
| `validation_strategy` | `holdout` / `cross_validation` | `holdout`: single 70/30 split; `CV`: 5-fold for more robust scores |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

Classify dimensions. Validate upstream artifacts.

```
-- Validate outcome variable
assert metric_result.metrics contains >=1 outcome-type metric
  IF not: HALT: "No identifiable outcome variable in metric_result.json."

-- Validate temporal window
assert cohort has temporal observation window (>=2 time periods)
  IF not: HALT: "Cohort has no temporal observation window -- cannot develop leading indicators."
```

### Step 1 — Define Outcome and Horizon

```
outcome_variable = derive from metric_result or scope_artifact
outcome_horizon_days = from scope_artifact.timeframe or default 90

-- Create binary/continuous outcome from feature_set data
IF outcome_type == "binary":
  outcome = 1 if event occurred within horizon, else 0
ELIF outcome_type == "time_to_event":
  outcome = days until event (censored if no event)
ELIF outcome_type == "continuous":
  outcome = metric value at end of horizon
```

### Loop Mechanics

```
-- Loop mechanics (supports_loop: true, max iterations per exit_conditions)
iteration = 1

WHILE iteration <= max_iterations:
  Execute Steps 1-3
  
  -- Check exit condition: sufficient leading indicators identified
  IF qualified_indicators >= target_count:
    EXIT loop
  
  IF iteration < max_iterations:
    WARN: "Iteration {iteration}: {qualified_indicators} indicators found (target: {target_count}). Relaxing lead_time or predictive_strength thresholds."
    -- Relax: reduce minimum predictive_strength by 10%, shorten minimum lead_time by 1 period
  
  iteration += 1

-- Proceed to Step 4 with best available indicators
```

### Step 2 — Score Candidate Features

```
indicators = []
FOR each feature in feature_set.features_applied:
  IF outcome_type == "binary":
    -- Logistic AUC
    auc = roc_auc_score(outcome, feature_values)
    -- Mutual information
    mi = mutual_info_classif(feature_values, outcome)
    predictive_score = max(auc, mi_normalized)
    predictive_method = "logistic_auc" if auc > mi else "mutual_information"

  ELIF outcome_type == "time_to_event":
    -- Concordance index
    c_index = concordance_index(durations, feature_values, events)
    predictive_score = c_index
    predictive_method = "survival_concordance"

  ELIF outcome_type == "continuous":
    -- Mutual information for continuous
    mi = mutual_info_regression(feature_values, outcome)
    predictive_score = mi_normalized
    predictive_method = "mutual_information"

  -- Compute lead time (how far ahead the indicator predicts)
  lead_time_days = compute_optimal_lead(feature_values, outcome, horizon)

  indicators.append({feature, predictive_method, predictive_score, lead_time_days})
```

### Step 3 — Validate on Holdout

```
IF validation_strategy == "holdout":
  train, test = split(data, 0.7)
  FOR each indicator:
    train_score = score(indicator, train)
    holdout_score = score(indicator, test)
    indicator.validation_holdout_score = holdout_score
    -- Flag overfitting
    IF train_score - holdout_score > 0.15:
      WARN: "Indicator '{indicator.feature}' shows overfitting (train={train_score}, holdout={holdout_score})"
      indicator.confidence = "low"

ELIF validation_strategy == "cross_validation":
  FOR each indicator:
    cv_scores = cross_val_score(indicator, data, cv=5)
    indicator.validation_holdout_score = mean(cv_scores)
    indicator.confidence = classify_by_cv_std(std(cv_scores))
```

### Step 4 — Rank and Write Terminal Artifact

```
-- Rank by holdout score descending
indicators.sort(key=validation_holdout_score, descending)
FOR i, ind in enumerate(indicators): ind.indicator_id = f"I-{i+1:03d}"

-- Classify confidence
FOR each indicator:
  IF holdout_score >= 0.7: confidence = "high"
  ELIF holdout_score >= 0.5: confidence = "medium"
  ELSE: confidence = "low"

indicators_meeting_threshold = count where holdout_score >= 0.5

Write signal_result.json
```

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "leading-indicator-development",
  "timestamp": "2026-04-10T17:45:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "outcome_variable": "churn_within_90d",
  "outcome_horizon_days": 90,
  "indicators": [
    {
      "indicator_id": "I-001",
      "feature": "days_since_last_purchase",
      "predictive_method": "logistic_auc",
      "predictive_score": 0.78,
      "lead_time_days": 45,
      "confidence": "high",
      "validation_holdout_score": 0.74,
      "causal_note": "association only"
    },
    {
      "indicator_id": "I-002",
      "feature": "purchase_rate_per_30d",
      "predictive_method": "logistic_auc",
      "predictive_score": 0.72,
      "lead_time_days": 30,
      "confidence": "high",
      "validation_holdout_score": 0.69,
      "causal_note": "association only"
    }
  ],
  "exploration_iterations": 1,
  "indicators_meeting_threshold": 4
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | population_size == 0 | HALT Step 0 |
| Too few features | feature_count < 3 | HALT: "Insufficient features for indicator development." |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| All features non-predictive | all scores < 0.5 | WARN: "No features exceed predictive threshold." Loop may retry. |
| Severe class imbalance | outcome prevalence < 5% | WARN: "Rare outcome — AUC may be inflated. Use precision-recall." |
| Overfitting detected | train-holdout gap > 0.15 | WARN: downgrade confidence to "low" |
| No outcome variable in metric_result | metric_result.metrics array has no outcome-type metric | HALT Step 0: "No identifiable outcome variable in metric_result.json." |
| No temporal window in cohort | cohort lacks temporal structure | HALT Step 0: "Cohort has no temporal observation window -- cannot develop leading indicators." |

---

## Postconditions

- [ ] `signal_result.json` exists with all 5 universal envelope fields
- [ ] Indicators are ranked by holdout score
- [ ] Each indicator has causal_note (always "association only" unless upgraded)

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] ≥3 indicators meeting threshold or budget exhausted with documented count
- [ ] All indicators validated on holdout data
- [ ] Downstream `finding-assembly` and `hypothesis-validation` can validate

---

## Scope Boundary

This skill does NOT:
- Detect engagement decay patterns → handled by `engagement-decay-analysis`
- Validate hypotheses → handled by `hypothesis-validation`
- Establish causal relationships → handled by `causal-linkage-analysis`
- Engineer features → handled by `feature-engineering`

---

## Downstream

1. **`finding-assembly`** — includes validated leading indicators as actionable findings
2. **`hypothesis-validation`** — may use indicator findings to generate testable hypotheses about causal mechanisms
