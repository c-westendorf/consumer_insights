# Assessment Report — data-remediation

**Generated:** 2026-04-09
**Tester:** dse-skill-tester
**SKILL.md path:** `.claude/skills/data-remediation/SKILL.md`
**Test inventory:** `tests/test-inventory.md`

---

## Test Summary

```
Total: 14  |  ✅ Pass: 7  |  ⚠️ Warn: 3  |  🚫 Critical: 4
```

---

## Per-Test Results

| # | Name | Outcome | Step | Notes |
|---|---|---|---|---|
| 1 | happy-path-blocking-imputation-small | ✅ Pass | — | All 5 envelope fields; issues_remaining=0; 3 applied + 1 not_actionable in change_log |
| 2 | variance-advisory-only | ✅ Pass ⚠️ | Step 2 | Advisory confirmation gate described in Variance Surface but absent from Step workflow |
| 3 | variance-empty-manifest | ✅ Pass | — | WARN fires; pass-through artifact written with original data_ref |
| 4 | variance-no-imputation | ✅ Pass | — | Steps 3–4 correctly skipped; post-dedup record_count reflected in artifact |
| 5 | variance-large-volume | ✅ Pass ⚠️ | Step 3 | SQL CTAS path correct; Step 3 lacks sampling guidance for large-volume mechanism tests |
| 6 | precond-wrong-schema-version | ✅ Pass | Step 0 | HALT fires with exact message from SKILL.md |
| 7 | precond-null-data-ref | ✅ Pass | Step 0 | HALT fires correctly |
| 8 | precond-lineage-mismatch | ✅ Pass | Step 0 | HALT fires with both artifact IDs in message |
| 9 | precond-all-investigate | 🚫 Fail | Step 0 | remediation_scope classification has no branch for all-blocking-all-investigate; P4 not enforced in Step 0 block |
| 10 | edge-empty-dataset | 🚫 Fail | Step 0 | row_count == 0 check absent from Step 0 pseudocode; would not HALT |
| 11 | edge-single-record | ⚠️ Warn | Step 3 | row_count == 1 guard absent; regression would error instead of clean WARN |
| 12 | edge-all-null-column | 🚫 Fail | Step 1 | null_rate == 1.0 guard absent from Step 1 triage; would attempt to impute fully-null column |
| 13 | edge-mnar-identifier-column | 🚫 Fail | Step 5 | MNAR override (indicator-only) counted as issues_remaining > 0; triggers false HALT |
| 14 | edge-imputation-training-fails | ✅ Pass ⚠️ | Step 3 | HALT at Step 4 correct; Step 3 may error on <50 non-null rows before reaching Step 4 |

---

## Required Fixes (🚫 BLOCKS MERGE)

### Fix 1 — Step 0: Add P4 enforcement to upstream validation block

**Test:** #9 (precond-all-investigate)
**Principle violated:** BLUEPRINT.md Principle 6 — Quality Bar Over Completeness
**Problem:** When all manifest entries are `recommended_remediation="investigate"` and `severity="blocking"`,
none of the three `remediation_scope` classification branches match. Skill enters Step 1 with
`remediation_scope` undefined. P4 is documented as a precondition but not enforced in Step 0's pseudocode.

**Fix — add to Step 0 upstream validation, after remediation_manifest is loaded:**
```
assert remediation_manifest is non-empty AND
       any(entry.recommended_remediation != "investigate" for entry in remediation_manifest)
  IF remediation_manifest is empty: handled by empty_manifest path
  IF all entries are "investigate":
    HALT: "Upstream validation failed: all {N} remediation_manifest entries require manual
    investigation — no automated remediation possible. Escalate to analyst and re-run
    data-quality-assessment after manual review."
```

---

### Fix 2 — Step 0: Add row_count > 0 guard

**Test:** #10 (edge-empty-dataset)
**Principle violated:** BLUEPRINT.md Principle 6
**Problem:** Edge case EC1 is declared but not enforced. Empty dataset (0 rows) would not HALT
at Step 0 — skill would proceed to Step 1, build a fix schedule, then fail silently or at warehouse query.

**Fix — add to Step 0 upstream validation, after loading raw_dataset:**
```
assert raw_dataset.row_count > 0
  IF row_count == 0:
    HALT: "Cannot remediate empty dataset — re-run data-retrieval."
```

---

### Fix 3 — Step 1: Add null_rate == 1.0 guard on Phase C entries

**Test:** #12 (edge-all-null-column)
**Principle violated:** BLUEPRINT.md Principle 6
**Problem:** Edge case EC3 is declared but not enforced. A fully-null column prescribed for imputation
would proceed to Phase C, where `median(all_null_series)` returns NaN, producing a corrupt artifact.

**Fix — add to Step 1, after Phase C entries are filtered:**
```
For each Phase C entry:
  IF entry.null_rate is not null AND entry.null_rate >= 1.0:
    HALT: "Column {entry.column} is 100% null — imputation cannot fill a fully missing column.
    Drop column and re-run data-quality-assessment."
```

---

### Fix 4 — Step 5: Treat MNAR indicator-only entries as resolved, not remaining

**Test:** #13 (edge-mnar-identifier-column)
**Principle violated:** BLUEPRINT.md Principle 4 — Artifact at Every State Change; Principle 6
**Problem:** When MNAR override is correctly applied (no imputation, indicator column added),
the blocking manifest entry has no `change_log` status of "applied", so `issues_remaining` counts
it as unresolved. Step 5 then fires a false HALT.

**Fix — two-part:**

Part A: Add `"not_applicable"` to change_log status vocabulary (add to Terminal Artifact spec):
```
"change_log" entry statuses:
  "applied"         — fix was executed
  "skipped"         — advisory fix, not applied this run
  "not_actionable"  — recommended_remediation == "investigate"
  "not_applicable"  — prescribed imputation overridden by MNAR mechanism classification;
                       correct alternative (indicator column) applied instead
```

Part B: Update Step 5 issues_remaining calculation:
```
issues_remaining = count of blocking manifest entries where change_log status
  NOT IN ["applied", "not_actionable", "not_applicable"]
```

---

## Advisory Fixes (⚠️ Recommended Before Merge)

### Advisory A — Step 3: Add row_count == 1 early-out

**Test:** #11 (edge-single-record)
**Problem:** Single-row dataset would attempt chi-squared/logistic tests that require ≥2 observations.
Would produce a confusing runtime error rather than a clean WARN.

**Fix — add to Step 3 before mechanism tests:**
```
IF raw_dataset.row_count <= 1:
  WARN: "Single-row dataset — MCAR/MAR statistical tests require ≥2 observations.
  Applying median/mode fill directly for all imputable columns."
  FOR each imputable column: column_mechanisms[column] = "MCAR"
  SKIP mechanism tests; proceed to Phase C
```

---

### Advisory B — Step 3: Add non_null_count < 50 early-out for impute_model entries

**Test:** #14 (edge-imputation-training-fails — partial)
**Problem:** Step 3 runs the MCAR chi-squared test even when only ~25 non-null rows exist.
This test would produce unreliable p-values or fail silently before Step 4's training check fires.

**Fix — add to Step 3, before mechanism tests, for each column:**
```
IF (total_rows * (1 - null_rate)) < 50:  -- fewer than 50 non-null rows
  WARN: "{column}: fewer than 50 non-null rows — mechanism tests unreliable; classifying as MNAR."
  column_mechanisms[column] = "MNAR"
  SKIP mechanism tests for this column
```

---

### Advisory C — Step 2 / Variance Surface: Document advisory confirmation gate

**Test:** #2 (variance-advisory-only)
**Problem:** The Variance Surface table states "analyst confirmation requested before applying each"
advisory fix, but Step 2's pseudocode has no confirmation pause. The behavior is undocumented.

**Fix — add to Step 2, before applying each advisory entry:**
```
IF entry.severity == "advisory" AND remediation_scope == "advisory_only":
  PROMPT: "Advisory fix pending for {column} ({entry.description}).
  Apply? [yes/no/skip-all-advisory]"
  IF no or skip: log status="skipped"; continue to next entry
  IF yes: apply fix; log status="applied"
```

---

### Advisory D — Step 3: Add sampling guidance for large-volume datasets

**Test:** #5 (variance-large-volume)
**Problem:** Step 3 mechanism classification runs chi-squared and logistic regression but does not
specify sampling for datasets ≥1M rows. Feasible but slow; analysts may observe 30-60s pause.

**Fix — add to Step 3 preamble:**
```
IF data_volume == "large":
  Sample up to 100,000 rows for mechanism tests:
    SQL: SELECT * FROM {data_ref} TABLESAMPLE SYSTEM (5) LIMIT 100000
  Log: "Large volume detected — mechanism classification using 100K-row sample"
  Use sample for chi-squared and logistic regression; apply resulting classification to full dataset
```

---

## Coverage Assessment

| Variance Dimension | Values Tested | Real-Data Testing Needed |
|---|---|---|
| remediation_scope | has_blocking ✅, advisory_only ✅, empty_manifest ✅ | advisory confirmation flow (pending Fix C implementation) |
| imputation_required | yes ✅, no ✅ | Both covered in synthetic tests |
| data_volume | small ✅, large ✅ | Real warehouse SQL CTAS execution |

| Edge Case | Status |
|---|---|
| EC1: empty dataset | 🚫 Not enforced — requires Fix 2 |
| EC2: single record | ⚠️ Partially covered — requires Advisory A |
| EC3: all-null column | 🚫 Not enforced — requires Fix 3 |
| EC4: lineage mismatch | ✅ Passes (covered by Test 8) |
| EC5: all-investigate | 🚫 Not enforced — requires Fix 1 |
| EC6: MNAR identifier column | 🚫 False HALT — requires Fix 4 |
| EC7: imputation training fails | ✅ Passes at Step 4; minor gap in Step 3 |
| EC8: empty manifest | ✅ Passes (covered by Test 3) |

---

## Blueprint Compliance

| Principle | Status | Notes |
|---|---|---|
| P1: Shared Vocabulary | ✅ CONFIRMED | Artifact types and status values consistent with DSE registry |
| P2: Input Before Output | ✅ CONFIRMED | All validation in Step 0 before any state change |
| P3: Explicit Assumptions | ✅ CONFIRMED | MCAR/MAR/MNAR mechanism documented; platform branches explicit |
| P4: Artifact at Every State Change | ⚠️ PARTIAL | False HALT at Step 5 (Test 13) prevents artifact from being written in MNAR override case |
| P5: Graceful Degradation | ⚠️ PARTIAL | "investigate" entries excluded cleanly; but single-row/sparse-column edge cases not handled gracefully |
| P6: Quality Bar Over Completeness | 🚫 VIOLATED | Four edge cases declared but not enforced in workflow pseudocode |
| P7: Manifest-Driven | ✅ CONFIRMED | Every fix traces to a manifest entry; no independent diagnosis |
| P8: Self-Contained Portability | ✅ CONFIRMED | references/missingness-classification.md provides standalone decision tree |

---

## Pre-Merge Readiness Verdict

**🚫 NOT READY — 4 critical fixes required before merge**

| # | Fix | Blocking? |
|---|---|---|
| Fix 1 | Add P4 (all-investigate) enforcement to Step 0 | 🚫 YES |
| Fix 2 | Add row_count > 0 guard to Step 0 | 🚫 YES |
| Fix 3 | Add null_rate == 1.0 guard to Step 1 Phase C | 🚫 YES |
| Fix 4 | Add "not_applicable" status; fix issues_remaining calculation | 🚫 YES |
| Advisory A | Single-record early-out in Step 3 | ⚠️ Recommended |
| Advisory B | Sparse-column (<50 non-null) early-out in Step 3 | ⚠️ Recommended |
| Advisory C | Document advisory confirmation gate in Step 2 | ⚠️ Recommended |
| Advisory D | Large-volume sampling guidance in Step 3 | ⚠️ Recommended |

All 4 required fixes are in **Step 0, Step 1, and Step 5** — they are localized and do not require structural changes. Re-run Tests 9, 10, 12, and 13 after applying fixes to confirm.
