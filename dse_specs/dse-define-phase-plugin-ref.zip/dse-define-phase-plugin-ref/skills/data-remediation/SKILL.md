---
name: data-remediation
description: >
  Manifest-driven data repair skill that reads the remediation_manifest from quality_report and
  applies prescribed fixes (type coercion, deduplication, outlier treatment, imputation) to
  produce a remediated_dataset with a full change_log. Activate after data-quality-assessment
  when verdict is FAIL or the remediation_manifest contains blocking issues; for imputation,
  classifies missingness mechanism (MCAR/MAR/MNAR) per column and selects the statistically
  appropriate strategy — never diagnoses issues independently.
inputs:
  - type: raw_dataset
    description: "Source data artifact — provides data_ref (warehouse temp table) and column manifest; remediation writes a new remediated temp table from this source"
  - type: quality_report
    description: "Quality gate output from data-quality-assessment — the remediation_manifest field prescribes exactly what to fix, which columns, which strategy, and which parameters"
outputs:
  - type: remediated_dataset
    description: "Remediated data artifact with new data_ref pointing to cleaned warehouse temp table, change_log documenting every modification, and counts of blocking/advisory issues resolved"
can_follow: [data-quality-assessment]
can_precede: [data-quality-assessment, cohort-extraction, feature-engineering, exploratory-analysis]
supports_loop: true
exit_conditions:
  - "all blocking issues in remediation_manifest applied; change_log entry written for each"
  - "remediated_dataset.json written with data_ref pointing to verified temp table"
  - "remediation_budget exhausted — escalate to analyst with unresolved_issues documented"
---

## Overview

Data-quality-assessment diagnoses problems and prescribes fixes. This skill executes those fixes.
The separation is intentional: diagnosis and treatment are methodologically distinct — a skill that
both detects and silently corrects data problems is untestable and unauditable. Here, every change
is prescribed by the quality_report's remediation_manifest and documented in the change_log, creating
a reproducible, auditable chain: diagnosis → prescription → execution → re-assessment.

**Why MCAR/MAR/MNAR matters:** Imputation strategy is not a stylistic choice — it's a statistical
decision with measurable downstream impact. Applying mean imputation when data is MNAR (missing
not at random, e.g., high earners skipping income fields) pulls estimates toward the center and
biases every downstream metric. This skill classifies missingness mechanism per column and selects
strategy accordingly: mean/median for MCAR, regression or multiple imputation for MAR, domain-informed
constants or indicator variables for MNAR.

**What this skill produces:** A `remediated_dataset.json` artifact with a new `data_ref` pointing
to a cleaned warehouse temp table (or the same ref if changes were applied in-memory for small
datasets), a complete `change_log` of every modification applied, and counts of resolved vs. remaining
issues so that the re-assessment pass of data-quality-assessment has full context.

---

## When to Activate

- `quality_report.json` exists with `verdict == "FAIL"` — pipeline cannot proceed until blocking issues are resolved
- `quality_report.remediation_manifest` is non-empty (any blocking or advisory issues)
- A plan task node with `task_type: "data_remediation"` is the next unexecuted task
- After a prior remediation run, re-assessment found new or unresolved blocking issues
- User explicitly requests "fix the data quality issues" or "apply remediation"

---

## Preconditions

What must be true before this skill begins:
- [ ] `quality_report.json` exists with `schema_version == "1.0"` and `remediation_manifest` present (non-null list)
- [ ] `raw_dataset.json` exists with `schema_version == "1.0"` and `data_ref` pointing to an accessible warehouse temp table
- [ ] `quality_report.raw_dataset_artifact_id` matches `raw_dataset.artifact_id` (same lineage — remediating from the same extraction the quality report diagnosed)
- [ ] At least one entry in `remediation_manifest` where `recommended_remediation != "investigate"` (if all entries are "investigate", no automated fix is possible; escalate to analyst)

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.11 (MAR logistic test), numpy>=1.24, pandas>=2.0
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; heavy compute executes as warehouse SQL
- **Memory:** <500 MB small volume (pandas); warehouse-side for large
- **Upstream Artifacts:** `quality_report.json` (remediation_manifest), `raw_dataset.json` (data_ref)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `remediation_scope` | `has_blocking` / `advisory_only` / `empty_manifest` | has_blocking: ALL blocking entries must be applied before writing artifact; advisory_only: analyst confirmation requested before applying each; empty_manifest: pass-through artifact written, no changes applied |
| `imputation_required` | `yes` / `no` | yes: Steps 3–4 run full MCAR/MAR/MNAR classification per imputable column; no: Steps 3–4 skipped entirely |
| `data_volume` | `small` / `large` | small (<1M rows): pandas in-memory transformations on sampled data, then SQL CTAS to persist; large (≥1M rows): all fixes executed as warehouse SQL directly (CASE WHEN, UPDATE, INSERT) against temp table |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify remediation_scope: read quality_report.remediation_manifest
  IF any entry has severity == "blocking" AND recommended_remediation != "investigate"
    → "has_blocking"
  ELSE IF all entries have severity == "advisory" → "advisory_only"
  ELSE IF remediation_manifest is empty list → "empty_manifest"

classify imputation_required: scan remediation_manifest entries
  IF any entry has recommended_remediation in
    ["impute_mean", "impute_median", "impute_mode", "impute_model"]
    → "yes"
  ELSE → "no"

classify data_volume: read raw_dataset.row_count
  IF row_count < 1,000,000 → "small"
  IF row_count >= 1,000,000 → "large"

log: "Running data-remediation | scope={value} | imputation={value} | data_volume={value}"
```

**Upstream Validation:**
```
load quality_report.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF numeric: HALT: "Upstream validation failed: quality_report.json — schema_version is
  a number ({actual}), expected string '1.0'. Re-run data-quality-assessment."
  IF wrong string: HALT: "Upstream validation failed: quality_report.json — schema_version
  is '{actual}', expected '1.0'. Re-run data-quality-assessment."
assert remediation_manifest is present and is a list (may be empty)
  IF missing or null: HALT: "Upstream validation failed: quality_report.json —
  remediation_manifest field is missing. Re-run data-quality-assessment."

load raw_dataset.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: raw_dataset.json — schema_version mismatch.
  Re-run data-retrieval."
assert data_ref is not null
  IF null: HALT: "Upstream validation failed: raw_dataset.json — data_ref missing.
  Cannot locate warehouse temp table."
assert raw_dataset.row_count > 0
  IF row_count == 0: HALT: "Cannot remediate empty dataset — re-run data-retrieval."

Lineage check:
assert quality_report.raw_dataset_artifact_id == raw_dataset.artifact_id
  IF mismatch: HALT: "Upstream validation failed: quality_report was generated from
  a different raw_dataset (report references: {report_id}, current: {raw_id}).
  Re-run data-quality-assessment on the current raw_dataset before remediating."

assert any(entry.recommended_remediation != "investigate" for entry in remediation_manifest)
  IF all are "investigate": HALT: "All {N} manifest entries require manual investigation —
  no automated remediation possible. Escalate to analyst; re-run data-quality-assessment
  after manual review."

IF remediation_scope == "empty_manifest":
  WARN: "remediation_manifest is empty — no fixes prescribed. Writing pass-through artifact."
  SKIP to Step 5.
```

---

### Step 1 — Triage and Fix Schedule

**Goal:** Parse the remediation_manifest and build an ordered execution schedule: apply fixes
in a sequence that minimizes data contamination (structural fixes first, imputation last).

**Pre-step assertion:** remediation_manifest is a non-empty list with at least one entry
where recommended_remediation != "investigate".

**Actions:**
```
Build fix_schedule (ordered list for execution):

  Phase A — Structural fixes (execute first — these change the data shape):
    Filter manifest entries where recommended_remediation == "deduplicate"
    Filter manifest entries where recommended_remediation == "type_coerce"
    Add all "drop_column" entries

  Phase B — Outlier treatment (execute after structural fixes):
    Filter manifest entries where recommended_remediation == "cap_outliers"

  Phase C — Imputation (execute last — imputing before dedup or coercion distorts fill values):
    Filter manifest entries where recommended_remediation in
      ["impute_mean", "impute_median", "impute_mode", "impute_model"]
    For each Phase C entry:
      IF entry.null_rate is not null AND entry.null_rate >= 1.0:
        HALT: "Column {entry.column} is 100% null — imputation cannot fill a fully missing column.
        Drop column and re-run data-quality-assessment."

  Exclude entries where recommended_remediation == "investigate"
    WARN for each: "Issue {issue_id} ({column}) requires manual investigation —
    skipping automated remediation. Analyst must review before re-running quality gate."

Log: "Fix schedule built: {N_structural} structural, {N_outlier} outlier, {N_impute} imputation,
{N_investigate} manual-review items excluded"
```

**Checkpoint:**
> - [ ] PASS: fix_schedule built; all entries classified into phases A/B/C or excluded
> - [ ] WARN: "investigate" entries excluded from schedule — logged to remediation notes
> - [ ] HALT: no actionable fixes in schedule (all entries are "investigate") →
>   "All prescribed fixes require manual investigation. Escalate to analyst — no automated remediation possible."

---

### Step 2 — Apply Structural Fixes (Phase A)

**Goal:** Apply type coercion, deduplication, and column drops — changes that affect data shape
and must complete before any statistical operations.

**Pre-step assertion:** Phase A fix_schedule entries loaded; data_ref accessible.

*Branch on data_volume:*

**IF `small` (<1M rows): pandas in-memory**
```
Load sample from warehouse temp table via data_ref:
  SQL: SELECT * FROM {data_ref}

For each "type_coerce" entry in Phase A schedule:
  target_type = entry.remediation_params.target_type  (e.g., "date", "float", "integer")
  column = entry.column
  Apply pandas type cast: df[column] = df[column].astype(target_type)
    IF cast fails on any row: log failed rows; fill with null; add to change_log
  Log: {issue_id}: coerced {column} → {target_type}, {N} rows converted, {M} failed → null

For each "deduplicate" entry in Phase A schedule:
  dedup_keys = entry.remediation_params.dedup_keys  (columns to use for PK detection)
  strategy = entry.remediation_params.strategy  ("keep_first" | "keep_last" | "keep_max_complete")
  Apply pandas deduplication: df = df.drop_duplicates(subset=dedup_keys, keep=strategy)
  Log: {issue_id}: removed {N} duplicate rows on keys {dedup_keys}

For each "drop_column" entry in Phase A schedule:
  column = entry.column
  df = df.drop(columns=[column])
  Log: {issue_id}: dropped column {column} — reason: {entry.description}
```

**IF `large` (≥1M rows): warehouse SQL**
```
Generate new temp table name: REMEDIATED_{data_ref}

Build CREATE TABLE AS SELECT statement:
  For each type_coerce entry: add CAST({column} AS {target_type}) AS {column}
  For duplicate entries: add appropriate WHERE clause or ROW_NUMBER() dedup CTE
  Exclude drop_column entries from SELECT list

Execute: CREATE TEMP TABLE {REMEDIATED_{data_ref}} AS SELECT ... FROM {data_ref}
Log row delta: rows_before vs rows_after (dedup may reduce count)
```

**Checkpoint:**
> - [ ] PASS: all Phase A fixes applied; row count delta logged
> - [ ] WARN: type coercion failures (some rows → null) — logged to change_log
> - [ ] HALT: warehouse temp table inaccessible → "Temp table {data_ref} not found.
>   Restart warehouse session and re-run data-retrieval."

---

### Step 3 — Classify Missingness Mechanism (Phase C Prerequisite)

**ONLY runs if `imputation_required == "yes"`. Skip entirely if no imputation in fix_schedule.**

**Goal:** For each column flagged for imputation, classify whether missingness is MCAR, MAR,
or MNAR. This classification determines which imputation strategy is statistically defensible.

**Reference:** `references/missingness-classification.md` — full decision tree, strategy-per-mechanism
table, indicator column rules, and failure modes.

**Pre-step assertion:** Phase B (outlier treatment) already applied (if applicable).

**Actions:**
```
IF row_count <= 1:
  WARN: "Single-row dataset — statistical tests require ≥2 rows; classifying all as MCAR."
  FOR each imputable column: column_mechanisms[column] = "MCAR"
  SKIP to Phase C

IF data_volume == "large":
  Sample: SELECT * FROM {data_ref} TABLESAMPLE SYSTEM (5) LIMIT 100000
  Log: "Large volume — mechanism classification using 100K-row sample"

For each imputation entry in Phase C fix_schedule:
  column = entry.column
  non_null_count = row_count * (1 - entry.null_rate)
  IF non_null_count < 50:
    WARN: "{column}: {non_null_count:.0f} non-null rows — classifying as MNAR; indicator only."
    column_mechanisms[column] = "MNAR"; CONTINUE
  IF null_rate < 0.01: classify as MCAR
  ELSE: run mechanism tests per references/missingness-classification.md decision tree:
    1. MCAR test: chi-squared on is_missing_{column} vs other features (p > 0.05 → MCAR)
    2. MAR test: logistic regression of missingness on observed features (p < 0.05 → MAR)
    3. MNAR heuristics: identifier/temporal → MNAR; spend/revenue → likely MNAR (WARN)
  Store: column_mechanisms[column] = {MCAR | MAR | MNAR}
  Log: "{column}: {mechanism} (null_rate={null_rate:.1%})"
```

**Checkpoint:**
> - [ ] PASS: mechanism classified for all imputable columns; stored in column_mechanisms dict
> - [ ] WARN: MNAR classification uncertain — analyst should verify spend/revenue columns
> - [ ] HALT: see failure modes in references/missingness-classification.md

---

### Step 4 — Apply Outlier Treatment and Imputation (Phases B and C)

**Goal:** Apply outlier treatment (Phase B), then imputation (Phase C) using strategy selected
by mechanism classification in Step 3.

**Pre-step assertion:** Phase A complete; for imputation entries, mechanism classified in Step 3.

**Phase B — Outlier Treatment:**
```
For each "cap_outliers" entry in Phase B schedule:
  column = entry.column
  strategy = entry.remediation_params.strategy  ("winsorize" | "cap_at_bounds" | "flag_and_remove")
  p_lower = entry.remediation_params.p_lower  (e.g., 0.01)
  p_upper = entry.remediation_params.p_upper  (e.g., 0.99)

  IF data_volume == "small":
    Compute actual p01 and p99 from the post-Phase-A dataset
    Apply strategy:
      IF "winsorize": clip values to [p01, p99] — replace extremes with bound values
      IF "cap_at_bounds": same as winsorize (alias)
      IF "flag_and_remove": drop rows where column < p01 OR column > p99
    Log: {issue_id}: {strategy} on {column} — {N} values modified, bounds=[{p01:.2f}, {p99:.2f}]

  IF data_volume == "large":
    Compute bounds via warehouse APPROX_PERCENTILE (platform-specific — see data-quality-assessment Step 4)
    Apply via SQL UPDATE or CASE WHEN in new SELECT
```

**Phase C — Imputation (by mechanism):**

**Reference:** `references/missingness-classification.md` — strategy-per-mechanism table and indicator column rules.

```
For each imputation entry in Phase C fix_schedule:
  column = entry.column
  mechanism = column_mechanisms[column]  (from Step 3)

  Apply strategy per references/missingness-classification.md strategy table:
    MCAR → median fill (numeric) or mode fill (categorical); no indicator column
    MAR (null ≤ 30%) → regression imputation; log predictor_r2
    MAR (null > 30%) → median/mode fallback + indicator column + WARN
    MNAR (identifier/temporal) → NO IMPUTE; indicator column only
    MNAR (measure/dimension) → domain constant (if provided) or median fallback + indicator column + WARN

  For every imputed column: log to change_log with mechanism, fill_value, rows_filled
  For every indicator column added: append to indicator_columns_added list
```

**Checkpoint:**
> - [ ] PASS: all Phase B and C entries applied; change_log populated for each
> - [ ] WARN: MAR imputation with null_rate > 30%, or MNAR fallback to median — analyst review needed
> - [ ] HALT: imputation model training fails (insufficient non-null training rows) →
>   "Cannot fit imputation model for {column}: fewer than 50 non-null rows. Drop or
>   flag column and re-run data-quality-assessment."

---

### Step 5 — Write Terminal Artifact

**Goal:** Persist the remediated data to a warehouse temp table and write `remediated_dataset.json`
with a complete change_log and issue resolution counts.

**Pre-step assertion:** All fix phases complete or explicitly skipped.

**Actions:**
```
IF data_volume == "small" AND in-memory changes were made:
  Persist to warehouse: CREATE TEMP TABLE REMEDIATED_{data_ref} AS SELECT * FROM python_df
  NOTE: This writes the pandas DataFrame back to a queryable temp table.
  new_data_ref = "REMEDIATED_{data_ref}"
ELSE IF data_volume == "large":
  new_data_ref already set in Step 2 (REMEDIATED_{data_ref})
ELSE IF remediation_scope == "empty_manifest":
  new_data_ref = raw_dataset.data_ref  (pass-through — no new table created)

Count resolution outcomes:
  issues_resolved       = count(change_log entries where status == "applied")
  issues_not_actionable = count(change_log entries where status in
                            ["not_actionable", "not_applicable"])
  issues_remaining      = count(blocking manifest entries where status NOT IN
                            ["applied", "not_actionable", "not_applicable"])
  (issues_remaining should be 0 if remediation completed successfully)

Generate artifact_id: UUID v4

Write remediated_dataset.json (see Terminal Artifact spec)
Log: "remediated_dataset written | resolved={issues_resolved} | not_actionable={issues_not_actionable}
| remaining={issues_remaining} | data_ref={new_data_ref}"

IF issues_remaining > 0:
  HALT: "Remediation incomplete: {issues_remaining} blocking issues from the manifest
  were not applied. Review change_log for failures. Fix errors and re-run data-remediation,
  or escalate to analyst."
```

**Checkpoint:**
> - [ ] PASS: remediated_dataset.json written; all 5 universal envelope fields present
> - [ ] PASS: `issues_remaining == 0` (all blocking issues addressed)
> - [ ] WARN: advisory issues skipped (logged in change_log with status "skipped")
> - [ ] HALT: write failure or issues_remaining > 0

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "data-remediation",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 84329,
  "artifact_id": "{uuid}",
  "source_raw_dataset_artifact_id": "{raw_dataset.artifact_id}",
  "quality_report_artifact_id": "{quality_report.artifact_id}",
  "data_ref": "REMEDIATED_DSE_EXTRACTION_dqa003",
  "row_count": 84329,
  "column_count": 5,
  "issues_resolved": 3,
  "issues_not_actionable": 1,
  "issues_remaining": 0,
  "imputation_methods_used": {"revenue": "impute_median_MCAR"},
  "indicator_columns_added": ["revenue_was_missing"],
  "change_log": [
    {
      "issue_id": "RM-001",
      "column": "transaction_date",
      "action_taken": "none",
      "status": "skipped",
      "reason": "MNAR temporal column — indicator column added, no fill"
    },
    {
      "issue_id": "RM-002",
      "column": "revenue",
      "action_taken": "cap_outliers_winsorize",
      "status": "applied",
      "rows_affected": 1412,
      "method_details": {"strategy": "winsorize", "lower_bound": 1.99, "upper_bound": 489.00}
    },
    {
      "issue_id": "RM-003",
      "column": "revenue",
      "action_taken": "impute_median",
      "status": "applied",
      "rows_affected": 35584,
      "method_details": {"mechanism": "MCAR", "fill_value": 45.00}
    }
  ],
  "profiling_notes": ["Row count reduced 84729→84329 (400 rows removed via dedup)"]
}
```

**Write to:** `remediated_dataset.json` in the project directory.

**Field: `record_count`** = row count of the remediated dataset (may differ from `raw_dataset.row_count` if deduplication applied).

**`change_log` entry statuses:**
- `"applied"` — fix was executed successfully
- `"skipped"` — advisory fix, not applied this run
- `"not_actionable"` — recommended_remediation == "investigate"; excluded in Step 1
- `"not_applicable"` — prescribed imputation overridden by MNAR mechanism classification; indicator column added instead; counts toward `issues_not_actionable`, NOT `issues_remaining`

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty dataset (0 rows) | `raw_dataset.row_count == 0` | HALT Step 0: "Cannot remediate empty dataset — re-run data-retrieval." |
| Single record | row_count == 1 | WARN Step 3: "Single-row dataset — MCAR/MAR tests meaningless; median/mode fill applied; imputation quality cannot be validated." |
| All-null column prescribed for imputation | null_rate == 1.0 in manifest entry | HALT Step 1: "Column {name} is 100% null — imputation cannot fill a fully missing column. Drop and re-run data-quality-assessment." |
| Lineage mismatch | quality_report.raw_dataset_artifact_id ≠ raw_dataset.artifact_id | HALT Step 0: "Quality report and raw_dataset are from different extractions — cannot remediate consistently." |
| All manifest entries are "investigate" | all recommended_remediation == "investigate" | HALT Step 1: "All prescribed fixes require manual investigation — no automated remediation possible. Escalate to analyst." |
| MNAR identifier column (e.g., customer_id has nulls) | column_role == "identifier" AND null_rate > 0 in manifest | WARN Step 4: do NOT impute; add is_missing indicator; document that rows with missing IDs are structurally unusable for join-based analysis |
| Imputation model training fails (< 50 non-null training rows) | computed during Step 4 regression fit | HALT Step 4: "Insufficient non-null rows for regression imputation on {column}. Drop column or investigate upstream." |
| Empty manifest (pass-through) | remediation_manifest == [] | Skip Steps 1–4; write pass-through artifact with data_ref = raw_dataset.data_ref; WARN "No fixes prescribed — remediated_dataset is identical to raw_dataset." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `remediated_dataset.json` exists with all 5 universal envelope fields
- [ ] `data_ref` in the artifact points to an accessible warehouse temp table (or same ref for pass-through)
- [ ] `issues_remaining == 0` (all blocking manifest entries applied or documented as not-actionable)
- [ ] `change_log` has one entry per manifest item with status: `applied`, `skipped`, or `not_actionable`
- [ ] All MNAR columns that were imputed have a corresponding `{column}_was_missing` indicator column
- [ ] `source_raw_dataset_artifact_id` and `quality_report_artifact_id` are set for full lineage tracing

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] All blocking issues in `remediation_manifest` have `change_log` entries with status `"applied"` or `"not_actionable"` (none silently skipped)
- [ ] `issues_remaining == 0`
- [ ] MCAR/MAR/MNAR classification ran for every imputed column (unless null_rate < 0.01)
- [ ] No imputation was applied without a mechanism classification (no blind mean-fill on MNAR columns)
- [ ] `change_log` is complete: one entry per manifest item including skipped and investigate items
- [ ] Indicator columns (`{col}_was_missing`) added for all MNAR columns where imputation was applied
- [ ] Re-run of `data-quality-assessment` on the remediated dataset should show no blocking issues on the remediated dimensions
- [ ] `cohort-extraction` Step 0 can load `remediated_dataset.json` and read `data_ref`

---

## Scope Boundary

This skill does NOT:
- Diagnose data quality issues → handled by `data-quality-assessment` (this skill only executes
  prescribed fixes from the remediation_manifest; it does not independently discover problems)
- Profile schema structure or column types → handled by `schema-profiling`
- Define or filter the customer population → handled by `cohort-extraction`
- Make judgment calls about which advisory issues to fix → the manifest prescribes fixes;
  advisory-severity fixes prompt analyst confirmation, but this skill does not decide what needs fixing
- Build predictive models → imputation uses simple regression as a fill strategy only;
  model building for analytical purposes is handled by downstream Group 5 skills

---

## Downstream

Run after this skill completes:
1. **`data-quality-assessment`** (re-assess) — re-run on `remediated_dataset.data_ref` to confirm
   all blocking issues are resolved before cohort-extraction proceeds
2. **`cohort-extraction`** (if re-assessment passes) — reads `remediated_dataset.data_ref`; pass
   `indicator_columns_added` forward as features
3. **`feature-engineering`** — `{col}_was_missing` indicator columns are binary predictive features;
   treat as dimensions, not measures
