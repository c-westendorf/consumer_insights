# Missingness Mechanism Classification — data-remediation Reference

Used by data-remediation Step 3 to select imputation strategy per column.

---

## Decision Tree

For each column with null_rate > 0.01 that is prescribed for imputation:

```
Step A — MCAR test (approximate Little's MCAR via chi-squared):
  Create binary missing indicator: is_missing_{column} = 1 where column is null
  Compute association between is_missing_{column} and all other features
  IF no significant associations (p > 0.05 across all features): → MCAR
  ELSE: proceed to Step B

Step B — MAR test (logistic regression on observed features):
  Fit logistic regression: is_missing_{column} ~ all_other_features
  IF any feature has significant coefficient (p < 0.05): → MAR
  ELSE: → MNAR (default when neither MCAR nor MAR confirmed)

Step C — MNAR domain heuristics (apply before tests for known cases):
  IF column.column_role == "identifier" or "temporal": → MNAR
    (IDs and timestamps with missingness indicate structural failure, not random)
  IF column is a spend/revenue/income measure: likely MNAR — WARN analyst
    (high earners and zero-spend customers systematically omit these fields)
```

---

## Imputation Strategy by Mechanism

| Mechanism | Column Type | Strategy | Notes |
|---|---|---|---|
| MCAR | numeric | median fill | median preferred; mean if symmetric distribution noted in quality_report |
| MCAR | categorical/string | mode fill | most frequent non-null value |
| MCAR | low null (<1%) | median/mode fill | no mechanism test required |
| MAR (null ≤30%) | numeric or categorical | regression imputation | fit on non-null rows; predict for null rows |
| MAR (null >30%) | any | median/mode fallback + indicator column | high null rate degrades regression; WARN analyst |
| MNAR | identifier or temporal | NO IMPUTE — indicator column only | is_missing indicator added; rows remain null |
| MNAR | measure or dimension | domain constant (if provided) OR median fallback | WARN; indicator column always required for MNAR |

---

## Indicator Column Rules

- Required for all MNAR columns (missingness is predictive — preserves signal)
- Optional but recommended for MAR with null_rate > 30%
- NOT required for MCAR (missingness is random — no signal to preserve)
- Indicator column name: `{column}_was_missing` (binary: 1 = was null, 0 = had value)
- Indicator columns are passed forward to feature-engineering as binary dimensions

---

## Failure Modes

| Condition | Action |
|---|---|
| Insufficient non-null rows for regression fit (<50 rows) | HALT: cannot train imputation model |
| MNAR identifier column prescribed for impute_mean | Override to indicator-only; WARN: identifier columns cannot be imputed |
| column.null_rate == 1.0 (all null) | HALT Step 1: 100% null column cannot be imputed; prescribe drop |
| Mechanism classification inconclusive (all tests borderline) | Default to MNAR with WARN; add indicator column |
