---
name: exploratory-analysis
description: >
  Explores distributions, correlations, and anomalies across a feature-enriched population to
  surface ranked hypotheses for downstream validation. Activate after feature-engineering and
  optionally metric-computation when scope requires data exploration; takes feature_set +
  metric_result + quality_report; produces hypothesis_set.json with ranked hypotheses by
  effect size.
inputs:
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref and features_applied drive the exploration space"
  - type: metric_result
    description: "Computed metrics from metric-computation; metric values contextualize which distributions to explore most deeply"
  - type: quality_report
    description: "Data quality assessment from data-quality-assessment; quality issues inform which columns to treat cautiously during exploration"
outputs:
  - type: hypothesis_set
    description: "Ranked hypotheses with effect sizes, evidence types, and supporting features; each hypothesis is a testable statement derived from observed patterns"
can_follow: [feature-engineering, metric-computation]
can_precede: [hypothesis-validation, statistical-comparison]
supports_loop: true
exit_conditions:
  - "≥3 hypotheses ranked by effect size (≥ small per Cohen's conventions)"
  - "exploration budget exhausted (max 5 iterations per composition-rules)"
---

## Overview

Feature-engineering and metric-computation establish *what signals exist* and *what the aggregate
values are*. Exploratory-analysis answers *what patterns, anomalies, and relationships are worth
investigating further*. This skill systematically explores univariate distributions, bivariate
correlations, and group contrasts to surface hypotheses — testable statements about the data
that downstream hypothesis-validation can formally evaluate.

The skill operates iteratively: each iteration examines a set of features, computes effect sizes,
and generates hypotheses. It terminates when ≥3 hypotheses meet the minimum effect size threshold
(small per Cohen's conventions: d≥0.2, r≥0.1, V≥0.1) or when the exploration budget is exhausted.

**What this skill produces:** `hypothesis_set.json` with a `hypotheses` array — each entry
contains a statement, evidence type, observed effect size, supporting features, rank, and priority.

---

## When to Activate

- A plan task node with `task_type: "exploratory_analysis"` is the next unexecuted task
- `feature_set.json` exists and scope implies data exploration is needed before hypothesis testing
- User explicitly requests "explore the data", "what patterns exist", or "run EDA"
- `scope_artifact.analytical_pattern` is "profile", "explain", or "segment"
- Previous iteration produced <3 qualifying hypotheses and budget remains

---

## Preconditions

What must be true before this skill begins:

- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"`
- [ ] `feature_set.data_ref` is accessible in the warehouse
- [ ] `metric_result.json` exists (may be absent on first iteration — proceed with WARN)
- [ ] `quality_report.json` exists (may be absent — proceed with WARN)

Each required precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.10 (effect size computation, statistical tests); numpy>=1.24 (correlations); pandas>=2.0 (local analysis of samples)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; heavy computation pushed to warehouse SQL; local Python for correlation matrices and effect sizes
- **Memory:** <500 MB (may load sample data locally for correlation analysis)
- **Upstream Artifacts:** `feature_set.json` (data_ref, features_applied), `metric_result.json` (metrics), `quality_report.json` (issues to avoid)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `analytical_pattern` | `profile` / `compare` / `segment` | `profile`: univariate distributions + bivariate correlations; `compare`: group contrasts between target/reference; `segment`: cluster discovery + separation analysis |
| `exploration_depth` | `shallow` / `deep` | `shallow`: top-10 features by variance/correlation; `deep`: full feature cross-product, interaction effects |
| `data_richness` | `rich` (≥20 features) / `sparse` (<20 features) | `rich`: correlation matrix + PCA-driven exploration; `sparse`: univariate focus, no dimensionality reduction |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify analytical_pattern:
  read scope_artifact.analytical_pattern
  IF == "compare" → "compare"
  ELIF == "segment" → "segment"
  ELSE → "profile"
  log: "analytical_pattern={value}"

classify exploration_depth:
  IF plan_node.exploration_budget > 3 → "deep"
  ELSE → "shallow"
  log: "exploration_depth={value}"

classify data_richness:
  IF feature_set.feature_count >= 20 → "rich"
  ELSE → "sparse"
  log: "data_richness={value}"

log: "Running exploratory-analysis | pattern={value} | depth={value} | richness={value}"
```

**Upstream Validation:**
```
load feature_set.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json — schema_version mismatch."
assert data_ref is not null
  IF not: HALT: "Upstream validation failed: feature_set.json — data_ref missing."

load scope_artifact.json
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."

TRY load metric_result.json
  IF not found: WARN: "metric_result.json not found — exploring without metric context."

TRY load quality_report.json
  IF not found: WARN: "quality_report.json not found — exploring without quality context."
  ELSE: problematic_columns = [issue.column for issue in quality_report.blocking_issues]
```

---

### Step 1 — Univariate Exploration

**Goal:** Examine each feature's distribution to identify anomalies, skewness, and notable patterns.

**Pre-step assertion:** data_ref accessible; feature list available.

**Actions:**
```
univariate_findings = []

FOR each feature in feature_set.features_applied + original columns:
  IF feature.name in problematic_columns: SKIP with note

  Query distribution statistics:
    SELECT MIN, MAX, AVG, STDDEV, APPROX_PERCENTILE(0.25), APPROX_PERCENTILE(0.5),
           APPROX_PERCENTILE(0.75), COUNT(DISTINCT), COUNT(*) - COUNT({feature}) as null_count
    FROM {data_ref}

  -- Detect anomalies
  IF skewness > 2.0: flag "highly_skewed"
  IF null_rate > 0.3: flag "high_nulls"
  IF distinct_count == 1: flag "zero_variance" — skip
  IF outlier_ratio > 0.05: flag "outlier_heavy"

  univariate_findings.append(feature_summary)

Log: "Univariate exploration complete | features_examined={count} | anomalies_flagged={count}"
```

**Checkpoint:**
> - [ ] PASS: univariate statistics computed for all non-problematic features
> - [ ] WARN: features skipped due to quality issues

---

### Step 2 — Bivariate/Group Analysis

**Goal:** Identify relationships between features and with the outcome metric.

**Branch on `analytical_pattern`:**

**IF `profile`:**
```
-- Compute pairwise correlations for numeric features
IF data_richness == "rich":
  Sample data locally (max 50k rows)
  correlation_matrix = compute pairwise Pearson/Spearman correlations
  strong_correlations = filter |r| >= 0.3

  -- PCA for dimension reduction insight
  pca_result = fit PCA, examine top components for interpretable loadings

ELSE:
  -- Sparse: compute correlations with outcome metric only
  FOR each numeric feature:
    r = correlation(feature, outcome_metric)
    IF |r| >= 0.1: strong_correlations.append(feature, r)
```

**IF `compare`:**
```
-- Group contrasts between target and reference
FOR each feature:
  compute mean/median for target vs reference
  effect_size = cohens_d(target_values, reference_values)
  IF |effect_size| >= 0.2: group_contrasts.append(feature, effect_size)
```

**IF `segment`:**
```
-- Cluster analysis for segment discovery
IF data_richness == "rich":
  Run k-means or hierarchical clustering (k=2..6)
  Evaluate silhouette scores
  Identify distinguishing features per cluster
ELSE:
  WARN: "Sparse features — segment discovery may produce weak clusters"
```

**Checkpoint:**
> - [ ] PASS: bivariate analysis complete; relationships identified
> - [ ] WARN: weak or no significant relationships found

---

### Step 3 — Generate Hypotheses

**Goal:** Synthesize findings into ranked, testable hypotheses.

**Pre-step assertion:** Univariate and bivariate findings available.

**Actions:**
```
hypotheses = []
hypothesis_counter = 1

-- Generate hypotheses from strong correlations
FOR each (feature, r) in strong_correlations:
  effect_magnitude = classify_effect(|r|)  -- small/medium/large
  IF effect_magnitude != "negligible":
    hypotheses.append({
      hypothesis_id: "H-{counter:03d}",
      statement: "Higher {feature} is associated with higher/lower {outcome_metric}",
      evidence_type: "correlation",
      observed_effect_size: r,
      effect_size_type: "pearson_r",
      effect_size_magnitude: effect_magnitude,
      supporting_features: [feature],
      rank: null,  -- assigned after sorting
      priority: map_priority(effect_magnitude)
    })

-- Generate hypotheses from group contrasts (compare pattern)
FOR each (feature, d) in group_contrasts:
  ...similar hypothesis generation with cohens_d...

-- Generate hypotheses from distribution anomalies
FOR each anomaly in univariate_findings where flagged:
  ...hypothesis about anomaly impact...

-- Rank hypotheses by effect size (descending)
hypotheses.sort(key=|effect_size|, descending)
FOR i, h in enumerate(hypotheses):
  h.rank = i + 1

Log: "Hypotheses generated | total={len(hypotheses)} | meeting_threshold={count >= small}"
```

**Checkpoint:**
> - [ ] PASS: ≥3 hypotheses meeting small effect size threshold
> - [ ] WARN: <3 hypotheses — may need another iteration or deeper exploration
> - [ ] HALT: 0 hypotheses after full exploration — "No significant patterns found in data."

---

### Step 4 — Write Terminal Artifact

**Goal:** Persist hypothesis_set.json.

**Actions:**
```
Generate artifact_id: UUID v4

hypotheses_meeting_threshold = count(h for h in hypotheses where effect_size >= small_threshold)

Write hypothesis_set.json

Log: "hypothesis_set.json written | hypotheses={len(hypotheses)} | meeting_threshold={hypotheses_meeting_threshold}"
```

**Checkpoint:**
> - [ ] PASS: hypothesis_set.json written; all 5 universal envelope fields present

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "exploratory-analysis",
  "timestamp": "2026-04-10T15:30:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "hypotheses": [
    {
      "hypothesis_id": "H-001",
      "statement": "Customers with purchase_rate_per_30d > 2.0 have significantly higher annual_spend (d=0.72)",
      "evidence_type": "correlation",
      "observed_effect_size": 0.72,
      "effect_size_type": "pearson_r",
      "effect_size_magnitude": "large",
      "supporting_features": ["purchase_rate_per_30d", "annual_spend"],
      "rank": 1,
      "priority": "high"
    },
    {
      "hypothesis_id": "H-002",
      "statement": "Days since last purchase shows a bimodal distribution suggesting two distinct customer segments",
      "evidence_type": "distribution_gap",
      "observed_effect_size": 0.45,
      "effect_size_type": "cohens_d",
      "effect_size_magnitude": "medium",
      "supporting_features": ["days_since_last_purchase"],
      "rank": 2,
      "priority": "medium"
    }
  ],
  "exploration_iterations": 1,
  "patterns_examined": 45,
  "hypotheses_meeting_threshold": 4
}
```

**Write to:** `hypothesis_set.json` in the project directory.

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source (record_count == 0) | feature_set.record_count == 0 | HALT Step 0: "Cannot explore empty dataset." |
| Single record | record_count == 1 | WARN: "Single record — statistical exploration meaningless." |
| All-null features | all features 100% NULL | HALT: "All features are NULL — nothing to explore." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact artifact name |
| All features zero-variance | every feature has cardinality == 1 | HALT: "All features are constant — no variation to explore." |
| No significant patterns | 0 hypotheses after full exploration | HALT Step 3: "No significant patterns found." |
| Correlation matrix singular | features are linearly dependent | WARN: drop redundant features and retry |
| Exploration budget exhausted | iteration count >= max_iterations (5) | EXIT: write current hypotheses regardless of count |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `hypothesis_set.json` exists with all 5 universal envelope fields
- [ ] Every hypothesis has non-null `statement`, `evidence_type`, `observed_effect_size`, and `rank`
- [ ] Hypotheses are sorted by `rank` (1 = highest effect size)
- [ ] `effect_size_magnitude` is correctly classified per Cohen's conventions
- [ ] `exploration_iterations` reflects actual iteration count

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `hypothesis_set.json` written and validates against terminal artifact spec
- [ ] ≥3 hypotheses meeting small effect size threshold (or budget exhausted with documented count)
- [ ] All hypotheses have testable statements (not vague observations)
- [ ] Effect sizes are computed with appropriate method for the data type
- [ ] Downstream `hypothesis-validation` Step 0 can load and validate `hypothesis_set.json`
- [ ] No exploration of features flagged as quality-problematic without documented justification

---

## Scope Boundary

This skill does NOT:
- Formally validate hypotheses with statistical tests → handled by `hypothesis-validation`
- Compare groups with controlled statistical methods → handled by `statistical-comparison`
- Engineer or derive feature columns → handled by `feature-engineering`
- Compute aggregate metrics → handled by `metric-computation`
- Discover behavioral segments with formal clustering → handled by `cohort-behavior-analysis` or `latent-factor-modeling`

---

## Downstream

Run after this skill completes:
1. **`hypothesis-validation`** — reads `hypothesis_set.hypotheses` to formally test each hypothesis with statistical methods, confounder checks, and evidence strength assessment
2. **`statistical-comparison`** — may use hypothesis priorities to determine which group comparisons to run first
