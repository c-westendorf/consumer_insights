# Skill Test Assessment Report

**Skill:** `metric-computation`
**Tested by:** dse-skill-tester
**Date:** 2026-04-10
**Skill path:** `.claude/skills/metric-computation/SKILL.md`

---

## Test Summary

| Category          | Tests Run | Pass | Warn | Fail | Critical |
|-------------------|-----------|------|------|------|----------|
| A -- Happy Path    | 2         | 2    | 0    | 0    | 0        |
| B -- Variance      | 20        | 17   | 3    | 0    | 0        |
| C -- Precondition  | 9         | 8    | 0    | 1    | 0        |
| D -- Edge Cases    | 12        | 10   | 1    | 1    | 0        |
| **Total**         | **43**    | **37**| **4**| **2**| **0**    |

---

## Per-Test Results

### Category A -- Happy Path

| Test | Outcome | Notes |
|------|---------|-------|
| A1: Profile proportion w/ sample_set | PASS | Traced Steps 0-4. Step 0 validates all three artifacts, classifies 5 dimensions. Step 1 maps proportion to AVG(CASE WHEN...) and forces wilson CI. Step 2 runs single SQL. Step 3 computes wilson interval. Step 4 writes metric_result.json with all 5 envelope fields + 1 metric entry. All postconditions met. |
| A2: Compare mean w/ cohort | PASS | Step 0 validates, classifies pattern=compare. Step 2 branches into FOR loop over base/comparison refs, producing 2 entries. Step 3 computes normal_approx CI for both. Step 4 writes 2 metric entries with population labels "target" and "reference". Postcondition for compare (both populations present) satisfied. |

### Category B -- Variance Coverage

| Test | Outcome | Notes |
|------|---------|-------|
| B1: source=sample_set | PASS | Step 0 classification correctly branches: loads sample_set.json, asserts sample_size > 0. Population metadata sourced from sample_set. |
| B2: source=cohort | PASS | Step 0 ELSE branch: loads cohort.json, asserts population_size > 0. |
| B3: pattern=profile | PASS | Step 2 profile branch: single SQL execution, single metric entry with population="target". |
| B4: pattern=compare | PASS | Step 2 compare branch: FOR loop over base/comparison refs. Produces 2 entries. HALT on empty reference specified. |
| B5: agg=proportion | PASS | Step 1 maps to AVG(CASE WHEN...); ci_method forced to wilson in both Step 0 classification and Step 1. Consistent. |
| B6: agg=mean | PASS | Step 1 maps to AVG(CAST...); ci_method depends on n: normal_approx if n>=30, bootstrap otherwise. |
| B7: agg=median | PASS | Step 1 maps to APPROX_PERCENTILE(col, 0.5); ci_method = bootstrap. |
| B8: agg=count | PASS | Step 1 maps to COUNT(*). CI computation proceeds normally. |
| B9: agg=sum | PASS | Step 1 maps to SUM(...). CI computation proceeds normally. |
| B10: agg=rate | PASS | Step 1 maps to SUM(num)/NULLIF(SUM(denom),0). Handles divide-by-zero via NULLIF. |
| B11: agg=percentile | PASS | Step 1 maps to APPROX_PERCENTILE(col, {pct}); ci_method = bootstrap. |
| B12: agg=weighted_mean | WARN | Step 1 maps to SUM(m*w)/NULLIF(SUM(w),0); ci_method = bootstrap. **Issue:** The spec does not specify how the bootstrap resampling in Step 3 handles weighted data. Standard bootstrap on summary stats may not correctly propagate weights. The spec says bootstrap operates on "draw n_obs values with replacement from data" but weighted_mean requires weight-aware resampling. Spec gap -- does not break the skill but CI may be statistically incorrect for weighted metrics. |
| B13: agg=rolling_mean | WARN | Step 1 maps to window function. **Issue:** Rolling mean produces multiple rows (one per period), but the CI computation in Step 3 treats each metric as a single value. The spec does not describe how CI is computed per-period for rolling_mean. Additionally, the grain classification does not force grain=period for rolling_mean, which would be the natural expectation. Spec gap. |
| B14: agg=cohort_indexed | WARN | Step 1 maps to metric/NULLIF(baseline,0)*100. **Issue:** The spec references `{baseline_value}` but does not define where this value comes from. Is it a column? A precomputed value? A subquery? The sql_expr template has an undefined variable. Spec gap. |
| B15: ci=wilson | PASS | Step 3 wilson branch: formula is standard Wilson score interval. Bounds clamped to [0,1]. Input validation asserts value in [0,1]. |
| B16: ci=normal_approx | PASS | Step 3 normal_approx branch: z-interval formula correct. Note: requires std_dev from SQL (STDDEV), which is mentioned in Step 3 but not in Step 2 SQL templates. Minor gap but the spec comment in Step 3 clarifies the need. |
| B17: ci=bootstrap | PASS | Step 3 bootstrap branch: 1000 iterations, percentile(2.5/97.5). Fallback to normal_approx if n<5. Zero-width CI detection present. |
| B18: grain=customer | PASS | Step 2: no GROUP BY clause. Single aggregate row. |
| B19: grain=transaction | PASS | Step 2: no GROUP BY clause. Single aggregate row. |
| B20: grain=period | PASS | Step 2: GROUP BY {period_bucket_expression}. Multiple rows produced. Note: Step 4 terminal artifact shows single metric entry, but period grain would produce multiple. The spec does not clarify whether multiple period rows become multiple metric entries or are aggregated. Minor spec gap but workable. |

### Category C -- Precondition Violations

| Test | Outcome | Notes |
|------|---------|-------|
| C1: Missing/bad feature_set | PASS | Step 0 line: assert schema_version == "1.0" with explicit HALT message. |
| C2: data_ref null | PASS | Step 0 line: assert data_ref is not null with explicit HALT. |
| C3: Missing scope metric | PASS | Step 0 line: assert metric.name non-null with explicit HALT. |
| C4: No population artifact | FAIL | **Issue:** Step 0 classification says "IF sample_set.json exists -> sample_set, ELSE -> cohort" and then validates whichever is selected. But the precondition states "At least one of sample_set.json or cohort.json exists." If neither exists, the classification defaults to cohort, and Step 0 would HALT on "cohort.json -- schema_version mismatch" (file not found). The HALT fires but the error message is misleading -- it says "schema_version mismatch" when the real issue is the file does not exist. The precondition is functionally enforced but with a confusing error message. |
| C5: Compare w/ string data_ref | PASS | Step 0: explicit check for dict with base/comparison keys when pattern=compare. Clear HALT message. |
| C6: scope_artifact schema mismatch | PASS | Step 0: explicit assertion with HALT. |
| C7: features_applied not array | PASS | Step 0: explicit assertion with HALT. |
| C8: Missing timeframe | PASS | Step 0: explicit assertion with HALT. |
| C9: sample_size = 0 | PASS | Step 0: asserts sample_size > 0 with HALT. |

### Category D -- Edge Cases

| Test | Outcome | Notes |
|------|---------|-------|
| D1: Empty source | PASS | Edge case table specifies HALT Step 0. Step 0 validates population_size > 0 (cohort) or sample_size > 0 (sample_set). Consistent. |
| D2: Single record | PASS | Edge case table specifies WARN. Step 2 checkpoint: "n_observations < 30 -> WARN". Single record (n=1) is caught by this check. Step 3 bootstrap fallback triggers at n<5. Degenerate CI reported. |
| D3: All-null metric | PASS | Edge case table specifies HALT. Step 2 would return NULL for metric_value. However, the HALT for all-null is declared in the edge case table but not explicitly in Step 2 pseudocode -- the Step 2 checkpoint does not list "metric_value IS NULL" as a HALT condition. The edge case table declares it, so the intent is clear, but implementation would need to add a null check after SQL execution. Passing with note. |
| D4: Schema mismatch | PASS | Covered by Step 0 validation for all three artifact types. HALT messages are artifact-specific. |
| D5: Zero-variance | PASS | Step 3 explicitly checks ci_lower == value AND ci_upper == value AND n_obs > 1. WARN fired, added to computation_warnings. |
| D6: Proportion outside [0,1] | PASS | Step 3 wilson branch: assert 0.0 <= value <= 1.0 with explicit HALT. |
| D7: Small sample n<30 | PASS | Step 2 checkpoint: WARN with message. |
| D8: Bootstrap zero-width | PASS | Step 3 bootstrap branch: explicit check for ci_lower == ci_upper with WARN. Edge case table adds "fallback to normal_approx" which is consistent with the bootstrap n<5 fallback pattern. |
| D9: Compare empty reference | PASS | Step 2 compare branch: explicit check for reference n_obs == 0 with HALT. |
| D10: Weighted mean null weights | FAIL | Edge case table specifies HALT if >50% null, WARN if <=50%. **Issue:** This check is not present anywhere in the Step 0-4 workflow pseudocode. Neither Step 1 nor Step 2 examines the weight column for NULLs. The edge case is declared but has no corresponding workflow logic to implement it. A weight-null check must be added to Step 2 (post-SQL or pre-SQL inspection query). |
| D11: Rolling mean insufficient periods | WARN | Edge case table specifies WARN with window reduction. **Issue:** Similar to D10, this check is not in the workflow pseudocode. The edge case is declared but lacks implementation guidance in the steps. However, the rolling_mean SQL would naturally handle this (window function operates on available rows), so the functional impact is lower. The WARN message would need to be emitted somewhere in Step 2. |
| D12: FEATURES_ table expired | PASS | Step 2 checkpoint: explicit HALT on SQL error with message to re-run feature-engineering. |

---

## Terminal Artifact Validation

Verified on passing tests (A1, A2):

| Envelope Field | Present | Source |
|----------------|---------|--------|
| schema_version | Yes | "1.0" -- hardcoded in Step 4 |
| skill_name | Yes | "metric-computation" -- hardcoded in Step 4 |
| timestamp | Yes | now_utc_iso8601() -- generated in Step 4 |
| record_count | Yes | Sum of n_observations across metric entries -- computed in Step 4 |
| artifact_id | Yes | UUID v4 -- generated in Step 4 |

**Skill-specific fields:**

| Field | Present | Description |
|-------|---------|-------------|
| metrics | Yes | Array of metric entry objects; each has name, definition, aggregation_type, grain, value, confidence_interval_95, ci_method, population, period, n_observations |
| computation_warnings | Yes | Array (may be empty); collects non-blocking issues |

All 5 universal envelope fields confirmed present. Terminal artifact example in spec is well-formed JSON.

---

## Coverage Assessment

### Variance Dimensions

| Dimension | Values Declared | Values Tested | Coverage |
|-----------|----------------|---------------|----------|
| source_population | 2 | 2 | 100% |
| analytical_pattern | 2 | 2 | 100% |
| aggregation_type | 10 | 10 | 100% |
| ci_method | 3 | 3 | 100% |
| grain | 3 | 3 | 100% |

### Precondition Coverage

9 of 9 testable precondition violations covered (derived from 5 declared preconditions, expanded to cover specific sub-assertions in Step 0). 8 pass cleanly, 1 has misleading error message (C4).

### Edge Case Coverage

12 of 12 declared edge cases tested. 10 pass, 1 warn (D11 -- declared but not implemented in workflow), 1 fail (D10 -- declared but not implemented in workflow).

---

## Blueprint Compliance

| Principle | Status | Evidence |
|-----------|--------|----------|
| Single Job | PASS | Skill computes aggregate metrics only. Scope boundary explicitly excludes comparison, exploration, feature engineering, impact estimation, and ROI. |
| Precondition/Postcondition Contracts | PASS | 5 preconditions with explicit HALT. 6 postconditions with testable assertions. |
| Explicit Variance | PASS | 5 dimensions with 20 total values. Classification logic in Step 0 with logging. Each dimension drives different code paths in Steps 1-3. |
| Artifact at Every State Change | PASS | Terminal artifact written in Step 4. Checkpoints at Steps 1, 2, 3, 4. No intermediate artifacts needed (single-step SQL + compute pattern). |
| Stateful Ops Scoped | PASS | Stateful operations limited to: (1) SQL queries against warehouse temp tables (read-only), (2) Writing metric_result.json. No DDL, no temp table creation, no external side effects. |
| Quality Bar Over Completeness | PASS | 8-item quality bar defined. Includes finite numeric check, CI ordering, method consistency, and downstream compatibility test. |
| Canonical Reference Library | PASS | Dependencies in tiered format (Tier 2-4). scipy, numpy for CI computation. snowflake-connector/bigquery for warehouse access. |
| Self-Contained Portability | PASS | All logic in SKILL.md. No external references beyond declared dependencies. Frontmatter complete with inputs, outputs, can_follow, can_precede, supports_loop, exit_conditions. |

---

## 17-Item Checklist

| # | Item | Status | Notes |
|---|------|--------|-------|
| 1 | Frontmatter complete | PASS | name, description, inputs (3), outputs (1), can_follow, can_precede, supports_loop, exit_conditions all present |
| 2 | All 12 sections present in order | PASS | Overview, When to Activate, Preconditions, Prerequisites, Variance Surface, Workflow, Terminal Artifact, Edge Cases, Postconditions, Quality Bar, Scope Boundary, Downstream -- all present in correct order |
| 3 | SKILL.md <= 500 lines | WARN | File is 526 lines. Exceeds 500-line guideline by 26 lines. The 10-value aggregation_type dimension is the primary contributor. Consider whether rolling_mean and cohort_indexed (which have spec gaps) should be deferred to reduce line count. |
| 4 | No artifact generation script needed | PASS | Spec-only phase; no script required |
| 5 | Dependencies in tiered format | PASS | Tier 2, 3, 4 declared with version constraints |
| 6 | Preconditions testable with explicit HALT | PASS | All 5 preconditions have HALT actions in Step 0 |
| 7 | Terminal artifact has all 5 envelope fields | PASS | schema_version, skill_name, timestamp, record_count, artifact_id |
| 8 | Stateful operations bounded | PASS | Read-only SQL + single file write |
| 9 | Degraded upstream produces HALT | PASS | Schema mismatch, missing fields, null data_ref all produce HALTs |
| 10 | Variance Surface >= 2 values per dimension | PASS | source_population(2), analytical_pattern(2), aggregation_type(10), ci_method(3), grain(3) |
| 11 | Workflow steps numbered sequentially | PASS | Steps 0-4 |
| 12 | Each step has pre-step assertion | PASS | Steps 1-4 each have pre-step assertion |
| 13 | Each step has checkpoint | PASS | Steps 1-4 each have PASS/HALT/WARN checkpoint |
| 14 | Edge case table has Detection + Action | PASS | 12 rows, each with detection condition and action |
| 15 | Postconditions are testable assertions | PASS | 6 postconditions, all verifiable against artifact |
| 16 | Quality bar items are binary pass/fail | PASS | 8 items, all boolean-testable |
| 17 | Scope boundary lists what skill does NOT do | PASS | 6 explicit exclusions with skill references |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL**

The skill is well-structured, has strong precondition/postcondition contracts, comprehensive variance coverage, and full blueprint compliance. However, 2 issues require attention before merge.

---

## Required Fixes

### Fix 1 (FAIL -- D10): Add weighted mean null-weight check to workflow

**Location:** Step 2, after SQL execution for aggregation_type == "weighted_mean"

**What to add:** Before or after the weighted_mean SQL execution, add a pre-check query:
```
IF aggregation_type == "weighted_mean":
  Execute: SELECT COUNT(*) as null_count, COUNT({weight_column}) as non_null_count FROM {data_ref}
  null_pct = null_count / (null_count + non_null_count)
  IF null_pct > 0.50: HALT: "Weight column >50% NULL -- weighted mean unreliable."
  ELIF null_pct > 0: WARN: "weights contain {null_pct*100}% nulls -- weighted mean excludes null-weight rows"
```

This reconciles the edge case table declaration (D10) with actual workflow logic.

### Fix 2 (FAIL -- C4): Improve error message for missing population artifact

**Location:** Step 0 upstream validation, cohort.json load block

**What to change:** Before loading cohort.json, add an existence check:
```
IF source_population == "cohort":
  assert cohort.json exists
    IF not: HALT: "Upstream validation failed: neither sample_set.json nor cohort.json found.
    Re-run cohort-extraction or population-sampling."
  load cohort.json
  ...
```

This ensures the error message accurately describes the failure when neither population artifact exists.

---

## Recommended Improvements (non-blocking)

1. **Line count (526 > 500):** Consider deferring `rolling_mean` and `cohort_indexed` aggregation types to a v2 extension, or moving the 10-type SQL mapping table to a canonical reference. Both have spec gaps (B13 baseline_value undefined, B14 CI-per-period undefined) that support deferral.

2. **rolling_mean workflow gap (B13/D11):** Add Step 2 logic for insufficient period detection and window reduction. Add Step 3 guidance for per-period CI computation.

3. **cohort_indexed baseline_value (B14):** Define where `{baseline_value}` comes from -- is it the first period's value, a reference population value, or a user-defined constant?

4. **normal_approx STDDEV gap (B16):** Step 2 SQL templates do not include STDDEV in the SELECT. Step 3 normal_approx requires std_dev. Add `STDDEV({metric_column}) AS std_dev` to the Step 2 SQL template for mean/sum/count/rate aggregation types.

5. **period grain multi-row handling (B20):** Clarify whether period grain produces one metric entry per period bucket or a single aggregated entry. If multiple entries, the terminal artifact metrics array and record_count computation need adjustment.

---

## Tests Still Needed

These tests require real warehouse connectivity and cannot be verified by spec walk-through:

1. **SQL execution against actual FEATURES_ table** -- verify sql_expr templates produce valid SQL for each warehouse dialect (Snowflake vs BigQuery)
2. **Bootstrap resampling correctness** -- verify 1000-iteration bootstrap on real data produces statistically valid 95% CI bounds
3. **Wilson CI numerical stability** -- test with extreme proportions (p near 0 or 1) and very large n
4. **Compare pattern end-to-end** -- verify both populations are queried and both metric entries appear in artifact
5. **Weighted mean with partial null weights** -- verify SQL correctly excludes null-weight rows and WARN fires
6. **Downstream compatibility** -- verify statistical-comparison Step 0 can load and validate the produced metric_result.json
7. **Temp table expiration handling** -- verify the HALT fires with correct message when FEATURES_ table has expired
8. **Large n performance** -- verify bootstrap resampling on summary stats (not raw data) stays under 200 MB memory bound
