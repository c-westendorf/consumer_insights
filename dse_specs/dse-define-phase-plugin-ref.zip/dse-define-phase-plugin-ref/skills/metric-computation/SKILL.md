---
name: metric-computation
description: >
  Computes aggregate metrics (proportions, means, rates, percentiles) with confidence intervals
  across a feature-enriched population, producing metric_result.json that downstream
  statistical-comparison, exploratory-analysis, behavioral-impact-estimation, and roi-computation
  consume. Activate after feature-engineering when scope_artifact.metric defines the business
  outcome to measure; takes feature_set + (cohort or sample_set) + scope_artifact.
inputs:
  - type: feature_set
    description: "Feature-enriched population table from feature-engineering; data_ref points to FEATURES_ warehouse temp table; features_applied manifest lists available derived columns"
  - type: cohort
    description: "Full filtered population from cohort-extraction; used when population-sampling was skipped; provides population_size and observation_window"
  - type: sample_set
    description: "Statistical sample from population-sampling; preferred source when sampling ran; provides sample_size and strata"
    optional: true
  - type: scope_artifact
    description: "Approved scope definition; metric.name, metric.aggregation, and timeframe drive the metric plan; analytical_pattern determines profile vs compare branching"
outputs:
  - type: metric_result
    description: "Computed aggregate metrics with 95% confidence intervals, grain, and population labels; one entry per metric per population"
can_follow: [feature-engineering, cohort-extraction]
can_precede: [statistical-comparison, exploratory-analysis, behavioral-impact-estimation, roi-computation]
supports_loop: false
exit_conditions:
  - "metric_result.json written with all scope-defined metrics computed or documented in computation_warnings"
  - "every metric entry has non-null value and valid confidence_interval_95, or a computation_warning explaining why"
---

## Overview

Feature-engineering builds *what signals exist* about a population. Metric-computation answers
*what are the aggregate values* of the business outcome across that population. The
scope_artifact.metric defines the business question ("what is the repeat purchase rate?"), and
this skill translates that into SQL aggregation, confidence interval computation, and a
structured metric_result.json that 10+ downstream skills consume.

The skill operates in the warehouse via SQL for aggregation, with local Python for confidence
interval computation (bootstrap resampling, Wilson score intervals). For the compare analytical
pattern, identical metric computations run against both target and reference populations,
producing parallel metric entries labeled by population.

**What this skill produces:** `metric_result.json` with a `metrics` array — each entry contains
the metric name, aggregation type, grain, computed value, 95% CI, CI method, population label,
period, and observation count. The `computation_warnings` array captures any non-blocking issues
(small n, zero variance, bootstrap fallback).

---

## When to Activate

- A plan task node with `task_type: "metric_computation"` is the next unexecuted task
- `feature_set.json` exists and `scope_artifact.metric.name` specifies a measurable business outcome
- User explicitly requests "compute the metric", "calculate the rate", or "measure the outcome"
- `feature-engineering` has completed and downstream analysis requires aggregate metric values
- `scope_artifact.analytical_pattern` is "compare" and both populations need parallel metric computation

---

## Preconditions

What must be true before this skill begins:

- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `scope_artifact.json` exists with `schema_version == "1.0"`, `metric` field present, `metric.name` non-null
- [ ] At least one of `sample_set.json` or `cohort.json` exists with `schema_version == "1.0"`
- [ ] `feature_set.data_ref` is accessible in the warehouse (temp table not expired)
- [ ] For compare pattern: `feature_set.data_ref` is a dict with `base` and `comparison` keys

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0, google-cloud-bigquery>=3.0
# Tier 3: scipy>=1.10 (Wilson CI, normal_approx CI); numpy>=1.24 (bootstrap resampling)
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; aggregation is warehouse SQL; CI computation is local Python
- **Memory:** <200 MB (bootstrap resampling on summary statistics, not raw data)
- **Upstream Artifacts:** `feature_set.json` (data_ref, features_applied), `scope_artifact.json` (metric, analytical_pattern, timeframe), `cohort.json` or `sample_set.json` (population context)

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `source_population` | `sample_set` / `cohort` | `sample_set`: use sample_set.sample_size for n_observations and sampling metadata; `cohort`: use cohort.population_size; if both present, sample_set takes precedence |
| `analytical_pattern` | `profile` / `compare` | `profile`: compute metrics for single population; `compare`: compute identical metrics for target AND reference populations separately, producing two metric entries per metric name |
| `aggregation_type` | `proportion` / `mean` / `median` / `count` / `sum` / `rate` / `percentile` / `weighted_mean` / `rolling_mean` / `cohort_indexed` | Drives the SQL aggregation expression and determines which CI method is appropriate |
| `ci_method` | `bootstrap` / `normal_approx` / `wilson` | `wilson`: for proportions only (exact binomial); `normal_approx`: z-interval for means with large n (≥30); `bootstrap`: general resampling method for medians, percentiles, and non-normal distributions |
| `grain` | `customer` / `transaction` / `period` | Determines the GROUP BY level for SQL aggregation; `customer`: one row per customer; `transaction`: one row per event; `period`: one row per time bucket |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify source_population:
  IF sample_set.json exists → "sample_set"
  ELSE → "cohort"
  log: "source_population={value}"

classify analytical_pattern:
  read scope_artifact.analytical_pattern
  IF == "compare" AND feature_set.data_ref is dict → "compare"
  ELSE → "profile"
  log: "analytical_pattern={value}"

classify aggregation_type:
  read scope_artifact.metric.aggregation
  Map to: proportion | mean | median | count | sum | rate | percentile | weighted_mean | rolling_mean | cohort_indexed
  IF not mappable: default to "mean" with WARN
  log: "aggregation_type={value}"

classify ci_method:
  IF aggregation_type == "proportion" → "wilson"
  ELIF aggregation_type IN ["median", "percentile", "weighted_mean", "rolling_mean", "cohort_indexed"] → "bootstrap"
  ELIF n_observations >= 30 → "normal_approx"
  ELSE → "bootstrap"
  log: "ci_method={value}"

classify grain:
  IF scope_artifact.timeframe.granularity is present → map to period grain
  ELIF scope_artifact.metric implies per-customer → "customer"
  ELSE → "customer" (default)
  log: "grain={value}"

log: "Running metric-computation | source={value} | pattern={value} | agg={value} | ci={value} | grain={value}"
```

**Upstream Validation:**
```
load feature_set.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json — schema_version mismatch.
  Re-run feature-engineering."
assert data_ref is not null
  IF null: HALT: "Upstream validation failed: feature_set.json — data_ref missing."
assert features_applied is array
  IF not: HALT: "Upstream validation failed: feature_set.json — features_applied not an array."

IF analytical_pattern == "compare":
  assert feature_set.data_ref is dict with "base" and "comparison" keys
    IF not: HALT: "Upstream validation failed: compare pattern declared but feature_set.data_ref
    is not a base/comparison dict. Re-run feature-engineering with compare scope."

load scope_artifact.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: scope_artifact.json — schema_version mismatch."
assert metric field is present AND metric.name is non-null
  IF not: HALT: "Upstream validation failed: scope_artifact.json — metric or metric.name absent.
  Re-run scope-formatting."
assert timeframe field is present with start and end dates
  IF not: HALT: "Upstream validation failed: scope_artifact.json — timeframe missing."

IF source_population == "sample_set":
  load sample_set.json
  assert schema_version == "1.0" AND sample_size > 0
    IF not: HALT: "Upstream validation failed: sample_set.json — schema_version mismatch or sample_size=0."
  population_artifact = sample_set
ELSE:
  assert cohort.json exists
    IF not: HALT: "Upstream validation failed: neither sample_set.json nor cohort.json found.
    Re-run cohort-extraction or population-sampling."
  load cohort.json
  assert schema_version == "1.0" AND population_size > 0
    IF not: HALT: "Upstream validation failed: cohort.json — schema_version mismatch or population_size=0."
  population_artifact = cohort
```

---

### Step 1 — Build Metric Plan

**Goal:** Derive the SQL aggregation expression and CI parameters from scope_artifact.metric.

**Pre-step assertion:** scope_artifact.metric is loaded and aggregation_type is classified.

**Actions:**
```
metric_plan = {
  name: scope_artifact.metric.name,
  definition: scope_artifact.metric.definition,
  aggregation_type: classified aggregation_type,
  grain: classified grain,
  ci_method: classified ci_method
}

-- Map aggregation_type to SQL expression
IF aggregation_type == "proportion":
  sql_expr = "AVG(CASE WHEN {metric_column} = 1 THEN 1.0 ELSE 0.0 END)"
  ci_method = "wilson"  -- forced override for proportions
ELIF aggregation_type == "mean":
  sql_expr = "AVG(CAST({metric_column} AS FLOAT))"
ELIF aggregation_type == "median":
  sql_expr = "APPROX_PERCENTILE({metric_column}, 0.5)"
ELIF aggregation_type == "count":
  sql_expr = "COUNT(*)"
ELIF aggregation_type == "sum":
  sql_expr = "SUM({metric_column})"
ELIF aggregation_type == "rate":
  sql_expr = "CAST(SUM({numerator_col}) AS FLOAT) / NULLIF(SUM({denominator_col}), 0)"
ELIF aggregation_type == "percentile":
  sql_expr = "APPROX_PERCENTILE({metric_column}, {percentile_value})"
ELIF aggregation_type == "weighted_mean":
  sql_expr = "SUM({metric_column} * {weight_column}) / NULLIF(SUM({weight_column}), 0)"
ELIF aggregation_type == "rolling_mean":
  sql_expr = "AVG({metric_column}) OVER (ORDER BY {period_col} ROWS BETWEEN {window-1} PRECEDING AND CURRENT ROW)"
ELIF aggregation_type == "cohort_indexed":
  sql_expr = "{metric_column} / NULLIF({baseline_value}, 0) * 100"

-- Determine metric column from scope and feature_set
metric_column = find column in feature_set.features_applied matching scope_artifact.metric.name
IF metric_column not found:
  Search feature_set.data_ref column list for closest match
  IF still not found: HALT: "Metric column '{scope_artifact.metric.name}' not found in
  feature_set. Verify scope metric maps to an available column."

-- Determine period from scope_artifact.timeframe
period = "{scope_artifact.timeframe.start} to {scope_artifact.timeframe.end}"

Log: "Metric plan built | name={metric_plan.name} | agg={aggregation_type} | grain={grain} | ci={ci_method}"
```

**Checkpoint:**
> - [ ] PASS: metric_plan populated with sql_expr, ci_method, and metric_column identified
> - [ ] HALT: metric column not found in feature_set
> - [ ] WARN: aggregation_type defaulted to "mean" (scope metric.aggregation not mappable)

---

### Step 2 — Execute Metric SQL

**Goal:** Run the aggregation SQL against the FEATURES_ data_ref and retrieve the raw metric value
and observation count.

**Pre-step assertion:** metric_plan is ready; feature_set.data_ref is accessible.

**Branch on `analytical_pattern`:**

**IF `profile` (single population):**
```
data_ref = feature_set.data_ref  -- string

IF grain == "customer":
  group_by = ""  -- aggregate across all customers
ELIF grain == "transaction":
  group_by = ""  -- aggregate across all transactions
ELIF grain == "period":
  group_by = "GROUP BY {period_bucket_expression}"

Execute:
  SELECT {sql_expr} AS metric_value,
         COUNT(*) AS n_observations
  FROM {data_ref}
  {group_by}

Store: raw_value = result.metric_value, n_obs = result.n_observations
population_label = "target"

Log: "Metric computed | value={raw_value} | n={n_obs} | population=target"
```

**IF `compare` (two populations):**
```
base_ref = feature_set.data_ref["base"]
comp_ref = feature_set.data_ref["comparison"]

-- Execute identical SQL against both
FOR each (ref, label) IN [(base_ref, "target"), (comp_ref, "reference")]:
  Execute:
    SELECT {sql_expr} AS metric_value,
           COUNT(*) AS n_observations
    FROM {ref}
    {group_by}
  Store: results[label] = {value: metric_value, n_obs: n_observations}

IF results["reference"].n_obs == 0:
  HALT: "Reference population is empty — cannot compute compare metrics.
  Verify cohort-extraction produced a reference population."

Log: "Compare metrics computed | target={results.target.value} | reference={results.reference.value}"
```

**Weighted mean null-weight check (when aggregation_type == "weighted_mean"):**
```
IF aggregation_type == "weighted_mean":
  Execute: SELECT COUNT(*) AS total_rows,
                  SUM(CASE WHEN {weight_column} IS NULL THEN 1 ELSE 0 END) AS null_weight_rows
           FROM {data_ref}
  null_pct = null_weight_rows / total_rows
  IF null_pct > 0.50:
    HALT: "Weight column >50% NULL ({null_pct*100}%) — weighted mean unreliable."
  ELIF null_pct > 0:
    WARN: "Weight column contains {null_pct*100}% nulls — weighted mean excludes null-weight rows."
    computation_warnings.append(warning)
```

**Checkpoint:**
> - [ ] PASS: metric value(s) computed; n_observations > 0
> - [ ] HALT: SQL error (temp table expired, connection dropped) → "FEATURES_ table {data_ref} not found. Re-run feature-engineering."
> - [ ] HALT: reference population empty in compare pattern
> - [ ] HALT: weighted mean weight column >50% NULL
> - [ ] WARN: n_observations < 30 → "Small sample size ({n_obs}). Confidence intervals may be unreliable."

---

### Step 3 — Compute Confidence Intervals

**Goal:** Apply the selected CI method to produce 95% confidence intervals for each metric value.

**Pre-step assertion:** raw metric value(s) and n_observations available from Step 2.

**Actions:**
```
FOR each (value, n_obs, pop_label) in computed metrics:

  IF ci_method == "wilson":
    -- Wilson score interval for proportions
    assert 0.0 <= value <= 1.0
      IF not: HALT: "Proportion value {value} outside [0,1]. Aggregation logic error —
      verify SQL expression produces a valid proportion."
    z = 1.96  -- 95% CI
    denominator = 1 + z^2 / n_obs
    centre = (value + z^2 / (2 * n_obs)) / denominator
    margin = z * sqrt((value * (1 - value) + z^2 / (4 * n_obs)) / n_obs) / denominator
    ci_lower = max(0, centre - margin)
    ci_upper = min(1, centre + margin)

  ELIF ci_method == "normal_approx":
    -- Normal approximation z-interval
    se = std_dev / sqrt(n_obs)  -- requires std_dev from SQL: STDDEV({metric_column})
    ci_lower = value - 1.96 * se
    ci_upper = value + 1.96 * se

  ELIF ci_method == "bootstrap":
    -- Bootstrap resampling (1000 iterations)
    IF n_obs < 5:
      WARN: "n_observations={n_obs} too small for reliable bootstrap. Using normal_approx fallback."
      ci_method_used = "normal_approx"
      -- fall through to normal_approx calculation
    ELSE:
      bootstrap_values = []
      FOR i in 1..1000:
        resample = draw n_obs values with replacement from data
        bootstrap_values.append(aggregation(resample))
      ci_lower = percentile(bootstrap_values, 2.5)
      ci_upper = percentile(bootstrap_values, 97.5)
      IF ci_lower == ci_upper:
        WARN: "Bootstrap produced zero-width CI — all resamples identical. Possible zero-variance metric."

  -- Handle zero-variance case
  IF ci_lower == value AND ci_upper == value AND n_obs > 1:
    WARN: "Zero-variance metric — all observations have identical value {value}. CI is [{value}, {value}]."
    computation_warnings.append("zero_variance: metric '{metric_plan.name}' has no variation")

  Store: ci_95 = [ci_lower, ci_upper], ci_method_used

Log: "CI computed | method={ci_method_used} | CI=[{ci_lower}, {ci_upper}]"
```

**Checkpoint:**
> - [ ] PASS: CI computed for all metric values; CI bounds are finite numbers
> - [ ] HALT: proportion outside [0,1]
> - [ ] WARN: n < 30 (CI unreliable); zero-variance metric; bootstrap fallback

---

### Step 4 — Validate and Write Terminal Artifact

**Goal:** Assemble and persist metric_result.json with full metric entries and computation warnings.

**Pre-step assertion:** All metric values and CIs computed; computation_warnings collected.

**Actions:**
```
Generate artifact_id: UUID v4

metrics_array = []
FOR each computed metric (value, ci, n_obs, pop_label, ci_method_used):
  metrics_array.append({
    name: metric_plan.name,
    definition: metric_plan.definition,
    aggregation_type: metric_plan.aggregation_type,
    grain: metric_plan.grain,
    value: value,
    confidence_interval_95: ci,
    ci_method: ci_method_used,
    population: pop_label,
    period: period,
    n_observations: n_obs
  })

record_count = sum of n_observations across all metric entries

Write metric_result.json:
{
  schema_version: "1.0",
  skill_name: "metric-computation",
  timestamp: now_utc_iso8601(),
  record_count: record_count,
  artifact_id: artifact_id,
  metrics: metrics_array,
  computation_warnings: computation_warnings
}

Log: "metric_result.json written | metrics={len(metrics_array)} | warnings={len(computation_warnings)}"
```

**Checkpoint:**
> - [ ] PASS: metric_result.json written; all 5 universal envelope fields present; metrics array non-empty

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "metric-computation",
  "timestamp": "2026-04-10T14:30:00Z",
  "record_count": 6148,
  "artifact_id": "{uuid}",
  "metrics": [
    {
      "name": "repeat_purchase_rate",
      "definition": "Proportion of customers with >=2 purchases in observation window",
      "aggregation_type": "proportion",
      "grain": "customer",
      "value": 0.342,
      "confidence_interval_95": [0.329, 0.355],
      "ci_method": "wilson",
      "population": "target",
      "period": "2025-01-01 to 2025-12-31",
      "n_observations": 6148
    }
  ],
  "computation_warnings": []
}
```

**Write to:** `metric_result.json` in the project directory.

**Compare pattern example (two entries):**
```json
"metrics": [
  {
    "name": "repeat_purchase_rate",
    "aggregation_type": "proportion",
    "value": 0.342,
    "confidence_interval_95": [0.329, 0.355],
    "ci_method": "wilson",
    "population": "target",
    "n_observations": 6148
  },
  {
    "name": "repeat_purchase_rate",
    "aggregation_type": "proportion",
    "value": 0.287,
    "confidence_interval_95": [0.271, 0.303],
    "ci_method": "wilson",
    "population": "reference",
    "n_observations": 4832
  }
]
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source (record_count == 0) | feature_set.record_count == 0 OR population_size == 0 | HALT Step 0: "Cannot compute metrics on empty population — re-run cohort-extraction." |
| Single record | n_observations == 1 | WARN: "Single observation — CI is degenerate. Metric value reported without meaningful CI." |
| All-null metric column | metric_value IS NULL after aggregation | HALT: "Metric column '{name}' is entirely NULL. Verify feature-engineering produced valid values." |
| Schema mismatch | any schema_version != "1.0" | HALT Step 0 with exact artifact name and mismatch detail |
| Zero-variance metric | all values identical; CI = [v, v] | WARN: "Zero-variance metric — all {n} observations have value {v}. No statistical variation to measure." |
| Proportion outside [0,1] | wilson CI input validation | HALT Step 3: "Proportion value {v} outside [0,1]. SQL aggregation logic error." |
| n_observations < 30 | n_obs < 30 after aggregation | WARN: "Small sample (n={n_obs}). CI may be unreliable. Consider whether population-sampling produced sufficient sample." |
| Bootstrap fails to converge | all 1000 resamples return same value | WARN + fallback to normal_approx with reduced confidence note |
| Compare pattern — empty reference | reference n_observations == 0 | HALT Step 2: "Reference population is empty — cannot compute compare metrics." |
| Weighted mean — null weights | weight column contains NULLs | HALT if >50% null; WARN if ≤50% with "weights contain {pct}% nulls — weighted mean excludes null-weight rows" |
| Rolling mean — insufficient periods | fewer periods than window size | WARN: "Rolling window ({window}) exceeds available periods ({n}). Reducing window to {n}." |
| FEATURES_ table expired | SQL error on query | HALT Step 2: "FEATURES_ table not found — re-run feature-engineering." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `metric_result.json` exists with all 5 universal envelope fields
- [ ] Every metric entry has non-null `value`, `confidence_interval_95`, `ci_method`, `population`, and `n_observations`
- [ ] For compare pattern: both `target` and `reference` population entries exist for each metric
- [ ] `computation_warnings` array is populated (may be empty) — no silent issues
- [ ] `period` field matches scope_artifact.timeframe range
- [ ] `aggregation_type` and `ci_method` are consistent (wilson only with proportion)

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] `metric_result.json` written and validates against terminal artifact spec
- [ ] Every metric has a finite numeric `value` (not NaN, not Infinity)
- [ ] CI bounds are ordered: `confidence_interval_95[0] <= value <= confidence_interval_95[1]`
- [ ] CI method matches aggregation type (wilson ↔ proportion; bootstrap or normal_approx ↔ others)
- [ ] For compare pattern: target and reference metrics computed with identical aggregation
- [ ] `n_observations` matches actual row count from SQL query
- [ ] Downstream `statistical-comparison` Step 0 can load and validate `metric_result.json`
- [ ] No computation_warnings of severity "blocking" remain unaddressed

---

## Scope Boundary

This skill does NOT:
- Compare metrics between target and reference populations statistically → handled by `statistical-comparison`
- Explore distributions or surface hypotheses → handled by `exploratory-analysis`
- Engineer or derive feature columns → handled by `feature-engineering`
- Estimate causal impact of behaviors on outcomes → handled by `behavioral-impact-estimation`
- Monetize metric differences into ROI → handled by `roi-computation`
- Assess data quality or remediate issues → handled by `data-quality-assessment` and `data-remediation`

---

## Downstream

Run after this skill completes:
1. **`statistical-comparison`** — reads `metric_result.metrics` to compare target vs reference values; relies on `population` labels and `n_observations` for test selection
2. **`exploratory-analysis`** — reads `metric_result.metrics` alongside feature_set to explore distributions around the computed metric values
3. **`behavioral-impact-estimation`** — reads `metric_result.metrics` to establish outcome baseline for behavioral impact sizing
4. **`roi-computation`** — reads `metric_result.metrics` to monetize metric differences into revenue impact estimates
