# Test Case Taxonomy — Deriving Tests from a SKILL.md

Every section of a well-formed DSE SKILL.md maps to a category of test cases. This reference
shows you what to extract from each section and what kind of test it produces.

---

## From `## Preconditions`

Each precondition bullet becomes **one Category C test** (precondition violation).

```markdown
## Preconditions
- [ ] scope_artifact.json exists in project directory
- [ ] schema_version == "1.0"
- [ ] partial_scope.population is not null
```

→ Generates 3 tests:
| Test | Fixture modification | Expected outcome |
|------|---------------------|-----------------|
| C-1: missing-artifact | Don't provide the file at all | HALT in Step 0 |
| C-2: wrong-schema-version | Set `"schema_version": "0.9"` | HALT in Step 0 |
| C-3: null-population | Set `"population": null` | HALT in Step 0 |

**How to write the HALT fixture:** Take the happy-path fixture and change exactly one field
to violate exactly one precondition. Everything else should be valid. This isolates the
precondition being tested.

**Critical check:** If any Category C test does NOT produce a HALT, it means the precondition
check is missing from Step 0 — a direct violation of BLUEPRINT.md Principle 2 and 6.

---

## From `## Variance Surface`

Each dimension value becomes **one Category B test** (variance coverage).

```markdown
| Dimension     | Values              | How behavior differs              |
|---------------|---------------------|-----------------------------------|
| pattern_type  | profile / compare   | compare: requires ComparisonDef   |
| confidence    | ≥0.8 / 0.3–0.7 / <0.3 | <0.3: HALT                     |
```

→ Generates 5 tests:
| Test | Fixture | Expected outcome |
|------|---------|-----------------|
| B-1: pattern-profile | Input with `analytical_pattern: "profile"` | Workflow takes profile path |
| B-2: pattern-compare | Input with `analytical_pattern: "compare"` + ComparisonDef | Workflow takes compare path |
| B-3: confidence-high | `confidence: 0.9` | Normal proceed |
| B-4: confidence-medium | `confidence: 0.6` | Proceed with uncertainty flag |
| B-5: confidence-low | `confidence: 0.2` | HALT: "Cannot classify..." |

**One test per dimension value**, not just one per dimension. If a dimension has 3 declared
values, generate 3 tests.

**What to observe:** For each B test, confirm that the workflow actually takes a different
code path. If the behavior is identical across dimension values, either the variance table
is wrong or the workflow steps aren't actually branching.

---

## From `## Edge Cases`

Each row becomes **one Category D test** (edge case).

```markdown
| Edge Case          | Detection               | Action                          |
|--------------------|------------------------|---------------------------------|
| Empty input        | record count == 0      | HALT: "Input is empty..."       |
| Single record      | count == 1             | WARN: statistical steps skipped |
| Schema mismatch    | schema_version != "1.0" | WARN: proceed with reduced trust |
```

→ Generates 3 tests:
| Test | Fixture | Expected outcome |
|------|---------|-----------------|
| D-1: empty-input | Artifact with `record_count: 0` | HALT fires |
| D-2: single-record | Artifact with `record_count: 1` | WARN logged, execution continues |
| D-3: schema-mismatch | Artifact with `"schema_version": "0.8"` | WARN logged, execution continues |

**Action → Outcome mapping:**
- HALT → test passes if skill halts with that message
- WARN + continue → test passes if skill logs warning but continues and produces artifact
- PROCEED → test passes if skill produces a valid artifact without warning

---

## From `## Terminal Artifact`

The terminal artifact spec drives **one structural validation test** per happy-path run.

```markdown
## Terminal Artifact
Required fields:
{
  "schema_version": "1.0",
  "skill_name": "completeness-validation",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": N,
  "artifact_id": "{uuid}",
  "is_complete": true/false,
  "missing_fields": [...],
  "warnings": [...]
}
```

After each Category A or B test that completes successfully (no HALT), validate:
- [ ] All 5 universal envelope fields present with correct types
- [ ] All declared DSE-specific fields present
- [ ] `schema_version` is exactly `"1.0"` (not `1.0` float, not `"1"`)
- [ ] `timestamp` is valid ISO-8601 UTC format
- [ ] `artifact_id` looks like a UUID (not empty, not a generic string)
- [ ] `record_count` is an integer ≥ 0

**If any field is missing or wrong type:** That's a checklist item 7 failure (terminal artifact
missing universal envelope fields) — a pre-merge blocker.

---

## From `## Postconditions`

Each postcondition becomes an **assertion** on completed (non-HALT) tests.

```markdown
## Postconditions
- [ ] Terminal artifact exists in project directory
- [ ] Terminal artifact is valid JSON with all 5 envelope fields
- [ ] is_complete field accurately reflects whether all required fields are populated
```

These are checked after every successful run. They tell you whether the skill's promises
were actually kept, not just whether it ran without crashing.

---

## From `## Quality Bar`

Use the Quality Bar to define the overall pass criteria for the full test suite:

```markdown
## Quality Bar
- [ ] All checkpoints passed or documented as WARN
- [ ] Terminal artifact exists and validates against schema
- [ ] Pattern-specific required fields are present when pattern is identified
- [ ] Confidence score is within 0–1 range
```

A skill's Quality Bar is considered met when all these items are confirmed across the
test suite — not just on the happy path.

---

## Test Case Naming Convention

Use descriptive names that communicate what's being tested:
- `happy-path-nominal` — not "test-1"
- `variance-pattern-compare` — not "test-variant-B"
- `precond-null-population` — not "bad-input"
- `edge-empty-input` — not "edge-test"

Good names make the assessment report readable without having to dig into each test's details.

---

## Minimum Test Suite Size

| Skill complexity | Minimum test cases |
|---|---|
| Simple (1–2 variance dimensions, 3 edge cases) | 8–10 tests |
| Medium (2–3 variance dimensions, 4–5 edge cases) | 12–16 tests |
| Complex (3+ variance dimensions, 6+ edge cases) | 18–24 tests |

Don't generate more tests than you can walk through — if the suite is very large, prioritize:
1. All Category C tests (precondition violations) — these are blocking failures
2. At least one value per variance dimension
3. All HALT-action edge cases
4. Happy-path at minimum
5. WARN-action edge cases (lower priority)
