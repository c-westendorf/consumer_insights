# Assessment Report Template

Write the final assessment to `tests/assessment-report.md` alongside the skill being tested.
Fill in every section. Use this template verbatim — consistent formatting makes it easy for
the team to compare reports across skills and over time.

---

```markdown
# Skill Test Assessment Report
**Skill:** `{verb-noun-identifier}`
**Tested by:** dse-skill-tester
**Date:** {YYYY-MM-DD}
**Skill path:** `{absolute or relative path to SKILL.md}`

---

## Test Summary

| Category          | Tests Run | ✅ Pass | ⚠️ Warn | ❌ Fail | 🚫 Critical |
|-------------------|-----------|---------|---------|---------|-------------|
| A — Happy Path    | N         | N       | N       | N       | N           |
| B — Variance      | N         | N       | N       | N       | N           |
| C — Precondition  | N         | N       | N       | N       | N           |
| D — Edge Cases    | N         | N       | N       | N       | N           |
| **Total**         | **N**     | **N**   | **N**   | **N**   | **N**       |

---

## Per-Test Results

| # | Name                          | Category | Outcome     | Step      | Notes                                       |
|---|-------------------------------|----------|-------------|-----------|---------------------------------------------|
| 1 | happy-path-nominal            | A        | ✅ Pass      | —         | All 5 envelope fields present; artifact valid |
| 2 | variance-pattern-profile      | B        | ✅ Pass      | —         | Profile path taken; no ComparisonDef required |
| 3 | variance-pattern-compare      | B        | ❌ Fail      | Step 2    | Compare path taken but ComparisonDef not validated |
| 4 | precond-missing-artifact      | C        | ✅ Pass      | Step 0    | HALT fired correctly: "Upstream validation failed..." |
| 5 | precond-wrong-schema          | C        | 🚫 Critical | Step 0    | Skill continued without halting on schema_version mismatch |
| 6 | edge-empty-input              | D        | ✅ Pass      | Step 0    | HALT: "Input is empty. Skill cannot proceed." |
| 7 | edge-single-record            | D        | ⚠️ Warn     | Step 1    | WARN logged but execution continued correctly |

---

## Terminal Artifact Validation

Checked on all Category A and B tests that completed without HALT:

| Test | schema_version | skill_name | timestamp | record_count | artifact_id | DSE fields |
|------|---------------|------------|-----------|--------------|-------------|------------|
| Test 1 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ✅ all present |
| Test 2 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ⚠️ missing `pattern_type` field |

---

## Coverage Assessment

### Variance Dimensions Covered

| Dimension      | Declared Values       | Tested   | Result          |
|----------------|-----------------------|----------|-----------------|
| pattern_type   | profile / compare     | ✅ Both  | Both paths confirmed |
| confidence     | ≥0.8 / 0.3–0.7 / <0.3 | ⚠️ Partial | Only ≥0.8 tested; <0.3 HALT path needs real data |
| scope_complete | true / false          | ✅ Both  | Both paths confirmed |

### Precondition Coverage

| Precondition                              | Tested | HALT Fires? | HALT Message Correct? |
|-------------------------------------------|--------|-------------|-----------------------|
| artifact file exists                      | ✅ Yes  | ✅ Yes       | ✅ Yes                |
| schema_version == "1.0"                   | ✅ Yes  | 🚫 No        | 🚫 N/A — skill continued |
| population field is not null              | ✅ Yes  | ✅ Yes       | ✅ Yes                |

### Edge Case Coverage

| Edge Case                | Tested | Outcome Correct? |
|--------------------------|--------|-----------------|
| Empty input (count == 0) | ✅ Yes  | ✅ HALT fired    |
| Single record (count == 1)| ✅ Yes  | ✅ WARN + continue |
| Schema mismatch          | ✅ Yes  | 🚫 Should WARN, skill did nothing |
| All-null dimension       | ❌ No   | Not tested — needs specific fixture |

---

## Blueprint Compliance

| Principle | Status | Evidence |
|-----------|--------|---------|
| 1. Single Job-to-be-Done | CONFIRMED | Skill does one transformation; Scope Boundary is clear |
| 2. Precondition/Postcondition Contracts | VIOLATED | schema_version precondition check missing from Step 0 |
| 3. Explicit Variance Surface | CONFIRMED | Table complete; variance tested |
| 4. Artifact at Every State Change | CONFIRMED | Terminal artifact produced on all non-HALT runs |
| 5. Stateful Operations Scoped | CONFIRMED | No fitting/training operations in this skill |
| 6. Quality Bar Over Completeness | VIOLATED | Silent continuation on schema_version mismatch — Principle 6 violation |
| 7. Canonical Reference Library | UNCONFIRMED | Could not verify — requires inspecting _shared-references/ |
| 8. Self-Contained Portability | CONFIRMED | Skill ran with only its own references/ directory |

---

## Pre-Merge Readiness Verdict

**{Choose one: READY TO MERGE / CONDITIONAL / NOT READY}**

**Summary:** {1–3 sentences explaining the verdict.}

---

## Required Fixes (if NOT READY or CONDITIONAL)

### Fix 1: {Short descriptive name} — 🚫 BLOCKS MERGE
**Failing test(s):** Test 5 (precond-wrong-schema)
**Blueprint principle violated:** Principle 2 (Precondition Contracts), Principle 6 (Quality Bar)
**What happened:** Skill received `schema_version: "0.9"` in Step 0 upstream validation but
did not halt. Execution continued and produced a terminal artifact from invalid input.

**Fix needed — replace the schema assertion block in Step 0 with:**
```
assert schema_version == "1.0"
IF schema_version != "1.0":
  HALT: "Upstream validation failed: schema_version is '{actual}', expected '1.0'. Artifact may be from an incompatible skill version. Investigate before proceeding."
```

### Fix 2: {Short descriptive name} — ⚠️ RECOMMENDED BEFORE MERGE
**Failing test(s):** Test 3 (variance-pattern-compare), Test 7 (terminal artifact missing field)
**What happened:** When analytical_pattern is "compare", the skill does not verify that
ComparisonDef is present before proceeding to Step 2. An empty comparison produces a malformed
artifact.

**Fix needed — add to Step 0 variance classification:**
```
IF pattern_type == "compare":
  assert partial_scope.comparison is not null
  IF null:
    HALT: "Compare pattern requires a ComparisonDef. Run scope-extraction again with comparison context."
```

---

## Tests Still Needed (pre-merge responsibility)

These tests require real data or a running environment and could not be run synthetically:
- confidence range 0.3–0.7 with real classified business questions
- Pipeline regression: insert skill at declared position and run end-to-end
- Downstream validation: confirm next skill's Step 0 can load the terminal artifact

---

## Assessor Notes

{Any observations about the skill design, surprising behaviors, or recommendations that
don't fit neatly into the above categories.}
```

---

## Verdict Criteria

**READY TO MERGE:**
- Zero 🚫 Critical failures
- Zero ❌ Fail on Category C tests (all precondition violations HALT correctly)
- All 5 universal terminal artifact fields present on all successful runs
- At least one value per variance dimension tested and passing

**CONDITIONAL:**
- One or more ⚠️ WARN items documented, but no critical failures
- Some variance dimensions not tested (needs pre-merge real-data testing)
- Minor terminal artifact field issues documented

**NOT READY:**
- Any 🚫 Critical failure (precondition violation did not HALT)
- Missing 5 universal envelope fields in terminal artifact
- Any BLUEPRINT.md Principle 2 or Principle 6 violations confirmed
- Skill behavior on a declared variance dimension value could not be observed or was wrong
