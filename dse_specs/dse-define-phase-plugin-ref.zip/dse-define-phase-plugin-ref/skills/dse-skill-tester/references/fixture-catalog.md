# Fixture Catalog — Synthetic DSE Data Types

Use these templates to generate test fixtures for any DSE skill. Each template represents
a valid instance of that data type. For violation fixtures, take the valid template and
deliberately break exactly one field.

---

## How to Use This Catalog

1. Find the skill's `inputs` type in the frontmatter
2. Copy the matching template below
3. Adjust field values to match the test scenario (don't change structure)
4. For precondition violations: change exactly one field to break exactly one assertion
5. For variance tests: change the field that drives the variance dimension

---

## Raw Input Types

### `raw_question`
```json
{
  "text": "Are reactivated customers who engaged with our ExtraCare rewards program in Q1 2025 sticking around or churning again within 90 days?",
  "source": "stakeholder_request",
  "submitted_at": "2026-04-09T09:00:00Z"
}
```

### `conversation_context`
```json
{
  "turns": [
    {
      "role": "user",
      "content": "Are reactivated customers sticking around or churning again?",
      "timestamp": "2026-04-09T09:00:00Z"
    },
    {
      "role": "assistant",
      "content": "I'll classify this as a reactivated lifecycle stage with a compare/profile analytical pattern.",
      "timestamp": "2026-04-09T09:00:05Z"
    }
  ],
  "attempt_count": 1,
  "max_attempts": 10
}
```

### `session_metadata`
```json
{
  "session_id": "test-session-001",
  "status": "disambiguating",
  "started_at": "2026-04-09T09:00:00Z",
  "attempt_count": 2
}
```

---

## Scope Agent Types

### `intent_classification`
```json
{
  "schema_version": "1.0",
  "skill_name": "intent-classification",
  "timestamp": "2026-04-09T09:01:00Z",
  "record_count": 1,
  "artifact_id": "ic-test-fixture-001",
  "lifecycle_stage": "reactivated",
  "analytical_pattern": "compare",
  "confidence": 0.85,
  "ambiguities": [],
  "candidate_stages": ["reactivated"],
  "pattern_reasoning": "Question uses comparison language ('sticking around or churning again')"
}
```

**Variation — low confidence (for variance test):**
```json
{
  "schema_version": "1.0",
  "skill_name": "intent-classification",
  "timestamp": "2026-04-09T09:01:00Z",
  "record_count": 1,
  "artifact_id": "ic-test-fixture-002",
  "lifecycle_stage": null,
  "analytical_pattern": null,
  "confidence": 0.2,
  "ambiguities": ["Could be reactivated or at_risk stage", "unclear timeframe reference"],
  "candidate_stages": ["reactivated", "at_risk", "lapsed"]
}
```

**Variation — profile pattern (for variance test):**
```json
{
  "schema_version": "1.0",
  "skill_name": "intent-classification",
  "timestamp": "2026-04-09T09:01:00Z",
  "record_count": 1,
  "artifact_id": "ic-test-fixture-003",
  "lifecycle_stage": "low_engaged",
  "analytical_pattern": "profile",
  "confidence": 0.88,
  "ambiguities": [],
  "candidate_stages": ["low_engaged"]
}
```

### `partial_scope`
```json
{
  "schema_version": "1.0",
  "skill_name": "scope-extraction",
  "timestamp": "2026-04-09T09:02:00Z",
  "record_count": 1,
  "artifact_id": "ps-test-fixture-001",
  "population": {
    "description": "Reactivated customers who lapsed > 90 days then made a purchase",
    "criteria": [
      {"field": "customer_lifecycle_stage", "operator": "==", "value": "reactivated"},
      {"field": "lapse_days_before_reactivation", "operator": ">", "value": 90}
    ]
  },
  "metric": {
    "name": "repeat_purchase_rate",
    "definition": "Proportion of reactivated customers who make a second purchase within 90 days",
    "aggregation": "proportion"
  },
  "timeframe": {
    "start": "2025-01-01",
    "end": "2025-12-31",
    "granularity": "monthly",
    "reference": "reactivation_date"
  },
  "comparison": null,
  "business_context": "Inform Q2 retention campaign targeting decisions",
  "constraints": []
}
```

**Variation — incomplete scope (missing metric, for completeness-validation test):**
```json
{
  "schema_version": "1.0",
  "skill_name": "scope-extraction",
  "timestamp": "2026-04-09T09:02:00Z",
  "record_count": 1,
  "artifact_id": "ps-test-fixture-002",
  "population": {
    "description": "Reactivated customers",
    "criteria": []
  },
  "metric": null,
  "timeframe": null,
  "comparison": null,
  "business_context": null,
  "constraints": []
}
```

### `completeness_assessment`
```json
{
  "schema_version": "1.0",
  "skill_name": "completeness-validation",
  "timestamp": "2026-04-09T09:03:00Z",
  "record_count": 1,
  "artifact_id": "ca-test-fixture-001",
  "is_complete": false,
  "missing_fields": [
    {
      "field": "metric",
      "importance": "required",
      "pattern": "compare",
      "reason": "Compare pattern requires a defined metric to measure the comparison against",
      "suggested_question": "What metric should we use to measure whether customers are sticking? (e.g., repeat purchase rate, revenue, visit frequency)"
    }
  ],
  "warnings": [
    {
      "type": "broad_timeframe",
      "message": "12-month window is broad — consider whether this should be indexed to reactivation date"
    }
  ],
  "disambiguation_questions": [
    "What metric should we use to measure whether customers are sticking?"
  ]
}
```

### `scope_artifact`
```json
{
  "schema_version": "1.0",
  "skill_name": "scope-formatting",
  "timestamp": "2026-04-09T09:05:00Z",
  "record_count": 1,
  "artifact_id": "sa-test-fixture-001",
  "approved_at": "2026-04-09T09:05:30Z",
  "approved_by": "user",
  "lifecycle_stage": "reactivated",
  "analytical_pattern": "compare",
  "confidence": 0.85,
  "population": {
    "description": "Reactivated customers who lapsed > 90 days then made a purchase",
    "criteria": [
      {"field": "customer_lifecycle_stage", "operator": "==", "value": "reactivated"}
    ]
  },
  "metric": {
    "name": "repeat_purchase_rate",
    "definition": "Proportion making second purchase within 90 days of reactivation",
    "aggregation": "proportion"
  },
  "timeframe": {
    "start": "2025-01-01",
    "end": "2025-12-31",
    "granularity": "monthly",
    "reference": "reactivation_date"
  },
  "comparison": {
    "type": "temporal",
    "reference": "same_cohort_prior_year",
    "baseline_period": {"start": "2024-01-01", "end": "2024-12-31"}
  },
  "business_context": "Inform Q2 retention campaign targeting decisions",
  "constraints": [],
  "human_readable_summary": "We will analyze reactivated customers by measuring repeat purchase rate (proportion making a second purchase within 90 days) over 2025, compared against the same cohort in 2024, to inform Q2 retention campaign targeting."
}
```

---

## Plan Agent Types

### `task_node_list`
```json
{
  "schema_version": "1.0",
  "skill_name": "task-decomposition",
  "timestamp": "2026-04-09T09:10:00Z",
  "record_count": 5,
  "artifact_id": "tn-test-fixture-001",
  "task_nodes": [
    {
      "task_id": "TN-001",
      "task_type": "data_extraction",
      "description": "Extract reactivated customer cohort from transaction data",
      "skill_ref": "data-extraction",
      "input_requirements": ["raw transaction data", "customer lifecycle flags"],
      "estimated_complexity": "medium",
      "requires_human_review": false
    },
    {
      "task_id": "TN-002",
      "task_type": "cohort_extraction",
      "description": "Define and extract the reactivated customer population per criteria",
      "skill_ref": "cohort-extraction",
      "input_requirements": ["raw_dataset from TN-001"],
      "estimated_complexity": "low",
      "requires_human_review": false
    }
  ],
  "skill_gaps": [],
  "novel_tasks": []
}
```

### `ordered_task_plan`
```json
{
  "schema_version": "1.0",
  "skill_name": "dependency-resolution",
  "timestamp": "2026-04-09T09:11:00Z",
  "record_count": 5,
  "artifact_id": "otp-test-fixture-001",
  "execution_order": [
    {"stage": 1, "tasks": ["TN-001"], "parallel": false},
    {"stage": 2, "tasks": ["TN-002", "TN-003"], "parallel": true},
    {"stage": 3, "tasks": ["TN-004"], "parallel": false}
  ],
  "dependencies": [
    {"from": "TN-001", "to": "TN-002", "data_type": "raw_dataset"},
    {"from": "TN-002", "to": "TN-004", "data_type": "cohort"}
  ],
  "fan_out_points": ["TN-002"],
  "join_points": ["TN-004"]
}
```

---

## Precondition Violation Fixtures

These are deliberately broken — use them only for Category C (precondition violation) tests.

### Missing required field (any type)
Take any fixture above and set a required field to `null`:
```json
{ "...all other fields...", "population": null }
```

### Wrong schema_version
```json
{ "schema_version": "0.9", "...rest of fields unchanged..." }
```

### Wrong schema_version type (float instead of string)
```json
{ "schema_version": 1.0, "...rest of fields unchanged..." }
```

### Empty record_count
```json
{ "record_count": 0, "...rest of fields unchanged..." }
```

### Missing artifact file (no fixture needed)
For tests where the upstream artifact file shouldn't exist: simply don't provide the file.
The test instruction is: "Run the skill without providing any input artifact."

### Mismatched artifact_id (for downstream validation tests)
```json
{ "artifact_id": "", "...rest of fields unchanged..." }
```

---

## Fixture Labeling Convention

Always label fixtures clearly:
```
// Fixture: test-03-variance-compare
// Type: scope_artifact
// Purpose: verify compare-pattern code path in scope-formatting
// Variance dimension: analytical_pattern = "compare"
// Changes from baseline: comparison field populated
```

This makes it immediately clear what's being tested when the colleague reviews the fixture.
