---
name: dse-skill-tester
description: >
  Read a DSE SKILL.md and generate a structured test suite — covering happy path, variance
  dimension coverage, precondition violations, and edge cases — then walk through the skill
  end-to-end with the user using synthetic fixtures, compiling a pass/fail assessment as you
  go. Use this skill whenever someone wants to verify a new or modified DSE skill works as
  designed, asks "how do I test my skill?", or has just finished the dse-skill-builder workflow
  and needs to run the skill through its paces before merging. Invoke proactively after a
  SKILL.md has been written or updated.
---

## What This Skill Does

You are a testing partner for DSE skills. Your job is to turn the contracts already written
in a SKILL.md (preconditions, variance surface, edge cases, terminal artifact spec) into a
concrete, runnable test suite — including synthetic fixtures the colleague can use even if
they don't have real project data yet — and then walk them through each test step by step,
noting failures and producing a structured assessment at the end.

The key insight: a well-written SKILL.md is already a test specification. You're not inventing
tests from scratch — you're reading what the skill already promises and verifying each promise.

**Reference files** (load as each step requires):
- `references/test-case-taxonomy.md` — how to derive test cases from each SKILL.md section
- `references/fixture-catalog.md` — synthetic JSON templates for every DSE data type
- `references/assessment-template.md` — the structured report format

---

## Workflow

### Step 0 — Locate and Parse the Target Skill

Ask the colleague: *"Which skill do you want to test? Give me the path to its directory or
SKILL.md file."*

Read the full SKILL.md. Extract and record these elements — you'll use all of them to generate
the test suite:

```
PARSED SKILL PROFILE:
  name: {skill-name}
  inputs: [{type, description}, ...]
  outputs: [{type, description}, ...]
  can_follow: [...]
  can_precede: [...]
  supports_loop: true/false

  preconditions: [list of testable assertions from ## Preconditions]
  variance_dimensions: [{dimension, values, behavior_diff}, ...]  (from ## Variance Surface)
  workflow_steps: [{step_number, name, halt_conditions, warn_conditions}, ...]
  edge_cases: [{case, detection, action}, ...]  (from ## Edge Cases)
  terminal_artifact_fields: [list of required fields from ## Terminal Artifact]
  postconditions: [list from ## Postconditions]
  quality_bar: [list from ## Quality Bar]
```

Confirm with the colleague: *"I've read the skill. Here's what I extracted — does anything
look wrong before we generate tests?"* Show them the parsed profile in a compact format.

---

### Step 1 — Generate the Test Case Inventory

Load `references/test-case-taxonomy.md` and derive tests from each parsed element.
Organize into four categories:

**Category A — Happy Path (1–2 tests)**
The skill receives well-formed inputs with all preconditions satisfied, nominal variance values,
and no edge conditions. This establishes that the baseline behavior works before stress-testing.

**Category B — Variance Coverage (1 test per variance dimension value)**
One test per declared variance dimension value from the Variance Surface table. Each test
isolates a single dimension value while keeping everything else nominal. If the skill declares
`pattern_type: profile / compare`, generate one test for profile-scope input and one for
compare-scope input.

**Category C — Precondition Violations (1 test per precondition)**
Each test deliberately violates one precondition while satisfying all others. These tests
should HALT — they are passing tests only if the skill correctly halts with the right message.
Examples:
- Missing upstream artifact
- Artifact with wrong `schema_version`
- Artifact with a required field set to null
- Artifact with mismatched record count

**Category D — Edge Cases (1 test per edge case row)**
Each row in the skill's `## Edge Cases` table becomes one test. The fixture for each
should trigger that specific edge case. Pay attention to the declared Action — some edge cases
HALT (the test passes if HALT fires), some WARN (test passes if execution continues with logged
warning), some PROCEED (test passes if normal output is produced).

Present the inventory to the colleague in a table before generating fixtures:

```
| # | Category | Name                        | Expected Outcome              |
|---|----------|-----------------------------|-------------------------------|
| 1 | A        | happy-path-nominal          | Terminal artifact produced    |
| 2 | B        | variance-profile-pattern    | Artifact produced, profile path |
| 3 | B        | variance-compare-pattern    | Artifact produced, compare path |
| 4 | C        | precond-missing-artifact    | HALT: "Upstream validation failed..." |
| 5 | C        | precond-wrong-schema        | HALT: specific message        |
| 6 | D        | edge-empty-input            | HALT: "Input is empty..."     |
| 7 | D        | edge-single-record          | WARN + continue               |
```

Ask: *"Does this look right? Any tests you want to add, remove, or adjust?"*

---

### Step 2 — Generate Synthetic Fixtures

For each test case, generate the fixture(s) needed to run it. Load
`references/fixture-catalog.md` for the canonical JSON template for each DSE data type.

A fixture is a concrete, self-contained input the skill can actually receive. Generate:
- A valid fixture for Category A and B tests (matches the skill's declared `inputs` type)
- A deliberately broken fixture for each Category C test (violates exactly one precondition)
- A targeted fixture for each Category D test (triggers the specific edge condition)

**Fixture format:** Write each fixture as a JSON block inline in the test output. Label it
clearly so the colleague knows what to provide when running the test.

```json
// Fixture for Test #1: happy-path-nominal
// Input type: scope_artifact
{
  "schema_version": "1.0",
  "skill_name": "scope-formatting",
  "timestamp": "2026-04-09T00:00:00Z",
  "record_count": 1,
  "artifact_id": "test-fixture-001",
  "population": { "description": "Reactivated low-engaged customers", "criteria": [] },
  "metric": { "name": "repeat_purchase_rate", "aggregation": "mean" },
  "timeframe": { "start": "2025-01-01", "end": "2025-12-31", "granularity": "monthly" },
  "comparison": null,
  "business_context": "Inform Q2 retention campaign targeting",
  "constraints": []
}
```

**Environment and configuration scan:** Ask the colleague:
1. *"Does your project have any of these already? (scope_artifact.json, plan_artifact.json,
   scope_session.json, or other JSON artifacts in the project root)"*
2. *"Are there any environment variables or config settings the skill reads?"*
3. *"Is there a `_shared-references/` directory available?"*

If real artifacts exist, prefer them for happy-path tests (more realistic). Use the synthetic
fixtures for violation and edge case tests where controlled breakage is needed.

Write all fixtures to a `tests/fixtures/` directory alongside the skill:
```
skills/{verb-noun}/
└── tests/
    ├── test-inventory.md          (the table from Step 1)
    └── fixtures/
        ├── test-01-happy-path.json
        ├── test-02-variance-profile.json
        ├── test-03-variance-compare.json
        ├── test-04-precond-missing-artifact.json
        ├── test-05-precond-wrong-schema.json
        └── test-06-edge-empty-input.json
```

---

### Step 3 — Walk-Through Mode

Now execute each test case interactively with the colleague. For each test:

**Before the test:** Present the fixture and say what the expected outcome is.
```
─── Test #1: happy-path-nominal ────────────────────
Input fixture: tests/fixtures/test-01-happy-path.json
Expected: skill completes Step 0–N without HALT; terminal artifact produced
with all 5 universal fields + skill-specific fields
────────────────────────────────────────────────────
```

**During the test:** Follow the skill's SKILL.md workflow step by step, using the fixture
as input. For each step:
- Execute the step's instructions as written
- Check each checkpoint assertion
- Record: ✅ PASS / ⚠️ WARN / 🚫 HALT / ❌ UNEXPECTED BEHAVIOR

Note exactly what happened vs. what the SKILL.md said should happen.

**After each test:** Record the result in the running log (see Step 4 format).

**If a test produces UNEXPECTED BEHAVIOR:** Document the discrepancy in detail:
- Which step failed
- What the SKILL.md said would happen
- What actually happened
- Whether this is a skill design issue, a fixture issue, or a genuine bug

Ask the colleague after each test: *"Ready for the next test? Or do you want to dig into
that result first?"* — respect their pace.

**For Category C tests (precondition violations):** The test PASSES only if:
- The skill correctly halts in Step 0
- The HALT message matches (or closely matches) the one declared in the skill

If the skill continues past a violated precondition without halting — that's a 🚫 CRITICAL
FAILURE of BLUEPRINT.md Principle 6 (Quality Bar Over Completeness).

---

### Step 4 — Compile the Assessment Report

After all tests are complete, generate the structured assessment report. Load
`references/assessment-template.md` for the format. The report covers:

**Test Summary:**
```
Total: N | ✅ Pass: N | ⚠️ Warn: N | ❌ Fail: N | 🚫 Critical: N
```

**Per-Test Results Table:**
```
| # | Name                     | Outcome | Step Failed | Notes                        |
|---|--------------------------|---------|-------------|------------------------------|
| 1 | happy-path-nominal       | ✅ Pass  | —           | All 5 envelope fields present |
| 4 | precond-missing-artifact | 🚫 Fail | Step 0      | HALT did not fire — skill continued |
```

**Coverage Assessment:**
- Which variance dimensions were covered ✅ and which still need real-data testing
- Which edge cases fired correctly vs. silently passed through

**Blueprint Compliance:**
For each of the 8 BLUEPRINT.md principles, note: CONFIRMED / UNCONFIRMED / VIOLATED

**Pre-Merge Readiness Verdict:**
- ✅ READY TO MERGE — all critical tests pass
- ⚠️ CONDITIONAL — minor issues noted, document before merging
- 🚫 NOT READY — critical failures that must be fixed first

For each failure, include:
1. What failed
2. Why it matters (which blueprint principle it violates)
3. The specific fix needed in the SKILL.md

Write the report to `tests/assessment-report.md` alongside the skill.

---

### Step 5 — Remediation Guidance (if needed)

If the assessment finds failures, provide actionable remediation for each one before closing.

For each ❌ or 🚫 result, write the exact change needed:
- For missing HALT: show the Step 0 block that should be added or corrected
- For wrong terminal artifact fields: show the complete corrected JSON structure
- For undertested variance: show what additional fixture would cover that dimension
- For silent continuation on violations: show the assert → HALT pattern to add

Ask: *"Would you like me to apply these fixes directly to the SKILL.md, or would you prefer
to review them first?"*

If fixes are applied, note that the affected tests should be re-run to confirm.

---

## Variance Surface

| Dimension           | Values                                    | How behavior differs                                        |
|---------------------|-------------------------------------------|-------------------------------------------------------------|
| Test mode           | Generate-only / Walk-through / Full       | Generate-only: produces fixtures + inventory but doesn't run; Full: does everything |
| Real data available | Yes / No                                  | Yes: use real artifacts for happy-path, synthetic for violations; No: pure synthetic |
| Skill complexity    | Simple (3–4 steps) / Complex (7–8 steps) | Complex: more variance dimensions, more test cases, walk-through takes longer |
| Failures found      | None / Minor / Critical                   | Critical: remediation guidance before closing; None: affirm readiness |

---

## Scope Boundary

This skill does NOT:
- Design or modify the skill being tested → that's `dse-skill-builder`'s job
- Run automated CI pipelines or bash scripts → tests are conversational walk-throughs
- Generate production data or access real CVS databases → fixtures are synthetic only
- Replace the full 17-item pre-merge checklist → this tests runtime behavior; the checklist
  also covers documentation and integration items not testable here
- Test playbooks or agent `.md` files → different structure, out of scope

## Downstream

After using this skill:
1. **Fix any failures** identified in the assessment report
2. **Re-run affected tests** after fixes (targeted re-run, not full suite)
3. **Update the SKILL.md** quality bar items that were confirmed during testing
4. **Run `claude plugin validate`** to confirm structural compliance
5. **Proceed to merge** if all critical tests pass and checklist items are ✅
