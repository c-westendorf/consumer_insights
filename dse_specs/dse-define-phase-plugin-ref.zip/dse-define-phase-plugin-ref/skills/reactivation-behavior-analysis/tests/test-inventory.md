# Test Inventory: reactivation-behavior-analysis

Generated: 2026-04-10

---

## Category A -- Happy Path

| ID | Test Name | Description | Expected Outcome |
|---|---|---|---|
| A1 | Standard reactivation analysis (time_based / 90d / correlation) | Valid cohort with 289 reactivated customers, valid feature_set and metric_result. churn_definition=time_based, reactivation_window=90d, trigger_detection=correlation. | reactivation_profile.json written with all 5 envelope fields, triggers with confidence levels, value_recovery_sustainability in {strong, moderate, weak, declining}. |
| A2 | Standard reactivation analysis (event_based / 180d / temporal_proximity) | Valid inputs. churn_definition=event_based, reactivation_window=180d, trigger_detection=temporal_proximity. | reactivation_profile.json written with triggers identified via temporal proximity, post_reactivation_behavior populated, sustainability verdict assigned. |
| A3 | Large cohort (time_based / 365d / correlation) | Cohort with 10,000 reactivated customers, 365d window, correlation-based detection. | Profile written, triggers ranked by correlation magnitude, longer window reflected in behavior metrics. |

---

## Category B -- Variance Coverage

Each variance dimension must have >= 2 distinct values tested.

### Dimension: churn_definition (2 values)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B1 | churn_definition = time_based | time_based | Reactivated customers identified by N weeks of no activity then subsequent activity. |
| B2 | churn_definition = event_based | event_based | Reactivated customers identified by specific churn event marker then subsequent activity. |

### Dimension: reactivation_window (3 values)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B3 | reactivation_window = 90d | 90d | Post-return behavior assessed over 90 days; tighter observation window. |
| B4 | reactivation_window = 180d | 180d | Post-return behavior assessed over 180 days; moderate observation window. |
| B5 | reactivation_window = 365d | 365d | Post-return behavior assessed over 365 days; broadest observation window. |

### Dimension: trigger_detection (2 values)

| ID | Test Name | Dimension Value | Expected Behavior Difference |
|---|---|---|---|
| B6 | trigger_detection = correlation | correlation | Triggers identified via feature importance / correlation with reactivation event. |
| B7 | trigger_detection = temporal_proximity | temporal_proximity | Triggers identified via event sequence analysis / proximity to return date. |

### Cross-Dimension Combinations

| ID | Test Name | Combination | Notes |
|---|---|---|---|
| B8 | Worst-case combo: event_based / 365d / temporal_proximity | All dimensions at maximum complexity | Verifies skill produces valid artifact under broadest parameter space. |
| B9 | Minimal combo: time_based / 90d / correlation | Simplest parameters | Baseline correctness check. |

---

## Category C -- Precondition Violations

Category C tests PASS only if the skill HALTs (does not proceed to produce output).

| ID | Test Name | Violated Precondition | Expected Outcome |
|---|---|---|---|
| C1 | Missing cohort.json | cohort.json does not exist | HALT: upstream validation failure. |
| C2 | cohort.json wrong schema_version | cohort.json schema_version = "2.0" | HALT: schema mismatch. |
| C3 | cohort.json has no reactivated customers | cohort.json exists but 0 reactivated customers | HALT: "No reactivated customers in cohort." (edge case overlap). |
| C4 | Missing feature_set.json | feature_set.json does not exist | HALT: upstream validation failure. |
| C5 | feature_set.json null data_ref | feature_set.json exists, schema_version = "1.0", but data_ref is null | HALT: precondition violation (non-null data_ref required). |
| C6 | feature_set.json wrong schema_version | feature_set.json schema_version = "0.9" | HALT: schema mismatch. |
| C7 | Missing metric_result.json | metric_result.json does not exist | HALT: upstream validation failure. |
| C8 | metric_result.json wrong schema_version | metric_result.json schema_version = "3.0" | HALT: schema mismatch. |
| C9 | All three upstream artifacts missing | No upstream artifacts present | HALT at Step 0. |

---

## Category D -- Edge Cases

| ID | Test Name | Edge Case | Detection | Expected Action |
|---|---|---|---|---|
| D1 | Empty source (0 reactivated) | Empty source | cohort has 0 reactivated customers | HALT: "No reactivated customers in cohort." |
| D2 | Single reactivated customer | Single reactivated customer | cohort_size == 1 | WARN: "Single reactivation -- patterns unreliable." Proceed with artifact. |
| D3 | Schema mismatch on upstream | Schema mismatch | schema_version != "1.0" on any input | HALT Step 0. |
| D4 | No triggers identifiable | No triggers identifiable | All correlations/proximities below threshold | WARN: "No clear reactivation triggers identified." reactivation_triggers_identified may be empty. |
| D5 | Zero post-return activity | Zero post-return activity | Reactivated customers have no subsequent events | WARN: "Reactivated customers show no post-return activity." Behavior metrics reflect zero activity. |
| D6 | Pre-lapse data unavailable | Pre-lapse data unavailable | No historical data before lapse | WARN: comparison_to_pre_lapse fields set to null. |

---

## Test Count Summary

| Category | Count |
|---|---|
| A: Happy Path | 3 |
| B: Variance Coverage | 9 |
| C: Precondition Violations | 9 |
| D: Edge Cases | 6 |
| **Total** | **27** |
