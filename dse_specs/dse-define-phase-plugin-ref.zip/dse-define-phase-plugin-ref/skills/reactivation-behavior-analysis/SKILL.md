---
name: reactivation-behavior-analysis
description: >
  Identifies triggers and post-reactivation behavioral patterns for customers who returned
  after lapsing, assessing value recovery sustainability, producing reactivation_profile.json.
  Activate when scope involves understanding lapsed customer return patterns; takes cohort +
  feature_set + metric_result.
inputs:
  - type: cohort
    description: "Population from cohort-extraction; must include reactivated customers (lifecycle_stage 'reactivated')"
  - type: feature_set
    description: "Feature-enriched population from feature-engineering; data_ref for behavioral analysis"
  - type: metric_result
    description: "Aggregate metrics from metric-computation; outcome values for value recovery assessment"
outputs:
  - type: reactivation_profile
    description: "Reactivation triggers, post-reactivation behavior metrics, and value recovery sustainability assessment"
can_follow: [feature-engineering, metric-computation]
can_precede: [finding-assembly, roi-computation]
supports_loop: true
exit_conditions:
  - "reactivation_profile.json written with triggers identified and value recovery assessed"
  - "triggers identified or budget exhausted (max 2 iterations)"
---

## Overview

Maturity-state-classification identifies *who is reactivated*. This skill investigates *why they came back* and *whether the return is sustainable*. By analyzing pre-return context and post-return behavior, it identifies reactivation triggers (what brought them back) and assesses whether the recovered value is durable.

**What this skill produces:** `reactivation_profile.json` with identified triggers, post-reactivation behavior metrics (repeat rate, spend, category expansion), pre-lapse comparison, and sustainability verdict.

---

## When to Activate

- Scope involves reactivation, win-back, lapsed customer analysis
- `cohort.json` or `maturity_classification.json` shows reactivated customers
- User requests "reactivation analysis" or "win-back patterns"

---

## Preconditions

- [ ] `cohort.json` exists with `schema_version == "1.0"` and includes reactivated customers
- [ ] `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
- [ ] `metric_result.json` exists with `schema_version == "1.0"`

---

## Prerequisites

### Library Dependencies
```
# Tier 2: snowflake-connector-python>=3.0
# Tier 3: scipy>=1.10; numpy>=1.24; pandas>=2.0
# Tier 4: Python>=3.10
```

### Infrastructure Requirements
| Resource | Requirement |
|---|---|
| Compute | Standard; no GPU required |
| Memory | 4 GB minimum (scales with cohort size) |
| Disk | 100 MB for intermediate artifacts |
| OS packages | None beyond Python standard library |
| Environment | Snowflake credentials via environment variables or connection config |

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `churn_definition` | `time_based` / `event_based` | `time_based`: N weeks no activity; `event_based`: specific churn event marker |
| `reactivation_window` | `90d` / `180d` / `365d` | Post-return observation window for behavior assessment |
| `trigger_detection` | `correlation` / `temporal_proximity` | `correlation`: feature importance analysis; `temporal_proximity`: event sequence analysis |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

Classify variance dimensions from scope context:
- `churn_definition`: time_based | event_based
- `reactivation_window`: 90d | 180d | 365d
- `trigger_detection`: correlation | temporal_proximity

Validate upstream artifacts sequentially; HALT on first failure:

```
load cohort.json
  IF not found: HALT: "Upstream validation failed: cohort.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: cohort.json -- schema_version mismatch."
assert cohort contains customers with lifecycle_stage == "reactivated"
  IF not: HALT: "Upstream validation failed: cohort.json -- no reactivated customers in cohort."

load feature_set.json
  IF not found: HALT: "Upstream validation failed: feature_set.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: feature_set.json -- schema_version mismatch."
assert data_ref is not null
  IF not: HALT: "Upstream validation failed: feature_set.json -- data_ref is null."

load metric_result.json
  IF not found: HALT: "Upstream validation failed: metric_result.json not found."
assert schema_version == "1.0"
  IF not: HALT: "Upstream validation failed: metric_result.json -- schema_version mismatch."
```

### Step 1 — Identify Reactivated Customers

```
-- Filter to customers who lapsed (no activity for churn_threshold) then returned
reactivated = customers WHERE:
  gap > churn_threshold_weeks AND subsequent activity exists
```

### Step 2 — Identify Reactivation Triggers

```
-- Analyze pre-return context for common patterns
IF trigger_detection == "correlation":
  FOR each feature: compute correlation with reactivation event
  rank by |correlation|; top features = triggers
ELIF trigger_detection == "temporal_proximity":
  FOR each event type: compute temporal proximity to return date
  rank by proximity; closest events = triggers
```

### Step 3 — Assess Post-Reactivation Behavior

```
Execute SQL for reactivated customers within reactivation_window:
  repeat_purchase_rate_90d = proportion with ≥2 purchases in 90d post-return
  avg_spend_90d = average spend in 90d post-return
  category_expansion_rate = proportion expanding to new categories

-- Compare to pre-lapse behavior
  spend_recovery_pct = post_avg_spend / pre_lapse_avg_spend
  frequency_recovery_pct = post_frequency / pre_lapse_frequency
```

### Step 4 — Assess Value Recovery Sustainability

```
-- When pre-lapse data is available, use recovery percentages:
IF spend_recovery_pct is not null:
  IF spend_recovery_pct >= 0.8 AND repeat_purchase_rate_90d >= 0.5: "strong"
  ELIF spend_recovery_pct >= 0.5: "moderate"
  ELIF spend_recovery_pct >= 0.3 AND trend is positive: "weak"
  ELSE: "declining"

-- When pre-lapse data is unavailable, use absolute post-reactivation thresholds:
ELIF spend_recovery_pct is null:
  WARN: "Pre-lapse data unavailable; sustainability assessed on absolute thresholds only."
  IF repeat_purchase_rate_90d >= 0.5 AND avg_spend_90d >= cohort_median_spend: "moderate"
  ELIF repeat_purchase_rate_90d >= 0.3: "weak"
  ELSE: "indeterminate"
```

Note: When pre-lapse data is unavailable, the maximum attainable verdict is `"moderate"` because recovery comparison is not possible. The value `"indeterminate"` signals that sustainability cannot be reliably assessed.

### Step 5 — Write Terminal Artifact

Write reactivation_profile.json.

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "reactivation-behavior-analysis",
  "timestamp": "2026-04-10T17:00:00Z",
  "record_count": 289,
  "artifact_id": "{uuid}",
  "churn_threshold_weeks": 52,
  "cohort_size": 289,
  "reactivation_triggers_identified": [
    {"trigger": "promotional_email_campaign", "trigger_rate": 0.42, "confidence": "high"},
    {"trigger": "seasonal_event_proximity", "trigger_rate": 0.28, "confidence": "medium"},
    {"trigger": "price_reduction_on_prior_category", "trigger_rate": 0.18, "confidence": "low"}
  ],
  "post_reactivation_behavior": {
    "repeat_purchase_rate_90d": 0.34,
    "avg_spend_90d": 127.50,
    "category_expansion_rate": 0.21,
    "comparison_to_pre_lapse": {"spend_recovery_pct": 0.67, "frequency_recovery_pct": 0.54}
  },
  "value_recovery_sustainability": "moderate"
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty source | cohort has 0 reactivated customers | HALT: "No reactivated customers in cohort." |
| Single reactivated customer | cohort_size == 1 | WARN: "Single reactivation — patterns unreliable." |
| Schema mismatch | schema_version != "1.0" | HALT Step 0 |
| No triggers identifiable | all correlations/proximities below threshold | WARN: "No clear reactivation triggers identified." |
| Zero post-return activity | reactivated customers have no subsequent events | WARN: "Reactivated customers show no post-return activity." |
| Pre-lapse data unavailable | no historical data before lapse | WARN: comparison_to_pre_lapse fields set to null; sustainability assessed on absolute thresholds (max verdict "moderate"); may yield "indeterminate" |

---

## Postconditions

- [ ] `reactivation_profile.json` exists with all 5 universal envelope fields
- [ ] `reactivation_triggers_identified` is populated (may be empty with WARN)
- [ ] `value_recovery_sustainability` is one of: strong, moderate, weak, declining, indeterminate

---

## Quality Bar

- [ ] Validates against terminal artifact spec
- [ ] Triggers have confidence levels
- [ ] Downstream `finding-assembly` and `roi-computation` can validate

---

## Scope Boundary

This skill does NOT:
- Classify lifecycle states → handled by `maturity-state-classification`
- Compute aggregate metrics → handled by `metric-computation`
- Monetize reactivation value → handled by `roi-computation`
- Detect engagement decay → handled by `engagement-decay-analysis`

---

## Downstream

1. **`finding-assembly`** — includes reactivation triggers and value recovery as findings
2. **`roi-computation`** — reads reactivation profile to estimate revenue impact of win-back efforts
