---
name: completeness-validation
description: >
  Evaluates whether a partial scope meets the minimum requirements for plan generation
  by checking pattern-specific required fields. Generates targeted disambiguation questions
  for missing or ambiguous fields. Activate after scope-extraction to determine if the scope
  is complete or needs more user input. Takes partial_scope and intent_classification;
  produces completeness_assessment with is_complete flag, missing_fields, and disambiguation_questions.
inputs:
  - type: partial_scope
    description: "Six structured scope fields from scope-extraction, some may be null"
  - type: intent_classification
    description: "Classified lifecycle stage and analytical pattern"
outputs:
  - type: completeness_assessment
    description: "Completeness verdict, missing fields list, and targeted disambiguation questions"
can_follow: [scope-extraction]
can_precede: [scope-formatting]
supports_loop: false
exit_conditions:
  - "completeness_assessment produced with is_complete flag and any missing_fields enumerated"
  - "if incomplete: at least one disambiguation_question generated for the highest-priority missing field"
---

# completeness-validation

## Overview

Scope-extraction populates what it can from the user's question. Completeness-validation
evaluates whether those fields meet the pattern-specific minimum for plan generation. Each
analytical pattern requires different fields -- a compare analysis needs a comparison
reference that a profile does not. When fields are missing, the skill generates ONE targeted
disambiguation question per invocation (not a laundry list) to guide the user toward a
complete scope. The question targets the highest-priority missing field, ranked by how
fundamentally it shapes the analysis.

---

## When to Activate

Invoke this skill when:

- `scope-extraction` has produced a `partial_scope` with at least one non-null field.
- The pipeline needs to determine whether the scope is ready for `scope-formatting` or
  whether additional user input is required.
- A disambiguation loop is in progress and the user has provided a new answer that may
  satisfy a previously missing field.

Do NOT invoke when:

- No `partial_scope` exists yet (run `scope-extraction` first).
- The user has explicitly abandoned the question or started a new one.

---

## Preconditions

| # | Condition | On Fail |
|---|-----------|---------|
| P1 | `partial_scope` artifact exists with `artifact_id` | HALT -- "No partial_scope found. Run scope-extraction first." |
| P2 | `intent_classification` artifact exists with `analytical_pattern` set | HALT -- "No intent_classification found. Run intent-classification first." |
| P3 | `analytical_pattern` is one of: `profile`, `compare`, `predict`, `explain`, `segment` | HALT -- "Unknown analytical_pattern '{value}'. Cannot evaluate completeness." |
| P4 | `attempt_count` is trackable (integer, starts at 1) | WARN -- default to 1 if missing. |

---

## Prerequisites

| Prerequisite | Required | Notes |
|---|---|---|
| `partial_scope` artifact | Yes | Produced by `scope-extraction`. Contains six structured fields. |
| `intent_classification` artifact | Yes | Produced by `intent-classification`. Must include `analytical_pattern`. |
| Disambiguation history | No | Prior questions and answers, used to avoid repeating questions. |

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `analytical_pattern` | `profile` / `compare` / `predict` / `explain` / `segment` | Each pattern has a different required-fields set (see matrix below). A field that is required for `compare` may be irrelevant for `profile`. |
| `completeness_status` | `complete` / `incomplete` | `complete`: set `is_complete=true`, skip question generation, proceed to scope-formatting. `incomplete`: generate targeted question for the highest-priority missing field. |
| `attempt_count` | `within_budget` (<=10) / `budget_exceeded` (>10) | `within_budget`: generate question normally. `budget_exceeded`: HALT with partial scope and message "Disambiguation budget exceeded. Please provide remaining details manually: {missing_fields}." |
| `field_ambiguity` | `null` / `present_but_ambiguous` | `null`: field is entirely missing, question asks user to provide it. `present_but_ambiguous`: field has a value but it is vague or conflicting, question asks user to clarify. |

---

## Workflow

### Step 0: Context Classification + Upstream Validation

Load and validate upstream artifacts before any logic executes.

```
LOAD partial_scope from upstream scope-extraction artifact
LOAD intent_classification from upstream intent-classification artifact

VALIDATE partial_scope.artifact_id exists          → on fail: HALT "Missing partial_scope"
VALIDATE intent_classification.artifact_id exists  → on fail: HALT "Missing intent_classification"
VALIDATE intent_classification.analytical_pattern
    IN [profile, compare, predict, explain, segment]
    → on fail: HALT "Unknown analytical_pattern"

# All-null guard
IF all 6 scope fields are null:
    HALT "partial_scope has all null fields. Nothing to validate."

# Schema guard
SET canonical_keys = [population, metric, timeframe, comparison, business_context, constraints]
FOR key IN canonical_keys:
    IF key not in partial_scope:
        HALT "partial_scope schema mismatch: missing key '{key}'."

SET attempt_count = session.attempt_count OR 1
IF attempt_count > 10:
    HALT "Disambiguation budget exceeded (10 turns). Missing: {missing_fields}.
          Ask user to provide remaining details in a single message."

# Pattern-change detection
IF prior completeness_assessment exists:
    SET prior_pattern = prior completeness_assessment.analytical_pattern
    SET current_pattern = intent_classification.analytical_pattern
    IF prior_pattern != current_pattern:
        WARN "Analytical pattern changed from {prior_pattern} to {current_pattern}. Re-evaluating all required fields."
```

> **CHECKPOINT -- Step 0**
> - [ ] `partial_scope` loaded with valid `artifact_id` -- PASS / HALT
> - [ ] `intent_classification` loaded with recognized `analytical_pattern` -- PASS / HALT
> - [ ] `attempt_count` within budget -- PASS / HALT

---

### Step 1: Check Required Fields

Evaluate `partial_scope` against the pattern-specific required-fields matrix.

**Required Fields Matrix:**

| Pattern | Required Fields |
|---------|----------------|
| `profile` | `population`, `metric`, `timeframe` |
| `compare` | `population`, `metric`, `timeframe`, `comparison` |
| `predict` | `population`, `metric`, `timeframe`, `prediction_horizon` |
| `explain` | `population`, `metric`, `timeframe`, `outcome_variable` |
| `segment` | `population`, `timeframe`, `segmentation_basis` |

```
SET pattern = intent_classification.analytical_pattern
SET required = REQUIRED_FIELDS_MATRIX[pattern]
SET populated = [field for field in required if partial_scope[field] is not null]
SET missing = [field for field in required if partial_scope[field] is null]
SET ambiguous = [field for field in populated if is_ambiguous(partial_scope[field])]
```

**Ambiguity detection rules:**
- `population`: ambiguous if description contains only "customers" or "users" with no qualifier.
- `metric`: ambiguous if it names a category ("engagement") but not a measurable quantity.
- `timeframe`: ambiguous if only relative ("recently", "last few months") with no anchor.
- `comparison`: ambiguous if it says "benchmark" without specifying the reference.

> **CHECKPOINT -- Step 1**
> - [ ] All required fields for the pattern have been evaluated -- PASS
> - [ ] `missing` and `ambiguous` lists are populated -- PASS
> - [ ] On error in field evaluation: HALT "Field evaluation failed for {field}."

---

### Step 2: Identify Gaps and Prioritize

For each missing or ambiguous field, assign a priority rank based on how fundamentally
it shapes the analysis. Higher priority = asked first.

**Priority ranking (1 = highest):**

| Priority | Field | Rationale |
|----------|-------|-----------|
| 1 | `population` | Cannot scope any analysis without knowing who |
| 2 | `metric` / `segmentation_basis` | Cannot measure without knowing what |
| 3 | `timeframe` | Cannot bound without knowing when |
| 4 | `comparison` / `outcome_variable` / `prediction_horizon` | Pattern-specific; needed but secondary |
| 5 | `business_context` | Informative but not blocking |

```
SET gaps = sort(missing + ambiguous, by=PRIORITY_RANKING)
SET highest_priority_gap = gaps[0] if gaps else null
```

Filter out rapid-cycling fields before generating a question:

```
FOR field IN gaps:
    IF field has been asked about >= 3 times (from disambiguation_history):
        Mark field as user_deferred. Skip generating a question for this field.
        WARN "Field '{field}' asked about 3+ times. Marking as user_deferred."

SET gaps = [g for g in gaps if g not marked user_deferred]
SET highest_priority_gap = gaps[0] if gaps else null
```

For the highest-priority gap, generate a context-aware disambiguation question:

- Reference what IS known to make the question specific.
- Never repeat a question already asked in the disambiguation history.
- Frame as a choice when possible ("Should we compare against X or Y?").

```
IF highest_priority_gap is not null:
    SET question = generate_disambiguation_question(
        field=highest_priority_gap,
        partial_scope=partial_scope,
        intent_classification=intent_classification,
        prior_questions=disambiguation_history
    )
```

> **CHECKPOINT -- Step 2**
> - [ ] Gaps sorted by priority -- PASS
> - [ ] If gaps exist: exactly ONE question generated -- PASS
> - [ ] Question does not duplicate a prior question -- PASS
> - [ ] On duplicate detection: WARN "Rephrasing question for {field}."

---

### Step 3: Check for Warnings

Flag non-blocking issues that may affect analysis quality but do not prevent completeness.

| Warning Condition | Severity | Message |
|-------------------|----------|---------|
| `timeframe` spans > 24 months | `advisory` | "Timeframe spans {N} months -- consider whether this introduces seasonality confounds." |
| `population` description suggests < 100 members | `advisory` | "Population may be too small for statistical significance." |
| `metric` uses an ambiguous aggregation term | `advisory` | "Metric '{name}' -- confirm whether this is a rate, count, or proportion." |
| `comparison` references self (same population) | `warning` | "Comparison reference appears identical to target population." |
| `timeframe` has no end date | `advisory` | "No end date specified -- defaulting to current date." |
| `business_context` is null | `advisory` | "No business context provided -- summary will lack decision framing." |

```
SET warnings = []
FOR each populated field in partial_scope:
    RUN warning_checks(field, value) → append any triggered warnings
```

> **CHECKPOINT -- Step 3**
> - [ ] All populated fields checked for warnings -- PASS
> - [ ] Warnings have `field`, `warning`, and `severity` -- PASS

---

### Step 4: Write Assessment

Assemble `completeness_assessment` with verdict, missing fields, warnings, and question.

```
SET is_complete = (len(missing) == 0 AND len(ambiguous) == 0)

SET completeness_assessment = {
    schema_version: "1.0",
    skill_name: "completeness-validation",
    timestamp: NOW_UTC_ISO8601,
    record_count: 1,
    artifact_id: NEW_UUID,
    is_complete: is_complete,
    missing_fields: [
        {
            field: gap.field,
            importance: "required",
            reason: gap.reason,
            disambiguation_question: gap.question  # null if is_complete
        }
        for gap in gaps
    ],
    warnings: warnings,
    fields_assessed: len(REQUIRED_FIELDS_MATRIX[pattern]),
    fields_populated: len(populated),
    fields_missing: len(missing) + len(ambiguous),
    attempt_count: attempt_count,
    source_partial_scope_id: partial_scope.artifact_id,
    source_intent_id: intent_classification.artifact_id
}

WRITE completeness_assessment.json
```

> **CHECKPOINT -- Step 4**
> - [ ] `is_complete` is boolean -- PASS
> - [ ] If `is_complete=false`: `missing_fields` is non-empty with at least one question -- PASS
> - [ ] If `is_complete=true`: `missing_fields` is empty -- PASS
> - [ ] All 5 envelope fields present (`schema_version`, `skill_name`, `timestamp`, `record_count`, `artifact_id`) -- PASS
> - [ ] On write failure: HALT "Failed to write completeness_assessment.json."

---

## Terminal Artifact

**File:** `completeness_assessment.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "completeness-validation",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 1,
  "artifact_id": "{uuid}",
  "is_complete": false,
  "missing_fields": [
    {
      "field": "comparison",
      "importance": "required",
      "reason": "Compare pattern requires a reference population or period",
      "disambiguation_question": "What should we compare reactivated customers against -- continuously active customers, or their own pre-lapse behavior?"
    }
  ],
  "warnings": [
    {
      "field": "timeframe",
      "warning": "Timeframe spans 18 months -- consider whether this introduces seasonality confounds",
      "severity": "advisory"
    }
  ],
  "fields_assessed": 6,
  "fields_populated": 5,
  "fields_missing": 1,
  "attempt_count": 2,
  "source_partial_scope_id": "{uuid}",
  "source_intent_id": "{uuid}"
}
```

---

## Edge Cases

| # | Edge Case | Detection | Action |
|---|-----------|-----------|--------|
| E1 | **Empty input** -- `partial_scope` has all null fields | All six fields are null | HALT -- "Scope is entirely empty. Re-run scope-extraction or ask user to restate their question." |
| E2 | **Single record** -- only one field populated | Exactly 1 of 6 fields non-null | WARN -- proceed but note "Only {field} is populated. Multiple disambiguation rounds likely needed." Generate question for highest-priority missing field. |
| E3 | **All-null dimension** -- a required field is null across all patterns | Field like `population` is null regardless of pattern | Generate question for that field at priority 1. No special handling beyond normal prioritization. |
| E4 | **Schema mismatch** -- `partial_scope` missing expected keys | `partial_scope` does not contain one of the six canonical field keys | HALT -- "partial_scope schema mismatch: missing key '{key}'. Expected keys: population, metric, timeframe, comparison, business_context, constraints." |
| E5 | **Rapid cycling** -- same field flagged missing 3+ consecutive times | Disambiguation history shows same field asked about >= 3 times | WARN -- "User may not have this information. Mark {field} as 'user_deferred' and proceed with remaining fields." Reduce priority of deferred field. |
| E6 | **Conflicting fields** -- `timeframe.end` is before `timeframe.start` | Date comparison fails | WARN -- add to `warnings` with severity `warning`: "End date precedes start date. Confirm intended timeframe." Flag `timeframe` as ambiguous. |
| E7 | **Pattern change mid-loop** -- `analytical_pattern` differs from prior attempt | Compare current vs. prior `intent_classification.analytical_pattern` | WARN -- "Analytical pattern changed from {old} to {new}. Re-evaluating required fields from scratch." Reset `missing_fields`. |
| E8 | **Budget boundary** -- `attempt_count` equals exactly 10 | `attempt_count == 10` | WARN -- "This is the final disambiguation turn. After this, remaining gaps must be provided manually." |

---

## Postconditions

| # | Condition | Enforcement |
|---|-----------|-------------|
| Q1 | `completeness_assessment.json` exists with valid `artifact_id` | File-existence check after write. |
| Q2 | `is_complete` is strictly boolean (`true` or `false`) | Type check in assessment assembly. |
| Q3 | If `is_complete=false`, `missing_fields` contains >= 1 entry with a non-empty `disambiguation_question` | Array-length and string-presence check. |
| Q4 | If `is_complete=true`, `missing_fields` is an empty array | Array-length check. |
| Q5 | `attempt_count` is incremented and persisted to session | Session-state write check. |
| Q6 | `source_partial_scope_id` and `source_intent_id` match input artifact IDs | UUID comparison. |

---

## Quality Bar

Every completeness-validation run must meet this standard:

- All required fields for the detected pattern have been evaluated (no field skipped).
- Every entry in `missing_fields` has all four sub-fields: `field`, `importance`, `reason`, `disambiguation_question`.
- Every entry in `warnings` has all three sub-fields: `field`, `warning`, `severity`.
- `is_complete` accurately reflects the gap analysis (no false positives or negatives).
- Disambiguation questions are specific to the user's context, not generic templates.
- No question is repeated verbatim from the disambiguation history.
- The `attempt_count` is accurate and the budget (<=10) is enforced.

---

## Scope Boundary

This skill evaluates completeness. It does NOT:

- Classify the question intent -- that is `intent-classification`.
- Extract structured fields from the question -- that is `scope-extraction`.
- Format the scope for approval -- that is `scope-formatting`.
- Decompose the scope into tasks -- that is `task-decomposition`.
- Modify the `partial_scope` -- it is read-only with respect to scope fields.
- Answer the user's business question -- it only asks clarifying questions.

---

## Downstream

| If outcome is... | Next skill | Rationale |
|---|---|---|
| `is_complete=true` | `scope-formatting` | Scope meets pattern-specific minimum; ready for formatting and approval. |
| `is_complete=false`, `within_budget` | Return question to user, then re-invoke `scope-extraction` with answer | User provides missing information; extraction updates `partial_scope`; re-validate. |
| `is_complete=false`, `budget_exceeded` | Surface partial scope to user | Pipeline cannot continue automated disambiguation; user must complete manually. |
