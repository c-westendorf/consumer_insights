---
name: schema-profiling
description: >
  Connects to the temp table produced by data-retrieval and catalogs the dataset's
  structural metadata: column types, nullability, cardinality distributions, primary/foreign
  key candidates, temporal grain, and join relationship candidates. Produces a profiled_schema
  artifact that downstream skills (data-quality-assessment, cohort-extraction,
  feature-engineering) rely on to make informed decisions about type handling, joins, and
  aggregation strategies. Activate immediately after data-retrieval completes — schema
  profiling is the structural foundation that all downstream skills assume is available.
inputs:
  - type: raw_dataset
    description: "Extraction artifact from data-retrieval — provides data_ref (temp table), column manifest, platform, and row_count needed to connect and profile"
  - type: plan_artifact
    description: "(Optional) Plan artifact from plan-formatting — used to classify schema_complexity as multi_table when the plan task node specifies multiple source tables. If absent, schema_complexity defaults to single_table."
outputs:
  - type: profiled_schema
    description: "Structural catalog of the extracted dataset: column types, null rates, cardinality, temporal grains, join candidates, and column role classifications"
can_follow: [data-retrieval]
can_precede: [data-quality-assessment, cohort-extraction, feature-engineering, business-context-layer]
supports_loop: false
exit_conditions:
  - "profiled_schema artifact written with column_count matching raw_dataset.column_count"
  - "every column has cardinality, null_rate, and column_role assigned"
  - "temporal_columns populated (or empty with temporal_presence=no_temporal)"
---

## Overview

Schema profiling is the structural intelligence layer between raw extraction and all
downstream analysis. Without it, downstream skills must guess at column types, can't
identify join paths, and have no basis for distinguishing identifiers from measures from
temporal anchors. The profiled_schema artifact encodes what the data IS structurally —
distinct from what `data-quality-assessment` determines about fitness and `business-context-layer`
determines about meaning.

This skill operates entirely through database catalog queries and columnar statistics —
it never pulls raw data rows into memory. On Snowflake it uses `INFORMATION_SCHEMA.COLUMNS`
and aggregate functions against the temp table; on BigQuery it uses `INFORMATION_SCHEMA.COLUMNS`
within the dataset and BigQuery's `APPROX_COUNT_DISTINCT` scalar function. The skill
classifies each column into a structural role — identifier, measure, dimension, temporal,
text, or flag — using heuristic rules about type, cardinality, and naming patterns.

---

## When to Activate

- `raw_dataset.json` exists with a populated `data_ref` pointing to an active temp table
- A plan task node with `task_type: "schema_profiling"` is the next unexecuted task
- Downstream skills (`data-quality-assessment`, `cohort-extraction`, or `feature-engineering`)
  are about to run and `profiled_schema.json` does not yet exist
- The raw_dataset was refreshed and the prior profiled_schema is stale

---

## Preconditions

What must be true before this skill begins:
- [ ] `raw_dataset.json` exists in the project directory with `schema_version == "1.0"`
- [ ] `raw_dataset.data_ref` is not null (points to an active temp table)
- [ ] `raw_dataset.row_count > 0` (empty extraction would have halted data-retrieval)
- [ ] `raw_dataset.columns` is not empty (column manifest available)
- [ ] Connection config is available matching `raw_dataset.source_platform`
- [ ] The temp table named in `data_ref` still exists in the warehouse session

Each precondition produces a HALT if violated (see Step 0).

---

## Prerequisites

### Library Dependencies
```
# Tier 1 — Domain core
# (none — profiling via catalog queries and aggregate SQL)

# Tier 2 — Domain optional
snowflake-connector-python>=3.0   # used when platform == "snowflake"
google-cloud-bigquery>=3.0        # used when platform == "bigquery"

# Tier 3 — Skill-specific
# (none — catalog queries return structured results directly)

# Tier 4 — Infrastructure
# Python version: >=3.10
```

### Infrastructure Requirements
- **Compute:** CPU-only; all profiling runs as warehouse SQL (aggregate queries)
- **Memory:** <100 MB (catalog metadata only; no row-level data pulled)
- **Disk:** ~50 KB for profiled_schema artifact JSON
- **Upstream Artifacts:** `raw_dataset.json` (fields: `data_ref`, `columns`, `row_count`,
  `source_platform`, `schema_version`)
- **Credentials:** Same SNOWFLAKE_* or GOOGLE_APPLICATION_CREDENTIALS used by data-retrieval

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `platform` | `snowflake` / `bigquery` | INFORMATION_SCHEMA catalog syntax, `APPROX_COUNT_DISTINCT` function syntax, and temp table naming conventions differ between platforms |
| `schema_complexity` | `single_table` / `multi_table` | single_table: column catalog only; multi_table: adds join relationship mapping in Step 4 (key column overlap analysis, cardinality ratio estimation) |
| `temporal_presence` | `has_temporal` / `no_temporal` | has_temporal: adds Step 3 (grain detection, gap analysis, freshness lag); no_temporal: Step 3 is skipped |
| `data_volume` | `small` (<1M rows) / `large` (≥1M rows) | small: exact cardinality via COUNT(DISTINCT); large: approximate cardinality via APPROX_COUNT_DISTINCT to avoid full-table scans |

---

## Workflow

### Step 0 — Context Classification and Upstream Validation

**Context Classification:**
```
classify platform: read raw_dataset.source_platform → "snowflake" or "bigquery"
classify schema_complexity: examine plan_artifact task node (if available)
  IF plan_artifact.json exists in project directory:
    Find the schema_profiling task node in execution_view.task_nodes
    IF task node input_requirements references multiple tables → "multi_table"
    ELSE → "single_table"
  ELSE (no plan_artifact available — standalone run):
    default to "single_table"
    WARN: "No plan_artifact provided — assuming single_table. If the extraction involved
    multi-table joins, provide plan_artifact for accurate schema_complexity classification."
classify temporal_presence: scan raw_dataset.columns for SQL types in
  [DATE, DATETIME, TIMESTAMP, TIMESTAMP_TZ, TIMESTAMP_LTZ, TIMESTAMP_NTZ, TIMESTAMP_WITH_TIME_ZONE]
  IF any column matches → "has_temporal"
  ELSE → "no_temporal"
classify data_volume: read raw_dataset.row_count
  IF row_count < 1,000,000 → "small" (exact cardinality)
  IF row_count >= 1,000,000 → "large" (approximate cardinality)
log: "Running schema-profiling | platform={value} | schema_complexity={value} | temporal_presence={value} | data_volume={value}"
```

**Upstream Validation:**
```
load raw_dataset.json
assert type(schema_version) is string AND schema_version == "1.0"
  IF schema_version is numeric type:
    HALT: "Upstream validation failed: raw_dataset.json — schema_version is a number ({actual}),
    expected string '1.0'. Artifact may be from an incompatible tool version."
  IF schema_version != "1.0":
    HALT: "Upstream validation failed: raw_dataset.json — schema_version is '{actual}',
    expected '1.0'. Re-run data-retrieval to produce a compatible artifact."
assert data_ref is not null and not empty string
  IF null or empty: HALT: "Upstream validation failed: raw_dataset.json — data_ref is missing.
  The temp table reference is required. Re-run data-retrieval."
assert row_count > 0
  IF not: HALT: "Upstream validation failed: raw_dataset.json — row_count is 0 or missing.
  Cannot profile an empty dataset. Re-run data-retrieval with corrected population criteria."
assert columns is a non-empty list
  IF empty: HALT: "Upstream validation failed: raw_dataset.json — column manifest is empty.
  Cannot profile schema without column list. Re-run data-retrieval."
assert source_platform is one of ["snowflake", "bigquery"]
  IF not: HALT: "Upstream validation failed: raw_dataset.json — source_platform '{value}'
  is not supported. Must be 'snowflake' or 'bigquery'."

verify temp table {data_ref} exists in warehouse
  IF not found: HALT: "Upstream validation failed: temp table '{data_ref}' not found in
  {platform} session. The warehouse session may have expired. Re-run data-retrieval to
  regenerate the temp table."
```

---

### Step 1 — Catalog Column Metadata

**Goal:** Retrieve authoritative type, nullability, and key information from the warehouse
catalog for every column in the dataset.

**Pre-step assertion:** Temp table `data_ref` is accessible; platform is classified.

**Actions:**

*Branch on platform:*

**IF `snowflake`:**
```sql
SELECT column_name, data_type, is_nullable, character_maximum_length,
       numeric_precision, numeric_scale, ordinal_position
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_name = '{temp_table_name}' AND table_schema = '{schema}'
ORDER BY ordinal_position;
```

**IF `bigquery`:**
```sql
SELECT column_name, data_type, is_nullable, ordinal_position
FROM `{project}.{dataset}.INFORMATION_SCHEMA.COLUMNS`
WHERE table_name = '{temp_table_name}'
ORDER BY ordinal_position;
```

**Post-catalog actions (platform-independent):**
```
For each column from catalog:
  Map platform-native type to normalized_type:
    Snowflake: NUMBER/FLOAT/DECIMAL → "numeric"; VARCHAR/TEXT → "string";
               DATE/TIMESTAMP_* → "temporal"; BOOLEAN → "boolean"; VARIANT/OBJECT → "semi_structured"
    BigQuery:  INT64/FLOAT64/NUMERIC/BIGNUMERIC → "numeric"; STRING → "string";
               DATE/DATETIME/TIMESTAMP → "temporal"; BOOL → "boolean"; JSON/STRUCT/ARRAY → "semi_structured"
  Record: column_name, platform_type, normalized_type, nullable (true/false), ordinal_position

Detect primary key candidates using heuristics:
  IF column_name matches pattern *_id, *_key, *_uuid, id, uuid AND cardinality_ratio ≈ 1.0
  → is_primary_key_candidate: true

Detect foreign key candidates:
  IF column_name matches *_id pattern AND is_primary_key_candidate is false
  → is_foreign_key_candidate: true (join mapping in Step 4 if multi_table)

Log count: "{N} columns cataloged from {table}"
```

**Checkpoint:**
> - [ ] PASS: column_count from catalog matches raw_dataset.column_count
> - [ ] WARN: catalog column count differs from raw_dataset manifest → "Schema drift detected: raw_dataset declared {N} columns but catalog shows {M}. Temp table may have been modified."
> - [ ] HALT: catalog query fails → "INFORMATION_SCHEMA query failed: {error}. Check warehouse permissions."

**Post-step assertion:** Every column has `normalized_type`, `nullable`, and `ordinal_position` recorded.

---

### Step 2 — Cardinality and Distribution Profiling

**Goal:** For each column, compute null rate, cardinality (unique value count), value range, and top values. These are the statistics that `data-quality-assessment` uses to score completeness and distributional health.

**Pre-step assertion:** Column metadata from Step 1 is complete; data_volume classification available.

*Branch on data_volume:*

**IF `small` (<1M rows): exact cardinality**
```sql
-- Run per column (batched if platform supports multi-column aggregate):
SELECT
  COUNT(*) AS total_rows,
  COUNT({col}) AS non_null_count,
  COUNT(DISTINCT {col}) AS cardinality,
  MIN({col}) AS min_value,
  MAX({col}) AS max_value
FROM {data_ref};
```

**IF `large` (≥1M rows): approximate cardinality**
```sql
-- Snowflake:
SELECT
  COUNT(*) AS total_rows,
  COUNT({col}) AS non_null_count,
  APPROX_COUNT_DISTINCT({col}) AS cardinality_approx,
  MIN({col}) AS min_value,
  MAX({col}) AS max_value
FROM {data_ref};

-- BigQuery:
SELECT
  COUNT(*) AS total_rows,
  COUNTIF({col} IS NOT NULL) AS non_null_count,
  APPROX_COUNT_DISTINCT({col}) AS cardinality_approx,
  MIN({col}) AS min_value,
  MAX({col}) AS max_value
FROM {data_ref};
```

**Top values (for string/dimension columns, cardinality ≤ 50):**
```sql
SELECT {col}, COUNT(*) AS freq
FROM {data_ref}
GROUP BY {col}
ORDER BY freq DESC
LIMIT 10;
```

**Post-profiling classification:**
```
For each column:
  null_rate = (total_rows - non_null_count) / total_rows
  cardinality_ratio = cardinality / total_rows

  Assign column_role (evaluate rules in order — first match wins):
    IF normalized_type == "temporal" → "temporal"
    IF normalized_type == "boolean" OR (normalized_type == "numeric" AND cardinality ≤ 2) → "flag"
    IF normalized_type == "string" AND cardinality_ratio ≈ 1.0 → "identifier"
    IF normalized_type == "numeric" AND is_primary_key_candidate → "identifier"
    IF normalized_type == "numeric" AND is_foreign_key_candidate → "dimension"
      NOTE: FK columns (store_id, channel_id, segment_id) are categorical even when numeric.
            Classifying them as "measure" would cause feature-engineering to aggregate them
            as continuous quantities — always classify FK columns as dimensions first.
    IF normalized_type == "numeric" AND cardinality > 20 → "measure"
    IF normalized_type == "string" AND cardinality ≤ 100 → "dimension"
    IF normalized_type == "string" AND cardinality > 100 → "text"
    DEFAULT → "dimension"
```

**Checkpoint:**
> - [ ] PASS: all columns profiled; null_rate computed for every column
> - [ ] WARN: any column null_rate == 1.0 → "Column {name} is 100% null. downstream quality gate will flag this."
> - [ ] WARN: no identifier-role columns detected → "No primary key candidate found. Join operations may produce cartesian products."
> - [ ] WARN: cardinality_method == "approximate" → log per column that approximation was used

**Post-step assertion:** Every column has `null_rate`, `cardinality`, `cardinality_method`, `column_role` assigned.

---

### Step 3 — Temporal Grain Analysis

**ONLY runs if temporal_presence == "has_temporal". Skip entirely if no_temporal.**

**Goal:** For each temporal column, detect the data's natural grain (daily/weekly/monthly),
identify gaps in the timeline, and compute freshness lag relative to today.

**Pre-step assertion:** At least one column with column_role == "temporal" exists.

**Actions:**
```
For each temporal column (column_role == "temporal"):
  1. Detect grain:
     Compute median interval between consecutive distinct date values:
       median_interval_days ≤ 1   → detected_grain = "daily"
       median_interval_days 2–8   → detected_grain = "weekly"
       median_interval_days 9–35  → detected_grain = "monthly"
       median_interval_days > 35  → detected_grain = "sparse" (WARN)

     SQL (Snowflake):
       SELECT MEDIAN(DATEDIFF('day', lag_date, curr_date)) AS median_gap
       FROM (SELECT {col} AS curr_date,
                    LAG({col}) OVER (ORDER BY {col}) AS lag_date
             FROM (SELECT DISTINCT {col} FROM {data_ref}) t) t2
       WHERE lag_date IS NOT NULL;

     NOTE: LAG() window function requires the temp table to be queryable in the current
     session. If the grain query fails, HALT: "Temporal grain detection failed: {error}.
     The temp table may have expired — re-run data-retrieval."

  2. Date range:
     Read min_value and max_value from Step 2 for this column.

  3. Gap detection:
     Count date intervals > 2× median_interval_days:
       gap_count = count of consecutive pairs where DATEDIFF > 2 × median_interval
     IF gap_count > 0: WARN: "Temporal column {name} has {gap_count} gaps exceeding 2× expected interval."

  4. Freshness lag:
     freshness_lag_days = DATEDIFF('day', max_value, TODAY())
     IF freshness_lag_days > 90: WARN: "Temporal column {name} is {freshness_lag_days} days stale."
```

**Checkpoint:**
> - [ ] PASS: detected_grain assigned for all temporal columns
> - [ ] WARN: detected_grain == "sparse" → downstream retention and time-series skills will be limited
> - [ ] WARN: gap_count > 0 → note in profiling_notes for quality assessment
> - [ ] WARN: freshness_lag_days > 90 → stale data, note for downstream context

**Post-step assertion:** All temporal columns have `detected_grain`, `date_range`, `gap_count`, `freshness_lag_days`.

---

### Step 4 — Join Relationship Mapping

**ONLY runs if schema_complexity == "multi_table". Skip entirely if single_table.**

**Goal:** Identify which columns are viable join keys between tables, estimate the join
cardinality type, and flag many-to-many relationships that would explode row counts.

**Pre-step assertion:** Multiple source tables identified in plan task node; Step 2 cardinality data available.

**Actions:**
```
For each pair of tables in multi_table join spec:
  Identify join key candidates:
    Columns in Table A with is_foreign_key_candidate == true that name-match
    columns in Table B with is_primary_key_candidate == true

  For each candidate join pair (col_a, col_b):
    Compute join cardinality ratio:
      ratio_a = cardinality(col_a) / row_count(table_a)
      ratio_b = cardinality(col_b) / row_count(table_b)

    Classify join type:
      IF ratio_a ≈ 1.0 AND ratio_b ≈ 1.0 → "one_to_one"
      IF ratio_a < 1.0 AND ratio_b ≈ 1.0 → "many_to_one"
      IF ratio_a ≈ 1.0 AND ratio_b < 1.0 → "one_to_many"
      IF ratio_a < 1.0 AND ratio_b < 1.0 → "many_to_many" (WARN)

    Record join candidate:
      {from_table, from_column, to_table, to_column, join_type_estimate, cardinality_ratio}

    IF join_type_estimate == "many_to_many":
      WARN: "Many-to-many join detected between {table_a}.{col_a} and {table_b}.{col_b}.
      This will multiply rows — verify join logic before proceeding."
```

**Checkpoint:**
> - [ ] PASS: at least one valid join candidate identified for each table pair
> - [ ] WARN: many-to-many join detected → document in profiling_notes
> - [ ] WARN: no join candidate found for a table pair → "No join key found between {table_a} and {table_b}. Query may produce cartesian product."

**Post-step assertion:** All table pairs have at least one join_candidate entry (or WARN explaining absence).

---

### Step 5 — Write Terminal Artifact

**Goal:** profiled_schema artifact written to project directory with complete structural catalog.

**Actions:**
```
Generate artifact_id: UUID v4
Write profiled_schema.json to project directory with all fields below
Log: "profiled_schema written | {column_count} columns | temporal_presence={value} | schema_complexity={value}"
```

**Checkpoint:**
> - [ ] PASS: profiled_schema.json written; all 5 universal envelope fields present; column_count matches
> - [ ] HALT: write failure → "Could not write profiled_schema.json: {error}"

---

## Terminal Artifact

```json
{
  "schema_version": "1.0",
  "skill_name": "schema-profiling",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 24,
  "artifact_id": "{uuid}",
  "source_table": "CUSTOMER_ANALYTICS.CUSTOMER_TRANSACTIONS",
  "source_platform": "snowflake",
  "data_ref": "DSE_EXTRACTION_a1b2c3d4",
  "schema_complexity": "single_table",
  "temporal_presence": "has_temporal",
  "data_volume": "small",
  "profiling_method": "exact",
  "raw_dataset_artifact_id": "{raw_dataset.artifact_id}",
  "columns": [
    {
      "name": "customer_id",
      "platform_type": "VARCHAR",
      "normalized_type": "string",
      "nullable": false,
      "null_rate": 0.0,
      "cardinality": 84729,
      "cardinality_method": "exact",
      "cardinality_ratio": 0.9997,
      "is_primary_key_candidate": true,
      "is_foreign_key_candidate": false,
      "column_role": "identifier",
      "min_value": null,
      "max_value": null,
      "top_values": null
    },
    {
      "name": "transaction_date",
      "platform_type": "DATE",
      "normalized_type": "temporal",
      "nullable": false,
      "null_rate": 0.0,
      "cardinality": 365,
      "cardinality_method": "exact",
      "cardinality_ratio": 0.004,
      "is_primary_key_candidate": false,
      "is_foreign_key_candidate": false,
      "column_role": "temporal",
      "min_value": "2025-01-01",
      "max_value": "2025-12-31",
      "top_values": null
    },
    {
      "name": "category",
      "platform_type": "VARCHAR",
      "normalized_type": "string",
      "nullable": true,
      "null_rate": 0.02,
      "cardinality": 12,
      "cardinality_method": "exact",
      "cardinality_ratio": 0.000142,
      "is_primary_key_candidate": false,
      "is_foreign_key_candidate": false,
      "column_role": "dimension",
      "min_value": null,
      "max_value": null,
      "top_values": ["Food & Beverage", "Personal Care", "Household", "Health"]
    }
  ],
  "temporal_columns": [
    {
      "name": "transaction_date",
      "detected_grain": "daily",
      "date_range": {"min": "2025-01-01", "max": "2025-12-31"},
      "gap_count": 0,
      "freshness_lag_days": 99
    }
  ],
  "join_candidates": [],
  "profiling_notes": [
    "freshness_lag_days=99 for transaction_date — data is ~3 months stale"
  ]
}
```

**Write to:** `profiled_schema.json` in the project directory.

**Field: `record_count`** = number of columns profiled (not rows in the dataset).

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Zero columns returned from catalog | `column_count == 0` from INFORMATION_SCHEMA | HALT: "Schema catalog returned 0 columns for temp table '{data_ref}'. Table may be empty or inaccessible." |
| Schema drift | catalog column_count ≠ raw_dataset.column_count | WARN: "Schema drift: raw_dataset declared {N} columns but catalog shows {M}. Artifact recorded with catalog values as authoritative." |
| All-null column | any column with `null_rate == 1.0` | WARN: "Column {name} is 100% null — data-quality-assessment will flag this as a blocking issue." |
| No primary key candidate | no column with `is_primary_key_candidate == true` | WARN: "No primary key candidate detected. Join operations may produce unexpected cardinality." |
| Many-to-many join | `join_type_estimate == "many_to_many"` in Step 4 | WARN: log in profiling_notes; execution continues but downstream join steps must validate |
| Temp table expired | `data_ref` not found in warehouse | HALT: "Temp table '{data_ref}' no longer exists. Re-run data-retrieval to recreate the extraction." |
| Temporal grain undetectable | median interval is 0 or columns has < 3 distinct dates | WARN: "Cannot detect grain for {name} — fewer than 3 distinct values. Recorded as 'sparse'." |
| Single column only | column_count == 1 | WARN: "Dataset contains only 1 column — most analytical skills require multiple columns." |

---

## Postconditions

After successful completion, this skill guarantees:
- [ ] `profiled_schema.json` exists with all 5 universal envelope fields
- [ ] Every column in `raw_dataset.columns` has a corresponding entry in `profiled_schema.columns`
- [ ] Every column has `null_rate`, `cardinality`, `cardinality_method`, and `column_role` assigned
- [ ] `temporal_columns` is populated (or empty with `temporal_presence == "no_temporal"`)
- [ ] `join_candidates` is populated (or empty with `schema_complexity == "single_table"`)
- [ ] `raw_dataset_artifact_id` links this profile to its source extraction for lineage

---

## Quality Bar

This skill run is "done" when ALL of the following are true:
- [ ] All Step checkpoints passed or documented as WARN with explanation in `profiling_notes`
- [ ] `profiled_schema.json` validates against `data-type-registry.md` schema
- [ ] `record_count` (column count) matches the catalog's actual column count
- [ ] No column has null `column_role`, `null_rate`, or `cardinality`
- [ ] `profiling_method` accurately reflects whether exact or approximate cardinality was used
- [ ] `data-quality-assessment` Step 0 can load `profiled_schema.json` and read `columns`

---

## Scope Boundary

This skill does NOT:
- Assess data fitness or flag quality issues → handled by `data-quality-assessment` (this skill
  describes structure; that skill scores it)
- Clean, impute, or transform data → handled by `data-remediation`
- Assign business meaning to columns → handled by `business-context-layer` (which column
  "active_customer_flag" MEANS vs. its type "boolean" are different concerns)
- Execute the joins described in join_candidates → the join mapping is advisory metadata;
  actual joins are constructed by `data-retrieval` or `feature-engineering`
- Profile model-readiness or feature utility → handled by `feature-engineering`

---

## Downstream

Run after this skill completes:
1. **`data-quality-assessment`** — reads `profiled_schema.json` to score completeness, consistency,
   and distributional health using `null_rate`, `cardinality`, and `column_role`
2. **`business-context-layer`** — reads `profiled_schema.json` to map normalized column types to
   business semantic definitions
3. **`feature-engineering`** — reads `profiled_schema.json` to determine safe aggregation types
   per column and identify temporal window anchors
