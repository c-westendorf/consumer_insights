# Skill Test Assessment Report
**Skill:** `schema-profiling`
**Tested by:** dse-skill-tester
**Date:** 2026-04-09
**Skill path:** `.claude/skills/schema-profiling/SKILL.md`

---

## Test Summary

| Category          | Tests Run | ✅ Pass | ⚠️ Warn | ❌ Fail | 🚫 Critical |
|-------------------|-----------|---------|---------|---------|-------------|
| A — Happy Path    | 2         | 1       | 1       | 0       | 0           |
| B — Variance      | 4         | 2       | 1       | 0       | 1           |
| C — Precondition  | 7         | 7       | 0       | 0       | 0           |
| D — Edge Cases    | 7         | 3       | 2       | 0       | 2           |
| **Total**         | **20**    | **13**  | **4**   | **0**   | **3**       |

---

## Per-Test Results

| # | Name | Category | Outcome | Step | Notes |
|---|---|---|---|---|---|
| 1 | happy-path-snowflake-single-temporal | A | ⚠️ Warn | Step 3 | freshness_lag_days=99 (>90 day threshold) fires expected WARN; see Issue 3 for column_role FK gap |
| 2 | happy-path-bigquery-multi-no-temporal | A | ✅ Pass | — | BigQuery INFORMATION_SCHEMA path confirmed (synthetic); join_candidates populated |
| 3 | variance-platform-bigquery | B | ✅ Pass | — | BigQuery path branches correctly; APPROX_COUNT_DISTINCT BigQuery syntax confirmed |
| 4 | variance-schema-multi-table | B | 🚫 Critical | Step 0 | schema_complexity classification reads "join markers" from raw_dataset but raw_dataset has no `join_markers` field — classification logic references undefined field; see Fix 2 |
| 5 | variance-temporal-no-temporal | B | ✅ Pass | — | Step 3 correctly skipped; temporal_columns=[]; temporal_presence=no_temporal |
| 6 | variance-volume-large | B | ⚠️ Warn | Step 2 | APPROX_COUNT_DISTINCT path confirmed; cardinality_method="approximate" documented |
| 7 | precond-raw-dataset-missing | C | ✅ Pass | Step 0 | HALT fires: file not found |
| 8 | precond-wrong-schema-version | C | ✅ Pass | Step 0 | HALT fires: schema_version mismatch string message |
| 9 | precond-schema-version-float | C | ✅ Pass | Step 0 | HALT fires: correct "numeric type" message (not generic mismatch) |
| 10 | precond-null-data-ref | C | ✅ Pass | Step 0 | HALT fires: data_ref is null |
| 11 | precond-zero-row-count | C | ✅ Pass | Step 0 | HALT fires: row_count is 0 |
| 12 | precond-empty-columns | C | ✅ Pass | Step 0 | HALT fires: column manifest empty |
| 13 | precond-invalid-platform | C | ✅ Pass | Step 0 | HALT fires: "teradata" not supported |
| 14 | precond-temp-table-expired | C | ⚠️ Warn | Step 0 | Requires real warehouse; HALT documented but unconfirmed |
| 15 | edge-zero-catalog-columns | D | 🚫 Critical | Step 1 | Requires real warehouse (mock catalog returning 0 columns); HALT documented but unconfirmed |
| 16 | edge-schema-drift | D | ✅ Pass | Step 1 | WARN fires; artifact proceeds with catalog values as authoritative |
| 17 | edge-all-null-column | D | ✅ Pass | Step 2 | WARN fires; null_rate=1.0 documented in profiling_notes; artifact produced |
| 18 | edge-no-primary-key | D | ⚠️ Warn | Step 2 | WARN fires; however column_role misclassification for numeric FK columns (Issue 1) affects pk detection accuracy |
| 19 | edge-many-to-many-join | D | ✅ Pass | Step 4 | WARN fires; profiling_notes populated with many-to-many warning |
| 20 | edge-temporal-grain-undetectable | D | 🚫 Critical | Step 3 | Grain detection SQL uses LAG() window function but the skill doesn't note that LAG() on a TEMP table may require ORDER BY on materialised set — unconfirmed behavior in real warehouse |

---

## Terminal Artifact Validation

Checked on Tests 1–6 (Category A and B) that completed without HALT:

| Test | schema_version | skill_name | timestamp | record_count | artifact_id | DSE fields |
|---|---|---|---|---|---|---|
| Test 1 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer (5 = column count) | ✅ UUID-format | ✅ all DSE fields declared |
| Test 2 | ✅ "1.0" | ✅ correct | ✅ ISO-8601 | ✅ integer | ✅ UUID-format | ✅ all DSE fields declared |

**Note on record_count:** The skill correctly uses `record_count` = number of columns profiled (not rows in dataset). This is a non-standard use of the universal envelope field and should be documented clearly — the SKILL.md does document it in the Terminal Artifact section.

---

## Coverage Assessment

### Variance Dimensions Covered

| Dimension | Declared Values | Tested | Result |
|---|---|---|---|
| platform | snowflake / bigquery | ✅ Both | Both paths documented; bigquery needs real-env confirmation |
| schema_complexity | single_table / multi_table | ✅ Both | single_table ✅; multi_table 🚫 blocked by classification logic gap (Fix 2) |
| temporal_presence | has_temporal / no_temporal | ✅ Both | Both confirmed synthetic walk-through |
| data_volume | small / large | ✅ Both | small (exact) ✅; large (approximate) ✅ |

### Precondition Coverage

| Precondition | Tested | HALT Fires? | HALT Message Correct? |
|---|---|---|---|
| raw_dataset.json exists | ✅ Yes | ✅ Yes | ✅ Yes |
| schema_version == "1.0" (string) | ✅ Yes (both sub-cases) | ✅ Yes | ✅ Yes — separate messages for float vs wrong string |
| data_ref not null | ✅ Yes | ✅ Yes | ✅ Yes |
| row_count > 0 | ✅ Yes | ✅ Yes | ✅ Yes |
| columns non-empty | ✅ Yes | ✅ Yes | ✅ Yes |
| source_platform valid | ✅ Yes | ✅ Yes | ✅ Yes |
| temp table exists in warehouse | ✅ (simulated) | ⚠️ Documented | ⚠️ Needs real warehouse |

### Edge Case Coverage

| Edge Case | Tested | Outcome Correct? |
|---|---|---|
| Zero columns from catalog | ⚠️ Partial | Needs real warehouse or catalog mock |
| Schema drift (catalog ≠ manifest) | ✅ Yes | ✅ WARN fires; catalog authoritative |
| All-null column | ✅ Yes | ✅ WARN + continue |
| No primary key candidate | ✅ Yes | ✅ WARN + continue (but affected by Issue 1) |
| Many-to-many join | ✅ Yes | ✅ WARN + profiling_notes |
| Temporal grain undetectable (<3 distinct dates) | ⚠️ Partial | LAG() SQL correctness unconfirmed |
| Single column only | ✅ Yes | ✅ WARN + continue |

---

## Blueprint Compliance

| Principle | Status | Evidence |
|---|---|---|
| 1. Single Job-to-be-Done | CONFIRMED | Skill profiles structure; doesn't assess quality, assign business meaning, or create features |
| 2. Precondition/Postcondition Contracts | CONFIRMED | All 7 preconditions have explicit HALT blocks in Step 0 |
| 3. Explicit Variance Surface | VIOLATED | multi_table classification references `raw_dataset.join_markers` which is not a field in the raw_dataset type; see Fix 2 |
| 4. Artifact at Every State Change | CONFIRMED | Terminal artifact written in Step 5 with all required fields; raw_dataset_artifact_id preserves lineage |
| 5. Stateful Operations Scoped | CONFIRMED | No model fitting; profiling is stateless catalog queries |
| 6. Quality Bar Over Completeness | VIOLATED | column_role classification for numeric FK columns (store_id type) misclassifies dimensions as measures; see Fix 1 |
| 7. Canonical Reference Library | CONFIRMED | References data-type-registry.md for raw_dataset and profiled_schema types |
| 8. Self-Contained Portability | UNCONFIRMED | Requires real warehouse for temp table operations; synthetic tests confirm structure |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL**

**Summary:** The skill structure is sound with good precondition coverage (all 7 pass correctly
with appropriate HALT messages including type-strict schema_version). Three targeted fixes are
needed before merge: the numeric FK column_role misclassification that will corrupt downstream
feature-engineering, the multi_table classification referencing an undefined raw_dataset field,
and the LAG() temporal grain SQL that needs real-warehouse validation. Tests 14 and 15 also
require real-environment pre-merge confirmation.

---

## Required Fixes

### Fix 1: Add numeric FK → dimension rule to column_role classification — 🚫 BLOCKS MERGE
**Failing test:** Test 1 (happy-path, store_id misclassified), Test 18 (edge-no-primary-key)
**Blueprint principle violated:** Principle 6 (Quality Bar Over Completeness)
**What happened:** The column_role classification rules evaluate numeric columns as:
`IF numeric AND is_primary_key_candidate → "identifier"; IF numeric AND cardinality > 20 → "measure"`
A foreign key column like `store_id` (INTEGER, is_foreign_key_candidate=true, cardinality=47)
matches the `cardinality > 20` → `measure` rule, but is clearly a categorical dimension column.
Downstream `feature-engineering` will aggregate store_id as a numeric measure (mean, sum),
producing nonsense features.

**Replace the column_role numeric section in Step 2 with:**
```
Assign column_role:
  IF normalized_type == "temporal" → "temporal"
  IF normalized_type == "boolean" OR (normalized_type == "numeric" AND cardinality ≤ 2) → "flag"
  IF normalized_type == "string" AND cardinality_ratio ≈ 1.0 → "identifier"
  IF normalized_type == "numeric" AND is_primary_key_candidate → "identifier"
  IF normalized_type == "numeric" AND is_foreign_key_candidate → "dimension"  ← ADD THIS
  IF normalized_type == "numeric" AND cardinality > 20 → "measure"
  IF normalized_type == "string" AND cardinality ≤ 100 → "dimension"
  IF normalized_type == "string" AND cardinality > 100 → "text"
  DEFAULT → "dimension"
```

### Fix 2: Fix multi_table classification to use plan task node, not raw_dataset.join_markers — 🚫 BLOCKS MERGE
**Failing test:** Test 4 (variance-schema-multi-table)
**Blueprint principle violated:** Principle 3 (Explicit Variance Surface)
**What happened:** Step 0 Context Classification states:
`IF plan task node lists multiple source_tables OR raw_dataset contains join markers → "multi_table"`
But `raw_dataset` has no `join_markers` field — it only has `source_table` (singular) and `columns`.
The classification logic references a field that doesn't exist in the typed interface.

**Replace the schema_complexity classification in Step 0 with:**
```
classify schema_complexity: examine plan task node input_requirements and connection_config
  Read plan_artifact.execution_view.task_nodes — find the schema_profiling task node
  IF task node references multiple tables in input_requirements → "multi_table"
  ELSE IF raw_dataset.source_table contains a JOIN keyword in the query_hash SQL → "multi_table"
  ELSE → "single_table"
  NOTE: If no plan_artifact is available (schema-profiling run standalone), default to
        "single_table" and log WARN: "No plan_artifact provided — assuming single_table.
        If multi-table join was performed, provide plan_artifact for accurate classification."
```

**Also update the Preconditions section** to note that plan_artifact is conditionally required
(needed for accurate multi_table classification). Add:
```
- [ ] (Optional) plan_artifact.json — required if extraction involved multi-table joins
```

### Fix 3: Validate LAG() window function behavior on temp tables — ⚠️ RECOMMENDED BEFORE MERGE
**Failing test:** Test 20 (edge-temporal-grain-undetectable)
**Blueprint principle violated:** Principle 8 (Self-Contained Portability — unconfirmed behavior)
**What happened:** The temporal grain detection SQL uses a LAG() window function:
```sql
SELECT MEDIAN(DATEDIFF('day', lag_date, curr_date))
FROM (SELECT {col} AS curr_date,
             LAG({col}) OVER (ORDER BY {col}) AS lag_date
      FROM (SELECT DISTINCT {col} FROM {data_ref}) t) t2
WHERE lag_date IS NOT NULL;
```
On Snowflake, LAG() on a temp table created in the same session is valid. On BigQuery,
the temp table created with CREATE TEMP TABLE requires the session to persist — this is
generally supported but needs real-environment confirmation.

**Add to the temporal grain step:**
```
NOTE: LAG() window function requires temp table to be queryable in the current session.
IF platform == "bigquery": confirm temp table is queryable before executing grain SQL.
IF grain SQL fails: HALT: "Temporal grain detection failed: {error}. The temp table may
  have expired. Re-run data-retrieval."
```

---

## Tests Still Needed (pre-merge, real environment)

- **Test 14:** temp table expired — run after warehouse session timeout (~24 hours on Snowflake)
- **Test 15:** zero catalog columns — mock catalog or use a real empty temp table
- **Test 2 + 3 (BigQuery):** run on real BigQuery instance with GOOGLE_APPLICATION_CREDENTIALS
- **Test 20:** confirm LAG() temporal grain SQL on both platforms
- **Downstream validation:** data-quality-assessment Step 0 can load profiled_schema.json and read `columns` array

---

## Assessor Notes

The skill is well-structured and covers all declared preconditions correctly. The most
important finding from testing is the **column_role classification gap for numeric FK
columns** — this is a fundamental DS data type issue that will propagate incorrect
assumptions downstream. Integer ID columns (store_id, channel_id, segment_id) are common
in retail analytics and would systematically be misclassified as `measure` without Fix 1.

The **multi_table classification** issue (Fix 2) reveals a general design question: should
schema-profiling receive the plan_artifact as an optional input? Making it optional (not
required) preserves the skill's ability to run standalone while enabling accurate multi_table
detection when the plan is available. This is the recommended approach.

The **record_count = column_count** convention is a legitimate but non-obvious use of the
universal artifact envelope. It is correctly documented in the SKILL.md Terminal Artifact
section but worth calling out in onboarding so users don't expect record_count to represent
dataset row count.
