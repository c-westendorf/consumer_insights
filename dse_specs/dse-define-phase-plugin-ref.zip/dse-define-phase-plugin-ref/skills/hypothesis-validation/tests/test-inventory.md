# Test Inventory: hypothesis-validation

**Skill:** hypothesis-validation
**Date:** 2026-04-10
**Spec source:** `.claude/skills/hypothesis-validation/SKILL.md`

---

## Parsed Spec Elements

### Preconditions (4)
1. `hypothesis_set.json` exists with `schema_version == "1.0"` and `hypotheses` array non-empty
2. `feature_set.json` exists with `schema_version == "1.0"` and non-null `data_ref`
3. `metric_result.json` exists with `schema_version == "1.0"`
4. `feature_set.data_ref` is accessible in the warehouse

### Variance Surface (3 dimensions)
| Dimension | Values |
|---|---|
| `confounder_handling` | `none`, `stratification`, `regression` |
| `evidence_threshold` | `strict`, `relaxed` |
| `causal_upgrade` | `eligible`, `not_eligible` |

### Edge Cases (8)
1. Empty source (record_count == 0)
2. Single record (record_count == 1)
3. All-null features
4. Schema mismatch (schema_version != "1.0")
5. All hypotheses not_supported
6. Confounder collinear with predictor (VIF > 10)
7. Insufficient data for stratification (stratum < 10 obs)
8. All hypotheses inconclusive after max iterations (3)

### Terminal Artifact Fields (5 envelope + skill-specific)
1. `schema_version` ("1.0")
2. `skill_name` ("hypothesis-validation")
3. `timestamp` (ISO-8601 UTC)
4. `record_count` (integer)
5. `artifact_id` (UUID v4)
6. `hypotheses_tested` (array with per-hypothesis details)
7. `hypotheses_count`, `supported_count`, `inconclusive_count`

### Postconditions (3)
1. `hypothesis_result.json` exists with all 5 universal envelope fields
2. Every tested hypothesis has verdict, evidence_strength, and test_applied
3. `supported_count + not_supported_count + inconclusive_count == hypotheses_count`

### Quality Bar (4)
1. `hypothesis_result.json` validates against terminal artifact spec
2. All hypotheses have explicit verdicts
3. Confounder handling is documented for each hypothesis
4. Downstream `finding-assembly` and `causal-linkage-analysis` Step 0 can validate the artifact

---

## Category A: Happy Path Tests

| ID | Name | Variance Config | Description | Expected Outcome |
|---|---|---|---|---|
| A-1 | Basic validation, no confounders, relaxed | `none / relaxed / not_eligible` | 3 hypotheses (correlation, distribution_gap, cluster_separation), feature_set with <5 covariates, relaxed scope | `hypothesis_result.json` with 3 verdicts, p<0.05 threshold, upgrade_recommendation = "none" for all |
| A-2 | Regression confounders, strict, causal eligible | `regression / strict / eligible` | 2 hypotheses, feature_set with >=5 covariates, plan specifies confounder control, scope analytical_pattern = "explain" | Confounders checked via regression, p<0.01 threshold, supported hypotheses get upgrade = "requires_causal_linkage_analysis" |
| A-3 | Stratification confounders, relaxed, not eligible | `stratification / relaxed / not_eligible` | 2 hypotheses, feature_set with 3-4 covariates | Stratified tests applied, p<0.05 threshold, no causal upgrade |
| A-4 | Mixed verdicts | `none / relaxed / not_eligible` | 4 hypotheses designed to yield supported, not_supported, and inconclusive verdicts | Counts sum correctly: supported_count + not_supported_count + inconclusive_count == hypotheses_count |

---

## Category B: Variance Coverage Tests

| ID | Name | Dimension Tested | Values Exercised | Description | Expected Outcome |
|---|---|---|---|---|---|
| B-1 | confounder_handling: none | confounder_handling | `none` | <3 covariates in feature_set | raw_p used as adjusted_p, no confounder fields populated |
| B-2 | confounder_handling: stratification | confounder_handling | `stratification` | 3-4 covariates in feature_set | stratified_test applied, adjusted_p from stratification |
| B-3 | confounder_handling: regression | confounder_handling | `regression` | >=5 covariates + plan specifies confounder control | run_multivariate_test called, confounders_checked populated |
| B-4 | evidence_threshold: strict | evidence_threshold | `strict` | Scope requires high confidence | Supported requires p<0.01 AND medium+ effect size |
| B-5 | evidence_threshold: relaxed | evidence_threshold | `relaxed` | Default scope | Supported requires p<0.05 AND small+ effect size |
| B-6 | causal_upgrade: eligible | causal_upgrade | `eligible` | scope_artifact.analytical_pattern == "explain" | Supported hypotheses get upgrade = "requires_causal_linkage_analysis" |
| B-7 | causal_upgrade: not_eligible | causal_upgrade | `not_eligible` | analytical_pattern != "explain" | All hypotheses get upgrade = "none" |
| B-8 | evidence_type: correlation | test selection | `correlation` | Hypothesis with evidence_type = "correlation" | partial_correlation or regression test selected |
| B-9 | evidence_type: distribution_gap | test selection | `distribution_gap` | Hypothesis with evidence_type = "distribution_gap" | t_test or mann_whitney selected based on normality |
| B-10 | evidence_type: cluster_separation | test selection | `cluster_separation` | Hypothesis with evidence_type = "cluster_separation" | ANOVA or permutation test selected |
| B-11 | Cross-dimension: regression + strict + eligible | all 3 | `regression / strict / eligible` | Full rigor configuration | All three behaviors compose correctly |
| B-12 | Cross-dimension: none + relaxed + not_eligible | all 3 | `none / relaxed / not_eligible` | Minimal rigor configuration | Simplest path produces valid artifact |

---

## Category C: Precondition Violation Tests

| ID | Name | Violated Precondition | Description | Expected Outcome |
|---|---|---|---|---|
| C-1 | Missing hypothesis_set.json | PC-1 | hypothesis_set.json does not exist | HALT at Step 0 with upstream validation failure message |
| C-2 | Empty hypotheses array | PC-1 | hypothesis_set.json exists but hypotheses = [] | HALT at Step 0: hypotheses non-empty assertion fails |
| C-3 | Wrong schema_version in hypothesis_set | PC-1 | hypothesis_set.json with schema_version = "0.9" | HALT at Step 0: schema_version assertion fails |
| C-4 | Missing feature_set.json | PC-2 | feature_set.json does not exist | HALT at Step 0 |
| C-5 | Null data_ref in feature_set | PC-2 | feature_set.json exists but data_ref = null | HALT at Step 0: data_ref not null assertion fails |
| C-6 | Wrong schema_version in feature_set | PC-2 | feature_set.json with schema_version = "2.0" | HALT at Step 0 |
| C-7 | Missing metric_result.json | PC-3 | metric_result.json does not exist | HALT at Step 0 |
| C-8 | Wrong schema_version in metric_result | PC-3 | metric_result.json with schema_version = "0.5" | HALT at Step 0 |
| C-9 | Inaccessible data_ref | PC-4 | feature_set.data_ref points to non-existent warehouse table | HALT at Step 0 |

---

## Category D: Edge Case Tests

| ID | Name | Edge Case | Description | Expected Outcome |
|---|---|---|---|---|
| D-1 | Empty source data | EC-1 | feature_set.record_count == 0 | HALT at Step 0 |
| D-2 | Single record | EC-2 | record_count == 1 | WARN: "Cannot validate hypotheses on single observation." |
| D-3 | All-null features | EC-3 | All supporting features for a hypothesis are NULL | HALT per hypothesis (not full skill halt) |
| D-4 | Schema mismatch | EC-4 | Any upstream schema_version != "1.0" | HALT at Step 0 (overlaps with C-3/C-6/C-8) |
| D-5 | All hypotheses not_supported | EC-5 | Every verdict == "not_supported" | Proceed -- valid finding, artifact written normally |
| D-6 | Confounder collinear with predictor | EC-6 | VIF > 10 for a confounder variable | WARN: drop collinear confounder from model |
| D-7 | Insufficient stratification data | EC-7 | Stratum has <10 observations | WARN + fallback to unstratified test |
| D-8 | Max iterations exhausted | EC-8 | 3 iterations completed, hypotheses still inconclusive | EXIT with inconclusive verdicts documented in artifact |

---

## Test Count Summary

| Category | Count |
|---|---|
| A: Happy Path | 4 |
| B: Variance Coverage | 12 |
| C: Precondition Violations | 9 |
| D: Edge Cases | 8 |
| **Total** | **33** |
