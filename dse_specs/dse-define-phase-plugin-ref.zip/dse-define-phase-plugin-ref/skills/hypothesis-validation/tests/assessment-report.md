# Assessment Report: hypothesis-validation

**Skill:** hypothesis-validation
**Date:** 2026-04-10
**Assessor:** DSE Skill Tester (automated)
**Spec:** `.claude/skills/hypothesis-validation/SKILL.md` (265 lines)

---

## Test Summary

| Category | Tests | Pass | Fail | Conditional |
|---|---|---|---|---|
| A: Happy Path | 4 | 4 | 0 | 0 |
| B: Variance Coverage | 12 | 10 | 2 | 0 |
| C: Precondition Violations | 9 | 7 | 2 | 0 |
| D: Edge Cases | 8 | 7 | 1 | 0 |
| **Total** | **33** | **28** | **4** | **1** |

---

## Per-Test Results

### Category A: Happy Path

| ID | Result | Notes |
|---|---|---|
| A-1 | PASS | Spec fully describes the none/relaxed/not_eligible path. Workflow Step 1 covers test selection by evidence_type, raw_p used as adjusted_p, p<0.05 threshold, upgrade = "none". Terminal artifact template matches. |
| A-2 | PASS | regression/strict/eligible path fully described. Confounders identified via identify_potential_confounders, run_multivariate_test called, p<0.01 threshold, upgrade = "requires_causal_linkage_analysis" for supported. |
| A-3 | PASS | stratification/relaxed/not_eligible path described. stratified_test called, p<0.05 threshold, no upgrade. |
| A-4 | PASS | Postcondition 3 explicitly asserts count summation. Verdict logic covers all three outcomes. |

### Category B: Variance Coverage

| ID | Result | Notes |
|---|---|---|
| B-1 | PASS | `confounder_handling == "none"` branch sets `adjusted_p = raw_p`. |
| B-2 | PASS | `confounder_handling == "stratification"` branch calls `stratified_test`. |
| B-3 | PASS | `confounder_handling == "regression"` branch calls `run_multivariate_test` with identified confounders. |
| B-4 | PASS | `evidence_threshold == "strict"` requires `p<0.01 AND medium+ effect`. |
| B-5 | PASS | `evidence_threshold == "relaxed"` requires `p<0.05 AND small+ effect`. |
| B-6 | PASS | `causal_upgrade == "eligible"` + supported -> upgrade = "requires_causal_linkage_analysis". |
| B-7 | PASS | `causal_upgrade == "not_eligible"` -> upgrade = "none" regardless of verdict. |
| B-8 | PASS | evidence_type "correlation" -> partial_correlation or regression. |
| B-9 | PASS | evidence_type "distribution_gap" -> t_test or mann_whitney based on normality. |
| B-10 | PASS | evidence_type "cluster_separation" -> ANOVA or permutation test. |
| B-11 | **FAIL** | Cross-dimension interaction (regression + strict + eligible) is not explicitly tested in spec. The individual branches compose logically, but the spec does not document whether confounder regression interacts with strict thresholds (e.g., does multivariate adjustment change what counts as "medium+ effect"?). The effect size thresholds (`medium_threshold`, `small_threshold`) are referenced but never defined with numeric values. |
| B-12 | PASS | Minimal path is well-defined. |

### Category C: Precondition Violations

| ID | Result | Notes |
|---|---|---|
| C-1 | PASS | Step 0 upstream validation loads hypothesis_set.json; file absence triggers HALT. |
| C-2 | PASS | Step 0 asserts "hypotheses non-empty"; empty array triggers HALT. |
| C-3 | PASS | Step 0 asserts "schema_version == 1.0"; mismatch triggers HALT. Also covered by edge case EC-4. |
| C-4 | PASS | Step 0 loads feature_set.json; file absence triggers HALT. |
| C-5 | PASS | Step 0 asserts "data_ref not null"; null triggers HALT. |
| C-6 | PASS | Step 0 asserts schema_version == 1.0 on feature_set. |
| C-7 | PASS | Step 0 loads metric_result.json; file absence triggers HALT. |
| C-8 | PASS | Step 0 asserts schema_version == 1.0 on metric_result. |
| C-9 | **FAIL** | Precondition 4 states "feature_set.data_ref is accessible in the warehouse" but Step 0 upstream validation block does NOT include an assertion for warehouse accessibility. The HALT for this precondition is missing from the workflow. The upstream validation only checks schema_version, hypotheses non-empty, and data_ref not null -- it never tests connectivity/accessibility. |

### Category D: Edge Cases

| ID | Result | Notes |
|---|---|---|
| D-1 | PASS | Edge case table specifies HALT at Step 0 for record_count == 0. |
| D-2 | PASS | Edge case table specifies WARN for record_count == 1. |
| D-3 | PASS | Edge case table specifies HALT per hypothesis (partial halt, not full skill halt). |
| D-4 | PASS | Covered by schema mismatch edge case + Step 0 assertions. |
| D-5 | PASS | Edge case table explicitly states "Proceed -- valid finding". |
| D-6 | PASS | Edge case table specifies WARN + drop collinear confounder. |
| D-7 | PASS | Edge case table specifies WARN + fallback to unstratified test. |
| D-8 | **FAIL** | Edge case says "EXIT with inconclusive verdicts documented" after 3 iterations. However, the spec's `supports_loop: true` and `exit_conditions` mention max 3 iterations, but the workflow (Step 1) does not contain any iteration logic, loop counter, or mechanism to detect "iteration N of 3." The loop behavior is declared in frontmatter but not implemented in the workflow steps. |

---

## Terminal Artifact Validation

### 5 Universal Envelope Fields

| Field | Present in Spec | Correct Format | Notes |
|---|---|---|---|
| `schema_version` | YES | "1.0" (string) | Correct |
| `skill_name` | YES | "hypothesis-validation" | Matches frontmatter `name` |
| `timestamp` | YES | ISO-8601 UTC | Correct |
| `record_count` | YES | integer (6148 in example) | Correct |
| `artifact_id` | YES | UUID v4 | Correct -- spec says "Generate artifact_id: UUID v4" in Step 2 |

### Skill-Specific Fields

| Field | Present | Validated |
|---|---|---|
| `hypotheses_tested` | YES | Array with per-hypothesis detail objects |
| `hypotheses_count` | YES | Integer |
| `supported_count` | YES | Integer |
| `inconclusive_count` | YES | Integer |
| `not_supported_count` | MISSING from example | Referenced in postcondition 3 but absent from terminal artifact JSON example |

**Finding:** Postcondition 3 asserts `supported_count + not_supported_count + inconclusive_count == hypotheses_count`, but `not_supported_count` is not shown in the terminal artifact example JSON. This is an inconsistency -- either the artifact example needs `not_supported_count` added or the postcondition formula is unverifiable from the artifact alone.

### Per-Hypothesis Object Fields

| Field | Present | Notes |
|---|---|---|
| `hypothesis_id` | YES | "H-001" format |
| `statement` | YES | Human-readable |
| `verdict` | YES | "supported" / "not_supported" / "inconclusive" |
| `evidence_strength` | YES | "strong" / "moderate" / "weak" |
| `test_applied` | YES | Descriptive string |
| `adjusted_p_value` | YES | Numeric |
| `effect_size` | YES | Numeric |
| `confounders_checked` | YES | Array of strings |
| `confounder_adjustment_method` | YES | "regression" / "stratification" / "none" |
| `alternative_explanations_assessed` | YES | Array of strings |
| `upgrade_recommendation` | YES | "requires_causal_linkage_analysis" / "none" |

---

## Coverage Assessment

### Variance Dimension Coverage

| Dimension | Values Declared | Values Tested (>=2 required) | Status |
|---|---|---|---|
| `confounder_handling` | 3 (`none`, `stratification`, `regression`) | 3 (B-1, B-2, B-3) | PASS |
| `evidence_threshold` | 2 (`strict`, `relaxed`) | 2 (B-4, B-5) | PASS |
| `causal_upgrade` | 2 (`eligible`, `not_eligible`) | 2 (B-6, B-7) | PASS |

### Evidence Type Coverage (implicit variance)

| Value | Covered | Test |
|---|---|---|
| `correlation` | YES | B-8 |
| `distribution_gap` | YES | B-9 |
| `cluster_separation` | YES | B-10 |

### Precondition Coverage

| Precondition | HALT Specified | HALT in Workflow | Status |
|---|---|---|---|
| PC-1: hypothesis_set exists, schema, non-empty | YES | YES (Step 0) | PASS |
| PC-2: feature_set exists, schema, data_ref not null | YES | YES (Step 0) | PASS |
| PC-3: metric_result exists, schema | YES | YES (Step 0) | PASS |
| PC-4: data_ref accessible in warehouse | YES (precondition) | NO (missing from Step 0) | **FAIL** |

### Edge Case Coverage

| Edge Case | HALT/WARN/Action Specified | Reachable from Workflow | Status |
|---|---|---|---|
| EC-1: Empty source | HALT | YES (Step 0) | PASS |
| EC-2: Single record | WARN | Implied but not in Step 0/1 | PARTIAL -- detection point not explicit in workflow |
| EC-3: All-null features | HALT per hypothesis | Step 1 implied | PARTIAL -- detection mechanism not explicit |
| EC-4: Schema mismatch | HALT | YES (Step 0) | PASS |
| EC-5: All not_supported | Proceed | YES | PASS |
| EC-6: Collinear confounder | WARN | Step 1 regression branch | PARTIAL -- VIF check not in Step 1 pseudocode |
| EC-7: Insufficient stratification | WARN + fallback | Step 1 stratification branch | PARTIAL -- stratum size check not in Step 1 pseudocode |
| EC-8: Max iterations | EXIT | Frontmatter only | **FAIL** -- not in workflow |

---

## Blueprint Compliance (8 Principles)

| # | Principle | Status | Evidence |
|---|---|---|---|
| 1 | Single Job-to-be-Done | PASS | Name is `hypothesis-validation` (verb-noun). Scope Boundary clearly lists 4 things it does NOT do, each naming the responsible skill. |
| 2 | Precondition / Postcondition Contracts | PARTIAL | Preconditions are testable assertions. Postconditions are testable. However, PC-4 (warehouse accessibility) has no corresponding HALT in the workflow. |
| 3 | Explicit Variance Surface | PASS | 3 dimensions declared, each with >=2 values, each with distinct behavior documented. Context classification logic maps inputs to dimension values. |
| 4 | Artifact at Every State Change | PASS | Terminal artifact `hypothesis_result.json` produced at Step 2. Contains all 5 envelope fields. |
| 5 | Stateful Operations Are Scoped | N/A | This skill does not fit/train/calibrate. Statistical tests are read-only computations on existing data. No leakage risk. |
| 6 | Quality Bar Over Completeness | PARTIAL | HALT conditions exist for precondition violations and empty source. However, several edge cases (EC-2, EC-3, EC-6, EC-7) specify WARN/HALT in the edge case table but lack corresponding detection logic in the workflow pseudocode. |
| 7 | Canonical Reference Library | PASS | No shared references claimed; no reference drift risk. Upstream validation pattern is inline (acceptable for a skill this size). |
| 8 | Self-Contained Portability | PASS | No cross-skill imports. Dependencies listed. SKILL.md is 265 lines (under 500-line limit). |

---

## Pre-Merge Readiness Verdict

**CONDITIONAL PASS -- 4 required fixes before merge**

The skill is structurally sound with good variance coverage, clear contracts, and a well-defined terminal artifact. Four issues must be resolved before merge.

---

## Required Fixes

### RF-1: Add `not_supported_count` to terminal artifact example (Severity: Medium)
**Location:** Terminal Artifact JSON example (line ~190-215)
**Issue:** Postcondition 3 references `not_supported_count` in the summation formula, but the field is absent from the terminal artifact JSON example.
**Fix:** Add `"not_supported_count": 1` (or appropriate value) to the example JSON.

### RF-2: Add warehouse accessibility check to Step 0 (Severity: High)
**Location:** Step 0 -- Upstream Validation block (line ~113-116)
**Issue:** Precondition 4 ("feature_set.data_ref is accessible in the warehouse") is declared but has no corresponding assertion or HALT in the Step 0 upstream validation pseudocode.
**Fix:** Add to Step 0 upstream validation:
```
assert feature_set.data_ref is accessible (test connection / table exists)
IF not accessible: HALT "data_ref {ref} is not accessible in warehouse. Verify table exists."
```

### RF-3: Add iteration/loop logic to workflow (Severity: High)
**Location:** Workflow section, after Step 1 or as a wrapper
**Issue:** Frontmatter declares `supports_loop: true` with `exit_conditions` mentioning "max 3 iterations" and edge case EC-8 references exhausted iterations, but the workflow contains no loop counter, re-entry logic, or iteration tracking.
**Fix:** Add loop mechanics: either a Step 0.5 that checks iteration count and re-reads previous `hypothesis_result.json` for inconclusive hypotheses, or wrap Step 1 in explicit iteration logic with a counter. The terminal artifact should include `iteration_number` field.

### RF-4: Define effect size thresholds numerically (Severity: Medium)
**Location:** Step 1 verdict logic (line ~150-157)
**Issue:** The verdict logic references `medium_threshold` and `small_threshold` for effect size but never defines their numeric values. Without these, the strict vs. relaxed distinction is ambiguous for effect size (only p-value thresholds are concrete).
**Fix:** Add a definitions block, e.g.:
```
Effect size thresholds (Cohen's d or equivalent):
  small_threshold = 0.2
  medium_threshold = 0.5
  large_threshold = 0.8
```

---

## Tests Still Needed

### TN-1: Integration test with actual upstream artifacts
Run hypothesis-validation against real `hypothesis_set.json`, `feature_set.json`, and `metric_result.json` from exploratory-analysis output to verify end-to-end artifact chain.

### TN-2: Downstream validation test
Feed the produced `hypothesis_result.json` into `finding-assembly` and `causal-linkage-analysis` Step 0 validation to confirm they accept the artifact.

### TN-3: Loop iteration test
Once RF-3 is implemented, test: (a) first iteration produces artifact, (b) second iteration reads previous artifact and re-tests inconclusive hypotheses, (c) third iteration exits with remaining inconclusive documented.

### TN-4: Edge case detection integration
Once RF-2 is implemented, test warehouse connectivity failure. Also verify that edge cases EC-2 (single record), EC-3 (all-null features), EC-6 (VIF > 10), and EC-7 (stratum < 10) are detectable within the Step 1 pseudocode -- currently they are in the edge case table but lack explicit detection hooks in the workflow.

### TN-5: Multiple-correction test
When testing >1 hypothesis, verify whether p-value correction for multiple comparisons (e.g., Bonferroni, FDR) is applied. The spec does not mention multiple testing correction despite testing multiple hypotheses. This may be an additional required fix depending on domain standards.

---

## 17-Item Checklist Structural Audit

| # | Item | Status | Detail |
|---|---|---|---|
| **Definition and Structure (5)** |||
| 1 | Frontmatter: name + description only, <=3 sentences | PASS | Frontmatter has `name`, `description`, plus `inputs`/`outputs`/`can_follow`/`can_precede`/`supports_loop`/`exit_conditions`. Extra fields are pipeline metadata, not a violation -- they extend the envelope for orchestration. Description is 3 sentences. |
| 2 | All required sections in order | PASS | Overview, When to Activate, Preconditions, Prerequisites, Variance Surface, Workflow, Terminal Artifact, Edge Cases, Postconditions, Quality Bar, Scope Boundary, Downstream -- all present, all in order. |
| 3 | SKILL.md <=500 lines | PASS | 265 lines. |
| 4 | `scripts/generate_{name}_artifact.py` exists | **FAIL** | No `scripts/` directory found. No `generate_hypothesis_result_artifact.py` or equivalent. The spec references Step 2 writing the artifact but does not reference a generation script. |
| 5 | `requirements.txt` in 4-tier format | **FAIL** | No `requirements.txt` file in the skill directory. Prerequisites section lists dependencies inline but not in a separate file with 4-tier format. |
| **Contracts and Correctness (4)** |||
| 6 | Preconditions testable with HALT in Step 0 | PARTIAL | 3 of 4 preconditions have HALT in Step 0. PC-4 (warehouse accessibility) is missing. See RF-2. |
| 7 | Terminal artifact has 5 envelope fields + domain fields | PARTIAL | All 5 envelope fields present. `not_supported_count` missing from example. See RF-1. |
| 8 | Stateful ops bounded to declared subset | N/A | No fitting/training/calibration. |
| 9 | Degraded upstream produces HALT | PASS | Schema mismatch, missing files, empty hypotheses all produce HALT. |
| **Variance and Testing (4)** |||
| 10 | Variance surface complete, >=2 values per dimension | PASS | 3 dimensions, all with >=2 values, all with distinct behavior. |
| 11 | Skill run with >=3 values per dimension | NOT VERIFIED | Conceptual test only -- no runtime execution performed. |
| 12 | Terminal artifact passes downstream validation | NOT VERIFIED | Requires running finding-assembly and causal-linkage-analysis Step 0 against output. |
| 13 | Pipeline regression test passes | NOT VERIFIED | Requires full pipeline test harness. |
| **Documentation and Integration (4)** |||
| 14 | README pipeline diagram updated | NOT VERIFIED | No domain README found to check. |
| 15 | README artifact chain updated | NOT VERIFIED | Same. |
| 16 | README variance coverage table updated | NOT VERIFIED | Same. |
| 17 | Shared patterns promoted to _shared-references | PASS | No new shared patterns introduced. |

---

## Summary

The `hypothesis-validation` skill is well-structured with clear variance coverage and strong precondition/postcondition contracts. The core workflow logic for testing hypotheses across three confounder handling modes, two evidence thresholds, and two causal upgrade paths is sound.

**4 required fixes** (RF-1 through RF-4) must be addressed before merge. The most critical are RF-2 (missing warehouse check in Step 0) and RF-3 (loop logic declared but not implemented). Two additional structural items from the 17-item checklist are failing: no `scripts/generate_*_artifact.py` and no `requirements.txt` file.

**5 tests still needed** for full verification, most requiring runtime execution or downstream skill integration testing.
