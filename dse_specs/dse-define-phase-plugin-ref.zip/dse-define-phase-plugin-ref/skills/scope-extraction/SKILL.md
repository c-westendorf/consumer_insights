---
name: scope-extraction
description: >
  Extracts structured scope fields from a business question and conversation context,
  populating population, metric, timeframe, comparison, business_context, and constraints.
  Activate after intent-classification to build the structured scope. Takes raw_question,
  intent_classification, and conversation_context; produces partial_scope with fields set
  to null when not extractable from available context.
inputs:
  - type: raw_question
    description: "User's business question as natural language text"
  - type: intent_classification
    description: "Classified lifecycle stage and analytical pattern from intent-classification"
  - type: conversation_context
    description: "Prior conversation turns providing additional scope details"
    optional: true
outputs:
  - type: partial_scope
    description: "Six structured scope fields, each populated or explicitly null"
can_follow: [intent-classification]
can_precede: [completeness-validation]
supports_loop: true
exit_conditions:
  - "partial_scope produced with all extractable fields populated and remaining fields explicitly null"
  - "no contradictions between extracted fields"
---

# scope-extraction

## Overview

Intent-classification determines *what kind* of analysis is needed. Scope-extraction
determines *what specifically* is being analyzed. This skill parses the business question
and any available conversation context to populate 6 structured scope fields:

1. **population** — who is being analyzed
2. **metric** — what is being measured
3. **timeframe** — when the analysis covers
4. **comparison** — what is being compared against (pattern-dependent)
5. **business_context** — why this analysis matters
6. **constraints** — any exclusions or restrictions

Any field that cannot be reliably extracted from available input is set to `null`. The
skill never invents data. In loop mode (re-invoked after user provides disambiguation
answers), it incorporates new information from `conversation_context` and merges it with
the existing `partial_scope`.

## When to Activate

- An `intent_classification` artifact exists with a valid lifecycle stage and pattern.
- The Scope Agent pipeline needs structured scope fields for completeness validation.
- In loop mode: the user has provided additional information that may fill null fields.

Do **not** activate when no `intent_classification` artifact exists — route to
`intent-classification` first.

## Preconditions

| Condition | Check | On Failure |
|---|---|---|
| Intent classification exists | `intent_classification.json` loadable | HALT — run intent-classification first |
| Schema version matches | `schema_version == "1.0"` | HALT — incompatible upstream artifact version |
| Lifecycle stage present | `lifecycle_stage` is non-null string | HALT — upstream artifact incomplete |
| Analytical pattern present | `analytical_pattern` is non-null string | HALT — upstream artifact incomplete |
| Raw question non-empty | `len(raw_question.strip()) > 0` | HALT — no input to extract from |

## Prerequisites

- **Runtime:** CPU-only, no GPU required.
- **Memory:** < 50 MB working set.
- **Dependencies:** None beyond the agent runtime (Tier 1 only). No external APIs,
  no database connections, no warehouse access, no heavy libraries.
- **Reference files:** `intent_classification.json` (produced by upstream skill).

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `extraction_completeness` | `full` / `partial` | `full`: all 6 fields populated — proceed directly to terminal artifact; `partial`: >= 1 field is null — mark for downstream completeness-validation to generate disambiguation questions |
| `analytical_pattern` | `profile` / `compare` / `predict` / `explain` / `segment` | Determines extraction priority and pattern-specific fields: `compare` prioritizes comparison field; `predict` looks for prediction_horizon; `explain` looks for outcome_variable; `segment` looks for segmentation_basis |
| `loop_iteration` | `initial` / `subsequent` | `initial`: extract from raw_question only; `subsequent`: merge new info from conversation_context with existing partial_scope, overwriting only fields the user explicitly provided |

## Workflow

### Step 0 — Context Classification + Upstream Validation

1. Classify the three variance dimensions:
   - `extraction_completeness`: unknown until extraction completes (set after Step 6).
   - `analytical_pattern`: read from `intent_classification.json`.
   - `loop_iteration`: `initial` if no prior `partial_scope.json` exists;
     `subsequent` if re-invoked with conversation_context.
2. Load `intent_classification.json`:
   - Assert `schema_version == "1.0"`. On mismatch: **HALT**.
   - Assert `lifecycle_stage` and `analytical_pattern` are present. On missing: **HALT**.
   - Read `artifact_id` for provenance linking.
3. If `loop_iteration == subsequent`, load existing `partial_scope.json` as merge base.

Checkpoint: **PASS** — upstream validated and variance dimensions set.

### Step 1 — Extract Population

Parse the question and context for customer segment references:

- **Lifecycle stage anchoring**: use `lifecycle_stage` from intent classification as
  the primary population signal.
- **Filter criteria**: look for qualifiers like "who purchased in Q1", "with 3+ orders",
  "in the Northeast region".
- **Exclusions**: note any "excluding", "not including", "except" language.

Output: `PopulationDef` object with `description` (human-readable) and `criteria` array
(structured filter conditions).

> If no population identifiable: set `population = null`.

Checkpoint: **PASS** — population extracted or explicitly null.

### Step 2 — Extract Metric

Parse for measurement language:

- **What is measured**: the noun being quantified (retention, revenue, frequency).
- **Aggregation**: how it is summarized (rate, average, sum, proportion, count).
- **Success definition**: what constitutes a good outcome, if stated.

Output: `MetricDef` object with `name`, `definition`, and `aggregation`.

> If no metric identifiable: set `metric = null`.

Checkpoint: **PASS** — metric extracted or explicitly null.

### Step 3 — Extract Timeframe

Parse for temporal references:

- **Absolute dates**: "Q1 2025", "January to March 2025", "2024".
- **Relative periods**: "last 6 months", "past year", "trailing 90 days".
- **Granularity**: "daily", "weekly", "monthly", "quarterly".
- **Reference windows**: "with 12 months of behavioral history" — distinct from
  the analysis window.

Output: `TimeframeDef` object with `start`, `end`, `granularity`, and `reference`.

> If no timeframe identifiable: set `timeframe = null`.

Checkpoint: **PASS** — timeframe extracted or explicitly null.

### Step 4 — Extract Pattern-Specific Fields

Based on `analytical_pattern` from intent classification, extract the relevant
pattern-specific field:

| Pattern | Field to extract | What to look for |
|---|---|---|
| `compare` | `comparison` | The reference group or benchmark: "vs new customers", "compared to last year", "against industry average" |
| `predict` | `comparison.prediction_horizon` | The forecast window: "next 90 days", "within 6 months", "by end of year" |
| `explain` | `comparison.outcome_variable` | The dependent variable: "what drives retention", "factors behind churn" |
| `segment` | `comparison.segmentation_basis` | The clustering dimension: "by behavior", "by value tier", "by channel" |
| `profile` | `comparison` | Not required — set to `null` unless comparison language present |

Output: populate the `comparison` field with pattern-specific content, or set to `null`.

Checkpoint: **PASS** — pattern-specific field extracted or explicitly null.

### Step 5 — Extract Business Context and Constraints

Parse for decision-making and operational context:

- **Business context** (structured object with three sub-fields):
  - `question`: the original business question, preserved verbatim.
  - `decision`: what decision this analysis informs ("to inform our Q3 campaign strategy",
    "to decide whether to expand the program").
  - `stakeholder`: who consumes the output ("VP Marketing", "board", "retention team").
- **Constraints**: "exclude test accounts", "only domestic", "minimum 30-day tenure",
  "must be HIPAA-compliant".

Output: populate `business_context` (object with `question`, `decision`, `stakeholder` —
any sub-field may be null) and `constraints` (array, may be empty).

Checkpoint: **PASS** — context and constraints extracted or explicitly empty/null.

### Step 6 — Validate and Write

1. **Contradiction check**: scan extracted fields for logical conflicts:
   - Timeframe `end` before `start`.
   - Population excludes the lifecycle stage from intent classification.
   - Metric aggregation incompatible with population type.
2. If contradictions found: **WARN** — log contradictions in `extraction_metadata` and
   flag for user resolution. Do not suppress the conflicting data.
3. Count populated vs null fields to set `extraction_completeness`:
   - All 6 populated: `full`.
   - Any null: `partial`.
4. Assemble `partial_scope.json` terminal artifact.

If `loop_iteration == subsequent`:
- Step 5.5 — Merge Precedence:
  1. Run extraction on `conversation_context` ONLY to identify new/corrected fields.
     Tag these as `source: "user_provided"`.
  2. Compare against existing `partial_scope` fields.
  3. Merge rule: `user_provided` fields always win over existing values;
     existing non-null fields are preserved unless explicitly overridden;
     raw_question re-extraction only fills fields that are still null and
     were not previously user-provided.
- Increment `loop_iteration` counter in metadata.
- Log: "Merge applied: {N} fields updated from user input, {M} preserved."

Checkpoint: **PASS** — artifact assembled and written.

## Terminal Artifact

**File:** `partial_scope.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "scope-extraction",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 1,
  "artifact_id": "{uuid}",
  "population": {
    "description": "Reactivated low-engaged customers who returned in Q1 2025",
    "criteria": [
      {"field": "lifecycle_stage", "operator": "==", "value": "reactivated_low_engaged"},
      {"field": "reactivation_date", "operator": ">=", "value": "2025-01-01"},
      {"field": "reactivation_date", "operator": "<=", "value": "2025-03-31"}
    ]
  },
  "metric": {
    "name": "90-day repeat purchase rate",
    "definition": "Percentage of customers with 2+ purchases within 90 days of reactivation",
    "aggregation": "proportion"
  },
  "timeframe": {
    "start": "2025-01-01",
    "end": "2025-06-30",
    "granularity": "monthly",
    "reference": "12 months for behavioral features"
  },
  "comparison": null,
  "business_context": {
    "question": "How do reactivated low-engaged customers compare to continuously active ones?",
    "decision": null,
    "stakeholder": null
  },
  "constraints": [],
  "extraction_metadata": {
    "fields_populated": 3,
    "fields_null": 3,
    "extraction_completeness": "partial",
    "loop_iteration": 1,
    "contradictions": [],
    "source_artifact_id": "{intent_classification artifact_id}"
  }
}
```

**Envelope fields** (required on every artifact):

| Field | Type | Description |
|---|---|---|
| `schema_version` | string | Always `"1.0"` for Define Phase v1 |
| `skill_name` | string | `"scope-extraction"` |
| `timestamp` | string | ISO-8601 UTC timestamp at artifact creation |
| `record_count` | integer | Always `1` for this skill |
| `artifact_id` | string | UUID v4 unique to this artifact instance |

## Edge Cases

| # | Scenario | Detection | Response |
|---|---|---|---|
| 1 | Empty input | `raw_question` is empty or whitespace | **HALT** — return error requesting a business question |
| 2 | Single record | Only one scope field extractable from input | **PASS** — populate that field, set remaining 5 to null; downstream completeness-validation will generate disambiguation questions |
| 3 | All-null dimension | No scope fields extractable from question | **WARN** — produce artifact with all fields null and `fields_populated: 0`; downstream will generate full disambiguation prompt |
| 4 | Schema mismatch | `intent_classification.json` has unexpected schema_version | **HALT** — incompatible upstream artifact; cannot proceed |
| 5 | Contradictory fields | Timeframe end before start, or population excludes classified stage | **WARN** — log contradictions in `extraction_metadata.contradictions`; keep both values for user resolution |
| 6 | Ambiguous metric | Multiple metrics mentioned without clear primary | **WARN** — extract the first mentioned as primary `metric`; list alternatives in `extraction_metadata` for user confirmation |
| 7 | Loop with conflicting update | User provides info in subsequent turn that contradicts prior extraction | **WARN** — overwrite with user's latest input (user authority prevails); log the override in `extraction_metadata.contradictions` |
| 8 | Implicit timeframe | No explicit dates but question implies recency ("current", "recent") | **PASS** — set `timeframe.start` to null, `timeframe.granularity` to null, add note in description; let completeness-validation prompt for specifics |

## Postconditions

| Condition | Verification |
|---|---|
| Artifact written | `partial_scope.json` exists with all 5 envelope fields |
| All 6 scope fields present | Each of `population`, `metric`, `timeframe`, `comparison`, `business_context`, `constraints` exists as key (value may be null) |
| Field count accurate | `extraction_metadata.fields_populated` + `extraction_metadata.fields_null` == 6 |
| No silent nulls | Every null field is an explicit `null`, not a missing key |
| Provenance linked | `extraction_metadata.source_artifact_id` matches upstream `artifact_id` |
| No invented data | Every populated field traces to text in `raw_question` or `conversation_context` |

## Quality Bar

- The skill must never populate a field with invented or assumed data. If unsure, the
  field must be `null`.
- `extraction_metadata.fields_populated` must exactly match the count of non-null fields.
- In loop mode, only fields explicitly provided by the user in the latest turn may be
  overwritten — no speculative fills.
- Contradictions must be surfaced, never silently resolved.
- Population criteria must be structured as operator-based filters, not free text.
- Extraction must be reproducible: same inputs must yield same outputs.

## Scope Boundary

This skill **only** extracts scope fields. It does NOT:

| Out-of-scope action | Responsible skill |
|---|---|
| Classify the business question intent | `intent-classification` |
| Validate whether the scope is complete | `completeness-validation` |
| Generate disambiguation questions for null fields | `completeness-validation` |
| Format scope for stakeholder approval | `scope-formatting` |
| Decompose scope into analytical tasks | `task-decomposition` |
| Query databases or warehouses | N/A — Define Phase is pre-warehouse |

## Downstream

- **Primary consumer:** `completeness-validation` — checks whether all required fields
  (based on analytical pattern) are populated and generates disambiguation questions
  for null fields.
- **Loop re-entry:** if `completeness-validation` obtains user answers, it re-invokes
  `scope-extraction` with updated `conversation_context` for a subsequent loop iteration.
- **Artifact reference:** downstream skills load `partial_scope.json` and validate
  `schema_version == "1.0"` before proceeding.
- **Failure propagation:** if this skill HALTs (upstream artifact missing or invalid),
  the pipeline routes back to `intent-classification`.
