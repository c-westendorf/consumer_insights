# Skill Test Assessment Report
**Skill:** `scope-extraction`
**Tested by:** dse-skill-tester
**Date:** 2026-04-10
**Skill path:** `/Users/chris/Documents/GitHub/consumer_insights/dse_specs/dse-define-phase-plugin-ref/skills/scope-extraction/SKILL.md`

## Test Summary
| Category | Tests Run | Pass | Warn | Fail | Critical |
|---|---|---|---|---|---|
| A -- Happy Path | 2 | 2 | 0 | 0 | 0 |
| B -- Variance | 7 | 6 | 0 | 1 | 0 |
| C -- Precondition | 5 | 5 | 0 | 0 | 0 |
| D -- Edge Cases | 8 | 7 | 0 | 1 | 0 |
| **Total** | **22** | **20** | **0** | **2** | **0** |

## Per-Test Results

| # | Name | Category | Outcome | Step | Notes |
|---|---|---|---|---|---|
| A1 | Full extraction from rich question | A | PASS | All | Input: "What is the 90-day repeat purchase rate for reactivated customers in Q1 2025, excluding test accounts, to inform our Q3 campaign strategy?" with intent_classification (lifecycle_stage=reactivated, analytical_pattern=profile, confidence=0.9). Step 0: upstream artifact valid, schema_version=1.0, both fields present, loop_iteration=initial. PASS. Step 1: population = reactivated customers, criteria includes lifecycle_stage==reactivated. PASS. Step 2: metric = 90-day repeat purchase rate, aggregation=proportion. PASS. Step 3: timeframe = Q1 2025 (start=2025-01-01, end=2025-03-31). PASS. Step 4: profile pattern, comparison=null (no comparison language). PASS. Step 5: business_context="inform Q3 campaign strategy", constraints=["exclude test accounts"]. PASS. Step 6: no contradictions, fields_populated=5 (population, metric, timeframe, business_context, constraints), fields_null=1 (comparison), extraction_completeness=partial. PASS. All postconditions met: artifact written, all 6 fields present as keys, field count accurate (5+1=6), no silent nulls, provenance linked, no invented data. |
| A2 | Partial extraction from sparse question | A | PASS | All | Input: "How are our lapsed customers doing?" with intent_classification (lifecycle_stage=lapsed, analytical_pattern=profile). Step 0: valid upstream. PASS. Step 1: population = lapsed customers. PASS. Step 2: metric = null (no specific metric). PASS. Step 3: timeframe = null. PASS. Step 4: profile, comparison = null. PASS. Step 5: business_context = null, constraints = []. PASS. Step 6: fields_populated=1, fields_null=5, extraction_completeness=partial. PASS. All postconditions met. Downstream completeness-validation will generate disambiguation questions for the 5 null fields. |
| B1 | Extraction completeness: full | B | PASS | Step 6 | See A1 variant where all 6 fields are populated. When comparison is also provided (e.g., add "compared to new customers"), fields_populated=6, extraction_completeness=full. Step 6 proceeds directly to terminal artifact. PASS. |
| B2 | Extraction completeness: partial | B | PASS | Step 6 | See A2. At least one field null. extraction_completeness=partial. Correctly marked for downstream disambiguation. PASS. |
| B3 | Pattern: compare | B | PASS | Step 4 | Input: "How does retention of reactivated customers compare to new customers?" with analytical_pattern=compare. Step 4 extracts comparison field: reference group = "new customers". comparison is populated with the comparison reference. PASS. |
| B4 | Pattern: predict | B | PASS | Step 4 | Input: "Will our at-risk customers churn in the next 90 days?" with analytical_pattern=predict. Step 4 looks for prediction_horizon, extracts "next 90 days" into comparison.prediction_horizon. PASS. |
| B5 | Pattern: explain | B | PASS | Step 4 | Input: "What drives retention among high-engaged customers?" with analytical_pattern=explain. Step 4 looks for outcome_variable, extracts "retention" into comparison.outcome_variable. PASS. |
| B6 | Pattern: segment | B | PASS | Step 4 | Input: "What types of at-risk customers do we have by behavior?" with analytical_pattern=segment. Step 4 looks for segmentation_basis, extracts "by behavior" into comparison.segmentation_basis. PASS. |
| B7 | Loop iteration: subsequent | B | FAIL | Step 0, Step 6 | Fixture: re-invocation with existing partial_scope.json (population populated, metric null) and new conversation_context where user says "The metric is 90-day retention rate." Step 0: loads existing partial_scope.json as merge base. PASS. Steps 1-5: extracts metric from conversation_context. Step 6: merges -- should only overwrite metric (explicitly provided by user), keep population unchanged. However, the spec has an ambiguity: Step 6 says "only overwrite fields the user explicitly provided in the latest conversation turn" but Steps 1-5 run extraction on ALL input (raw_question + conversation_context). If Step 2 extracts a metric from the original raw_question AND conversation_context provides a different one, which wins? The spec says user authority prevails (edge case 7), but the workflow does not specify how to distinguish "extracted from raw_question in this pass" vs "user explicitly provided in conversation_context." If the skill re-extracts population from raw_question and it differs slightly from the stored version, does it overwrite? FAIL -- merge semantics are under-specified for the subsequent iteration extraction-vs-merge boundary. |
| C1 | Intent classification missing | C | PASS | Step 0 | No intent_classification.json file exists. Step 0 attempts to load it, fails. Precondition says HALT -- run intent-classification first. Step 0 workflow explicitly checks: "Load intent_classification.json... On mismatch: HALT." The load failure triggers HALT. PASS. |
| C2 | Schema version mismatch | C | PASS | Step 0 | intent_classification.json has schema_version="2.0". Step 0 asserts schema_version=="1.0". Mismatch -> HALT. Precondition and workflow are aligned. PASS. |
| C3 | Lifecycle stage missing | C | PASS | Step 0 | intent_classification.json has lifecycle_stage=null. Step 0 asserts lifecycle_stage is non-null string. Null fails -> HALT. Precondition and workflow aligned. PASS. |
| C4 | Analytical pattern missing | C | PASS | Step 0 | intent_classification.json has analytical_pattern=null. Step 0 asserts analytical_pattern is non-null string. Null fails -> HALT. Precondition and workflow aligned. PASS. |
| C5 | Raw question empty | C | PASS | Step 0 | raw_question="". Precondition checks len(raw_question.strip()) > 0. Empty fails -> HALT. However, Step 0 workflow does not explicitly mention this check in its numbered steps (it focuses on upstream artifact validation). The precondition table documents it, and Step 0 is the natural enforcement point. The check is implied but could be more explicit in the workflow text. Minor observation, but precondition correctly HALTs. PASS. |
| D1 | Empty input | D | PASS | Step 0 | Duplicate of C5. raw_question empty -> HALT. Edge case table confirms: HALT -- return error requesting a business question. Consistent. PASS. |
| D2 | Single record (one field extractable) | D | PASS | Steps 1-6 | Input: "Retention" with intent_classification (lifecycle_stage=high_engaged, analytical_pattern=profile). Only metric extractable ("retention"). Step 1: population could be inferred from lifecycle_stage (high_engaged) -- spec says "use lifecycle_stage from intent classification as primary population signal." So population IS extractable. Step 2: metric = retention. Steps 3-5: all null or empty. Step 6: fields_populated=2, fields_null=4, extraction_completeness=partial. Edge case says PASS with remaining fields null. Downstream handles disambiguation. PASS. |
| D3 | All-null dimension (no fields extractable) | D | PASS | Steps 1-6 | Input: "Help me understand things" with intent_classification (lifecycle_stage=low_engaged, analytical_pattern=profile). Step 1: population could still be anchored to lifecycle_stage (low_engaged) from upstream -- spec says use lifecycle_stage as primary population signal. So even with vague input, population may be partially populated. Steps 2-5: all null. Step 6: fields_populated=1, fields_null=5 or fields_populated=0, fields_null=6. Edge case says WARN -- produce artifact with all fields null. But population anchoring from upstream means true all-null is unlikely unless the lifecycle_stage anchoring is excluded. Edge case response is still correct: produce the artifact, downstream generates full disambiguation. PASS. |
| D4 | Schema mismatch | D | PASS | Step 0 | Duplicate of C2. intent_classification.json has wrong schema_version -> HALT. Consistent. PASS. |
| D5 | Contradictory fields | D | PASS | Step 6 | Input: "What was the retention rate of acquisition prospects from March 2025 to January 2025?" with intent_classification (lifecycle_stage=acquisition). Step 3: timeframe start=2025-03-01, end=2025-01-31 -- end before start. Step 6 contradiction check catches this. Edge case says WARN -- log in extraction_metadata.contradictions, keep both values. Spec Step 6 workflow explicitly describes this check: "Timeframe end before start... log contradictions in extraction_metadata and flag for user resolution. Do not suppress the conflicting data." PASS. |
| D6 | Ambiguous metric | D | PASS | Step 2 | Input: "What is the retention rate and average order value for reactivated customers?" -- two metrics. Edge case says WARN: extract first mentioned as primary, list alternatives in extraction_metadata. Step 2 would extract "retention rate" as primary metric. The spec does not have explicit workflow guidance in Step 2 for multi-metric handling (Step 2 says "Parse for measurement language" without addressing multiplicity), but the edge case table provides the resolution. Adequate. PASS. |
| D7 | Loop with conflicting update | D | FAIL | Step 6 | Fixture: existing partial_scope has population="high-engaged customers". User says in conversation_context: "Actually, I meant medium-engaged customers." Step 6 merge should overwrite population with user's latest input. Edge case says WARN -- overwrite with user's latest, log override in contradictions. This is correct behavior. However, the same merge ambiguity from B7 applies: how does the skill distinguish "user explicitly provided population in latest turn" from "population re-extracted from original raw_question"? If the original raw_question still says "high-engaged" and the conversation_context says "medium-engaged", the skill needs to prioritize conversation_context for fields the user is correcting. The workflow does not define this precedence mechanism. FAIL -- same root cause as B7: merge precedence between raw_question re-extraction and conversation_context correction is undefined. |
| D8 | Implicit timeframe | D | PASS | Step 3 | Input: "What's the current retention rate for reactivated customers?" -- "current" implies recency but no explicit dates. Edge case says PASS: set timeframe.start=null, timeframe.granularity=null, add note in description, let completeness-validation prompt for specifics. Step 3 workflow lists "relative periods" as a category including implicit references. The edge case correctly routes to partial timeframe with a note. PASS. |

## Terminal Artifact Validation

Validated against all non-HALT test cases (A1, A2, B1-B7, D2, D3, D5, D6, D7, D8):

| Field | Present | Correct Type | Notes |
|---|---|---|---|
| `schema_version` | Yes | string "1.0" | Defined in spec |
| `skill_name` | Yes | string "scope-extraction" | Defined in spec |
| `timestamp` | Yes | string ISO-8601 UTC | Defined in spec |
| `record_count` | Yes | integer, always 1 | Defined in spec |
| `artifact_id` | Yes | string UUID v4 | Defined in spec |

All 5 universal envelope fields present and correctly typed.

Additional artifact structure validated:
- 6 scope fields present as keys (population, metric, timeframe, comparison, business_context, constraints): PASS
- `extraction_metadata` object with fields_populated, fields_null, extraction_completeness, loop_iteration, contradictions, source_artifact_id: PASS
- fields_populated + fields_null == 6: PASS (verified in A1: 5+1=6, A2: 1+5=6)
- Provenance linked via source_artifact_id: PASS
- No silent nulls (missing keys): PASS -- spec explicitly requires every null to be an explicit null, not a missing key

## Coverage Assessment

### Variance Dimensions Covered
| Dimension | Values Tested | Coverage |
|---|---|---|
| `extraction_completeness` | full (B1), partial (B2/A2) | 2/2 = 100% |
| `analytical_pattern` | profile (A1/A2), compare (B3), predict (B4), explain (B5), segment (B6) | 5/5 = 100% |
| `loop_iteration` | initial (A1/A2), subsequent (B7) | 2/2 = 100% |

### Precondition Coverage
| Precondition | Tested | Result |
|---|---|---|
| Intent classification exists | C1 | PASS |
| Schema version matches | C2 | PASS |
| Lifecycle stage present | C3 | PASS |
| Analytical pattern present | C4 | PASS |
| Raw question non-empty | C5 | PASS |

All 5 preconditions have corresponding HALT checks in the Step 0 workflow. This is well-designed -- no gaps between precondition table and workflow enforcement.

### Edge Case Coverage
All 8 edge cases tested. 7 PASS, 1 FAIL (D7 -- same root cause as B7).

## Blueprint Compliance

| Principle | Status | Evidence |
|---|---|---|
| Variance surface fully enumerated | PASS | 3 dimensions, all values listed with behavioral differences |
| Step 0 validates upstream artifact | PASS | Explicit schema_version, lifecycle_stage, and analytical_pattern assertions with HALT on failure |
| Preconditions all enforced in Step 0 | PASS | All 5 preconditions have corresponding checks in Step 0 workflow (note: raw_question check is implied but should be more explicit) |
| Terminal artifact has 5 envelope fields | PASS | All present with correct types in artifact template |
| Edge cases have detection + response | PASS | All 8 edge cases have both columns populated |
| Postconditions verifiable | PASS | 6 postconditions, all mechanically checkable |
| Quality bar items testable | PASS | 6 quality bar items, all specific and measurable |
| Scope boundary defined | PASS | Clear out-of-scope table with responsible skill references |
| No external dependencies | PASS | Tier 1 only, CPU-only, no APIs |
| Loop mode documented | PASS | supports_loop=true with initial/subsequent variance and merge semantics (though merge has gaps) |
| Provenance linking | PASS | source_artifact_id links to upstream intent_classification artifact_id |

## Pre-Merge Readiness Verdict

**CONDITIONAL**

The skill is well-structured with excellent precondition coverage (all 5 checked in Step 0), clean variance surface, and solid terminal artifact design. The single issue -- merge semantics in loop mode -- is real but scoped to the subsequent iteration path only. Initial invocation path is clean.

## Required Fixes

### 1. FAIL -- Merge precedence in loop mode is under-specified (B7, D7)
**What failed:** When `loop_iteration == subsequent`, the skill re-runs Steps 1-5 on ALL input (raw_question + conversation_context), then Step 6 says "only overwrite fields the user explicitly provided in the latest conversation turn." But there is no mechanism to distinguish which extracted values came from the user's latest conversation_context vs. re-extraction from the original raw_question.
**Why it matters:** Without clear precedence rules, implementers may accidentally overwrite user-corrected values with stale raw_question extractions, or vice versa. This is especially problematic in the D7 scenario where the user is explicitly correcting a prior extraction.
**Fix needed:** Add a sub-step to Step 6 (or a new Step 5.5) for subsequent iterations:
1. Run extraction on conversation_context ONLY to identify new/corrected fields.
2. Tag these as "user-provided" fields.
3. Run extraction on raw_question for any fields still null (not previously populated and not user-provided).
4. Merge rule: user-provided fields always win; existing partial_scope fields are preserved unless explicitly overridden; raw_question re-extraction only fills remaining nulls.

Alternatively, modify Step 0 to set a `merge_source_priority` flag: `conversation_context > existing_partial_scope > raw_question_re_extraction`.

### 2. Minor -- Step 0 raw_question check could be more explicit
**What it is:** The raw_question non-empty precondition is in the precondition table but Step 0's numbered workflow steps focus on upstream artifact validation. Adding an explicit sub-step "Assert raw_question is non-empty; on failure: HALT" would align the workflow text with the precondition table.
**Severity:** Low -- the precondition table is authoritative and implementers would check it. But consistency between precondition table and workflow steps improves clarity.

## Tests Still Needed

1. **Merge conflict resolution test:** subsequent iteration where raw_question extraction yields a DIFFERENT value than conversation_context for the SAME field -- validates the precedence fix once implemented.
2. **Loop iteration counter test:** Verify that `extraction_metadata.loop_iteration` increments correctly across 3+ iterations.
3. **Pattern-specific field naming consistency:** The spec puts predict/explain/segment sub-fields under `comparison` (e.g., `comparison.prediction_horizon`). But for a profile pattern, comparison is null. If the pattern changes between iterations (unlikely but possible if intent is reclassified), the comparison field structure would be inconsistent.
4. **Constraint parsing edge case:** Constraints with complex boolean logic ("exclude test accounts AND include only domestic OR HIPAA-compliant") -- how are these structured in the criteria array?
5. **Population criteria structure validation:** Quality bar says "Population criteria must be structured as operator-based filters, not free text." Test a question where the population description resists structured decomposition (e.g., "customers who seem unhappy").
6. **Large conversation_context:** subsequent iteration with 20+ prior turns of conversation -- does the skill handle gracefully or does context length degrade extraction quality?
