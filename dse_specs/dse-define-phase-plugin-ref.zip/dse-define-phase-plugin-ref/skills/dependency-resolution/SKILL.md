---
name: dependency-resolution
description: >
  Organizes task nodes into a dependency-aware execution order with fan-out points,
  join semantics, and parallelism annotations. Identifies data flow dependencies between
  tasks and validates the DAG has no circular dependencies or orphan nodes. Activate after
  task-decomposition produces task_node_list.json. Takes task_node_list; produces
  ordered_task_plan with execution stages.
inputs:
  - type: task_node_list
    description: "Array of atomic task nodes from task-decomposition with task_id, task_type, input_requirements, and output_type"
outputs:
  - type: ordered_task_plan
    description: "Dependency graph with execution stages, fan-out/join annotations, and parallelism markers"
can_follow: [task-decomposition]
can_precede: [budget-allocation]
supports_loop: false
exit_conditions:
  - "ordered_task_plan produced with all tasks assigned to execution stages"
  - "no circular dependencies detected"
  - "no orphan tasks (every task appears in exactly one stage)"
---

## Overview

Task-decomposition produces *what work needs to happen*. Dependency-resolution
determines *in what order*. This skill reads the task_node_list, identifies which
tasks produce outputs that other tasks consume, groups tasks into execution stages,
and annotates fan-out points (where work can parallelize) and join points (where
parallel branches reconverge). The output is a directed acyclic graph (DAG)
serialized as ordered execution stages. Without this skill, the pipeline cannot
determine safe parallelism or enforce data availability before a task runs.
Budget-allocation consumes the ordered_task_plan to add iteration constraints.

---

## When to Activate

- task_node_list.json exists in the working directory with a valid artifact_id
- Plan Agent pipeline has completed task-decomposition and no ordered_task_plan.json exists
- task_node_list.json has been regenerated since the last ordered_task_plan.json timestamp
- A prior ordered_task_plan.json was rejected and task_node_list.json is unchanged
- The Plan Agent receives an `order` or `resolve-dependencies` command referencing a valid task_node_list
- task_node_list.json contains >= 2 task nodes (single-task lists produce a trivial plan)

---

## Preconditions

What must be true before this skill begins:

- [ ] `task_node_list.json` exists and `schema_version == "1.0"`
- [ ] `task_node_list.json` contains `task_nodes` array with >= 1 entry
- [ ] Every task node has `task_id`, `task_type`, `input_requirements`, and `output_type`
- [ ] `task_node_list.json` contains a valid `artifact_id`
- [ ] `decomposition_metadata.template_used` is present (provides pattern context)

Each precondition has a corresponding HALT condition in Step 0.

---

## Prerequisites

### Library Dependencies

```
python>=3.10
# Skill-specific: json, uuid, datetime, collections (all stdlib)
```

No external library dependencies. CPU-only, minimal memory.

### Infrastructure Requirements

- **Compute:** CPU-only
- **Memory:** < 256 MB (graph construction on metadata only)
- **Disk:** < 1 MB scratch (JSON artifacts only)
- **OS packages:** None
- **Environment:** Any Python 3.10+ runtime

### Upstream Artifacts

- `task_node_list.json`: produced by `task-decomposition` -- required fields: `schema_version`, `artifact_id`, `task_nodes` (array), each node with `task_id`, `task_type`, `input_requirements`, `output_type`

---

## Variance Surface

| Dimension | Values | How behavior differs |
|---|---|---|
| `graph_shape` | `linear` / `fan_out` / `fan_out_join` | `linear`: all tasks form a single sequential chain, no parallelism; `fan_out`: one source task feeds multiple downstream tasks that do not reconverge; `fan_out_join`: parallel branches reconverge at a join task that consumes outputs from all branches |
| `has_parallel_stages` | `true` / `false` | `true`: >= 1 execution stage contains multiple tasks that can run simultaneously, max_parallelism > 1; `false`: every stage has exactly 1 task, plan is fully sequential |

---

## Workflow

### Step 0 -- Context Classification and Upstream Validation

**Context Classification:** Classify variance dimensions from task_node_list.

```
load task_node_list.json

# Preliminary scan for graph shape (refined in Steps 2-3)
output_types = collect output_type from all task nodes
input_reqs = collect input_requirements from all task nodes
shared_outputs = output_types that appear in multiple tasks' input_requirements

classify graph_shape (preliminary):
  IF no shared_outputs feed multiple consumers -> "linear"
  IF shared_outputs feed multiple consumers but no task consumes from multiple branches -> "fan_out"
  IF shared_outputs feed multiple consumers AND a task consumes from multiple branches -> "fan_out_join"

log: "Running dependency-resolution | graph_shape={value} | task_count={N}"
```

**Upstream Validation:**

```
assert task_node_list.schema_version == "1.0"
  HALT: "Schema version mismatch: expected 1.0, got {value}."
assert task_node_list.task_nodes is array with length >= 1
  HALT: "task_nodes is empty. Nothing to order."
assert task_node_list.artifact_id is present
  HALT: "task_node_list missing artifact_id. Cannot establish provenance chain."

FOR each task_node in task_nodes:
  assert task_node.task_id is present and matches TN-NNN pattern
    HALT: "Task node missing or malformed task_id: {value}."
  assert task_node.task_type is present
    HALT: "Task node {task_id} missing task_type."
  assert task_node.input_requirements is array
    HALT: "Task node {task_id} missing input_requirements."
  assert task_node.output_type is present
    HALT: "Task node {task_id} missing output_type."

assert no duplicate task_ids
  HALT: "Duplicate task_id found: {value}."
```

**Checkpoint:**
> - [ ] PASS: All upstream assertions pass, graph_shape classified
> - [ ] HALT: Any assertion failure -- stop with exact message

---

### Step 1 -- Identify Data Flow Dependencies

**Goal:** Build an adjacency list of task-to-task dependencies based on input/output type matching.

**Pre-step assertion:** All task nodes validated with input_requirements and output_type.

**Actions:**

```
adjacency = {}  # task_id -> list of upstream task_ids
edges = []      # list of {from, to, data_type} records

FOR each task_node T in task_nodes:
  adjacency[T.task_id] = []
  FOR each required_type in T.input_requirements:
    # Find upstream tasks that produce this type
    producers = [U for U in task_nodes
                 if U.output_type == required_type
                 and U.task_id != T.task_id]
    IF len(producers) == 0 AND required_type not in ["connection_config", "scope_artifact"]:
      WARN: "Task {T.task_id} requires {required_type} but no upstream task produces it."
    FOR each producer U in producers:
      adjacency[T.task_id].append(U.task_id)
      edges.append({from: U.task_id, to: T.task_id, data_type: required_type, edge_type: "data_flow"})

# Identify root tasks (no upstream dependencies within the task list)
root_tasks = [T.task_id for T in task_nodes if len(adjacency[T.task_id]) == 0]
```

> **At ambiguous matching (multiple producers for same type):** Use task_id ordering
> as tiebreaker -- earlier task in sequence is preferred upstream. Log ambiguity.

**Checkpoint:**
> - [ ] Assert: adjacency list covers all task_ids
> - [ ] Assert: at least one root task exists (else graph has no entry point)
> - [ ] PASS: Dependency edges identified
> - [ ] HALT: Zero root tasks -- "All tasks have upstream dependencies. Possible cycle or missing root."
> - [ ] WARN: Any task with unresolved input_requirements -- log details

---

### Step 2 -- Identify Fan-Out Points

**Goal:** Detect tasks whose output feeds multiple downstream tasks (parallelism opportunities).

**Pre-step assertion:** adjacency list and edges are populated.

**Actions:**

```
fan_out_points = []

FOR each task_node S in task_nodes:
  downstream = [edge.to for edge in edges if edge.from == S.task_id]
  IF len(downstream) >= 2:
    fan_out_points.append({
      source_task: S.task_id,
      branches: downstream,
      data_type: S.output_type
    })
    log: "Fan-out detected: {S.task_id} -> {downstream}"
```

**Checkpoint:**
> - [ ] PASS: Fan-out points identified (may be zero for linear graphs)

---

### Step 3 -- Identify Join Points

**Goal:** Detect tasks that consume outputs from multiple upstream branches (reconvergence).

**Pre-step assertion:** adjacency list is populated.

**Actions:**

```
FOR each fan_out in fan_out_points:
  # Find tasks downstream of ALL branches
  branch_descendants = {}
  FOR each branch_task in fan_out.branches:
    branch_descendants[branch_task] = get_all_descendants(branch_task, edges)

  # A join task appears in descendants of >= 2 branches
  # OR has input_requirements from >= 2 branch outputs
  candidate_joins = intersection of branch_descendants values
  IF len(candidate_joins) >= 1:
    join_task = earliest candidate by topological position
    fan_out.join_task = join_task
    fan_out.group_id = generate_group_id(fan_out.source_task, fan_out.branches)
    log: "Join detected: branches {fan_out.branches} -> {join_task}"
  ELSE:
    fan_out.join_task = null  # fan-out without reconvergence

# Refine graph_shape classification
IF len(fan_out_points) == 0:
  graph_shape = "linear"
ELIF any fan_out has join_task != null:
  graph_shape = "fan_out_join"
ELSE:
  graph_shape = "fan_out"
```

**Checkpoint:**
> - [ ] PASS: Join points identified and linked to fan-out groups
> - [ ] WARN: Fan-out without join -- "Branches {ids} never reconverge. Verify this is intentional."

---

### Step 4 -- Build Execution Order

**Goal:** Topological sort of task nodes into sequential execution stages; tasks within a stage can run in parallel.

**Pre-step assertion:** adjacency list complete, fan-out/join points identified.

**Actions:**

```
# Kahn's algorithm for topological sort into stages
in_degree = {T.task_id: len(adjacency[T.task_id]) for T in task_nodes}
stages = []
remaining = set of all task_ids

WHILE remaining is not empty:
  # Tasks with no unresolved upstream dependencies form the next stage
  ready = [tid for tid in remaining if in_degree[tid] == 0]

  IF len(ready) == 0 AND len(remaining) > 0:
    HALT: "Circular dependency detected among tasks: {remaining}. Cannot build DAG."

  stage_num = len(stages) + 1
  parallel = len(ready) > 1
  # Compute entry_conditions per task from upstream edges
  stage_tasks = []
  FOR each tid in sorted(ready):
    conds = []
    FOR each edge in edges where edge.to == tid:
      conds.append({type: "finding_gate" if edge.edge_type == "finding_gate" else "data_ready", artifact: edge.data_type})
      conds.append({type: "task_complete", task_id: edge.from})
    stage_tasks.append({task_id: tid, entry_conditions: conds})
  stages.append({stage: stage_num, tasks: [t.task_id for t in stage_tasks],
    task_details: stage_tasks, parallel: parallel})

  # Remove completed tasks and update in-degrees
  FOR each completed_tid in ready:
    remaining.remove(completed_tid)
    FOR each downstream edge where edge.from == completed_tid:
      in_degree[edge.to] -= 1

has_parallel_stages = any(stage.parallel for stage in stages)
max_parallelism = max(len(stage.tasks) for stage in stages)
```

**Checkpoint:**
> - [ ] Assert: Every task_id appears in exactly one stage
> - [ ] Assert: No tasks remain in the `remaining` set
> - [ ] PASS: Topological sort complete with {len(stages)} stages
> - [ ] HALT: Circular dependency detected -- list involved task_ids

---

### Step 5 -- Validate DAG

**Goal:** Final integrity checks on the execution graph before writing.

**Pre-step assertion:** stages array populated, all tasks assigned.

**Actions:**

```
# Check 1: No circular dependencies (already enforced in Step 4)
has_cycles = false  # Would have HALTed in Step 4

# Check 2: No orphan tasks
all_staged_tasks = flatten(stage.tasks for stage in stages)
all_task_ids = [T.task_id for T in task_nodes]
orphan_tasks = set(all_task_ids) - set(all_staged_tasks)
IF len(orphan_tasks) > 0:
  WARN: "Orphan tasks detected: {orphan_tasks}. Adding to final stage."
  stages[-1].tasks.extend(orphan_tasks)

# Check 3: Data flow completeness
FOR each edge in edges:
  from_stage = stage containing edge.from
  to_stage = stage containing edge.to
  assert from_stage < to_stage
    HALT: "Data flow violation: {edge.from} (stage {from_stage}) must precede {edge.to} (stage {to_stage})."

# Check 4: Classify finding_gate edges; verify all edges have valid edge_type
FOR each edge in edges:
  IF edge.data_type contains "finding" or "hypothesis": edge.edge_type = "finding_gate"
  assert edge.edge_type in ["data_flow", "finding_gate", "sequence"]
    HALT: "Edge {edge.from}->{edge.to} missing valid edge_type."

# Check 5: Critical path length
critical_path_length = len(stages)
```

**Checkpoint:**
> - [ ] Assert: orphan_tasks is empty (or resolved with WARN)
> - [ ] Assert: all data flows respect stage ordering; all edges have valid edge_type
> - [ ] PASS: DAG validation complete
> - [ ] HALT: Data flow violation, invalid edge_type, or unresolvable cycle

---

### Step 6 -- Write Terminal Artifact

**Goal:** Serialize the validated DAG as ordered_task_plan.json.

**Pre-step assertion:** DAG validated, all checks passed.

**Actions:**

```
generate artifact_id (uuid v4)
write ordered_task_plan.json with:
  - execution_order: stages array
  - dependencies: edges array
  - fan_out_points: annotated fan-out/join groups
  - dag_metadata: summary statistics
```

**Checkpoint:**
> - [ ] Assert: ordered_task_plan.json is valid JSON
> - [ ] Assert: record_count matches total task count
> - [ ] PASS: Artifact written successfully
> - [ ] HALT: Write failure -- "{exact error}"

---

## Terminal Artifact

**File:** `ordered_task_plan.json`

```json
{
  "schema_version": "1.0",
  "skill_name": "dependency-resolution",
  "timestamp": "{ISO-8601 UTC}",
  "record_count": 9,
  "artifact_id": "{uuid}",
  "source_task_node_list_id": "{uuid}",
  "execution_order": [
    {"stage": 1, "tasks": ["TN-001"], "parallel": false,
     "task_details": [{"task_id": "TN-001", "entry_conditions": []}]},
    {"stage": 2, "tasks": ["TN-002", "TN-003"], "parallel": true,
     "task_details": [
       {"task_id": "TN-002", "entry_conditions": [
         {"type": "data_ready", "artifact": "raw_dataset"}, {"type": "task_complete", "task_id": "TN-001"}]},
       {"task_id": "TN-003", "entry_conditions": [
         {"type": "data_ready", "artifact": "raw_dataset"}, {"type": "task_complete", "task_id": "TN-001"}]}]},
    {"stage": 3, "tasks": ["TN-004", "TN-005"], "parallel": true},
    {"stage": 4, "tasks": ["TN-006"], "parallel": false},
    {"stage": 5, "tasks": ["TN-007"], "parallel": false},
    {"stage": 6, "tasks": ["TN-008"], "parallel": false},
    {"stage": 7, "tasks": ["TN-009"], "parallel": false}
  ],
  "dependencies": [
    {"from": "TN-001", "to": "TN-002", "data_type": "raw_dataset", "edge_type": "data_flow"},
    {"from": "TN-001", "to": "TN-003", "data_type": "raw_dataset", "edge_type": "data_flow"},
    {"from": "TN-002", "to": "TN-006", "data_type": "cohort_dataset", "edge_type": "data_flow"},
    {"from": "TN-003", "to": "TN-006", "data_type": "cohort_dataset", "edge_type": "data_flow"}
  ],
  "fan_out_points": [
    {
      "group_id": "comparison_populations",
      "source_task": "TN-001",
      "branches": ["TN-002", "TN-003"],
      "join_task": "TN-006"
    }
  ],
  "dag_metadata": {
    "total_stages": 7,
    "max_parallelism": 2,
    "critical_path_length": 7,
    "has_cycles": false,
    "has_parallel_stages": true,
    "graph_shape": "fan_out_join",
    "orphan_tasks": []
  }
}
```

---

## Edge Cases

| Edge Case | Detection | Action |
|---|---|---|
| Empty input | task_nodes array is empty | HALT: "task_nodes is empty. Nothing to order." |
| Single record | task_nodes has exactly 1 entry | WARN: "Single task -- trivial plan with 1 stage." Produce single-stage plan. |
| All-null dimension | task nodes missing output_type universally | HALT: "No task nodes have output_type. Cannot resolve data flow dependencies." |
| Schema mismatch | schema_version != "1.0" | HALT: "Upstream schema_version mismatch: expected 1.0, got {value}." |
| Circular dependency | Kahn's algorithm leaves remaining tasks after all zero-degree nodes processed | HALT: "Circular dependency among tasks: {remaining_ids}. DAG cannot be constructed." |
| Orphan task | Task not reachable from any root and has no downstream consumers | WARN: "Orphan task {task_id} has no dependencies. Appending to final stage." |
| Ambiguous data flow | Multiple tasks produce the same output_type consumed by one task | WARN: "Ambiguous producers for {data_type}: {producer_ids}. Using task_id order as tiebreaker." |
| All tasks independent | No data flow edges between any tasks | WARN: "No dependencies found -- all tasks in a single parallel stage." Produce 1-stage plan with parallel=true. |

---

## Postconditions

After successful completion, this skill guarantees:

- [ ] `ordered_task_plan.json` exists and is valid JSON
- [ ] Every task_id from task_node_list appears in exactly one execution stage
- [ ] No circular dependencies exist (has_cycles == false)
- [ ] All data flow edges respect stage ordering (producer stage < consumer stage)
- [ ] Fan-out and join points are annotated with group_ids
- [ ] Every dependency edge has an edge_type classification
- [ ] Terminal artifact contains all 5 universal envelope fields
- [ ] source_task_node_list_id traces back to the source task_node_list

---

## Quality Bar

This skill run is "done" when ALL of the following are true:

- [ ] All Step 0 upstream assertions passed
- [ ] Every task from task_node_list is assigned to exactly one execution stage
- [ ] Topological sort completed without detecting cycles
- [ ] All data flow edges validated (producer precedes consumer in stage order)
- [ ] Fan-out points detected and annotated with branches and join tasks
- [ ] dag_metadata accurately reflects graph statistics
- [ ] Terminal artifact validates: schema_version, skill_name, timestamp, record_count, artifact_id present
- [ ] ordered_task_plan.json is consumable by budget-allocation (execution_order, dependencies present)

---

## Scope Boundary

This skill does NOT:

- Decompose scope into task nodes -> handled by `task-decomposition`
- Allocate iteration budgets or resource constraints -> handled by `budget-allocation`
- Format the plan for human approval -> handled by `plan-formatting`
- Execute any tasks in the plan -> handled by Analyze Phase skills
- Modify task node definitions (task_type, skill_ref, description) -> immutable from task-decomposition
- Resolve skill gaps or assign novel tasks to skills -> handled by human review

---

## Downstream

Run after this skill completes:

1. **`budget-allocation`** -- Consumes `ordered_task_plan.json` to add iteration budgets and resource constraints. Reads `execution_order` for stage structure, `dag_metadata.critical_path_length` for budget distribution, and `fan_out_points` to allocate parallel resource pools.
