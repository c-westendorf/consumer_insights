# DSE Plugin Hooks

Hooks are event-driven automations that fire before or after Claude Code tool executions. They enforce governance, catch mistakes, and automate compliance checks for the DSE Define Phase plugin.

## How Hooks Work

```
User request -> Claude picks a tool -> PreToolUse hook runs -> Tool executes -> PostToolUse hook runs
                                                                                         |
                                                                              Claude responds -> Stop hook runs
```

- **PreToolUse** hooks run before the tool executes. They can **block** (exit code 2) or **warn** (stderr without blocking).
- **PostToolUse** hooks run after the tool completes. They can warn but cannot block.
- **Stop** hooks run after each Claude response. They can inject context for the next turn.

## Hooks in This Plugin

### PreToolUse Hooks

| Hook | Matcher | Behavior | Exit Code |
|------|---------|----------|-----------|
| **Artifact guard** | `Write\|Edit` | Blocks overwriting `*_artifact.json` files that contain `approved_at` (immutable after approval) | 2 (blocks) |
| **SQL interceptor** | `Bash` | Logs all commands to `audit/query_log.jsonl`. Blocks destructive DDL/DML: DROP, DELETE, TRUNCATE, ALTER TABLE, INSERT INTO, UPDATE SET, CREATE TABLE | 2 (blocks destructive) / 0 (logs and allows) |
| **Decision log gate** | `Agent` | Blocks plan-agent activation unless `decision_log.json` exists with at least one decision entry | 2 (blocks) |
| **Strategic compact** | `Edit\|Write` | Tracks tool call count per session. Suggests `/compact` every ~40 tool calls to prevent context overflow | 0 (warns only) |

### PostToolUse Hooks

| Hook | Matcher | Behavior |
|------|---------|----------|
| **Artifact schema validator** | `Write` | After writing `scope_artifact.json`, `plan_artifact.json`, or `decision_log.json`, validates against the corresponding JSON schema in `schemas/`. Warns on validation failure and logs to `audit/validation_log.jsonl` |

### Stop Hooks

| Hook | Matcher | Behavior |
|------|---------|----------|
| **Decision reminder** | `*` (all) | During active scoping sessions (`scope_session.json` exists with status `disambiguating`), checks if any decisions have been logged. If not, injects a reminder into Claude's context to present options and log decisions |

## Script Details

All hook scripts live in `hooks/scripts/` and follow the same pattern:

1. Read JSON from stdin (`INPUT=$(cat)`)
2. Parse with `jq` (e.g., `echo "$INPUT" | jq -r '.tool_input.file_path'`)
3. Perform checks
4. Exit 0 (allow) or exit 2 (block PreToolUse only)
5. Write block reasons to stderr, context injection to stdout

### Input Schema

Every hook receives JSON on stdin:

```json
{
  "session_id": "abc123",
  "cwd": "/Users/analyst/my-project",
  "hook_event_name": "PreToolUse",
  "tool_name": "Bash",
  "tool_input": {
    "command": "snowsql -q 'SELECT * FROM dim_customer LIMIT 10'"
  }
}
```

### Exit Codes

| Code | Meaning | When to Use |
|------|---------|-------------|
| `0` | Allow | Tool call proceeds. Stderr warnings are shown but don't block |
| `2` | Block | Tool call is cancelled. Stderr message is fed back to Claude as feedback |
| Other | Error | Tool call proceeds. A hook error notice appears in the transcript |

## Audit Trail

The SQL interceptor and schema validator write to the `audit/` directory in the project root:

- `audit/query_log.jsonl` — Every Bash command logged with timestamp
- `audit/validation_log.jsonl` — Schema validation failures

These files are append-only JSONL (one JSON object per line).

## Customizing Hooks

### Disabling a Hook

Override in your `~/.claude/settings.json` by providing an empty hooks array for the same matcher:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [],
        "description": "Override: disable SQL interception"
      }
    ]
  }
}
```

### Adding Project-Specific Hooks

Add to `.claude/settings.json` in your project root. Plugin hooks and project hooks both run — they don't replace each other.

## Dependencies

- `jq` — Required for JSON parsing in hook scripts. Install with `brew install jq` (macOS) or `apt-get install jq` (Linux)
- `python3` — Used for JSON encoding in sql-interceptor and decision log validation
- `jsonschema` (Python package, optional) — Enables full schema validation in artifact-schema-validator. Install with `pip install jsonschema`. Without it, only basic JSON parse checking is performed.
