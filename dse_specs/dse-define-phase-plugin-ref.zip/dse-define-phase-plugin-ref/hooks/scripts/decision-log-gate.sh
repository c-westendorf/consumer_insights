#!/bin/bash
# decision-log-gate.sh
# PreToolUse hook: Block plan-agent activation without decision log
#
# Fires before the Agent tool. Checks stdin to see if the agent
# being spawned is plan-agent. If so, verifies that decision_log.json
# exists in the project directory and contains at least one decision.
#
# Exit 0 = allow, Exit 2 = block

INPUT=$(cat)

# Extract the agent name from tool input
# The Agent tool input includes a "prompt" and potentially agent identification
TOOL_INPUT=$(echo "$INPUT" | jq -r '.tool_input // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // "."')

# Check if this is a plan-agent invocation by looking for plan-agent references
# in the tool input (subagent_type, prompt content, or description)
SUBAGENT_TYPE=$(echo "$INPUT" | jq -r '.tool_input.subagent_type // empty')
PROMPT_TEXT=$(echo "$INPUT" | jq -r '.tool_input.prompt // empty')
DESCRIPTION=$(echo "$INPUT" | jq -r '.tool_input.description // empty')

IS_PLAN_AGENT=false

if [[ "$SUBAGENT_TYPE" == *"plan"* ]] || [[ "$PROMPT_TEXT" == *"plan-agent"* ]] || [[ "$PROMPT_TEXT" == *"plan agent"* ]] || [[ "$DESCRIPTION" == *"plan"* ]]; then
  IS_PLAN_AGENT=true
fi

# If not a plan-agent invocation, allow
if [ "$IS_PLAN_AGENT" = false ]; then
  exit 0
fi

# Check for decision_log.json
DECISION_LOG="${CWD}/decision_log.json"

if [ ! -f "$DECISION_LOG" ]; then
  echo "BLOCKED: No decision_log.json found in the project directory." >&2
  echo "The scope agent must log analytical decisions before plan generation." >&2
  echo "Run /scope first and ensure decisions are documented at each fork point." >&2
  echo "Each decision must present at least 3 options with pros/cons." >&2
  exit 2
fi

# Check that the decision log has at least one entry
COUNT=$(python3 -c "
import json, sys
try:
    with open('$DECISION_LOG') as f:
        d = json.load(f)
    decisions = d.get('decisions', [])
    print(len(decisions))
except Exception as e:
    print(0, file=sys.stderr)
    print(0)
" 2>/dev/null || echo "0")

if [ "$COUNT" = "0" ]; then
  echo "BLOCKED: decision_log.json exists but contains 0 decisions." >&2
  echo "At least one analytical decision must be logged during scoping" >&2
  echo "before plan generation can begin." >&2
  exit 2
fi

exit 0
