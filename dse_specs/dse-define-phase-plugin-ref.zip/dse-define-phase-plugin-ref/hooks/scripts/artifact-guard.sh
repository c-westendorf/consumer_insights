#!/bin/bash
# artifact-guard.sh
# PreToolUse hook: Prevent overwriting approved artifacts
#
# Fires before Write or Edit on *_artifact.json files.
# Reads the target file path from stdin JSON, checks if the file
# already contains "approved_at" — if so, blocks the write.
#
# Exit 0 = allow, Exit 2 = block

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

# Only guard artifact files
if [[ "$FILE_PATH" != *_artifact.json ]]; then
  exit 0
fi

# If file doesn't exist yet, allow the write (first creation)
if [ ! -f "$FILE_PATH" ]; then
  exit 0
fi

# Check if the artifact has been approved (immutable)
if grep -q '"approved_at"' "$FILE_PATH" 2>/dev/null; then
  echo "BLOCKED: Cannot modify an approved artifact." >&2
  echo "$FILE_PATH contains 'approved_at' and is immutable." >&2
  echo "Once a scope or plan is approved, it cannot be changed." >&2
  echo "To create a new scope, delete the existing artifact first." >&2
  exit 2
fi

exit 0
