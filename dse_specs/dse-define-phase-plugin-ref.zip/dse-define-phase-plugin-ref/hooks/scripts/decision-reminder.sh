#!/bin/bash
# decision-reminder.sh
# Stop hook: Remind about decision logging after each response
#
# Fires after Claude finishes responding. If a scope_session.json
# exists (meaning we're in a scoping session) but decision_log.json
# is empty or missing, nudge the agent to log decisions.
#
# Non-blocking: exit 0 always. Injects context via stdout.

INPUT=$(cat)
CWD=$(echo "$INPUT" | jq -r '.cwd // "."')
STOP_HOOK_ACTIVE=$(echo "$INPUT" | jq -r '.stop_hook_active // false')

# Prevent infinite loops — if we already triggered a continuation, let Claude stop
if [ "$STOP_HOOK_ACTIVE" = "true" ]; then
  exit 0
fi

# Check if we're in a scoping session
SCOPE_SESSION="${CWD}/scope_session.json"
if [ ! -f "$SCOPE_SESSION" ]; then
  exit 0
fi

# Check session status — only remind during active scoping
STATUS=$(python3 -c "
import json
try:
    with open('$SCOPE_SESSION') as f:
        d = json.load(f)
    print(d.get('status', 'unknown'))
except:
    print('unknown')
" 2>/dev/null || echo "unknown")

# Only remind during disambiguation (the phase where decisions happen)
if [ "$STATUS" != "disambiguating" ] && [ "$STATUS" != "validating" ]; then
  exit 0
fi

# Check decision log
DECISION_LOG="${CWD}/decision_log.json"
DECISION_COUNT=0
if [ -f "$DECISION_LOG" ]; then
  DECISION_COUNT=$(python3 -c "
import json
try:
    with open('$DECISION_LOG') as f:
        d = json.load(f)
    print(len(d.get('decisions', [])))
except:
    print(0)
" 2>/dev/null || echo "0")
fi

# If in active scoping with no decisions logged, add context reminder
if [ "$DECISION_COUNT" = "0" ]; then
  echo "[DSE Reminder] You are in an active scoping session but have not logged any decisions yet. At each analytical fork point (metric selection, population boundaries, comparison design), present at least 3 options with pros/cons and log the user's choice to decision_log.json. The plan-agent requires at least one logged decision before it can activate."
fi

exit 0
