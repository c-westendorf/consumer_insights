#!/bin/bash
# sql-interceptor.sh
# PreToolUse hook: Log and gate-check all Bash commands
#
# Fires before every Bash tool call. Logs the command to
# audit/query_log.jsonl, then checks for destructive DDL/DML
# operations and blocks them. The DSE plugin operates in
# read-only mode against data sources.
#
# Exit 0 = allow, Exit 2 = block

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // "."')

# --- Audit logging ---
LOGDIR="${CWD}/audit"
mkdir -p "$LOGDIR" 2>/dev/null

# Encode the command as a JSON string safely
ENCODED_CMD=$(echo "$COMMAND" | python3 -c "import sys,json; print(json.dumps(sys.stdin.read()))" 2>/dev/null || echo "\"[encoding error]\"")

echo "{\"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\", \"tool\": \"Bash\", \"command\": ${ENCODED_CMD}}" >> "$LOGDIR/query_log.jsonl"

# --- Destructive SQL detection ---
UPPER=$(echo "$COMMAND" | tr '[:lower:]' '[:upper:]')

BLOCKED_PATTERNS=(
  "DROP "
  "DELETE "
  "TRUNCATE "
  "ALTER TABLE"
  "INSERT INTO"
  "UPDATE .* SET"
  "CREATE TABLE"
  "CREATE OR REPLACE"
)

for PATTERN in "${BLOCKED_PATTERNS[@]}"; do
  if echo "$UPPER" | grep -qE "$PATTERN"; then
    echo "BLOCKED: Destructive SQL detected (matched: $PATTERN)." >&2
    echo "The DSE plugin operates in read-only mode against data sources." >&2
    echo "DDL/DML operations require manual execution outside the agent." >&2
    exit 2
  fi
done

exit 0
