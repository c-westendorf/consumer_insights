#!/bin/bash
# artifact-schema-validator.sh
# PostToolUse hook: Validate artifacts against JSON schemas after write
#
# Fires after Write completes on *_artifact.json or decision_log.json.
# Validates the written content against the corresponding JSON schema
# in the plugin's schemas/ directory.
#
# Non-blocking (PostToolUse cannot block), but warns via stderr
# and writes validation failures to audit log.

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')
CWD=$(echo "$INPUT" | jq -r '.cwd // "."')

# Only validate artifact and decision log files
case "$FILE_PATH" in
  *scope_artifact.json) SCHEMA_NAME="scope_artifact.schema.json" ;;
  *plan_artifact.json)  SCHEMA_NAME="plan_artifact.schema.json" ;;
  *decision_log.json)   SCHEMA_NAME="decision_log_artifact.schema.json" ;;
  *) exit 0 ;;
esac

# Locate schema file relative to plugin root
PLUGIN_ROOT="${CLAUDE_PLUGIN_ROOT:-$(dirname "$(dirname "$(dirname "$0")")")}"
SCHEMA_PATH="${PLUGIN_ROOT}/schemas/${SCHEMA_NAME}"

if [ ! -f "$SCHEMA_PATH" ]; then
  echo "[DSE Plugin] Warning: Schema not found at $SCHEMA_PATH" >&2
  echo "Cannot validate $FILE_PATH" >&2
  exit 0
fi

if [ ! -f "$FILE_PATH" ]; then
  exit 0
fi

# Validate using python jsonschema (best-effort)
VALIDATION_RESULT=$(python3 -c "
import json, sys
try:
    from jsonschema import validate, ValidationError, SchemaError
    with open('$FILE_PATH') as f:
        instance = json.load(f)
    with open('$SCHEMA_PATH') as f:
        schema = json.load(f)
    validate(instance=instance, schema=schema)
    print('VALID')
except ImportError:
    # jsonschema not installed — do basic JSON parse check only
    try:
        with open('$FILE_PATH') as f:
            json.load(f)
        print('VALID_JSON_ONLY')
    except json.JSONDecodeError as e:
        print(f'INVALID_JSON: {e}')
except ValidationError as e:
    print(f'SCHEMA_ERROR: {e.message}')
except SchemaError as e:
    print(f'BAD_SCHEMA: {e.message}')
except Exception as e:
    print(f'ERROR: {e}')
" 2>/dev/null || echo "SKIPPED")

case "$VALIDATION_RESULT" in
  VALID)
    # Silent success
    ;;
  VALID_JSON_ONLY)
    echo "[DSE Plugin] $FILE_PATH is valid JSON (install jsonschema for full validation)" >&2
    ;;
  SCHEMA_ERROR:*)
    echo "[DSE Plugin] SCHEMA VALIDATION FAILED for $FILE_PATH" >&2
    echo "${VALIDATION_RESULT#SCHEMA_ERROR: }" >&2
    echo "The artifact does not match ${SCHEMA_NAME}. Review and correct." >&2
    # Log validation failure to audit
    LOGDIR="${CWD}/audit"
    mkdir -p "$LOGDIR" 2>/dev/null
    echo "{\"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\", \"event\": \"schema_validation_failure\", \"file\": \"$FILE_PATH\", \"schema\": \"$SCHEMA_NAME\", \"error\": \"${VALIDATION_RESULT#SCHEMA_ERROR: }\"}" >> "$LOGDIR/validation_log.jsonl"
    ;;
  INVALID_JSON:*)
    echo "[DSE Plugin] INVALID JSON in $FILE_PATH" >&2
    echo "${VALIDATION_RESULT#INVALID_JSON: }" >&2
    ;;
  *)
    # Silently skip on errors
    ;;
esac

exit 0
