#!/bin/bash
# strategic-compact.sh
# PreToolUse hook: Suggest compaction at logical intervals
#
# DSE scoping sessions can run 10+ disambiguation turns.
# This hook tracks tool call count via a temp file and suggests
# /compact at logical breakpoints to prevent context overflow.
#
# Non-blocking: exit 0 always, warns via stderr.

INPUT=$(cat)
CWD=$(echo "$INPUT" | jq -r '.cwd // "."')

# Track tool call count per session
COUNTER_FILE="${CWD}/.dse_tool_count"
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // "unknown"')

# Initialize or read counter
if [ -f "$COUNTER_FILE" ]; then
  STORED_SESSION=$(head -1 "$COUNTER_FILE" 2>/dev/null)
  if [ "$STORED_SESSION" = "$SESSION_ID" ]; then
    COUNT=$(tail -1 "$COUNTER_FILE" 2>/dev/null || echo "0")
  else
    COUNT=0
  fi
else
  COUNT=0
fi

COUNT=$((COUNT + 1))

# Write updated counter
echo "$SESSION_ID" > "$COUNTER_FILE"
echo "$COUNT" >> "$COUNTER_FILE"

# Suggest compact at logical intervals (every 40 tool calls)
if [ $((COUNT % 40)) -eq 0 ] && [ "$COUNT" -gt 0 ]; then
  echo "[DSE Plugin] You have used $COUNT tool calls this session." >&2
  echo "Consider running /compact to free context space." >&2
  echo "This preserves your scope/plan progress while reclaiming memory." >&2
fi

exit 0
